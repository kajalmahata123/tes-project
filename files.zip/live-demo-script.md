# Live Demo Script: Claude for z/TPF Developers
## 30-Minute Hands-On Demonstration

---

## Pre-Demo Checklist (15 minutes before)

- [ ] Open claude.ai in browser (have it ready)
- [ ] Have this script open in another window
- [ ] Copy demo code examples to a text file (easy to paste)
- [ ] Test your internet connection
- [ ] Close unnecessary browser tabs
- [ ] Have backup slides ready (in case demo fails)
- [ ] Set up screen sharing if remote presentation

---

## Demo Structure (30 minutes total)

```
00:00 - 00:05  Introduction & Setup (5 min)
00:05 - 00:10  Demo 1: Code Review (5 min)
00:10 - 00:15  Demo 2: Bug Detection (5 min)
00:15 - 00:20  Demo 3: Code Explanation (5 min)
00:20 - 00:25  Demo 4: Quick Wins (5 min)
00:25 - 00:30  Q&A (5 min)
```

---

## INTRODUCTION (0:00 - 0:05)

### What You Say:

"Good morning everyone! Today I'm going to show you how Claude can help us with our daily z/TPF development work. This isn't about replacing anyone - it's about making our jobs easier and faster.

By the end of this demo, you'll see how Claude can:
- Review your code in seconds
- Find bugs before they reach production
- Explain that complex legacy code you've been avoiding
- Generate tests and documentation

Let me show you. I'll use real z/TPF code, and you'll see actual results in real-time. Feel free to interrupt with questions!"

### What You Do:
1. Share your screen
2. Open browser to claude.ai
3. Show the clean interface

### What You Say:
"This is Claude. Simple interface - just like texting. You can type questions or upload code files. That's it. No installation, no setup, no complicated configuration. Let's dive in."

---

## DEMO 1: CODE REVIEW (0:05 - 0:10)

### Setup:
"First, let's do something we all do - code review. I have a z/TPF entry point that processes passenger records. Let me paste it and ask Claude to review it."

### What You Type in Claude:

```
I'm working on z/TPF. Please review this entry point code for bugs, 
memory leaks, and TPF best practices violations:

#include <tpfdf.h>
#include <stdhdr.h>

#define PNR_FILE 0x01

struct pnr_record {
    char key[8];
    char passenger_name[64];
    short status;
};

void PNRPROC() {
    struct pnr_record *pnr;
    struct input_msg *msg;
    short rc;
    
    msg = (struct input_msg *)GETMSG();
    pnr = (struct pnr_record *)malloc(sizeof(struct pnr_record));
    
    memcpy(pnr->key, msg->record_key, 8);
    rc = tpfdf_lrec(PNR_FILE, pnr->key, pnr, LOCK_WRITE);
    
    if (rc != 0) {
        send_error(rc);
        return;
    }
    
    strcpy(pnr->passenger_name, msg->new_name);
    
    tpfdf_wrec(PNR_FILE, pnr->key, pnr);
    tpfdf_urec(PNR_FILE, pnr->key);
    
    EXITC();
}
```

### What You Say While Waiting:
"I'm pasting the code and asking for a review. Notice I mentioned z/TPF - this helps Claude understand the context. Let's see what it finds..."

### Expected Claude Response:
Claude will identify:
1. No null pointer check on GETMSG()
2. malloc without checking return value
3. No lock release on error path (lines after "if (rc != 0)")
4. strcpy buffer overflow risk
5. Memory leak - pnr never freed
6. No input validation

### What You Say:
"Wow, look at that! Claude found 5-6 issues in seconds. In a normal code review meeting, this would take 30-60 minutes. Let me highlight the important ones:

**Point to screen:**
- Memory leak here - we never free pnr
- Lock not released on error path - this causes production issues!
- Buffer overflow risk with strcpy

These are exactly the kinds of bugs that slip through and cause problems in production.

Let me ask a follow-up question..."

### Follow-up (Type this):
```
Show me the corrected version with all issues fixed
```

### What You Say:
"Notice how I can just ask for more detail. Claude remembers the conversation context. Let's see the fixed code..."

### Expected Response:
Claude shows corrected code with:
- Null checks
- malloc error handling
- Proper lock cleanup
- Safe string operations
- Memory freed

### What You Say:
"Perfect! In about 2 minutes, we got a complete code review and a corrected version. This is what would normally take an hour in a meeting plus another hour to fix. 

**Key takeaway: Use this before every code commit.**"

---

## DEMO 2: BUG DETECTION (0:10 - 0:15)

### Setup:
"Now let's look at a real debugging scenario. We have code that's causing deadlocks in production - intermittent, hard to reproduce. Watch this..."

### What You Type:

```
This z/TPF code is causing intermittent deadlocks in production. 
Can you identify the problem?

#include <tpfdf.h>

#define FLIGHT_FILE 0x02
#define INVENTORY_FILE 0x03

struct flight_rec {
    char flight_key[8];
    short available_seats;
};

struct inventory_rec {
    char inv_key[8];
    short booked_seats;
};

short book_seat(char *flight_key, char *inv_key) {
    struct flight_rec flt;
    struct inventory_rec inv;
    short rc;
    
    rc = tpfdf_lrec(FLIGHT_FILE, flight_key, &flt, LOCK_WRITE);
    if (rc != 0) return rc;
    
    rc = tpfdf_lrec(INVENTORY_FILE, inv_key, &inv, LOCK_WRITE);
    if (rc != 0) {
        tpfdf_urec(FLIGHT_FILE, flight_key);
        return rc;
    }
    
    if (flt.available_seats <= 0) {
        tpfdf_urec(INVENTORY_FILE, inv_key);
        tpfdf_urec(FLIGHT_FILE, flight_key);
        return ERR_NO_SEATS;
    }
    
    flt.available_seats--;
    inv.booked_seats++;
    
    tpfdf_wrec(FLIGHT_FILE, flight_key, &flt);
    tpfdf_wrec(INVENTORY_FILE, inv_key, &inv);
    
    tpfdf_urec(FLIGHT_FILE, flight_key);
    tpfdf_urec(INVENTORY_FILE, inv_key);
    
    return 0;
}
```

### Expected Claude Response:
Claude will identify:
- Deadlock risk from inconsistent lock ordering
- Transaction A locks FLIGHT then INVENTORY
- Transaction B might lock INVENTORY then FLIGHT
- Classic deadlock scenario
- Will suggest consistent lock ordering

### What You Say:
"Look at this! Claude immediately identified the deadlock issue. It's a lock ordering problem - classic deadlock scenario.

**Point to screen and explain:**
- Thread 1 locks FLIGHT first, then INVENTORY
- Thread 2 somewhere else locks INVENTORY first, then FLIGHT
- Result: Deadlock!

Claude even explains how to fix it - always lock in the same order throughout your system.

This kind of bug is SO hard to find manually. You need to:
1. Understand the code
2. Find all other places that lock these files
3. Compare the ordering
4. Reproduce the timing

That could take days! Claude found it in 10 seconds.

**Key takeaway: Use this when you have mysterious intermittent bugs.**"

---

## DEMO 3: CODE EXPLANATION (0:15 - 0:20)

### Setup:
"Now, let's say you just inherited a 500-line module that was written in 1998. No documentation. The developer retired. You need to modify it. Sound familiar?"

### What You Type:

```
I inherited this z/TPF code and need to understand it before I can 
modify it. Can you explain what it does?

[Upload a file OR paste a complex function]

Here's a transaction processing function:

void process_credit_transaction() {
    struct card_rec card;
    struct trans_rec trans;
    char card_key[16];
    char trans_id[32];
    short rc;
    long timestamp;
    
    // Get input message
    struct input_msg *msg = get_transaction_message();
    if (!msg) {
        log_error("No input message");
        return;
    }
    
    // Format card key
    format_card_key(msg->card_number, card_key);
    
    // Read card record with lock
    rc = tpfdf_lrec(CARD_FILE, card_key, &card, LOCK_WRITE);
    if (rc != 0) {
        log_error("Card read failed", rc);
        send_decline(msg, ERR_CARD_NOT_FOUND);
        return;
    }
    
    // Validate card status
    if (card.status != STATUS_ACTIVE) {
        tpfdf_urec(CARD_FILE, card_key);
        send_decline(msg, ERR_CARD_INACTIVE);
        return;
    }
    
    // Check credit limit
    if (card.balance + msg->amount > card.credit_limit) {
        tpfdf_urec(CARD_FILE, card_key);
        send_decline(msg, ERR_OVER_LIMIT);
        return;
    }
    
    // Update balance
    card.balance += msg->amount;
    card.last_trans_date = get_current_date();
    
    // Write updated card
    rc = tpfdf_wrec(CARD_FILE, card_key, &card);
    if (rc != 0) {
        log_error("Card write failed", rc);
        tpfdf_urec(CARD_FILE, card_key);
        send_decline(msg, ERR_SYSTEM_ERROR);
        return;
    }
    
    // Create transaction record
    generate_trans_id(trans_id);
    init_transaction_record(&trans, trans_id, msg);
    trans.card_number = msg->card_number;
    trans.amount = msg->amount;
    trans.timestamp = get_timestamp();
    
    // Write transaction
    rc = tpfdf_wrec(TRANS_FILE, trans_id, &trans);
    
    // Release card lock
    tpfdf_urec(CARD_FILE, card_key);
    
    if (rc == 0) {
        send_approval(msg, trans_id);
    } else {
        send_decline(msg, ERR_SYSTEM_ERROR);
    }
}
```

### Expected Claude Response:
Claude will provide:
- High-level summary
- Step-by-step flow
- Explanation of each section
- Data structures used
- Error handling approach
- TPF-specific patterns

### What You Say:
"Look at this breakdown! Claude just explained:
- What the function does (credit card transaction processing)
- The flow step-by-step
- Error handling patterns
- Where it uses TPFDF
- The locking strategy

**Point to different parts:**

This would normally take me hours or days to figure out, especially if it's 500 lines instead of 50. I'd have to:
1. Read through line by line
2. Draw diagrams
3. Ask the team (if anyone remembers)
4. Test it to see what happens

With Claude, I understand it in 2 minutes.

**Key takeaway: Use this when you need to understand legacy code fast.**"

---

## DEMO 4: QUICK WINS (0:20 - 0:25)

### Setup:
"Let me rapid-fire a few more things Claude can do. Watch how fast this is..."

### Quick Win 1: Generate Tests (30 seconds)

**Type:**
```
Generate unit tests for this function:
[paste a simple function]
```

**Say:** "Boom! Complete test suite in 10 seconds. Would take an hour manually."

---

### Quick Win 2: Documentation (30 seconds)

**Type:**
```
Create documentation for this code with usage examples:
[paste same function]
```

**Say:** "There's your documentation. API reference, examples, everything."

---

### Quick Win 3: Performance Question (30 seconds)

**Type:**
```
This function needs to run in under 50 microseconds but takes 80. 
What's the bottleneck? [paste code]
```

**Say:** "Claude analyzes performance and suggests optimizations. No profiler needed for quick analysis."

---

### Quick Win 4: Ask Anything (1 minute)

**Type:**
```
In z/TPF, what's the difference between tpfdf_lrec and tpfdf_read?
```

**Expected Response:**
Quick explanation of the difference with examples

**Say:** "You can just ask questions! No searching through documentation. It's like having a z/TPF expert sitting next to you 24/7.

Try asking:
- 'How do I properly handle SERRC errors?'
- 'What's the best way to optimize TPFDF reads?'
- 'Show me the standard pattern for ECB handling'

Any z/TPF question, any time."

---

### Quick Win 5: Let Audience Suggest (2 minutes)

**Say:** 
"Does anyone have a piece of code they're struggling with right now? Give me a scenario, and let's see if Claude can help."

**[Take 1-2 suggestions from audience and demonstrate live]**

This builds credibility and shows it works for their real problems.

---

## WRAP UP & Q&A (0:25 - 0:30)

### Summary (2 minutes)

**Say:**
"So in 25 minutes, we've seen Claude:
1. ✓ Review code and find 6 bugs in seconds
2. ✓ Identify a deadlock issue that would take days to find
3. ✓ Explain complex legacy code
4. ✓ Generate tests
5. ✓ Create documentation
6. ✓ Answer technical questions

**The bottom line:**
- 50-75% time savings on common tasks
- Catch bugs before code review
- Understand code faster
- Better code quality
- More time for actual development

**It's free to start. No installation. No setup.**

Just go to claude.ai and start pasting code."

---

### Getting Started (1 minute)

**Say:**
"How do you start TODAY?

Step 1: Go to claude.ai after this meeting
Step 2: Copy one function you're working on
Step 3: Paste it and ask: 'Review this z/TPF code for bugs'
Step 4: See what it finds

That's it. Start small. Use it once today. Then once tomorrow. In a week, you'll wonder how you worked without it.

I'm sharing:
- Quick reference card (print and keep at your desk)
- 10 ready-to-use commands (copy and paste)
- Full guide with examples
- Demo code samples

These will be in [shared folder/email/etc.]"

---

### Q&A (2 minutes)

**Common questions and answers:**

**Q: "Is our code safe? Does Claude store it?"**
A: "No, Claude doesn't train on your conversations. Your code stays private. There are enterprise options with even stronger controls if needed."

**Q: "Can it access our TPF system?"**
A: "No. Claude can't access any systems, can't run code, can't connect to anything. You paste code in, get advice out. That's it."

**Q: "What if it gives wrong answers?"**
A: "Good question! Always test suggestions before deploying. Claude is a tool to help you, not replace your judgment. If something seems off, ask 'why did you suggest that?' and Claude will explain the reasoning."

**Q: "Does it work offline?"**
A: "No, it's web-based. But you can use it from anywhere - office, home, traveling."

**Q: "How much does it cost?"**
A: "Free tier is available. Pro plans are $20/month per person. Enterprise options for larger teams. Most people start with free."

**Q: "What about [specific z/TPF feature]?"**
A: "Claude understands z/TPF concepts like TPFDF, ECBs, entry points, real-time constraints. Try asking it! If it doesn't know something, it will say so."

---

## POST-DEMO ACTIONS

### Immediately After Demo:
1. Share screen to show where to access materials
2. Send follow-up email with:
   - Link to claude.ai
   - Quick reference card (PDF)
   - Command library
   - Demo code examples
3. Offer to help anyone get started

### Follow-up (Week 1):
- Schedule optional office hours for questions
- Create team Slack/Teams channel for sharing Claude tips
- Collect success stories

### Follow-up (Week 2):
- Send survey: "Have you tried Claude yet?"
- Share success stories from early adopters
- Offer advanced workshop

---

## BACKUP PLAN (If Demo Fails)

### If Internet Connection Fails:
1. Switch to pre-recorded video
2. Or switch to slides showing screenshots
3. Walk through examples using prepared images

### If Claude is Slow/Down:
1. Use cached screenshots of responses
2. Say: "Here's what it typically finds..."
3. Continue with next demo

### If Claude Gives Unexpected Response:
1. Stay calm
2. Say: "Interesting, let me refine that..."
3. Ask follow-up question
4. This actually shows the iterative process!

---

## PROPS/MATERIALS NEEDED

### On Your Computer:
- [ ] Browser with claude.ai open
- [ ] This script in another window
- [ ] Demo code in text file (for easy copying)
- [ ] Backup slides
- [ ] Quick reference card PDF

### To Share After:
- [ ] Quick reference card
- [ ] Command library  
- [ ] Full guide
- [ ] Demo code samples
- [ ] Link to claude.ai
- [ ] Sign-up instructions

---

## PRESENTATION TIPS

### Do:
✓ Talk while typing (explain what you're asking)
✓ Read key parts of Claude's response aloud
✓ Point to screen when highlighting issues
✓ Ask audience if they see similar problems
✓ Be enthusiastic but realistic
✓ Show real bugs that could happen
✓ Invite questions throughout

### Don't:
✗ Rush through responses
✗ Skip reading important parts
✗ Oversell ("replaces developers")
✗ Use complex examples
✗ Ignore questions
✗ Go over time
✗ Apologize if something goes wrong

---

## ENERGY MANAGEMENT

```
00:00-00:05: High energy - set the tone
00:05-00:15: Steady - let demos speak for themselves
00:15-00:20: Re-energize - quick wins, audience participation
00:20-00:25: Build excitement - practical value
00:25-00:30: Strong close - call to action
```

---

## SUCCESS METRICS

After the demo, you want people to:
1. ✓ Understand what Claude is
2. ✓ See specific value for z/TPF work
3. ✓ Know how to get started
4. ✓ Try it themselves today
5. ✓ Share with teammates

If 50%+ try Claude within a week = SUCCESS!

---

## FINAL CHECKLIST

**5 minutes before:**
- [ ] Screen sharing working
- [ ] claude.ai loaded
- [ ] Demo code ready to paste
- [ ] Script visible (other monitor/device)
- [ ] Phone on silent
- [ ] Closed unnecessary tabs
- [ ] Deep breath - you got this!

**Remember:**
- This is about helping your team
- You're showing a tool that saves time
- Real demos with real code work best
- It's okay if things aren't perfect
- Your enthusiasm matters more than perfection

**Good luck! 🚀**

---

## POST-DEMO SURVEY (Send After)

```
Quick Survey: Claude Demo Feedback

1. Did you find the demo useful?
   □ Very useful  □ Somewhat useful  □ Not useful

2. Have you tried Claude yet?
   □ Yes  □ Planning to  □ Not sure  □ No

3. What would you use Claude for? (Check all)
   □ Code review
   □ Debugging
   □ Understanding legacy code
   □ Writing tests
   □ Documentation
   □ Other: ___________

4. What would help you get started?
   □ One-on-one help
   □ More examples
   □ Office hours
   □ Advanced workshop
   □ Nothing, I'm good!

5. Any questions or feedback?
   [Text box]
```

---

END OF DEMO SCRIPT
