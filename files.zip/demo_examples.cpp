// Sample Mainframe C++ Code Examples for Demo
// File: demo_examples.cpp

// ============================================================================
// EXAMPLE 1: Legacy Code with Common Issues
// Use this to demonstrate code review and issue identification
// ============================================================================

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Legacy transaction processing code (has multiple issues)
void processMainframeTransaction(char* transData, int dataLen) {
    // Issue 1: No null pointer check
    char* buffer = (char*)malloc(dataLen);
    
    // Issue 2: No malloc failure check
    memcpy(buffer, transData, dataLen);
    
    // Issue 3: Manual EBCDIC conversion (error-prone)
    for(int i = 0; i < dataLen; i++) {
        if(buffer[i] >= 0x81 && buffer[i] <= 0x89) {
            buffer[i] = buffer[i] - 0x81 + 'a';
        }
    }
    
    // Issue 4: Global variable usage
    extern int transactionCount;
    transactionCount++;
    
    // Issue 5: Memory leak - no free()
    printf("Transaction processed: %s\n", buffer);
}

// ============================================================================
// EXAMPLE 2: Database Connection (z/OS DB2)
// Use this to show mainframe-specific API usage
// ============================================================================

#include <sqlcli.h>

class DB2Connection {
private:
    SQLHENV henv;
    SQLHDBC hdbc;
    SQLHSTMT hstmt;
    
public:
    // Legacy connection pattern
    int connect(char* database, char* user, char* password) {
        SQLRETURN rc;
        
        rc = SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &henv);
        if(rc != SQL_SUCCESS) return -1;
        
        rc = SQLAllocHandle(SQL_HANDLE_DBC, henv, &hdbc);
        if(rc != SQL_SUCCESS) return -1;
        
        rc = SQLConnect(hdbc, 
                       (SQLCHAR*)database, SQL_NTS,
                       (SQLCHAR*)user, SQL_NTS,
                       (SQLCHAR*)password, SQL_NTS);
        
        // No proper error handling or resource cleanup on failure
        return (rc == SQL_SUCCESS) ? 0 : -1;
    }
    
    // Missing destructor - resource leak!
};

// ============================================================================
// EXAMPLE 3: File Processing (VSAM-like Sequential)
// Use this to demonstrate modernization opportunities
// ============================================================================

#define MAX_RECORD_SIZE 512
#define RECORD_KEY_SIZE 8

typedef struct {
    char key[RECORD_KEY_SIZE];
    char data[MAX_RECORD_SIZE - RECORD_KEY_SIZE];
} MainframeRecord;

// Legacy batch processing
void processBatchFile(const char* filename) {
    FILE* fp = fopen(filename, "rb");
    if(!fp) {
        printf("Error opening file\n");
        return;
    }
    
    MainframeRecord record;
    int recordCount = 0;
    
    // Issue: No buffering, single-record reads (slow)
    while(fread(&record, sizeof(MainframeRecord), 1, fp) == 1) {
        // Issue: Blocking I/O in loop
        processRecord(&record);
        recordCount++;
        
        // Issue: No error handling for processRecord failures
    }
    
    fclose(fp);
    printf("Processed %d records\n", recordCount);
}

void processRecord(MainframeRecord* rec) {
    // Simulate processing
    // Issue: No validation of record structure
}

// ============================================================================
// EXAMPLE 4: Multi-threaded Transaction Handler
// Use this to demonstrate concurrency issues
// ============================================================================

#include <pthread.h>

// Shared state - potential race conditions!
static int activeTransactions = 0;
static char transactionLog[1000][256];
static int logIndex = 0;

void* transactionHandler(void* arg) {
    char* transId = (char*)arg;
    
    // Issue: Race condition on shared variables
    activeTransactions++;
    
    // Simulate transaction processing
    sleep(1);
    
    // Issue: No mutex protection
    strcpy(transactionLog[logIndex], transId);
    logIndex++;
    
    activeTransactions--;
    
    return NULL;
}

void startTransactionProcessing(int numThreads) {
    pthread_t threads[100];
    
    for(int i = 0; i < numThreads; i++) {
        char* transId = (char*)malloc(32);
        sprintf(transId, "TRANS-%05d", i);
        
        // Issue: No check for pthread_create failure
        // Issue: Memory leak - transId never freed
        pthread_create(&threads[i], NULL, transactionHandler, transId);
    }
    
    // Issue: No proper thread joining
    for(int i = 0; i < numThreads; i++) {
        pthread_join(threads[i], NULL);
    }
}

// ============================================================================
// EXAMPLE 5: EBCDIC/ASCII Conversion Utilities
// Use this to show character encoding challenges
// ============================================================================

// Incomplete EBCDIC to ASCII conversion table
static unsigned char ebcdic_to_ascii_table[256] = {
    0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
    0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
    // ... (incomplete table)
};

void convertEbcdicToAscii(char* buffer, int length) {
    // Issue: In-place conversion might not be safe
    // Issue: No validation of buffer or length
    for(int i = 0; i < length; i++) {
        buffer[i] = ebcdic_to_ascii_table[(unsigned char)buffer[i]];
    }
}

// ============================================================================
// EXAMPLE 6: Error Handling Pattern
// Use this to demonstrate poor error handling
// ============================================================================

int processMainframeRecord(const char* recordType, const void* data, int size) {
    // Issue: Magic numbers
    if(size > 4096) {
        return -1;  // What does -1 mean?
    }
    
    // Issue: String comparison without null-termination check
    if(strcmp(recordType, "TYPE_A") == 0) {
        // Process type A
        return 0;
    } else if(strcmp(recordType, "TYPE_B") == 0) {
        // Process type B
        return 0;
    } else {
        // Issue: Unhandled error case
        return -2;  // What does -2 mean?
    }
}

// ============================================================================
// EXAMPLE 7: Memory Management Pattern
// Use this to show memory issues
// ============================================================================

typedef struct {
    char* accountNumber;
    double balance;
    char* transactionHistory;
} AccountRecord;

AccountRecord* createAccountRecord(const char* accNum, double bal) {
    // Issue: malloc without checking return value
    AccountRecord* record = (AccountRecord*)malloc(sizeof(AccountRecord));
    
    // Issue: Multiple malloc calls, complex cleanup
    record->accountNumber = (char*)malloc(strlen(accNum) + 1);
    strcpy(record->accountNumber, accNum);
    
    record->balance = bal;
    
    // Issue: Magic number
    record->transactionHistory = (char*)malloc(10000);
    memset(record->transactionHistory, 0, 10000);
    
    return record;
}

// Issue: No corresponding cleanup function provided!
// Users will need to remember to free all three allocations

// ============================================================================
// EXAMPLE 8: Batch Job Controller
// Use this to demonstrate system integration
// ============================================================================

#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

void runBatchJob(const char* jobName, const char* params) {
    char command[512];
    
    // Issue: Buffer overflow risk with sprintf
    sprintf(command, "/usr/lpp/batch/%s %s", jobName, params);
    
    // Issue: system() call - security risk
    int result = system(command);
    
    // Issue: No proper error checking of return value
    if(result != 0) {
        printf("Job failed\n");
    }
}

// ============================================================================
// EXAMPLE 9: Configuration Management
// Use this to show parsing and validation issues
// ============================================================================

#define MAX_CONFIG_LINES 100

typedef struct {
    char key[64];
    char value[256];
} ConfigParam;

ConfigParam globalConfig[MAX_CONFIG_LINES];
int configCount = 0;

void loadConfiguration(const char* configFile) {
    FILE* fp = fopen(configFile, "r");
    char line[512];
    
    // Issue: No error checking on fopen
    while(fgets(line, sizeof(line), fp) != NULL) {
        char* equals = strchr(line, '=');
        if(equals) {
            // Issue: No bounds checking
            *equals = '\0';
            strcpy(globalConfig[configCount].key, line);
            strcpy(globalConfig[configCount].value, equals + 1);
            
            // Issue: No check for MAX_CONFIG_LINES
            configCount++;
        }
    }
    
    fclose(fp);
}

const char* getConfigValue(const char* key) {
    // Issue: Linear search (inefficient)
    // Issue: No error handling for missing keys
    for(int i = 0; i < configCount; i++) {
        if(strcmp(globalConfig[i].key, key) == 0) {
            return globalConfig[i].value;
        }
    }
    return NULL;  // Issue: Returning NULL without documentation
}

// ============================================================================
// EXAMPLE 10: Logging System
// Use this to demonstrate thread-safety and resource management
// ============================================================================

#define LOG_BUFFER_SIZE 10000

static char logBuffer[LOG_BUFFER_SIZE];
static int logBufferPos = 0;
static FILE* logFile = NULL;

void initLogging(const char* filename) {
    // Issue: No check if already initialized
    logFile = fopen(filename, "a");
    // Issue: No error checking
}

void writeLog(const char* message) {
    // Issue: Not thread-safe
    // Issue: No bounds checking
    int len = strlen(message);
    
    if(logBufferPos + len >= LOG_BUFFER_SIZE) {
        // Flush buffer
        fwrite(logBuffer, 1, logBufferPos, logFile);
        fflush(logFile);
        logBufferPos = 0;
    }
    
    strcpy(logBuffer + logBufferPos, message);
    logBufferPos += len;
}

void closeLogging() {
    // Flush remaining buffer
    if(logBufferPos > 0) {
        fwrite(logBuffer, 1, logBufferPos, logFile);
    }
    
    // Issue: No null check
    fclose(logFile);
    logFile = NULL;
}

// ============================================================================
// NOTES FOR DEMO:
// 
// These examples contain intentional issues commonly found in legacy mainframe
// C++ code. Use them to demonstrate how Claude can:
// 
// 1. Identify bugs and security issues
// 2. Suggest modern C++ alternatives
// 3. Improve error handling
// 4. Add thread safety
// 5. Optimize performance
// 6. Generate documentation
// 7. Create test cases
// 8. Provide refactoring suggestions
//
// Demo Strategy:
// - Start with Example 1 (simple issues)
// - Progress to Examples 4 & 10 (concurrency)
// - Show modernization with Examples 6 & 7 (error handling & memory)
// - End with system integration Examples 2 & 8
// ============================================================================
