# Claude Command Library for z/TPF Developers
## Ready-to-Use Prompts and Specialized Agents

---

## 📚 Table of Contents
1. Quick Commands (Copy & Paste)
2. Specialized Agents
3. Workflow Templates
4. Custom Agent Builder
5. Team Prompt Library

---

## 1. QUICK COMMANDS (Copy & Paste These)

### 🔍 AGENT 1: CODE REVIEWER
**Purpose:** Comprehensive code review for z/TPF code

**Command to copy:**
```
You are a z/TPF expert code reviewer. Analyze this code for:

1. **Memory Issues**: Leaks, buffer overflows, uninitialized variables
2. **TPFDF Operations**: Proper locking, error handling, record management
3. **Real-Time Violations**: Operations that break subsecond constraints
4. **Race Conditions**: Thread safety, lock ordering, shared state
5. **TPF Best Practices**: Compliance with z/TPF coding standards
6. **Performance**: Inefficient operations in critical path
7. **Error Handling**: Missing checks, orphaned locks, resource cleanup

For each issue found:
- State the line number
- Explain the problem
- Show the corrected code
- Explain why it matters

Code to review:
[PASTE YOUR CODE HERE]
```

**When to use:** Before committing any new code

---

### 🐛 AGENT 2: DEBUG DETECTIVE
**Purpose:** Find root cause of bugs and crashes

**Command to copy:**
```
You are a z/TPF debugging expert. I have a bug that needs diagnosis.

Environment: z/TPF [version]
System: [airline/credit card/other]
Frequency: [always/intermittent/under load]

**Symptom:**
[Describe what's happening - crash, wrong output, performance issue]

**Error Message/Code:**
[Paste error message, SERRC code, or dump info]

**Code:**
[PASTE YOUR CODE HERE]

**What I've tried:**
[What debugging steps you've already taken]

Please:
1. Identify the most likely root cause
2. Explain why this causes the symptom
3. Show the fix with corrected code
4. Suggest how to test the fix
5. Recommend how to prevent similar bugs
```

**When to use:** When debugging any issue

---

### ⚡ AGENT 3: PERFORMANCE OPTIMIZER
**Purpose:** Optimize code for real-time performance

**Command to copy:**
```
You are a z/TPF performance optimization expert.

**Current Performance:**
- Execution time: [X microseconds]
- Target time: [Y microseconds]
- Transaction volume: [N per second]
- System: z/TPF on [z14/z15/z16]

**Constraints:**
- Must maintain subsecond response time
- Real-time system - no blocking operations
- High availability requirements
- [Any other constraints]

**Code to optimize:**
[PASTE YOUR CODE HERE]

Please:
1. Identify performance bottlenecks
2. Suggest specific optimizations
3. Show optimized code
4. Estimate performance improvement
5. Explain any tradeoffs
6. Highlight what NOT to do in real-time code
```

**When to use:** When code is too slow

---

### 📖 AGENT 4: CODE EXPLAINER
**Purpose:** Understand legacy or complex code

**Command to copy:**
```
You are a z/TPF code documentation expert. I need to understand this code.

**Context:**
- This code is from [year/era]
- Purpose: [if known]
- I need to: [modify/debug/document it]

**Code to explain:**
[PASTE YOUR CODE HERE]

Please explain:
1. **High-level overview**: What does this code do?
2. **Data structures**: What are the key structures?
3. **Flow**: Step-by-step execution flow
4. **TPF-specific elements**: ECBs, TPFDF operations, global areas
5. **Dependencies**: What other systems/files does it interact with?
6. **Potential issues**: Any obvious problems you spot
7. **Modernization opportunities**: How could this be improved?

Use simple language and examples.
```

**When to use:** When you inherit unfamiliar code

---

### 🔄 AGENT 5: CODE MODERNIZER
**Purpose:** Update legacy C to modern C++

**Command to copy:**
```
You are a z/TPF modernization expert. Help me update this legacy code.

**Current Code:**
- Language: [C/Old C++]
- Written: [year if known]
- Style: [procedural/old patterns]

**Target:**
- Modern C++ (C++11/14/17)
- Maintain z/TPF compatibility
- Keep real-time performance
- Improve maintainability

**Constraints:**
- Cannot use: [list unavailable features, e.g., STL, exceptions]
- Must preserve: [backwards compatibility, interfaces, etc.]
- Real-time requirements: subsecond response

**Code to modernize:**
[PASTE YOUR CODE HERE]

Please:
1. Show modernized version
2. Highlight key improvements
3. Explain what changed and why
4. Note any performance impacts
5. Suggest testing approach
6. Flag anything that can't be modernized due to TPF constraints
```

**When to use:** Refactoring legacy code

---

### 🧪 AGENT 6: TEST GENERATOR
**Purpose:** Create comprehensive unit tests

**Command to copy:**
```
You are a z/TPF testing expert. Generate comprehensive tests for this code.

**Code to test:**
[PASTE YOUR CODE HERE]

**Testing Requirements:**
- Framework: [Google Test/CppUnit/custom]
- Coverage: Aim for 90%+ code coverage
- Include: Edge cases, error conditions, boundary values
- z/TPF specific: Mock TPFDF operations, simulate TPF environment

Please generate:
1. **Test cases** covering:
   - Happy path scenarios
   - Error conditions
   - Boundary values
   - Edge cases
   - Concurrent access (if applicable)
   - TPFDF error codes

2. **Mock objects** for:
   - TPFDF operations
   - External dependencies
   - TPF system calls

3. **Test data** for various scenarios

4. **Setup/teardown** code

5. **Test documentation** explaining what each test validates

Format as compilable test code.
```

**When to use:** Writing tests for any function

---

### 📝 AGENT 7: DOCUMENTATION GENERATOR
**Purpose:** Create comprehensive documentation

**Command to copy:**
```
You are a z/TPF technical writer. Generate complete documentation for this code.

**Code to document:**
[PASTE YOUR CODE HERE]

Generate:

1. **Overview Section**
   - Purpose and responsibility
   - System context (where it fits)
   - Key features

2. **API Documentation**
   - Function signatures
   - Parameters (type, purpose, constraints)
   - Return values and error codes
   - Pre-conditions and post-conditions

3. **Usage Examples**
   - Basic usage
   - Common scenarios
   - Error handling examples

4. **Implementation Details**
   - Algorithm description
   - Data structures used
   - TPFDF files accessed
   - Performance characteristics

5. **Integration Guide**
   - How to call from other programs
   - Dependencies
   - Configuration requirements
   - TPF-specific setup

6. **Troubleshooting Section**
   - Common errors
   - Debug tips
   - Known limitations

Format: [Markdown/Doxygen/inline comments]
```

**When to use:** Documenting any code module

---

### 🔐 AGENT 8: SECURITY AUDITOR
**Purpose:** Find security vulnerabilities

**Command to copy:**
```
You are a z/TPF security expert. Audit this code for security issues.

**Code to audit:**
[PASTE YOUR CODE HERE]

**Context:**
- System type: [credit card/airline/financial]
- Handles sensitive data: [yes/no - describe]
- External interfaces: [yes/no - describe]
- Compliance requirements: [PCI-DSS/other]

Check for:
1. **Input Validation**
   - Buffer overflows
   - SQL injection (if applicable)
   - Format string vulnerabilities
   - Boundary checks

2. **Data Protection**
   - Sensitive data exposure
   - Insecure storage
   - Unencrypted transmission
   - Memory exposure after use

3. **Access Control**
   - Unauthorized access paths
   - Privilege escalation
   - Missing authorization checks

4. **Error Handling**
   - Information leakage in errors
   - Unsafe error recovery
   - Missing audit logging

5. **Resource Management**
   - Resource exhaustion
   - Denial of service vectors
   - Lock handling issues

For each issue:
- Severity: Critical/High/Medium/Low
- Explanation
- Remediation code
- Testing approach
```

**When to use:** Security-critical code review

---

### 🔀 AGENT 9: MIGRATION PLANNER
**Purpose:** Plan migration from old systems

**Command to copy:**
```
You are a z/TPF migration expert. Help me plan this migration.

**Current System:**
[Describe source - COBOL, old TPF, assembler, etc.]

**Target System:**
- Platform: z/TPF with C++
- Requirements: [performance, features, compatibility]
- Timeline: [if known]
- Constraints: [must maintain, cannot change, etc.]

**Code to migrate:**
[PASTE SOURCE CODE HERE]

Please provide:

1. **Migration Strategy**
   - Recommended approach (big bang, phased, parallel)
   - Risk assessment
   - Effort estimation

2. **Architecture Design**
   - Proposed C++ structure
   - Data structure mapping
   - Interface design

3. **Implementation Plan**
   - Phase breakdown
   - Dependencies
   - Critical path items

4. **Code Samples**
   - Key functions in new implementation
   - Data structure definitions
   - Error handling patterns

5. **Testing Strategy**
   - Validation approach
   - Parallel testing plan
   - Rollback plan

6. **Risk Mitigation**
   - Known challenges
   - Mitigation strategies
   - Contingency plans
```

**When to use:** Planning any migration project

---

### 🎯 AGENT 10: REQUIREMENT IMPLEMENTER
**Purpose:** Implement new features correctly

**Command to copy:**
```
You are a z/TPF development expert. Help me implement this requirement.

**Requirement:**
[Describe what needs to be built]

**Existing Code:**
[PASTE RELEVANT EXISTING CODE HERE]

**Constraints:**
- Performance: Must complete in [X] microseconds
- Compatibility: Must work with [existing systems]
- Data: Uses TPFDF files [list files]
- Volume: [transactions per second]

**Questions:**
1. How should I implement this in z/TPF?
2. What data structures do I need?
3. What TPFDF operations are required?
4. How do I handle errors?
5. What are the performance implications?
6. How should I test this?

Please provide:
1. Implementation design
2. Complete code implementation
3. Error handling strategy
4. Test cases
5. Integration points with existing code
6. Performance analysis
```

**When to use:** Building new features

---

## 2. SPECIALIZED AGENTS BY ROLE

### 👤 FOR NEW DEVELOPERS

**AGENT: ONBOARDING BUDDY**
```
You are a z/TPF mentor helping a new developer learn the system.

I'm new to z/TPF. I have experience with [your background].

I'm looking at this code: [PASTE CODE]

Please explain:
- What is z/TPF and how is it different?
- What are the key concepts I need to know?
- What does this code do?
- What are common patterns I'll see?
- What mistakes should I avoid?
- What resources should I study?

Use simple language, lots of examples, and be patient!
```

---

### 👤 FOR MAINTENANCE DEVELOPERS

**AGENT: MAINTENANCE HELPER**
```
You are a z/TPF maintenance expert.

I need to fix/enhance this production code: [PASTE CODE]

Background:
- Code age: [old/very old/ancient]
- Documentation: [none/minimal/some]
- Last modified: [if known]
- Issue: [describe problem or enhancement]

I need:
1. Quick understanding of what this does
2. Where to make my change safely
3. What could break
4. How to test it
5. Rollback strategy if it goes wrong

Be practical and focus on safe, minimal changes.
```

---

### 👤 FOR ARCHITECTS

**AGENT: ARCHITECTURE ADVISOR**
```
You are a z/TPF system architect.

I'm designing: [describe system/component]

Requirements:
- Scale: [transactions/second]
- Latency: [target response time]
- Availability: [SLA]
- Integration: [systems to connect]

Current architecture: [PASTE CODE OR DESCRIBE]

Please advise on:
1. Architecture patterns for z/TPF
2. Data structure design
3. TPFDF file organization
4. Performance optimization strategy
5. Scalability approach
6. High availability design
7. Testing strategy
8. Potential bottlenecks

Provide architectural diagrams (in text/Mermaid) and code patterns.
```

---

### 👤 FOR TEAM LEADS

**AGENT: CODE REVIEW COORDINATOR**
```
You are a z/TPF code review expert.

Our team needs to review: [PASTE CODE]

Team context:
- Experience level: [junior/mixed/senior]
- Deadline: [date]
- Critical path: [yes/no]

Provide:
1. **Quick checklist** for reviewers
2. **Key areas** to focus on
3. **Red flags** to watch for
4. **Review talking points** for the meeting
5. **Acceptance criteria** - what must be fixed before merge
6. **Nice-to-haves** - improvements for future

Format for team discussion.
```

---

## 3. WORKFLOW TEMPLATES

### WORKFLOW 1: Daily Code Review Routine

**Morning Checklist:**
```
For each file you worked on yesterday:

1. Run CODE REVIEWER agent
2. Fix critical issues
3. Document why you made changes
4. Run TEST GENERATOR for new code
5. Update documentation
```

**Command sequence:**
```
1. Use AGENT 1 (Code Reviewer) on your changes
2. Use AGENT 6 (Test Generator) for new functions
3. Use AGENT 7 (Documentation Generator) if you changed interfaces
```

---

### WORKFLOW 2: Bug Fix Process

**When you get a bug report:**
```
Step 1: Gather info
- Error message
- Reproduction steps
- Frequency
- Environment

Step 2: Use DEBUG DETECTIVE (Agent 2)
[Run the agent with all info]

Step 3: Use CODE REVIEWER (Agent 1) on the fix
[Make sure fix doesn't introduce new issues]

Step 4: Use TEST GENERATOR (Agent 6)
[Create regression test]

Step 5: Use DOCUMENTATION GENERATOR (Agent 7)
[Update docs with new behavior]
```

---

### WORKFLOW 3: New Feature Development

```
Phase 1: Design
→ Use REQUIREMENT IMPLEMENTER (Agent 10)
→ Review design with team

Phase 2: Implementation
→ Write code based on agent's suggestion
→ Use CODE REVIEWER (Agent 1) as you go

Phase 3: Testing
→ Use TEST GENERATOR (Agent 6)
→ Use PERFORMANCE OPTIMIZER (Agent 3) if needed

Phase 4: Documentation
→ Use DOCUMENTATION GENERATOR (Agent 7)

Phase 5: Security Review (if applicable)
→ Use SECURITY AUDITOR (Agent 8)
```

---

### WORKFLOW 4: Legacy Code Exploration

```
Day 1: Understanding
→ Use CODE EXPLAINER (Agent 4) on main modules
→ Create high-level map of system

Day 2-3: Deep Dive
→ Use CODE EXPLAINER (Agent 4) on each subsystem
→ Use DOCUMENTATION GENERATOR (Agent 7) as you learn

Day 4: Modernization Planning
→ Use CODE MODERNIZER (Agent 5) to see possibilities
→ Use MIGRATION PLANNER (Agent 9) for roadmap

Day 5: Present findings to team
```

---

## 4. CUSTOM AGENT BUILDER

Want to create your own specialized agent? Use this template:

```
You are a z/TPF expert specializing in [YOUR SPECIALTY].

Context:
- System: [describe]
- Role: [your role]
- Goal: [what you want to achieve]

Specific requirements:
- [Requirement 1]
- [Requirement 2]
- [Requirement 3]

Code/situation: [PASTE HERE]

Please provide:
1. [Output 1]
2. [Output 2]
3. [Output 3]

Format: [how you want the response]
Additional constraints: [any special rules]
```

**Examples of custom agents you might create:**
- Database Schema Designer
- API Interface Generator
- Performance Profiler Analyzer
- Build System Expert
- Deployment Script Generator
- Log Analyzer
- Configuration Manager
- Data Migration Helper

---

## 5. TEAM PROMPT LIBRARY

### Setting Up a Shared Library

**Create a team wiki/document with:**

1. **Common Agents** - The 10 agents above
2. **Project-Specific Agents** - Custom for your codebase
3. **Success Stories** - What worked well
4. **Don'ts** - What didn't work
5. **Tips & Tricks** - Team discoveries

**Template for team prompt:**
```
AGENT NAME: [descriptive name]
PURPOSE: [one line description]
CREATED BY: [team member]
USED FOR: [scenarios]
SUCCESS RATE: [high/medium/low]

PROMPT:
[full prompt text]

EXAMPLE RESULTS:
[paste example of good result]

NOTES:
[any tips for using this prompt]
```

---

## 6. QUICK REFERENCE CHEAT SHEET

```
┌─────────────────────────────────────────────────────┐
│  NEED TO...              →  USE AGENT...            │
├─────────────────────────────────────────────────────┤
│  Review code             →  #1 Code Reviewer        │
│  Find bugs               →  #2 Debug Detective      │
│  Make code faster        →  #3 Performance Optimizer│
│  Understand code         →  #4 Code Explainer       │
│  Update old code         →  #5 Code Modernizer      │
│  Write tests             →  #6 Test Generator       │
│  Create docs             →  #7 Doc Generator        │
│  Check security          →  #8 Security Auditor     │
│  Plan migration          →  #9 Migration Planner    │
│  Build new feature       →  #10 Requirement Impl.   │
└─────────────────────────────────────────────────────┘
```

---

## 7. POWER USER TIPS

### Tip 1: Chain Agents Together

```
Problem: Need to add feature to legacy code

Solution: Chain multiple agents
1. CODE EXPLAINER → understand existing code
2. REQUIREMENT IMPLEMENTER → design the feature
3. CODE MODERNIZER → improve while adding
4. CODE REVIEWER → check the result
5. TEST GENERATOR → create tests
6. DOCUMENTATION GENERATOR → document it

Run them in sequence, each builds on the previous!
```

### Tip 2: Create Context Documents

```
Create a file: "my_project_context.txt"

Contents:
---
Project: Flight Booking System
Platform: z/TPF 1.1 on z15
Language: C++ (C++14)
Performance: <50μs per transaction
Volume: 100K transactions/second

Key files:
- BOOKING.c - Main booking logic
- PNRMGR.c - PNR management
- INVMGR.c - Inventory management

TPFDF Files:
- 0x01: PNR_FILE
- 0x02: FLIGHT_FILE
- 0x03: INVENTORY_FILE

Conventions:
- All keys are 8 bytes
- Error codes 0-99
- Lock order: always PNR→FLIGHT→INVENTORY

Common issues:
- Watch for deadlocks on inventory
- PNR cache timeout is 5 seconds
- Don't use malloc in transaction path
---

Paste this context before your code in every conversation!
```

### Tip 3: Build a Personal Agent Library

```
Create your own file: "my_claude_agents.txt"

Add:
- Agents you use most
- Customized versions
- Project-specific prompts
- Successful examples
- Lessons learned

Copy-paste from this file = super fast!
```

### Tip 4: Save Great Conversations

```
When Claude gives you a great answer:
1. Click the share button
2. Save the link
3. Add to your team wiki
4. Tag it with keywords

Build a knowledge base of solutions!
```

---

## 8. MEASURING SUCCESS

### Track Your Productivity

**Before Claude:**
- Code review time: [X hours]
- Debug time: [Y hours]
- Documentation time: [Z hours]

**After Claude (1 month):**
- Code review time: [X hours]
- Debug time: [Y hours]
- Documentation time: [Z hours]

**Calculate:**
- Time saved: [%]
- Bugs found: [more/less]
- Code quality: [better/same]

---

## 9. ADVANCED TECHNIQUES

### Technique 1: Multi-Pass Review

```
Pass 1: CODE REVIEWER (general)
Pass 2: PERFORMANCE OPTIMIZER (focus performance)
Pass 3: SECURITY AUDITOR (focus security)
Pass 4: CODE EXPLAINER (verify logic)

Each pass catches different issues!
```

### Technique 2: Conversational Refinement

```
You: [Use CODE REVIEWER agent]
Claude: [Finds 5 issues]

You: "Focus on issue #3. Show me 3 different ways to fix it"
Claude: [Shows alternatives]

You: "Which is best for real-time constraints?"
Claude: [Recommends with explanation]

You: "Show me the complete fixed function"
Claude: [Provides full code]

Keep drilling down!
```

### Technique 3: Context Building

```
Conversation 1: Explain the system
Conversation 2: Review component A (with system context)
Conversation 3: Review component B (with A and system context)
Conversation 4: Design new feature (with all context)

Build up knowledge in one conversation!
```

---

## 10. TROUBLESHOOTING AGENTS

**Agent gives wrong answer?**
```
Response: "Wait, in z/TPF we actually do it differently because..."
Then: Explain the TPF-specific constraint
Claude will adapt!
```

**Agent output too generic?**
```
Response: "Be more specific about z/TPF requirements"
Or: "Focus only on the performance issue at line 45"
Narrow the scope!
```

**Need different format?**
```
Response: "Show this as a table"
Or: "Format as inline code comments"
Or: "Create a checklist I can print"
Ask for what you need!
```

---

## CONCLUSION

**You now have:**
✓ 10 ready-to-use agents
✓ Role-specific agents
✓ Workflow templates
✓ Team collaboration tools
✓ Power user techniques

**Start today:**
1. Bookmark this file
2. Try Agent #1 (Code Reviewer) on your next commit
3. Share with your team
4. Customize for your needs
5. Build your own agent library

**Remember:**
- Agents are starting points - customize them!
- Chain agents together for complex tasks
- Save successful prompts for reuse
- Share discoveries with your team
- Iterate and improve your agents over time

---

## QUICK START CHECKLIST

Your first week with agents:

**Day 1:**
- [ ] Try CODE REVIEWER on one file
- [ ] Try CODE EXPLAINER on legacy code

**Day 2:**
- [ ] Try DEBUG DETECTIVE on a real bug
- [ ] Try DOCUMENTATION GENERATOR

**Day 3:**
- [ ] Try TEST GENERATOR
- [ ] Try PERFORMANCE OPTIMIZER

**Day 4:**
- [ ] Create your first custom agent
- [ ] Share results with team

**Day 5:**
- [ ] Build your personal agent library
- [ ] Measure time saved

**Week 2:**
- [ ] Train team members
- [ ] Create team prompt library
- [ ] Establish best practices

Good luck! 🚀
