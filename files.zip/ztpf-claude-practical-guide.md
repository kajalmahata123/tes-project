# How to Use Claude with Your z/TPF Codebase
## Practical Step-by-Step Guide for IBM z/TPF Developers

---

## Table of Contents
1. Getting Started with Claude
2. How to Share Your Code with Claude
3. Common Workflows and Use Cases
4. Step-by-Step Examples
5. Best Practices
6. Troubleshooting

---

## 1. Getting Started with Claude

### Step 1: Access Claude
1. Open your web browser
2. Go to **https://claude.ai**
3. Sign in (or create free account)
4. You'll see a chat interface - just like texting!

### Step 2: Understanding the Interface
```
┌─────────────────────────────────────┐
│  Claude                         [≡] │  ← Menu
├─────────────────────────────────────┤
│                                     │
│  Your messages appear here          │
│                                     │
│  Claude's responses appear here     │
│                                     │
├─────────────────────────────────────┤
│  📎 Type your message here...   ↑  │  ← Input area
└─────────────────────────────────────┘
     ↑ Attach files button
```

**Key Features:**
- 📎 **Paperclip icon**: Upload code files
- **Text box**: Type questions or paste code
- **Send arrow**: Submit your message
- **New chat**: Start fresh conversation (top left)

---

## 2. How to Share Your Code with Claude

### Method 1: Copy and Paste (Easiest)
**When to use:** Small code snippets (< 500 lines)

**Steps:**
1. Open your z/TPF source file in your editor
2. Select the code you want help with
3. Copy it (Ctrl+C)
4. Go to Claude
5. Type your question
6. Paste the code (Ctrl+V)
7. Press Enter

**Example:**
```
Can you review this TPF entry point code for bugs?

[Paste your code here]
```

### Method 2: Upload Files (Better for Larger Code)
**When to use:** Complete source files, headers, or multiple files

**Steps:**
1. Click the 📎 paperclip icon in Claude
2. Select your .c, .cpp, .h, or .hpp file
3. File uploads automatically
4. Type your question about the file
5. Press Enter

**Supported file types:**
- `.c` `.cpp` `.cc` - C/C++ source files
- `.h` `.hpp` - Header files  
- `.txt` `.log` - Build logs, error logs
- `.md` - Documentation

**Example conversation:**
```
You: [Upload PNRPROC.c file]
You: "This is our passenger name record processing code. 
      Can you explain what the main functions do?"

Claude: [Analyzes the uploaded file and explains it]
```

### Method 3: Share Code Context
**When to use:** You need Claude to understand your environment

**Include this information:**
```
I'm working on z/TPF (Transaction Processing Facility) with:
- TPF version: 1.1 (or your version)
- Compiler: TPF C/C++ compiler
- Environment: Airline reservation system
- Issue: [Describe your problem]

Here's my code:
[Paste code]
```

---

## 3. Common Workflows for z/TPF Developers

### Workflow A: Understanding Existing Code

**Scenario:** You inherited code and need to understand it

**Step-by-Step:**
```
1. Upload or paste the code file to Claude

2. Ask: "Can you explain what this z/TPF program does? 
        Break it down function by function."

3. Follow up with specific questions:
   - "What does this ECB handling section do?"
   - "Why is this global area being used?"
   - "What's the purpose of this TPFDF operation?"

4. Ask for documentation:
   "Can you create documentation for this code with:
    - Function descriptions
    - Parameter explanations
    - Return values
    - Usage examples"
```

**Real Example:**
```
User: [Pastes 300 lines of TPF code]
"This is a legacy reservation processing program from 2005. 
I need to understand how it handles seat assignments. 
Can you explain the flow?"

Claude: [Provides detailed explanation with step-by-step flow]

User: "What does the function 'check_seat_avail' do?"

Claude: [Explains that specific function]
```

---

### Workflow B: Finding and Fixing Bugs

**Scenario:** Your code has a bug or is crashing

**Step-by-Step:**
```
1. Gather information:
   - Error message or symptom
   - Code that's failing
   - Any log output
   - What you've tried

2. Ask Claude:
   "I'm getting [error/symptom] in this z/TPF code.
    Here's the error message: [paste error]
    Here's the code: [paste code]
    What could be causing this?"

3. Claude will analyze and suggest fixes

4. Ask for clarification:
   "Can you show me the corrected code?"
   "Why did that cause the problem?"
```

**Real Example:**
```
User: "My TPF program is getting a SERRC (file error) when 
trying to read from TPFDF. Here's the code:

rc = tpfdf_lrec(FILE_ID, key, &record, LOCK_MODE);
if (rc != 0) {
    // Error handling
}

What's wrong?"

Claude: [Analyzes and explains that LOCK_MODE might be 
incorrect, buffer might not be allocated properly, or 
file might not be open. Suggests specific fixes.]

User: "How do I properly check if the file is open first?"

Claude: [Shows the correct code pattern for z/TPF]
```

---

### Workflow C: Code Review Before Committing

**Scenario:** You wrote new code and want it reviewed

**Step-by-Step:**
```
1. Paste your new/modified code

2. Ask: "Can you review this z/TPF code for:
        - Memory leaks
        - Race conditions  
        - TPF best practices violations
        - Performance issues
        - Error handling gaps"

3. Review Claude's feedback

4. Ask for specific improvements:
   "How would you rewrite this to be more efficient?"
   "Show me the corrected version"
```

**Real Example:**
```
User: [Pastes new function]
"I just wrote this function to process credit card 
transactions in z/TPF. Can you review it for any issues?"

Claude: [Reviews and identifies: missing null checks, 
potential buffer overflow, inefficient string operations, 
missing error logging]

User: "Can you show me the improved version with those fixes?"

Claude: [Provides corrected code with explanations]
```

---

### Workflow D: Adding New Features

**Scenario:** You need to add functionality to existing code

**Step-by-Step:**
```
1. Share the existing code

2. Describe what you want to add:
   "I need to add [feature] to this code. 
    It should [describe behavior].
    Here's the existing code: [paste]"

3. Claude will suggest implementation

4. Iterate and refine:
   "That looks good, but I also need it to [requirement]"
   "How do I integrate this with my existing error handling?"
```

**Real Example:**
```
User: [Pastes PNR processing code]
"I need to add a frequent flyer miles calculation to this 
passenger record processing. The miles should be based on 
flight distance and fare class."

Claude: [Suggests implementation with code]

User: "We also need to handle elite status bonuses. 
Can you update the code?"

Claude: [Provides updated code with bonus logic]
```

---

### Workflow E: Modernizing Legacy Code

**Scenario:** Update old C code to modern C++

**Step-by-Step:**
```
1. Share the legacy code

2. Ask: "This z/TPF code was written in C in 1995. 
        How can I modernize it to use C++ features while 
        keeping it compatible with TPF?"

3. Review suggestions (smart pointers, classes, etc.)

4. Ask about specific concerns:
   "Will this affect performance in our real-time system?"
   "How do I test this safely?"
```

**Real Example:**
```
User: [Pastes old C code with manual memory management]
"This code uses malloc/free everywhere. Can I modernize 
it with C++ while maintaining TPF compatibility?"

Claude: [Shows how to use RAII patterns, smart pointers 
where appropriate, but warns about real-time constraints]

User: "What about the performance impact?"

Claude: [Explains performance considerations for TPF]
```

---

### Workflow F: Writing Tests

**Scenario:** Create test cases for your code

**Step-by-Step:**
```
1. Share the function you want to test

2. Ask: "Can you create unit tests for this function? 
        Include edge cases and error conditions."

3. Review and customize the tests

4. Ask for additional scenarios:
   "What about testing with invalid input?"
   "Can you add tests for concurrent access?"
```

---

### Workflow G: Documentation Generation

**Scenario:** Document undocumented code

**Step-by-Step:**
```
1. Upload or paste the code

2. Ask: "Generate documentation for this code including:
        - Overview
        - Function descriptions
        - Parameters and return values
        - Usage examples
        - Integration notes for z/TPF"

3. Save the documentation Claude provides

4. Ask for specific formats:
   "Can you format this as a README?"
   "Create this as inline code comments"
```

---

## 4. Detailed Step-by-Step Examples

### Example 1: Debugging a Real z/TPF Issue

**The Problem:** Program crashes with SERRC error

**Step 1: Start the conversation**
```
You type: "I have a z/TPF program that's crashing with a 
SERRC (file error) when reading passenger records. 
I'll paste the code."
```

**Step 2: Share your code**
```
You paste:
-----
void process_pnr() {
    struct pnr_rec pnr;
    char key[8];
    short rc;
    
    memcpy(key, input_msg->pnr_key, 8);
    rc = tpfdf_lrec(PNR_FILE, key, &pnr, LOCK_READ);
    
    if (rc != 0) {
        send_error(rc);
        return;
    }
    
    update_passenger_info(&pnr);
}
-----
```

**Step 3: Claude analyzes and responds**
```
Claude identifies:
1. File might not be open
2. Key might not be null-terminated
3. Buffer alignment issues
4. Missing error code logging

Claude suggests specific fixes with code examples
```

**Step 4: You ask follow-up questions**
```
You: "How do I check if the file is open first?"

Claude: [Shows proper file open check]

You: "What's the correct way to handle the key?"

Claude: [Shows proper key handling for TPF]
```

**Step 5: You get the fix**
```
Claude provides corrected code:
-----
void process_pnr() {
    struct pnr_rec pnr;
    char key[8];
    short rc;
    
    // Ensure file is open
    if (!is_file_open(PNR_FILE)) {
        log_error("PNR file not open");
        send_error(FILE_NOT_OPEN);
        return;
    }
    
    // Properly format key
    memset(key, 0, sizeof(key));
    memcpy(key, input_msg->pnr_key, 
           strlen(input_msg->pnr_key));
    
    // Read with proper error handling
    rc = tpfdf_lrec(PNR_FILE, key, &pnr, LOCK_READ);
    
    if (rc != 0) {
        log_error("TPFDF read failed", rc);
        send_error(rc);
        return;
    }
    
    update_passenger_info(&pnr);
    
    // Release lock
    tpfdf_urec(PNR_FILE, key);
}
-----
```

---

### Example 2: Understanding Complex Code

**The Situation:** You need to modify code you didn't write

**Complete Conversation:**

```
YOU: [Upload FLTTBL.c file - 500 lines]
"This is our flight table processing code. I need to add 
a new field to track aircraft type, but I don't fully 
understand how this code works. Can you explain it?"

CLAUDE: "This z/TPF program manages flight table records with 
three main sections:

1. Flight table lookup (lines 50-120)
   - Searches by flight number and date
   - Uses TPFDF indexed file operations
   - Implements caching for performance

2. Flight data update (lines 121-250)
   - Validates input data
   - Updates multiple related records
   - Handles schedule changes

3. Availability processing (lines 251-400)
   - Calculates seat availability
   - Manages booking classes
   - Integrates with inventory system

The key data structure is flight_rec (defined in FLTTBL.h):
[Claude shows structure breakdown]

To add aircraft type, you'll need to:
- Update flight_rec structure
- Modify the update_flight function
- Add validation in check_flight_data
- Update the database write operations"

YOU: "Can you show me specifically where to add the aircraft 
type field in the structure and what changes I need to make 
to the update function?"

CLAUDE: [Shows specific code changes with line numbers and 
explanations]

YOU: "Will this affect the file record length in TPFDF?"

CLAUDE: "Yes, adding a field increases the record size. You'll 
need to:
1. Update the file definition in your TPFDF schema
2. Run database migration
3. Update all programs that read this record type
4. Test with both old and new format records during migration

Here's a safe migration approach:
[Claude provides migration strategy]"
```

---

### Example 3: Performance Optimization

**The Situation:** Code is too slow for real-time requirements

```
YOU: [Paste code]
"This function processes 50,000 transactions per second 
but needs to handle 75,000. It's too slow. Can you help 
optimize it?"

CLAUDE: [Analyzes code]
"I found several performance issues:

1. Database lookup in loop (line 45)
   - Currently: O(n) operations
   - Solution: Batch read or cache

2. String operations (lines 67-82)
   - Using strcpy/strcmp in tight loop
   - Solution: Use memcmp, avoid string functions

3. Memory allocation (line 103)
   - Allocating per transaction
   - Solution: Use memory pools

4. Redundant calculations (lines 120-135)
   - Recalculating same value
   - Solution: Calculate once, reuse

Here's the optimized version:
[Claude shows improved code]

Expected improvement: 40-50% faster execution"

YOU: "Will this be safe for our real-time constraints?"

CLAUDE: "Yes, these changes actually improve determinism:
- No dynamic allocation in critical path
- Predictable execution time
- Better cache locality

However, test thoroughly:
1. Stress test with peak load
2. Measure response time distribution
3. Check for memory leaks over 24 hours
4. Verify behavior under CPU contention"
```

---

## 5. Best Practices for Using Claude with z/TPF Code

### DO's ✓

**1. Provide Context**
```
GOOD: "I'm working in z/TPF 1.1 on an airline reservation 
system. This code processes real-time booking requests..."

BAD: "Fix this code" [paste]
```

**2. Be Specific About Your Environment**
```
GOOD: "This runs on z/TPF with subsecond response time 
requirements. We use TPFDF for database operations..."

BAD: [No context provided]
```

**3. Share Error Messages**
```
GOOD: "Getting SERRC error code 0x04B when calling tpfdf_lrec. 
Here's the full error: [paste]"

BAD: "It's not working"
```

**4. Ask Follow-up Questions**
```
GOOD: "Why did you suggest using a memory pool here?"
"What's the performance impact of this change?"

Iterate until you understand!
```

**5. Provide Code Structure**
```
GOOD: [Upload multiple related files]
"Here's the main file, header, and the calling function"

This gives Claude better context
```

### DON'Ts ✗

**1. Don't Paste Entire Systems**
```
BAD: [Uploads 50,000 lines at once]

GOOD: Focus on specific modules or functions
Break large requests into smaller pieces
```

**2. Don't Include Sensitive Data**
```
BAD: [Paste code with production credentials, real customer data]

GOOD: Replace sensitive data with placeholders:
- Production IPs → "xxx.xxx.xxx.xxx"
- API keys → "YOUR_API_KEY_HERE"  
- Customer data → Sample/test data
```

**3. Don't Expect Claude to Run/Compile Code**
```
Claude cannot:
- Compile your TPF programs
- Run your code
- Access your TPF system
- Execute tests

Claude CAN:
- Analyze code statically
- Identify issues by inspection
- Suggest improvements
- Explain how to test
```

**4. Don't Use Unclear Prompts**
```
BAD: "Make this better"

GOOD: "Improve this function's error handling and add 
comments explaining the TPFDF operations"
```

**5. Don't Blindly Copy Code**
```
BAD: Copy Claude's code → Paste in production → Deploy

GOOD: Copy Claude's code → Understand it → Test it → 
Review with team → Deploy
```

---

## 6. Understanding Claude's Responses

### What Claude Can Tell You

**Code Analysis:**
- "This function has a memory leak on line 47"
- "The lock order on lines 120-125 could cause deadlock"
- "This buffer overflow occurs when input > 256 bytes"

**Explanations:**
- "This code implements a round-robin scheduler..."
- "The ECB is used here to synchronize..."
- "This TPFDF operation locks the record for update"

**Suggestions:**
- "Consider using a hash table instead of linear search"
- "Replace manual memory management with RAII pattern"
- "Add error logging at lines 78 and 92"

**Code Examples:**
```cpp
// Claude will show you actual code like:
void improved_function() {
    // Proper error handling
    if (validate_input() != SUCCESS) {
        log_error("Invalid input");
        return ERROR;
    }
    // ... rest of code
}
```

### What Claude Cannot Do

❌ **Access your systems**
- Cannot read files from your TPF system
- Cannot run your code
- Cannot deploy changes
- Cannot access your network

❌ **Execute or compile**
- Cannot compile your C++ code
- Cannot run tests
- Cannot measure actual performance

❌ **Make business decisions**
- Cannot decide what features to add
- Cannot prioritize your work
- Cannot approve code for production

✓ **What you should do:**
- Test Claude's suggestions yourself
- Review with your team
- Follow your normal deployment process
- Use Claude as a helpful assistant, not a replacement for your expertise

---

## 7. Common z/TPF Questions to Ask Claude

### Understanding Code
```
"Explain what this TPF entry point does"
"What is this ECB handling code doing?"
"How does this TPFDF operation work?"
"What's the flow of data through this function?"
```

### Debugging
```
"Why am I getting SERRC error 0x04B?"
"This code is causing a protection exception. What could be wrong?"
"My program hangs when processing high load. Where should I look?"
"How do I debug a timing issue in TPF?"
```

### Code Quality
```
"Review this code for memory leaks"
"Check for thread safety issues"
"Are there any buffer overflows here?"
"What TPF best practices am I violating?"
```

### Performance
```
"How can I make this faster?"
"What's causing the performance bottleneck?"
"Is this algorithm efficient for real-time processing?"
"How do I optimize this database access?"
```

### Modernization
```
"How do I convert this C code to C++?"
"Can I use STL containers in TPF?"
"What modern C++ features work in z/TPF?"
"How do I refactor this legacy code?"
```

### Integration
```
"How do I call this from another TPF program?"
"What's the best way to share data between programs?"
"How do I integrate with external systems?"
"What's the proper way to use global areas?"
```

---

## 8. Sample Conversations (Real Examples)

### Conversation 1: Quick Question

```
YOU: "In z/TPF, what's the difference between tpfdf_lrec 
and tpfdf_read?"

CLAUDE: "In z/TPF's TPFDF (TPF Database Facility):

tpfdf_lrec (Lock and Read):
- Reads a record AND locks it
- Used when you'll update the record
- Locks: LOCK_READ, LOCK_WRITE, or LOCK_EXCL
- Must call tpfdf_urec to unlock
- Example:
  rc = tpfdf_lrec(file, key, &rec, LOCK_WRITE);
  // Modify rec
  rc = tpfdf_wrec(file, key, &rec);
  rc = tpfdf_urec(file, key);

tpfdf_read (Read Only):
- Reads without locking
- Used for queries/lookups
- Faster, no lock overhead
- No need to unlock
- Example:
  rc = tpfdf_read(file, key, &rec);
  // Just read the data

Use tpfdf_lrec when updating, tpfdf_read when only reading."

YOU: "Thanks! That's clear."
```

### Conversation 2: Detailed Debug Session

```
YOU: [Uploads PROCESS_BOOKING.c]
"This booking processing code is failing intermittently 
with SERRC 0x04B. It happens maybe 1 in 1000 transactions. 
Very hard to reproduce. Help!"

CLAUDE: [Analyzes code]
"SERRC 0x04B typically means 'Record Locked' in TPFDF. 
The intermittent nature suggests a race condition.

I found the issue at lines 145-167:

[Claude highlights specific code section]

Problem: You're calling tpfdf_read (no lock), then later 
trying to write the record. Between read and write, another 
process can lock it.

Solution: Use tpfdf_lrec from the start:
[Shows corrected code]

Also found at line 203: Missing tpfdf_urec call in error path.
This orphans locks and causes exactly this intermittent issue.

Add proper cleanup:
[Shows fix]"

YOU: "Oh! So the orphaned locks cause other transactions 
to fail. That makes sense why it's random."

CLAUDE: "Exactly! The orphaned lock persists until timeout, 
blocking random later transactions. Your error handling 
path needs cleanup."

YOU: "Can you show the complete corrected version?"

CLAUDE: [Provides full corrected function with all fixes]
```

### Conversation 3: Learning New Pattern

```
YOU: "I'm new to z/TPF. How do I properly handle errors 
from TPFDF operations? Show me the standard pattern."

CLAUDE: "Here's the standard z/TPF error handling pattern 
for TPFDF:

[Shows complete example with:
- Return code checking
- Error logging
- Resource cleanup
- Error propagation
- Recovery strategies]

Key principles:
1. Always check return codes
2. Log errors with context
3. Clean up resources (unlock, free)
4. Return meaningful errors upstream
5. Use consistent error codes

Common mistakes to avoid:
- Ignoring return codes
- Forgetting to unlock on error
- Not logging transaction context
- Swallowing errors"

YOU: "What about timeout situations?"

CLAUDE: [Explains timeout handling in TPF context]

YOU: "Can I use exceptions instead?"

CLAUDE: "In z/TPF, exceptions have considerations:
[Explains pros/cons, shows when to use exceptions vs 
error codes in real-time systems]"
```

---

## 9. Tips for Effective Collaboration with Claude

### Start Simple, Go Deeper

**Level 1: Basic Question**
```
"What does this function do?"
```

**Level 2: More Context**
```
"What does this function do? I need to modify it to 
handle a new transaction type."
```

**Level 3: Complete Context**
```
"What does this function do? I need to modify it to handle 
a new transaction type (TYPE_X) that includes passenger 
meal preferences. The current code handles TYPE_A and TYPE_B. 
We need to maintain backward compatibility and subsecond 
response time."
```

More context = Better answers!

### Build on Previous Responses

```
YOU: "Review this code for issues"
CLAUDE: [Finds 5 issues]

YOU: "Focus on issue #3, the thread safety problem. 
     Show me how to fix it."
CLAUDE: [Detailed fix for issue #3]

YOU: "Will that fix impact performance?"
CLAUDE: [Performance analysis]

YOU: "What if we have 100 concurrent threads?"
CLAUDE: [Scaling considerations]
```

Each response builds on the last - keep the conversation going!

### Ask for Alternatives

```
YOU: "How should I implement this feature?"
CLAUDE: [Suggests approach A]

YOU: "Are there other ways to do this?"
CLAUDE: [Suggests approaches B and C]

YOU: "Which is best for high-volume transactions?"
CLAUDE: [Compares with recommendations]
```

### Request Explanations

```
YOU: "Why did you suggest using a memory pool?"
CLAUDE: [Explains reasoning]

YOU: "Can you show me the performance difference?"
CLAUDE: [Provides analysis]

YOU: "What are the tradeoffs?"
CLAUDE: [Discusses pros and cons]
```

---

## 10. Troubleshooting Common Issues

### Problem: "Claude doesn't understand my z/TPF code"

**Solution:** Add context at the start:
```
"This is z/TPF (Transaction Processing Facility) code.
Key details:
- Real-time operating system
- Single-level storage
- TPFDF database operations
- ECB-based programming model

[Then paste your code]"
```

### Problem: "The suggestions don't work in my environment"

**Solution:** Be explicit about constraints:
```
"Important: In z/TPF we cannot use:
- Dynamic memory allocation in transaction path
- Standard C++ exceptions (real-time constraints)
- STL containers (not available)
- Multi-threading (single-threaded model)

Given these constraints, how should I..."
```

### Problem: "I pasted code but Claude misunderstood"

**Solution:** Clarify with more details:
```
"Let me clarify:
- This function runs on every transaction (called 1000s/sec)
- The 'key' variable is a fixed 8-byte TPFDF key
- This needs to complete in under 50 microseconds
- Here's the code again with more comments..."
```

### Problem: "Response was too generic"

**Solution:** Ask for specifics:
```
Instead of: "How do I optimize this?"

Ask: "This function takes 80 microseconds but needs 
to run in 50. The profiler shows 60% time in the 
database read at line 45. How specifically can I 
make that read faster?"
```

### Problem: "I need to share multiple files"

**Solution:** Upload them one at a time and explain relationship:
```
YOU: [Upload FILE1.c]
"This is the main processing file"

[Upload FILE1.h]  
"This is its header with structures"

[Upload COMMON.h]
"This has shared definitions"

"Now, my question is about the function process_record() 
in FILE1.c that uses structures from FILE1.h..."
```

---

## 11. Quick Reference Card

### When You Need to...

| Task | What to Say to Claude |
|------|----------------------|
| Understand code | "Explain what this code does" |
| Find bugs | "Review this for bugs and issues" |
| Optimize performance | "How can I make this faster?" |
| Add a feature | "I need to add [X]. Here's the existing code..." |
| Fix a crash | "This crashes with [error]. Here's the code..." |
| Modernize code | "Update this old C code to modern C++" |
| Write tests | "Create unit tests for this function" |
| Document code | "Generate documentation for this" |
| Compare options | "What's the best way to [X]? Show alternatives" |
| Learn a pattern | "Show me the standard pattern for [X] in TPF" |

### Quick Prompts You Can Copy

```
📋 Code Review:
"Review this z/TPF code for memory leaks, race conditions, 
and TPF best practices violations: [paste code]"

📋 Debug Help:
"I'm getting [error] in this code. What's wrong? [paste code]"

📋 Explanation:
"Explain this z/TPF function line by line: [paste code]"

📋 Optimization:
"This function needs to be faster. Current time: [X]ms, 
Target: [Y]ms. Code: [paste]"

📋 Modernization:
"Convert this legacy C code to modern C++ while keeping 
it compatible with z/TPF: [paste code]"

📋 Documentation:
"Create comprehensive documentation for this code including 
usage examples: [paste code]"
```

---

## 12. Real Success Stories (What Others Do)

### Developer A: Bug Hunter
"I paste every function I write into Claude for review before 
committing. It catches 80% of bugs before code review. Saves 
hours of back-and-forth with the team."

### Developer B: Legacy Code Explorer
"When I need to modify old code, I upload the file and ask 
Claude to explain it. In 5 minutes I understand code that 
would have taken days to figure out."

### Developer C: Performance Optimizer
"I paste our slow functions and ask for optimization suggestions. 
Claude found inefficiencies our profiler didn't highlight. 
Cut response time by 40%."

### Developer D: Documentation Generator
"I upload undocumented modules and get comprehensive docs in 
minutes. Would have taken weeks manually. Now our codebase is 
fully documented."

### Team E: Code Modernization
"We're migrating from C to C++. Claude helps us understand 
safe modernization approaches for TPF real-time constraints. 
Project is ahead of schedule."

---

## 13. Your First Session Checklist

Ready to try Claude? Follow this checklist:

**Before You Start:**
- [ ] Go to claude.ai and sign in
- [ ] Find a code file you want help with
- [ ] Identify your specific question or problem
- [ ] Have any error messages ready to paste

**Your First Conversation:**
- [ ] Introduce your context: "I'm working on z/TPF..."
- [ ] Upload or paste your code file
- [ ] Ask one specific question
- [ ] Read Claude's response carefully
- [ ] Ask follow-up questions

**After First Session:**
- [ ] Save useful responses for reference
- [ ] Try with another file or problem
- [ ] Share success with your team
- [ ] Bookmark helpful prompts

---

## 14. Getting Help

### If Claude's Suggestion Seems Wrong
1. Ask "Why did you suggest that?"
2. Explain your constraints: "In z/TPF we can't do that because..."
3. Request alternatives: "Given those limitations, what else could work?"

### If You're Stuck
1. Start a new conversation (fresh context)
2. Break your problem into smaller pieces
3. Ask for explanations before solutions
4. Share more context about your environment

### If You Need More Help
- Claude documentation: docs.claude.com
- Support: support.claude.com
- Your team members who are using Claude

---

## 15. Next Steps

### Week 1: Get Comfortable
- [ ] Try 3 simple questions
- [ ] Upload and analyze one file
- [ ] Ask for code review on something you wrote

### Week 2: Go Deeper  
- [ ] Debug a real issue with Claude
- [ ] Generate documentation for a module
- [ ] Optimize a performance problem

### Week 3: Make it Habit
- [ ] Review every new function with Claude
- [ ] Use for understanding legacy code
- [ ] Share helpful prompts with team

### Week 4: Expand Usage
- [ ] Help team members get started
- [ ] Document best practices for your team
- [ ] Measure productivity improvements

---

## Conclusion

**Remember:**
- Claude is a tool to help you, not replace you
- Start with simple questions
- Provide context about z/TPF
- Ask follow-up questions
- Always test and review suggestions
- Share knowledge with your team

**You're ready to start!**
Go to claude.ai and paste your first code snippet.

**Good luck! 🚀**

---

## Appendix: Common z/TPF Terms Claude Understands

Claude knows these z/TPF concepts (use them freely):
- TPF/TPFDF operations
- ECB (Event Control Block)
- Entry points
- Global areas  
- SERRC/error codes
- Record locking (LOCK_READ, LOCK_WRITE)
- Core files
- DASD operations
- Single-level storage
- Real-time constraints
- Subsecond response requirements
- PNR (Passenger Name Record)
- Flight inventory systems
- Credit card processing patterns

If you use these terms, Claude will understand your context better!
