# config.py
import os
from typing import List
from pydantic_settings import BaseSettings
from dotenv import load_dotenv

load_dotenv('.env')


class BaseConfig(BaseSettings):
    # API Settings
    PROJECT_NAME: str = "SmartQL API"
    VERSION: str = "1.0.0"
    API_V1_STR: str = "/api/v1"

    # Server Settings
    HOST: str = "127.0.0.1"
    PORT: int = 8000
    ALTERNATE_PORTS: List[int] = [8000, 8001, 8002, 8003, 8004]
    ALLOWED_HOSTS: List[str] = ["*"]

    # CORS Settings
    BACKEND_CORS_ORIGINS: List[str] = [
        "http://localhost:3000",
        "http://localhost:8000",
        "http://localhost:8080",
        "http://127.0.0.1:8080",
        "*"  # Allow all origins in development
    ]

    # Database Settings
    DB_HOST: str = "103.185.74.157"
    DB_USER: str = "root"
    DB_PASSWORD: str = "Onlykajal111#"
    DB_NAME: str = "smart_ql"
    DB_PORT: int = 3306

    @property
    def DATABASE_URL(self) -> str:
        return f"mysql+pymysql://{self.DB_USER}:{self.DB_PASSWORD}@{self.DB_HOST}:{self.DB_PORT}/{self.DB_NAME}"

    # Database Pool Settings
    DB_POOL_SIZE: int = 5
    DB_MAX_OVERFLOW: int = 10
    DB_ECHO: bool = False
    DB_POOL_TIMEOUT: int = 30
    DB_POOL_RECYCLE: int = 3600

    # Logging Settings
    LOG_LEVEL: str = "INFO"
    ACCESS_LOG: bool = True
    LOG_FORMAT: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

    # Security Settings
    SECRET_KEY: str = os.getenv("SECRET_KEY", "sQAz6NYnOAzNVKQYGU7ZOzZh0aPpF9ZJRzBKBRB0BnlxKKZeIRu6Hg5qfCOZFPzK")
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7
    REFRESH_TOKEN_SECRET: str = os.getenv("REFRESH_TOKEN_SECRET", "sQAz6NYnOAzNVKQYGU7ZOzZh0aPpF9ZJRzBKBRB0BnlxKKZeIRu6Hg5qfCOZFPzK")

    # Rate Limiting
    RATE_LIMIT_ENABLED: bool = True
    RATE_LIMIT_REQUESTS: int = 100
    RATE_LIMIT_PERIOD: int = 60  # seconds

    class Config:
        case_sensitive = True


class DevelopmentConfig(BaseConfig):
    DEBUG: bool = True
    DB_ECHO: bool = True
    LOG_LEVEL: str = "DEBUG"

    # Development CORS settings
    BACKEND_CORS_ORIGINS: List[str] = [
        "http://localhost:3000",
        "http://localhost:8000",
        "http://localhost:8080",
        "*"
    ]

    # Relaxed rate limiting for development
    RATE_LIMIT_REQUESTS: int = 1000
    RATE_LIMIT_PERIOD: int = 60


class ProductionConfig(BaseConfig):
    DEBUG: bool = False
    DB_ECHO: bool = False
    LOG_LEVEL: str = "WARNING"
    ACCESS_LOG: bool = False

    # Strict CORS for production
    BACKEND_CORS_ORIGINS: List[str] = [
        "https://your-production-frontend.com"
    ]
    ALLOWED_HOSTS: List[str] = [
        "your-domain.com",
        "api.your-domain.com"
    ]

    # Stricter rate limiting for production
    RATE_LIMIT_REQUESTS: int = 100
    RATE_LIMIT_PERIOD: int = 60

    # Larger connection pool for production
    DB_POOL_SIZE: int = 20
    DB_MAX_OVERFLOW: int = 30


def get_config():
    env = os.getenv("ENVIRONMENT", "development")
    config_type = {"development": DevelopmentConfig, "production": ProductionConfig}
    return config_type.get(env, DevelopmentConfig)()


# Create settings instance
settings = get_config()