#  Smart-QL Application

## Setup
1. Create virtual environment: `python -m venv venv`
2. Activate virtual environment: `source venv/bin/activate`
3. Install dependencies: `pip install -r requirements.txt`
4. Set up environment variables in `.env`
5. Initialize database: `flask db init`
6. Run migrations: `flask db migrate`
7. Run the application: `flask run`

## Testing
- Run tests: `pytest`
- Run with coverage: `pytest --cov=app tests/`

## Development
- Format code: `black app/`
- Check style: `flake8 app/`
##
CREATE DATABASE quick_sense_dev;

-- Create a new user and grant permissions
CREATE USER 'quick_sense_user'@'localhost' IDENTIFIED BY 'your_password';
GRANT ALL PRIVILEGES ON quick_sense_dev.* TO 'quick_sense_user'@'localhost';
FLUSH PRIVILEGES;


## Application Metadata
--Application Meta Data stored in the database(MYSQL)
-- Data Sources Table
CREATE TABLE IF NOT EXISTS data_sources (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    vendor ENUM('mysql', 'postgresql', 'mongodb', 'oracle', 'sqlserver') NOT NULL,
    connection_type ENUM('direct', 'ssh', 'cloud') NOT NULL,
    credentials JSON NOT NULL,
    database_config JSON NOT NULL,
    ssh_config JSON,
    cloud_config JSON,
    status ENUM('pending', 'active', 'inactive', 'error') DEFAULT 'pending',
    
    -- Metadata
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by VARCHAR(255),
    updated_by VARCHAR(255),
    tags JSON DEFAULT (JSON_ARRAY()),
    
    -- Connection stats
    active_connections INT DEFAULT 0,
    total_connections INT DEFAULT 0,
    last_connected_at DATETIME,
    last_error TEXT,
    error_count INT DEFAULT 0,
    
    -- Sync History
    last_sync_at DATETIME,
    last_sync_status ENUM('pending', 'in_progress', 'completed', 'failed'),
    last_sync_error TEXT,
    total_sync_count INT DEFAULT 0,
    current_schema_hash VARCHAR(64),
    
    -- Indexes
    INDEX idx_datasource_name (name),
    INDEX idx_datasource_status (status),
    INDEX idx_datasource_last_sync (last_sync_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Schema Analysis Table
CREATE TABLE IF NOT EXISTS schema_analysis (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    database_source_id VARCHAR(36) NOT NULL,
    analysis_type ENUM('basic', 'enhanced') NOT NULL,
    status ENUM('pending', 'in_progress', 'completed', 'failed') NOT NULL,
    analysis_result JSON COMMENT 'Analysis results including:
        - data quality metrics
        - suggestions
        - warnings
        - performance metrics',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP,
    error_message TEXT,
    FOREIGN KEY (database_source_id) REFERENCES data_sources(id) ON DELETE CASCADE,
    KEY idx_status (status),
    KEY idx_analysis_type (analysis_type),
    KEY idx_database_source (database_source_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sync History Table
CREATE TABLE IF NOT EXISTS sync_history (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    database_source_id VARCHAR(36) NOT NULL,
    sync_type ENUM('full', 'incremental') NOT NULL,
    status ENUM('pending', 'in_progress', 'completed', 'failed') NOT NULL,
    changes_detected JSON COMMENT 'Schema changes detected',
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    error_message TEXT,
    FOREIGN KEY (database_source_id) REFERENCES data_sources(id) ON DELETE CASCADE,
    KEY idx_status (status),
    KEY idx_database_source (database_source_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;