from smart_ql.assistants.sql_assistant.config.db_config import DBConfig
from smart_ql.assistants.sql_assistant.schema_extractors.mysql_extractor import DatabaseVendor, MySQLSchemaExtractor
from smart_ql.features.sql_generator.sql_utility import SQLGenerator


# Example usage
async def main():
    # Initialize generator
    generator = SQLGenerator(
        anthropic_api_key="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"
    )

    config = DBConfig(
        vendor=DatabaseVendor.MYSQL,
        host="103.185.74.157",
        port=3306,
        database="alpha_ai_service",
        username="root",
        password="Onlykajal111#"
    )

    try:
        extractor = MySQLSchemaExtractor(config)
        schema = await extractor.extract_schema()
        print(schema.model_dump_json(indent=2))
        user_id = "user123"
        connection_id = "conn456"

        # Store schema
        await generator.schema_store.store_schema(
            schema.dict(),
            user_id,
            connection_id
        )

        # Generate query
        query = await generator.generate_query(
            "Find recent API keys",
            user_id,
            connection_id

        )
        print(f"\nGenerated Query:\n{query}")
      #  print(schema.model_dump_json(indent=2))  # Updated to use model_dump_json
    except Exception as e:
        print(f"Error: {str(e)}")

if __name__ == "__main__":
    import asyncio

    asyncio.run(main())