from typing import Optional
from pydantic import BaseModel, Field

from smart_ql.assistants.sql_assistant.schema_extractors.schemas import DatabaseVendor


class DBConfig(BaseModel):
    """Database connection configuration."""
    vendor: DatabaseVendor
    host: str = Field(default="localhost")
    port: int
    database: str
    username: str
    password: str
    db_schema: Optional[str] = Field(default=None, description="Database schema name")

    # Vendor-specific settings
    sid: Optional[str] = None  # For Oracle
    service_name: Optional[str] = None  # For Oracle
    windows_auth: Optional[bool] = False  # For SQL Server

    model_config = {
        "arbitrary_types_allowed": True
    }

    def connection_url(self) -> str:
        """Generate database connection URL based on vendor and configuration."""
        if self.vendor == DatabaseVendor.MYSQL:
            return f"mysql+pymysql://{self.username}:{self.password}@{self.host}:{self.port}/{self.database}"

        elif self.vendor == DatabaseVendor.POSTGRES:
            base_url = f"postgresql://{self.username}:{self.password}@{self.host}:{self.port}/{self.database}"
            if self.schema:
                base_url += f"?options=-csearch_path%3D{self.schema}"
            return base_url

        elif self.vendor == DatabaseVendor.SQLITE:
            return f"sqlite:///{self.database}"

        elif self.vendor == DatabaseVendor.ORACLE:
            if self.sid:
                return f"oracle://{self.username}:{self.password}@{self.host}:{self.port}/?service_name={self.sid}"
            elif self.service_name:
                return f"oracle://{self.username}:{self.password}@{self.host}:{self.port}/?service_name={self.service_name}"
            else:
                raise ValueError("Either SID or SERVICE_NAME must be provided for Oracle connections")

        elif self.vendor == DatabaseVendor.SQLSERVER:
            auth = "trusted" if self.windows_auth else f"{self.username}:{self.password}"
            return f"mssql://{auth}@{self.host}:{self.port}/{self.database}"

        else:
            raise ValueError(f"Unsupported database vendor: {self.vendor}")