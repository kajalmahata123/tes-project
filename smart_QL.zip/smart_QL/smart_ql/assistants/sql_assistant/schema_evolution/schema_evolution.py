import asyncio
from dataclasses import dataclass, asdict
from typing import Dict, List, Optional
import json
from anthropic import Anthropic
import logging
# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class Change:
    """Represents a suggested schema change"""
    change: str
    definition: Dict
    impact: str


@dataclass
class RiskAssessment:
    """Represents the risk assessment for schema changes"""
    high_risks: List[str]
    medium_risks: List[str]
    low_risks: List[str]


@dataclass
class EstimatedImpact:
    """Represents the estimated impact of schema changes"""
    performance: str
    data_integrity: str
    application_compatibility: str


@dataclass
class SchemaEvolutionPlan:
    """AI-generated schema evolution plan"""
    suggested_changes: List[Change]
    risk_assessment: RiskAssessment
    migration_steps: List[str]
    rollback_steps: List[str]
    estimated_impact: EstimatedImpact

    def to_dict(self) -> Dict:
        """Convert the plan to a dictionary."""
        return asdict(self)


class AISchemaEvolution:
    """Advanced AI-powered schema evolution planning."""

    def __init__(self, ai_client: Anthropic):
        """Initialize the AI Schema Evolution planner.

        Args:
            ai_client: Anthropic client instance
        """
        self.client = ai_client
        self.model = "claude-3-sonnet-20240229"

    async def _make_ai_request(self, prompt: str) -> Dict:
        """Make a request to the AI model and handle the response.

        Args:
            prompt: The prompt to send to the AI model

        Returns:
            Dict containing the parsed JSON response

        Raises:
            json.JSONDecodeError: If response cannot be parsed as JSON
            ValueError: If response is missing required fields
        """
        try:
            response =  self.client.messages.create(
                max_tokens=4096,
                model=self.model,
                messages=[{
                    "role": "user",
                    "content": prompt
                }]
            )

            content = response.content[0].text
            # Clean up any markdown formatting
            content = content.replace('```json', '').replace('```', '').strip()

            return json.loads(content)

        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse JSON response: {e}")
            logger.debug(f"Raw response content: {content}")
            raise
        except Exception as e:
            logger.error(f"Error making AI request: {e}")
            raise

    async def plan_schema_evolution(
            self,
            current_schema: Dict,
            requirements: str
    ) -> SchemaEvolutionPlan:
        """Generate intelligent schema evolution plan.

        Args:
            current_schema: Current database schema
            requirements: New requirements to implement

        Returns:
            SchemaEvolutionPlan containing suggested changes and impact analysis
        """
        prompt = self._create_evolution_prompt(current_schema, requirements)

        try:
            plan_data = await self._make_ai_request(prompt)

            # Validate response structure
            required_keys = {
                'suggested_changes', 'risk_assessment', 'migration_steps',
                'rollback_steps', 'estimated_impact'
            }
            missing_keys = required_keys - set(plan_data.keys())
            if missing_keys:
                raise ValueError(f"Missing required keys in response: {missing_keys}")

            # Convert nested dictionaries to appropriate classes
            risk_assessment = RiskAssessment(**plan_data['risk_assessment'])
            estimated_impact = EstimatedImpact(**plan_data['estimated_impact'])
            changes = [Change(**change) for change in plan_data['suggested_changes']]

            return SchemaEvolutionPlan(
                suggested_changes=changes,
                risk_assessment=risk_assessment,
                migration_steps=plan_data['migration_steps'],
                rollback_steps=plan_data['rollback_steps'],
                estimated_impact=estimated_impact
            )

        except Exception as e:
            logger.error(f"Error in plan_schema_evolution: {e}")
            raise

    async def validate_evolution_impact(
            self,
            current_schema: Dict,
            proposed_schema: Dict
    ) -> Dict:
        """Analyze potential impacts of schema evolution.

        Args:
            current_schema: Current database schema
            proposed_schema: Proposed new schema

        Returns:
            Dict containing impact analysis
        """
        prompt = self._create_validation_prompt(current_schema, proposed_schema)
        return await self._make_ai_request(prompt)

    def _create_evolution_prompt(self, current_schema: Dict, requirements: str) -> str:
        """Create the prompt for schema evolution planning."""
        return f"""
        Analyze current schema and requirements to suggest optimal evolution plan:

        Current Schema: {json.dumps(current_schema, indent=2)}
        New Requirements: {requirements}

        You must return ONLY a JSON object in exactly this format:
        {{
            "suggested_changes": [
                {{
                    "change": "string",
                    "definition": {{}},
                    "impact": "string"
                }}
            ],
            "risk_assessment": {{
                "high_risks": [],
                "medium_risks": [],
                "low_risks": []
            }},
            "migration_steps": [
                "step 1",
                "step 2"
            ],
            "rollback_steps": [
                "rollback step 1",
                "rollback step 2"
            ],
            "estimated_impact": {{
                "performance": "string",
                "data_integrity": "string",
                "application_compatibility": "string"
            }}
        }}

        The response must be ONLY the JSON object, with no additional text or markdown formatting.
        Ensure all JSON is properly formatted with double quotes around keys and string values.
        """

    def _create_validation_prompt(self, current_schema: Dict, proposed_schema: Dict) -> str:
        """Create the prompt for impact validation."""
        return f"""
        Analyze impact of proposed schema changes:

        Current Schema: {json.dumps(current_schema, indent=2)}
        Proposed Schema: {json.dumps(proposed_schema, indent=2)}

        Return ONLY a JSON object in exactly this format:
        {{
            "breaking_changes": [
                {{
                    "change": "string",
                    "severity": "string",
                    "affected_components": []
                }}
            ],
            "performance_impact": {{
                "read_operations": "string",
                "write_operations": "string",
                "index_usage": "string"
            }},
            "migration_complexity": {{
                "level": "string",
                "factors": [],
                "estimated_time": "string"
            }},
            "compatibility_risks": [
                {{
                    "risk": "string",
                    "mitigation": "string"
                }}
            ],
            "optimization_opportunities": [
                {{
                    "opportunity": "string",
                    "benefit": "string"
                }}
            ]
        }}

        The response must be ONLY the JSON object, with no additional text or markdown formatting.
        Ensure all JSON is properly formatted with double quotes around keys and string values.
        """


async def main():
    """Main function to demonstrate schema evolution planning."""
    try:
        # Sample schema
        sample_schema = {
            "tables": {
                "users": {
                    "columns": {
                        "id": {"type": "integer", "primary_key": True},
                        "email": {"type": "varchar", "max_length": 255},
                        "status": {"type": "varchar", "max_length": 20}
                    }
                },
                "orders": {
                    "columns": {
                        "id": {"type": "integer", "primary_key": True},
                        "user_id": {"type": "integer"},
                        "total": {"type": "decimal", "precision": 10, "scale": 2}
                    }
                }
            },
            "relationships": [
                {
                    "from_table": "orders",
                    "to_table": "users",
                    "from_column": "user_id",
                    "to_column": "id"
                }
            ]
        }

        # Initialize AI client
        api_key = "your-api-key-here"  # Replace with your actual API key
        ai_client = Anthropic(api_key='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')

        # Initialize evolution planner
        evolution_planner = AISchemaEvolution(ai_client)

        # Plan schema evolution
        logger.info("Planning schema evolution...")
        evolution_plan = await evolution_planner.plan_schema_evolution(
            sample_schema,
            "Add support for order items and product categories"
        )

        # Print results
        logger.info("Schema Evolution Plan:")
        print(json.dumps(evolution_plan.to_dict(), indent=2))

    except Exception as e:
        logger.error(f"Error in main: {e}")
        raise


if __name__ == "__main__":
    asyncio.run(main())