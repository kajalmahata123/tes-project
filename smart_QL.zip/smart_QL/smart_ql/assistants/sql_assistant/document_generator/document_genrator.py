import asyncio
from dataclasses import dataclass
from typing import Dict, List
import json
from anthropic import Anthropic
import logging
logger = logging.getLogger(__name__)
@dataclass
class DocumentationPackage:
    """Complete schema documentation package"""
    technical_docs: Dict
    api_docs: Dict
    developer_guides: Dict
    admin_guides: Dict
    #diagrams: Dict
    #examples: Dict


class AIDocumentationGenerator:
    """Advanced AI-powered documentation generation."""

    def __init__(self, ai_client: Anthropic):
        self.client = ai_client
        self.model = "claude-3-sonnet-20240229"

    async def generate_complete_documentation(
            self,
            schema: Dict,
            context: str
    ) -> DocumentationPackage:
        """Generate comprehensive documentation package."""
        docs = DocumentationPackage(
            technical_docs=await self._generate_technical_docs(schema),
            api_docs=await self._generate_api_docs(schema),
            developer_guides=await self._generate_developer_guides(schema, context),
            admin_guides=await self._generate_admin_guides(schema),
            #diagrams=await self._generate_diagrams(schema),
            #examples=await self._generate_examples(schema)
        )
        return docs

    async def _generate_technical_docs(self, schema: Dict) -> Dict:
        """Generate technical documentation."""
        prompt = f"""
        Generate comprehensive technical documentation for:
        {json.dumps(schema, indent=2)}

        Include:
        1. Schema overview
        2. Table relationships
        3. Constraints and indexes
        4. Performance considerations
        5. Security measures

        Format in Markdown with clear sections and examples.
        """

        response =  self.client.messages.create(
            model=self.model,
            messages=[{"role": "user", "content": prompt}]
        )

        return {"content": response.content[0].text}

    async def _generate_api_docs(self, schema: Dict) -> Dict:
        """Generate API documentation."""
        prompt = f"""
        Create API documentation based on this schema:
        {json.dumps(schema, indent=2)}

        Include:
        1. REST endpoints
        2. Request/response formats
        3. Authentication methods
        4. Error handling
        5. Rate limiting

        Include example requests and responses.
        """

        response =  self.client.messages.create(
            model=self.model,
            messages=[{"role": "user", "content": prompt}]
        )

        return {"content": response.content[0].text}



    async def _generate_technical_docs(self, schema: Dict) -> str:
        """Generate technical documentation from schema."""
        prompt = self._create_technical_docs_prompt(schema)
        response =  self.client.messages.create(
            model=self.model,
            max_tokens=4096,
            messages=[{
                "role": "user",
                "content": prompt
            }]
        )
        return response.content

    async def _generate_api_docs(self, schema: Dict) -> str:
        """Generate API documentation from schema."""
        prompt = self._create_api_docs_prompt(schema)
        response =  self.client.messages.create(
            model=self.model,
            max_tokens=4096,
            messages=[{
                "role": "user",
                "content": prompt
            }]
        )
        return response.content

    async def _generate_developer_guides(self, schema: Dict, context: str) -> str:
        """Generate developer guides with contextual information."""
        prompt = self._create_developer_guides_prompt(schema, context)
        response =  self.client.messages.create(
            max_tokens=4096,
            model=self.model,
            messages=[{"role": "user", "content": prompt}]
        )
        return response.content

    async def _generate_admin_guides(self, schema: Dict) -> str:
        """Generate administration guides from schema."""
        prompt = self._create_admin_guides_prompt(schema)
        response =  self.client.messages.create(
            max_tokens=4096,
            model=self.model,
            messages=[{"role": "user", "content": prompt}]
        )
        return response.content

    async def _generate_diagrams(self, schema: Dict) -> Dict:
        """Generate relevant diagrams from schema."""
        prompt = f"""
        Generate system diagrams for:
        {json.dumps(schema, indent=2)}

        Include:
        1. Entity Relationship Diagram (ERD)
        2. System Architecture Diagram
        3. Data Flow Diagram
        4. Component Interaction Diagram

        Format each diagram as a detailed textual description.
        """

        response =  self.client.messages.create(
            model=self.model,
            max_tokens=4096,
            messages=[{
                "role": "user",
                "content": prompt
            }]
        )

        return self._parse_diagrams_response(response.content)

    async def _generate_examples(self, schema: Dict) -> Dict:
        """Generate code examples from schema."""
        prompt = f"""
        Generate code examples for:
        {json.dumps(schema, indent=2)}

        Include:
        1. CRUD operations
        2. Common queries
        3. Data validation
        4. Error handling
        5. Best practices

        Provide examples in multiple languages (Python, SQL, REST).
        """

        response = await self.client.messages.create(
            model=self.model,
            max_tokens=4096,
            messages=[{
                "role": "user",
                "content": prompt
            }]
        )

        # Get the content from the response message
        content = response.content[0].text if isinstance(response.content, list) else response.content
        return self._parse_examples_response(content)

    def _parse_examples_response(self, content: str) -> Dict:
        """Parse the AI response into a structured examples dictionary."""
        examples = {
            "python": [],
            "sql": [],
            "rest": [],
            "validation": [],
            "error_handling": []
        }

        sections = content.split('\n\n')
        current_section = None

        for section in sections:
            section = section.strip()
            if not section:
                continue

            if "```python" in section.lower():
                current_section = "python"
                examples["python"].append(section)
            elif "```sql" in section.lower():
                current_section = "sql"
                examples["sql"].append(section)
            elif "```http" in section.lower() or "```curl" in section.lower():
                current_section = "rest"
                examples["rest"].append(section)
            elif "validation" in section.lower():
                current_section = "validation"
                examples["validation"].append(section)
            elif "error" in section.lower():
                current_section = "error_handling"
                examples["error_handling"].append(section)
            elif current_section:
                examples[current_section].append(section)

        return {
            "examples": examples,
            "content": content
        }

    def _create_technical_docs_prompt(self, schema: Dict) -> str:
        """Create prompt for technical documentation generation."""
        return f"""Please generate comprehensive technical documentation for the following schema:
                  {schema}
                  Include detailed explanations of all components, their relationships, and technical specifications."""

    def _create_api_docs_prompt(self, schema: Dict) -> str:
        """Create prompt for API documentation generation."""
        return f"""Please generate detailed API documentation for the following schema:
                  {schema}
                  Include endpoints, request/response formats, authentication requirements, and example calls."""

    def _create_developer_guides_prompt(self, schema: Dict, context: str) -> str:
        """Create prompt for developer guides generation."""
        return f"""Please generate developer guides for the following schema with this context:
                  Schema: {schema}
                  Context: {context}
                  Include setup instructions, best practices, and common use cases."""

    def _create_admin_guides_prompt(self, schema: Dict) -> str:
        """Create prompt for admin guides generation."""
        return f"""Please generate administration guides for the following schema:
                  {schema}
                  Include deployment instructions, maintenance procedures, and troubleshooting guides."""

    def _create_diagrams_prompt(self, schema: Dict) -> str:
        """Create prompt for diagram generation."""
        return f"""Please generate system diagrams for the following schema:
                  {schema}
                  Include architecture diagrams, component relationships, and data flow diagrams."""

    def _create_examples_prompt(self, schema: Dict) -> str:
        """Create prompt for code examples generation."""
        return f"""Please generate code examples for the following schema:
                  {schema}
                  Include common use cases, best practices, and error handling examples."""

    def _parse_diagrams_response(self, content: str) -> Dict:
        """Parse the AI response into a dictionary of diagram descriptions."""
        diagrams = {
            "erd": [],
            "architecture": [],
            "dataflow": [],
            "components": []
        }

        # Split content into sections and parse
        sections = content.split('\n\n')
        current_section = None

        for section in sections:
            section = section.strip()
            if not section:
                continue

            if "ERD" in section.upper():
                current_section = "erd"
                diagrams["erd"].append(section)
            elif "ARCHITECTURE" in section.upper():
                current_section = "architecture"
                diagrams["architecture"].append(section)
            elif "DATA FLOW" in section.upper():
                current_section = "dataflow"
                diagrams["dataflow"].append(section)
            elif "COMPONENT" in section.upper():
                current_section = "components"
                diagrams["components"].append(section)
            elif current_section:
                diagrams[current_section].append(section)

        return {
            "diagrams": diagrams,
            "content": content  # Keep original content as well
        }




async def main():
    healthcare_schema = {
        "tables": {
            "patients": {
                "columns": {
                    "id": {"type": "integer", "primary_key": True},
                    "mrn": {"type": "varchar", "unique": True},
                    "name": {"type": "varchar"},
                    "dob": {"type": "date"}
                }
            },
            "encounters": {
                "columns": {
                    "id": {"type": "integer", "primary_key": True},
                    "patient_id": {"type": "integer"},
                    "date": {"type": "timestamp"},
                    "notes": {"type": "text"}
                }
            }
        },
        "relationships": [
            {
                "from_table": "encounters",
                "to_table": "patients",
                "from_column": "patient_id",
                "to_column": "id"
            }
        ]
    }
    ai_client = Anthropic(api_key="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")

    # Initialize components
    doc_generator = AIDocumentationGenerator(ai_client)
    # Initialize components
    doc_generator = AIDocumentationGenerator(ai_client)
    print("\nGenerating Healthcare Documentation Package...")
    healthcare_docs = await doc_generator.generate_complete_documentation(
        healthcare_schema,
        "HIPAA-compliant healthcare data platform"
    )
    print("Healthcare Documentation Package Generated:",healthcare_docs)
    docs_dict = healthcare_docs.to_dict()
    print(json.dumps(docs_dict, indent=2))

if __name__ == "__main__":
    asyncio.run(main())