from typing import List, Dict, Any, Optional, TypedDict
from dataclasses import dataclass
from enum import Enum
import logging
import anthropic
import os
import json
from abc import ABC, abstractmethod

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class Priority(Enum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"

    @classmethod
    def get_score(cls, priority: str) -> int:
        scores = {
            cls.HIGH.value: 3,
            cls.MEDIUM.value: 2,
            cls.LOW.value: 1
        }
        return scores.get(priority.lower(), 0)

class DataType(Enum):
    NUMERIC = "numeric"
    CATEGORICAL = "categorical"
    TEMPORAL = "temporal"

@dataclass
class ChartConfig:
    suitable_for: List[str]
    min_data_points: Optional[int] = None
    max_categories: Optional[int] = None
    min_dimensions: Optional[int] = None
    max_levels: Optional[int] = None

class VisualizationConfig(TypedDict):
    suggested_x_axis: str
    suggested_y_axis: Optional[str]
    additional_dimensions: List[str]
    color_by: Optional[str]
    interactive_features: List[str]
    additional_settings: Dict[str, Any]

class Recommendation(TypedDict):
    type: str
    reason: str
    priority: str
    configuration: VisualizationConfig
    insights: str
    alternative_views: List[str]
    data_preparation: List[str]

class DataCharacteristics:
    def __init__(self, data: List[Dict[str, Any]]):
        self.data = data
        self.characteristics = self._analyze()

    def _analyze(self) -> Dict[str, Any]:
        if not self.data:
            return {}

        result = {
            "numeric_columns": [],
            "categorical_columns": [],
            "temporal_columns": [],
            "row_count": len(self.data),
            "has_time_series": False,
            "value_ranges": {},
            "correlation_hints": [],
            "data_quality": {
                "missing_values": {},
                "unique_ratios": {},
            }
        }

        self._analyze_columns(result)
        self._analyze_correlations(result)
        self._analyze_data_quality(result)

        return result

    def _analyze_columns(self, result: Dict[str, Any]) -> None:
        sample_row = self.data[0]
        for column, value in sample_row.items():
            if isinstance(value, (int, float)):
                self._analyze_numeric_column(column, result)
            elif isinstance(value, str):
                self._analyze_string_column(column, result)

    def _analyze_numeric_column(self, column: str, result: Dict[str, Any]) -> None:
        result["numeric_columns"].append(column)
        values = [row[column] for row in self.data if row[column] is not None]
        if values:
            result["value_ranges"][column] = {
                "min": min(values),
                "max": max(values),
                "mean": sum(values) / len(values),
                "distinct_count": len(set(values))
            }

    def _analyze_string_column(self, column: str, result: Dict[str, Any]) -> None:
        time_indicators = ["date", "time", "year", "month", "created", "updated"]
        if any(indicator in column.lower() for indicator in time_indicators):
            result["temporal_columns"].append(column)
            result["has_time_series"] = True
        else:
            result["categorical_columns"].append(column)

    def _analyze_correlations(self, result: Dict[str, Any]) -> None:
        for i, col1 in enumerate(result["numeric_columns"]):
            for col2 in result["numeric_columns"][i+1:]:
                result["correlation_hints"].append({
                    "columns": [col1, col2],
                    "relationship": "potential correlation"
                })

    def _analyze_data_quality(self, result: Dict[str, Any]) -> None:
        for column in result["numeric_columns"] + result["categorical_columns"] + result["temporal_columns"]:
            missing_count = sum(1 for row in self.data if row.get(column) is None)
            result["data_quality"]["missing_values"][column] = missing_count / len(self.data)

            if column in result["categorical_columns"]:
                unique_count = len(set(row[column] for row in self.data if row.get(column) is not None))
                result["data_quality"]["unique_ratios"][column] = unique_count / len(self.data)

class AIRecommender(ABC):
    @abstractmethod
    async def get_recommendations(
        self,
        data: List[Dict[str, Any]],
        characteristics: Dict[str, Any],
        query_context: Optional[str] = None
    ) -> List[Recommendation]:
        pass

class ClaudeRecommender(AIRecommender):
    def __init__(self, api_key: Optional[str] = None):
        self.client = anthropic.Client(
            api_key=api_key or os.environ.get("ANTHROPIC_API_KEY")
        )

    async def get_recommendations(
        self,
        data: List[Dict[str, Any]],
        characteristics: Dict[str, Any],
        query_context: Optional[str] = None
    ) -> List[Recommendation]:
        try:
            data_sample = data[:5] if data else []
            prompt = self._create_prompt(data_sample, characteristics, query_context)
            response = await self._get_claude_response(prompt)
            return self._parse_recommendations(response)
        except Exception as e:
            logger.error(f"Error in Claude recommendations: {str(e)}")
            return []

    def _create_prompt(
        self,
        data_sample: List[Dict[str, Any]],
        characteristics: Dict[str, Any],
        query_context: Optional[str]
    ) -> str:
        return f"""
        As a data visualization expert, analyze this dataset and provide visualization recommendations.

        Data Sample:
        {json.dumps(data_sample, indent=2)}

        Data Characteristics:
        {json.dumps(characteristics, indent=2)}

        Query Context:
        {query_context or 'No context provided'}

        Provide recommendations in this JSON format:
        {self._get_recommendation_format()}
        """

    async def _get_claude_response(self, prompt: str) -> str:
        response = self.client.messages.create(
            model="claude-3-sonnet-20240229",
            max_tokens=2000,
            messages=[{"role": "user", "content": prompt}]
        )
        return response.content[0].text

    def _get_recommendation_format(self) -> str:
        return """
        [
            {
                "type": "visualization type",
                "reason": "detailed explanation",
                "priority": "high|medium|low",
                "configuration": {
                    "suggested_x_axis": "column name",
                    "suggested_y_axis": "column name",
                    "additional_dimensions": ["column names"],
                    "color_by": "column name",
                    "interactive_features": ["feature list"],
                    "additional_settings": {
                        "setting1": "value1"
                    }
                },
                "insights": "potential insights",
                "alternative_views": ["other options"],
                "data_preparation": ["preparation steps"]
            }
        ]
        """

    def _parse_recommendations(self, response: str) -> List[Recommendation]:
        try:
            recommendations_text = response.split("[")[1].split("]")[0]
            recommendations_text = f"[{recommendations_text}]"
            return json.loads(recommendations_text)
        except Exception as e:
            logger.error(f"Error parsing recommendations: {str(e)}")
            return []

class VisualizationRecommender:
    def __init__(self, ai_recommender: Optional[AIRecommender] = None):
        self.ai_recommender = ai_recommender or ClaudeRecommender()
        self.chart_types = {
            "bar": ChartConfig(
                suitable_for=["categorical_comparison", "time_series", "distribution"],
                max_categories=20,
                min_data_points=2
            ),

            "line": ChartConfig(
                suitable_for=["time_series", "trend_analysis", "continuous_data"],
                min_data_points=5
            ),

            "pie": ChartConfig(
                suitable_for=["part_to_whole", "percentage_distribution"],
                max_categories=8,
                min_data_points=2
            ),

            "scatter": ChartConfig(
                suitable_for=["correlation", "distribution", "clustering"],
                min_data_points=10,
                min_dimensions=2
            ),

            "heatmap": ChartConfig(
                suitable_for=["correlation_matrix", "density_visualization", "multi_variable_analysis"],
                min_data_points=9,
                min_dimensions=2
            ),

            "treemap": ChartConfig(
                suitable_for=["hierarchical_data", "nested_proportions", "part_to_whole"],
                min_data_points=6,
                max_levels=3
            ),

            "area": ChartConfig(
                suitable_for=["cumulative_values", "stacked_time_series", "part_to_whole_over_time"],
                min_data_points=5
            ),

            "bubble": ChartConfig(
                suitable_for=["three_dimensional_data", "size_comparison", "multi_variable_analysis"],
                min_data_points=5,
                min_dimensions=3
            ),

            "box": ChartConfig(
                suitable_for=["distribution", "outlier_detection", "statistical_summary"],
                min_data_points=5,
                max_categories=15
            ),

            "violin": ChartConfig(
                suitable_for=["distribution", "density_estimation", "statistical_comparison"],
                min_data_points=10,
                max_categories=10
            ),

            "sunburst": ChartConfig(
                suitable_for=["hierarchical_data", "nested_proportions", "drill_down_analysis"],
                min_data_points=7,
                max_levels=4
            ),

            "sankey": ChartConfig(
                suitable_for=["flow_visualization", "process_analysis", "transition_mapping"],
                min_data_points=6,
                min_dimensions=2
            ),

            "radar": ChartConfig(
                suitable_for=["multi_variable_comparison", "performance_metrics", "feature_comparison"],
                min_dimensions=3,
                max_categories=12
            ),

            "parallel": ChartConfig(
                suitable_for=["multi_dimensional", "correlation_analysis", "pattern_recognition"],
                min_dimensions=3,
                max_dimensions=15
            ),

            "funnel": ChartConfig(
                suitable_for=["sequential_steps", "conversion_analysis", "process_stages"],
                min_data_points=3,
                max_categories=10
            ),

            "gauge": ChartConfig(
                suitable_for=["single_metric", "progress_tracking", "goal_comparison"],
                min_data_points=1,
                max_categories=1
            ),

            "calendar": ChartConfig(
                suitable_for=["daily_patterns", "time_distribution", "event_frequency"],
                min_data_points=7,
                min_dimensions=2
            ),

            "wordcloud": ChartConfig(
                suitable_for=["text_frequency", "categorical_importance", "term_analysis"],
                min_data_points=10,
                max_categories=200
            ),

            "donut": ChartConfig(
                suitable_for=["part_to_whole", "percentage_distribution", "nested_categories"],
                max_categories=8,
                min_data_points=2
            ),

            "stream": ChartConfig(
                suitable_for=["time_series", "continuous_flow", "trend_comparison"],
                min_data_points=10,
                min_dimensions=2
            )
        }

    async def recommend_visualizations(
        self,
        data: List[Dict[str, Any]],
        query_context: Optional[str] = None
    ) -> List[Recommendation]:
        try:
            # Analyze data characteristics
            data_analyzer = DataCharacteristics(data)
            characteristics = data_analyzer.characteristics

            # Get AI recommendations
            ai_recommendations = await self.ai_recommender.get_recommendations(
                data,
                characteristics,
                query_context
            )

            # Get basic recommendations
            basic_recommendations = self._get_basic_recommendations(characteristics)

            # Combine and deduplicate
            return self._deduplicate_recommendations(
                ai_recommendations + basic_recommendations
            )

        except Exception as e:
            logger.error(f"Error in visualization recommendations: {str(e)}")
            return []

    def _get_basic_recommendations(
        self,
        characteristics: Dict[str, Any]
    ) -> List[Recommendation]:
        recommendations = []

        if characteristics["has_time_series"]:
            recommendations.append(self._create_time_series_recommendation(characteristics))

        if self._is_suitable_for_categorical(characteristics):
            recommendations.append(self._create_categorical_recommendation(characteristics))

        return recommendations

    def _create_categorical_recommendation(
            self,
            characteristics: Dict[str, Any]
    ) -> Recommendation:
        """Create recommendation for categorical data visualization.

        Args:
            characteristics: Dictionary containing data characteristics

        Returns:
            Recommendation dictionary
        """
        categorical_column = characteristics["categorical_columns"][0]
        numeric_column = characteristics["numeric_columns"][0]

        # Determine if we should use horizontal bars based on category count
        unique_categories = characteristics.get("value_ranges", {}).get(
            categorical_column, {}
        ).get("distinct_count", 0)

        orientation = "horizontal" if unique_categories > 8 else "vertical"

        # Check for multiple numeric columns
        additional_metrics = [
            col for col in characteristics["numeric_columns"][1:]
            if col != numeric_column
        ]

        interactive_features = ["filter", "sort", "tooltip"]
        if len(additional_metrics) > 0:
            interactive_features.append("metric_selector")

        additional_settings = {
            "orientation": orientation,
            "sort_order": "descending",
            "bar_padding": 0.1,
            "legend_position": "right" if len(additional_metrics) > 0 else "none"
        }

        # If we have date columns, add time-based filtering
        if characteristics["temporal_columns"]:
            interactive_features.append("time_range_filter")
            additional_settings["time_column"] = characteristics["temporal_columns"][0]

        return {
            "type": "bar",
            "reason": f"Categorical data comparison between {categorical_column} and {numeric_column}",
            "priority": Priority.HIGH.value,
            "configuration": {
                "suggested_x_axis": categorical_column,
                "suggested_y_axis": numeric_column,
                "additional_dimensions": additional_metrics,
                "color_by": categorical_column,
                "interactive_features": interactive_features,
                "additional_settings": additional_settings
            },
            "insights": (
                f"Compare {numeric_column} across different {categorical_column} categories. "
                f"{'Multiple metrics available for comparison. ' if additional_metrics else ''}"
                f"{'Time-based analysis possible. ' if characteristics['temporal_columns'] else ''}"
            ),
            "alternative_views": self._get_alternative_views(characteristics),
            "data_preparation": self._get_data_preparation_steps(characteristics)
        }

    def _get_alternative_views(self, characteristics: Dict[str, Any]) -> List[str]:
        """Determine alternative visualization types based on data characteristics."""
        alternatives = []

        # Check category count for pie chart suitability
        categorical_column = characteristics["categorical_columns"][0]
        unique_categories = characteristics.get("value_ranges", {}).get(
            categorical_column, {}
        ).get("distinct_count", 0)

        if unique_categories <= self.chart_types["pie"].max_categories:
            alternatives.append("pie")

        # Add treemap for hierarchical data
        if len(characteristics["categorical_columns"]) > 1:
            alternatives.append("treemap")

        # Add line chart if time series data exists
        if characteristics["has_time_series"]:
            alternatives.append("line")

        # Add scatter plot for numeric correlations
        if len(characteristics["numeric_columns"]) > 1:
            alternatives.append("scatter")

        return alternatives

    def _get_data_preparation_steps(self, characteristics: Dict[str, Any]) -> List[str]:
        """Determine necessary data preparation steps."""
        steps = []

        # Check for missing values
        if any(characteristics["data_quality"]["missing_values"].values()):
            steps.append("Handle missing values in the dataset")

        # Check for high cardinality categories
        for col in characteristics["categorical_columns"]:
            unique_ratio = characteristics["data_quality"]["unique_ratios"].get(col, 0)
            if unique_ratio > 0.5:  # More than 50% unique values
                steps.append(f"Consider grouping {col} values to reduce categories")

        # Add sorting recommendation
        if characteristics["numeric_columns"]:
            steps.append(f"Sort data by {characteristics['numeric_columns'][0]} for better visualization")

        # Add date formatting if temporal data exists
        if characteristics["temporal_columns"]:
            steps.append("Ensure consistent date formatting")

        return steps

    def _create_time_series_recommendation(
        self,
        characteristics: Dict[str, Any]
    ) -> Recommendation:
        return {
            "type": "line",
            "reason": "Time series data detected",
            "priority": Priority.HIGH.value,
            "configuration": {
                "suggested_x_axis": characteristics["temporal_columns"][0],
                "suggested_y_axis": next(iter(characteristics["numeric_columns"]), None),
                "additional_dimensions": [],
                "color_by": None,
                "interactive_features": ["zoom", "pan", "tooltip"],
                "additional_settings": {}
            },
            "insights": "Temporal trends and patterns",
            "alternative_views": ["area", "bar"],
            "data_preparation": ["Ensure datetime formatting"]
        }

    def _is_suitable_for_categorical(self, characteristics: Dict[str, Any]) -> bool:
        return (
            characteristics["categorical_columns"]
            and characteristics["numeric_columns"]
            and len(characteristics["categorical_columns"]) <= self.chart_types["bar"].max_categories
        )

    def _deduplicate_recommendations(
        self,
        recommendations: List[Recommendation]
    ) -> List[Recommendation]:
        unique_recommendations = {}
        for rec in recommendations:
            viz_type = rec["type"]
            if (viz_type not in unique_recommendations or
                Priority.get_score(rec["priority"]) >
                Priority.get_score(unique_recommendations[viz_type]["priority"])):
                unique_recommendations[viz_type] = rec
        return list(unique_recommendations.values())

# Usage example
async def main():
    try:
        # Sample data
        data = [
            {"date": "2024-01-01", "sales": 100, "category": "A"},
            {"date": "2024-01-02", "sales": 150, "category": "B"}
        ]

        # Initialize recommender
        recommender = VisualizationRecommender()

        # Get recommendations
        recommendations = await recommender.recommend_visualizations(
            data,
            query_context="Analyze sales trends by category"
        )

        print("Visualization Recommendations:")
        print(json.dumps(recommendations, indent=2))

    except Exception as e:
        logger.error(f"Error in main: {str(e)}")

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())