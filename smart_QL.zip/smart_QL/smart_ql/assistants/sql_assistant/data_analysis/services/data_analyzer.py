import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Tuple
import logging
from datetime import datetime
from anthropic import Anthropic
from fastapi import HTTPException
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
from scipy import stats
from scipy.stats import chi2_contingency
import matplotlib.pyplot as plt
import seaborn as sns

logger = logging.getLogger(__name__)


class DataAnalyzer:
    """Comprehensive data analysis functionality"""

    def __init__(self, anthropic_client: Anthropic):
        self.anthropic = anthropic_client

    async def analyze_dataset(
            self,
            df: pd.DataFrame,
            analysis_config: Optional[Dict] = None
    ) -> Dict:
        """Perform comprehensive dataset analysis"""
        try:
            analysis_results = {
                'basic_analysis': await self.generate_basic_analysis(df),
                'statistical_analysis': await self.perform_statistical_analysis(df),
                'correlation_analysis': await self.analyze_correlations(df),
                'distribution_analysis': await self.analyze_distributions(df),
                'outlier_analysis': await self.detect_outliers(df),
                'pattern_analysis': await self.analyze_patterns(df)
            }

            if analysis_config:
                if analysis_config.get('time_series', False):
                    analysis_results['time_series'] = await self.analyze_time_series(df)
                if analysis_config.get('clustering', False):
                    analysis_results['clustering'] = await self.perform_clustering(df)
                if analysis_config.get('feature_importance', False):
                    analysis_results['feature_importance'] = await self.analyze_feature_importance(df)

            return analysis_results
        except Exception as e:
            logger.error(f"Dataset analysis error: {str(e)}")
            raise

    async def generate_basic_analysis(self, df: pd.DataFrame) -> Dict:
        """Generate basic dataset analysis"""
        try:
            basic_info = {
                'dataset_shape': df.shape,
                'column_info': {
                    'names': df.columns.tolist(),
                    'types': df.dtypes.astype(str).to_dict()
                },
                'missing_values': df.isnull().sum().to_dict(),
                'unique_values': {col: df[col].nunique() for col in df.columns},
                'memory_usage': df.memory_usage(deep=True).sum(),
                'duplicate_rows': df.duplicated().sum()
            }

            summary_stats = df.describe(include='all').to_dict()

            return {
                'basic_info': basic_info,
                'summary_statistics': summary_stats
            }
        except Exception as e:
            logger.error(f"Basic analysis error: {str(e)}")
            raise

    async def perform_statistical_analysis(self, df: pd.DataFrame) -> Dict:
        """Perform detailed statistical analysis"""
        try:
            numeric_cols = df.select_dtypes(include=[np.number]).columns
            categorical_cols = df.select_dtypes(include=['object']).columns

            stats_results = {
                'numeric_analysis': {},
                'categorical_analysis': {}
            }

            # Numeric column analysis
            for col in numeric_cols:
                stats_results['numeric_analysis'][col] = {
                    'mean': float(df[col].mean()),
                    'median': float(df[col].median()),
                    'std': float(df[col].std()),
                    'variance': float(df[col].var()),
                    'skewness': float(stats.skew(df[col].dropna())),
                    'kurtosis': float(stats.kurtosis(df[col].dropna())),
                    'normality_test': self._perform_normality_test(df[col])
                }

            # Categorical column analysis
            for col in categorical_cols:
                stats_results['categorical_analysis'][col] = {
                    'value_counts': df[col].value_counts().to_dict(),
                    'mode': df[col].mode()[0],
                    'entropy': float(stats.entropy(df[col].value_counts(normalize=True)))
                }

            return stats_results
        except Exception as e:
            logger.error(f"Statistical analysis error: {str(e)}")
            raise

    def _perform_normality_test(self, series: pd.Series) -> Dict:
        """Perform normality test on series"""
        statistic, p_value = stats.normaltest(series.dropna())
        return {
            'statistic': float(statistic),
            'p_value': float(p_value),
            'is_normal': p_value > 0.05
        }

    async def analyze_correlations(self, df: pd.DataFrame) -> Dict:
        """Analyze correlations between variables"""
        try:
            numeric_df = df.select_dtypes(include=[np.number])
            correlation_results = {}

            if not numeric_df.empty:
                # Pearson correlation
                pearson_corr = numeric_df.corr(method='pearson')
                # Spearman correlation
                spearman_corr = numeric_df.corr(method='spearman')

                strong_correlations = []
                for i in range(len(pearson_corr.columns)):
                    for j in range(i + 1, len(pearson_corr.columns)):
                        if abs(pearson_corr.iloc[i, j]) > 0.7:
                            strong_correlations.append({
                                'variables': [pearson_corr.columns[i], pearson_corr.columns[j]],
                                'pearson_correlation': float(pearson_corr.iloc[i, j]),
                                'spearman_correlation': float(spearman_corr.iloc[i, j])
                            })

                correlation_results = {
                    'pearson_matrix': pearson_corr.to_dict(),
                    'spearman_matrix': spearman_corr.to_dict(),
                    'strong_correlations': strong_correlations
                }

            # Categorical correlations (Chi-square test)
            categorical_df = df.select_dtypes(include=['object'])
            if not categorical_df.empty:
                categorical_correlations = {}
                for col1 in categorical_df.columns:
                    for col2 in categorical_df.columns:
                        if col1 < col2:
                            contingency_table = pd.crosstab(df[col1], df[col2])
                            chi2, p_value, dof, expected = chi2_contingency(contingency_table)
                            categorical_correlations[f"{col1}_vs_{col2}"] = {
                                'chi2_statistic': float(chi2),
                                'p_value': float(p_value),
                                'degrees_of_freedom': int(dof)
                            }

                correlation_results['categorical_correlations'] = categorical_correlations

            return correlation_results
        except Exception as e:
            logger.error(f"Correlation analysis error: {str(e)}")
            raise

    async def analyze_distributions(self, df: pd.DataFrame) -> Dict:
        """Analyze variable distributions"""
        try:
            distribution_results = {}
            numeric_cols = df.select_dtypes(include=[np.number]).columns

            for col in numeric_cols:
                # Basic distribution statistics
                distribution_results[col] = {
                    'basic_stats': {
                        'mean': float(df[col].mean()),
                        'median': float(df[col].median()),
                        'std': float(df[col].std())
                    },
                    'distribution_type': self._determine_distribution_type(df[col]),
                    'quartiles': {
                        'q1': float(df[col].quantile(0.25)),
                        'q2': float(df[col].quantile(0.50)),
                        'q3': float(df[col].quantile(0.75))
                    },
                    'range': {
                        'min': float(df[col].min()),
                        'max': float(df[col].max())
                    }
                }

            return distribution_results
        except Exception as e:
            logger.error(f"Distribution analysis error: {str(e)}")
            raise

    def _determine_distribution_type(self, series: pd.Series) -> str:
        """Determine the type of distribution"""
        skewness = float(stats.skew(series.dropna()))
        kurtosis = float(stats.kurtosis(series.dropna()))

        if abs(skewness) < 0.5 and abs(kurtosis) < 0.5:
            return 'normal'
        elif skewness > 1:
            return 'right_skewed'
        elif skewness < -1:
            return 'left_skewed'
        elif kurtosis > 1:
            return 'heavy_tailed'
        else:
            return 'unknown'

    async def detect_outliers(
            self,
            df: pd.DataFrame,
            methods: List[str] = ['zscore', 'iqr']
    ) -> Dict:
        """Detect outliers using multiple methods"""
        try:
            outlier_results = {}
            numeric_cols = df.select_dtypes(include=[np.number]).columns

            for col in numeric_cols:
                outlier_results[col] = {}

                if 'zscore' in methods:
                    z_scores = np.abs(stats.zscore(df[col].dropna()))
                    outliers_zscore = df[col][z_scores > 3]
                    outlier_results[col]['zscore'] = {
                        'outlier_count': len(outliers_zscore),
                        'outlier_percentage': len(outliers_zscore) / len(df) * 100,
                        'outlier_values': outliers_zscore.to_dict()
                    }

                if 'iqr' in methods:
                    Q1 = df[col].quantile(0.25)
                    Q3 = df[col].quantile(0.75)
                    IQR = Q3 - Q1
                    outliers_iqr = df[col][
                        (df[col] < Q1 - 1.5 * IQR) |
                        (df[col] > Q3 + 1.5 * IQR)
                        ]
                    outlier_results[col]['iqr'] = {
                        'outlier_count': len(outliers_iqr),
                        'outlier_percentage': len(outliers_iqr) / len(df) * 100,
                        'outlier_values': outliers_iqr.to_dict()
                    }

            return outlier_results
        except Exception as e:
            logger.error(f"Outlier detection error: {str(e)}")
            raise

    async def analyze_patterns(self, df: pd.DataFrame) -> Dict:
        """Analyze patterns in the dataset"""
        try:
            pattern_results = {
                'trends': await self._analyze_trends(df),
                'cyclic_patterns': await self._detect_cyclic_patterns(df),
                'relationships': await self._analyze_relationships(df)
            }
            return pattern_results
        except Exception as e:
            logger.error(f"Pattern analysis error: {str(e)}")
            raise

    async def _analyze_trends(self, df: pd.DataFrame) -> Dict:
        """Analyze trends in numeric columns"""
        try:
            numeric_cols = df.select_dtypes(include=[np.number]).columns
            trends = {}

            for col in numeric_cols:
                series = df[col].dropna()
                x = np.arange(len(series))
                slope, intercept, r_value, p_value, std_err = stats.linregress(x, series)

                trends[col] = {
                    'slope': float(slope),
                    'intercept': float(intercept),
                    'r_squared': float(r_value ** 2),
                    'p_value': float(p_value),
                    'trend_type': 'increasing' if slope > 0 else 'decreasing' if slope < 0 else 'stable',
                    'trend_strength': abs(r_value)
                }

            return trends
        except Exception as e:
            logger.error(f"Trend analysis error: {str(e)}")
            raise

    async def _detect_cyclic_patterns(self, df: pd.DataFrame) -> Dict:
        """Detect cyclic patterns in numeric columns"""
        try:
            numeric_cols = df.select_dtypes(include=[np.number]).columns
            patterns = {}

            for col in numeric_cols:
                series = df[col].dropna()
                if len(series) > 1:
                    # Perform autocorrelation analysis
                    autocorr = pd.Series(series).autocorr()
                    patterns[col] = {
                        'autocorrelation': float(autocorr),
                        'has_cyclical_pattern': abs(autocorr) > 0.7,
                        'pattern_strength': abs(autocorr)
                    }

            return patterns
        except Exception as e:
            logger.error(f"Cyclic pattern detection error: {str(e)}")
            raise

    async def _analyze_relationships(self, df: pd.DataFrame) -> Dict:
        """Analyze relationships between variables"""
        try:
            relationships = {
                'linear_relationships': {},
                'non_linear_relationships': {}
            }

            numeric_cols = df.select_dtypes(include=[np.number]).columns

            # Analyze pairwise relationships
            for i in range(len(numeric_cols)):
                for j in range(i + 1, len(numeric_cols)):
                    col1, col2 = numeric_cols[i], numeric_cols[j]

                    # Linear relationship
                    pearson_corr = df[col1].corr(df[col2])

                    # Non-linear relationship (Spearman correlation)
                    spearman_corr = df[col1].corr(df[col2], method='spearman')

                    # If Spearman is significantly higher than Pearson,
                    # might indicate non-linear relationship
                    if abs(spearman_corr) - abs(pearson_corr) > 0.2:
                        relationships['non_linear_relationships'][f"{col1}_vs_{col2}"] = {
                            'spearman_correlation': float(spearman_corr),
                            'pearson_correlation': float(pearson_corr),
                            'relationship_type': 'non_linear',
                            'strength': abs(spearman_corr)
                        }
                    else:
                        relationships['linear_relationships'][f"{col1}_vs_{col2}"] = {
                            'correlation': float(pearson_corr),
                            'strength': abs(pearson_corr)
                        }

            return relationships
        except Exception as e:
            logger.error(f"Relationship analysis error: {str(e)}")
            raise