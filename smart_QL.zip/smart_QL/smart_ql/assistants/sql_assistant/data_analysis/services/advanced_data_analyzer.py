import datetime
from typing import Optional, Dict, List
import pandas as pd
from anthropic import Anthropic
from fastapi.logger import logger
from app.services.data_analyzer import DataAnalyzer


class AdvancedDataAnalyzer:
    """Advanced data analysis with Claude 3.5 Sonnet"""

    def __init__(self, anthropic_client: Anthropic):
        self.anthropic = anthropic_client
        self.base_analyzer = DataAnalyzer(anthropic_client)

    async def comprehensive_analysis(
            self,
            df: pd.DataFrame,
            analysis_type: str = 'full',
            context: Optional[Dict] = None
    ) -> Dict:
        """Perform comprehensive data analysis"""
        try:
            results = {}

            # Basic analysis
            results['summary'] = await self.base_analyzer.generate_summary_statistics(df)

            # Pattern detection
            results['patterns'] = await self.base_analyzer.analyze_patterns(df)

            # Advanced analysis based on type
            if analysis_type in ['full', 'advanced']:
                # Time series analysis if datetime columns exist
                datetime_cols = df.select_dtypes(include=['datetime64']).columns
                if len(datetime_cols) > 0:
                    results['time_series'] = await self._analyze_time_series(df, datetime_cols)

                # Feature relationships
                results['feature_analysis'] = await self._analyze_feature_relationships(df)

                # Predictive insights
                results['predictive_insights'] = await self._generate_predictive_insights(df)

            # Generate AI-powered insights
            results['ai_insights'] = await self._generate_ai_insights(results, context)

            return results
        except Exception as e:
            logger.error(f"Comprehensive analysis error: {str(e)}")
            raise

    async def _analyze_time_series(
            self,
            df: pd.DataFrame,
            datetime_cols: List[str]
    ) -> Dict:
        """Analyze time series data"""
        try:
            message = await self.anthropic.messages.create(
                model="claude-3-sonnet-20240229",
                max_tokens=2000,
                system="""Analyze time series data providing:
                         1. Trend analysis
                         2. Seasonality detection
                         3. Cyclical patterns
                         4. Anomalies
                         5. Forecasting insights
                         Return analysis as JSON.""",
                messages=[{
                    "role": "user",
                    "content": f"""DataFrame info: {df.info()}
                                 Datetime columns: {datetime_cols}"""
                }]
            )

            return message.content[0].text
        except Exception as e:
            logger.error(f"Time series analysis error: {str(e)}")
            raise

    async def _analyze_feature_relationships(self, df: pd.DataFrame) -> Dict:
        """Analyze complex feature relationships"""
        try:
            message = await self.anthropic.messages.create(
                model="claude-3-sonnet-20240229",
                max_tokens=2000,
                system="""Analyze feature relationships providing:
                         1. Non-linear correlations
                         2. Feature importance
                         3. Interaction effects
                         4. Redundant features
                         5. Derived feature suggestions
                         Return analysis as JSON.""",
                messages=[{
                    "role": "user",
                    "content": f"DataFrame info: {df.info()}"
                }]
            )

            return message.content[0].text
        except Exception as e:
            logger.error(f"Feature analysis error: {str(e)}")
            raise

    async def _generate_predictive_insights(self, df: pd.DataFrame) -> Dict:
        """Generate predictive insights"""
        try:
            message = await self.anthropic.messages.create(
                model="claude-3-sonnet-20240229",
                max_tokens=2000,
                system="""Generate predictive insights including:
                         1. Potential target variables
                         2. Predictive power of features
                         3. Model suggestions
                         4. Feature engineering ideas
                         5. Data collection recommendations
                         Return insights as JSON.""",
                messages=[{
                    "role": "user",
                    "content": f"DataFrame info: {df.info()}"
                }]
            )

            return message.content[0].text
        except Exception as e:
            logger.error(f"Predictive insights error: {str(e)}")
            raise

    async def _generate_ai_insights(
            self,
            analysis_results: Dict,
            context: Optional[Dict] = None
    ) -> Dict:
        """Generate AI-powered insights"""
        try:
            message = await self.anthropic.messages.create(
                model="claude-3-sonnet-20240229",
                max_tokens=2500,
                system="""Generate comprehensive AI-powered insights including:
                         1. Key findings synthesis
                         2. Hidden patterns
                         3. Business implications
                         4. Action recommendations
                         5. Risk factors
                         6. Opportunity areas
                         Return detailed insights as JSON.""",
                messages=[{
                    "role": "user",
                    "content": f"""Analysis Results: {analysis_results}
                                 Context: {context if context else 'None'}"""
                }]
            )

            return message.content[0].text
        except Exception as e:
            logger.error(f"AI insights error: {str(e)}")
            raise

    async def generate_visual_insights(
            self,
            df: pd.DataFrame,
            viz_preferences: Optional[Dict] = None
    ) -> Dict:
        """Generate visualization recommendations"""
        try:
            message = await self.anthropic.messages.create(
                model="claude-3-sonnet-20240229",
                max_tokens=2000,
                system="""Generate visualization recommendations including:
                         1. Chart types for each insight
                         2. Color schemes
                         3. Layout suggestions
                         4. Interactive elements
                         5. Annotation recommendations
                         Return visualization plan as JSON.""",
                messages=[{
                    "role": "user",
                    "content": f"""DataFrame info: {df.info()}
                                 Preferences: {viz_preferences if viz_preferences else 'None'}"""
                }]
            )

            return message.content[0].text
        except Exception as e:
            logger.error(f"Visual insights error: {str(e)}")
            raise

    async def explain_findings(
            self,
            analysis_results: Dict,
            audience: str = 'general'
    ) -> str:
        """Generate explanations of findings"""
        try:
            message = await self.anthropic.messages.create(
                model="claude-3-sonnet-20240229",
                max_tokens=2000,
                system=f"""Explain analysis findings for {audience} audience.
                         Include:
                         1. Clear explanations
                         2. Relevant examples
                         3. Implications
                         4. Next steps
                         Adapt technical level appropriately.""",
                messages=[{
                    "role": "user",
                    "content": f"Analysis Results: {analysis_results}"
                }]
            )

            return message.content[0].text
        except Exception as e:
            logger.error(f"Explanation generation error: {str(e)}")
            raise

    async def generate_report(
            self,
            analysis_results: Dict,
            insights: Dict,
            report_type: str = 'detailed',
            output_format: str = 'json'
    ) -> Dict:
        """Generate comprehensive analysis report"""
        try:
            message = await self.anthropic.messages.create(
                model="claude-3-sonnet-20240229",
                max_tokens=3000,
                system=f"""Generate a {report_type} data analysis report including:
                         1. Executive Summary
                            - Key findings
                            - Critical insights
                            - Important recommendations
                         2. Methodology Overview
                            - Analysis approaches used
                            - Statistical methods applied
                            - Data quality assessment
                         3. Detailed Analysis Results
                            - Statistical findings
                            - Pattern discoveries
                            - Anomaly detections
                            - Correlation analysis
                         4. Data Insights
                            - Pattern interpretations
                            - Business implications
                            - Risk factors
                            - Opportunities identified
                         5. Actionable Recommendations
                            - Short-term actions
                            - Long-term strategy
                            - Priority areas
                         6. Technical Appendix
                            - Detailed metrics
                            - Statistical tests
                            - Data quality metrics
                         Format the report appropriately for the specified output format.
                         Ensure all numerical results are properly formatted.
                         Include visualizations recommendations where relevant.""",
                messages=[{
                    "role": "user",
                    "content": f"""Analysis Results: {analysis_results}
                                 Insights: {insights}
                                 Report Type: {report_type}
                                 Output Format: {output_format}"""
                }]
            )

            # Process the report based on output format
            report = message.content[0].text

            # Add metadata
            report_with_metadata = {
                'report_content': report,
                'metadata': {
                    'generated_at': datetime.utcnow().isoformat(),
                    'report_type': report_type,
                    'output_format': output_format,
                    'analysis_coverage': list(analysis_results.keys()),
                    'insight_categories': list(insights.keys())
                },
                'summary_metrics': self._extract_summary_metrics(analysis_results),
                'key_findings': self._extract_key_findings(insights),
                'visualization_suggestions': self._generate_visualization_suggestions(analysis_results)
            }

            return report_with_metadata
        except Exception as e:
            logger.error(f"Report generation error: {str(e)}")
            raise

    def _extract_summary_metrics(self, analysis_results: Dict) -> Dict:
        """Extract key summary metrics from analysis results"""
        summary_metrics = {}

        # Extract basic metrics
        if 'basic_analysis' in analysis_results:
            basic = analysis_results['basic_analysis']
            summary_metrics['data_overview'] = {
                'total_records': basic.get('dataset_shape', [0])[0],
                'total_features': basic.get('dataset_shape', [0, 0])[1],
                'missing_data_percentage': self._calculate_missing_percentage(basic.get('missing_values', {}))
            }

        # Extract statistical insights
        if 'statistical_analysis' in analysis_results:
            stats = analysis_results['statistical_analysis']
            summary_metrics['statistical_highlights'] = {
                'significant_correlations': self._count_significant_correlations(stats),
                'anomaly_percentage': self._calculate_anomaly_percentage(stats)
            }

        return summary_metrics

    def _extract_key_findings(self, insights: Dict) -> List[Dict]:
        """Extract and prioritize key findings from insights"""
        key_findings = []

        if 'patterns' in insights:
            for pattern in insights['patterns']:
                if pattern.get('significance', 0) > 0.7:  # High significance threshold
                    key_findings.append({
                        'type': 'pattern',
                        'description': pattern.get('description'),
                        'significance': pattern.get('significance'),
                        'implications': pattern.get('implications', [])
                    })

        if 'anomalies' in insights:
            for anomaly in insights['anomalies']:
                if anomaly.get('severity', 0) > 0.8:  # High severity threshold
                    key_findings.append({
                        'type': 'anomaly',
                        'description': anomaly.get('description'),
                        'severity': anomaly.get('severity'),
                        'recommendations': anomaly.get('recommendations', [])
                    })

        return sorted(key_findings, key=lambda x: x.get('significance', 0), reverse=True)

    def _generate_visualization_suggestions(self, analysis_results: Dict) -> List[Dict]:
        """Generate visualization suggestions for key findings"""
        suggestions = []

        # Analyze results and suggest appropriate visualizations
        if 'correlation_analysis' in analysis_results:
            correlations = analysis_results['correlation_analysis']
            if any(abs(corr) > 0.7 for corr in correlations.values()):
                suggestions.append({
                    'type': 'heatmap',
                    'title': 'Correlation Matrix',
                    'description': 'Visualize strong correlations between variables',
                    'priority': 'high'
                })

        if 'distribution_analysis' in analysis_results:
            distributions = analysis_results['distribution_analysis']
            suggestions.append({
                'type': 'histogram_grid',
                'title': 'Distribution Overview',
                'description': 'Show distribution patterns across key variables',
                'priority': 'medium'
            })

        return suggestions

    def _calculate_missing_percentage(self, missing_values: Dict) -> float:
        """Calculate overall missing data percentage"""
        if not missing_values:
            return 0.0
        total_missing = sum(missing_values.values())
        total_possible = len(missing_values.values()) * max(missing_values.values())
        return (total_missing / total_possible) * 100 if total_possible > 0 else 0

    def _count_significant_correlations(self, stats: Dict) -> int:
        """Count number of significant correlations"""
        if 'correlations' not in stats:
            return 0
        return sum(1 for corr in stats['correlations'].values() if abs(corr) > 0.7)

    def _calculate_anomaly_percentage(self, stats: Dict) -> float:
        """Calculate overall percentage of anomalies in the dataset"""
        try:
            if 'outlier_analysis' not in stats:
                return 0.0

            total_outliers = 0
            total_records = 0

            for column_stats in stats['outlier_analysis'].values():
                # Sum outliers detected by different methods (z-score and IQR)
                if 'zscore' in column_stats:
                    total_outliers += column_stats['zscore'].get('outlier_count', 0)
                    total_records += column_stats['zscore'].get('total_records', 0)
                if 'iqr' in column_stats:
                    total_outliers += column_stats['iqr'].get('outlier_count', 0)
                    total_records += column_stats['iqr'].get('total_records', 0)

            # Calculate percentage if we have records
            if total_records > 0:
                # Take average since we might have counted same records twice
                return (total_outliers / (2 * total_records)) * 100
            return 0.0

        except Exception as e:
            logger.error(f"Error calculating anomaly percentage: {str(e)}")
            return 0.0