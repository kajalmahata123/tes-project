from typing import Optional, Dict

import numpy as np
import pandas as pd
from anthropic import Anthropic
import logging

class ExploratoryDataAnalyzer:
    """Advanced EDA using Claude 3.5 Sonnet"""

    def __init__(self, anthropic_client: Anthropic):
        self.anthropic = anthropic_client

    async def perform_comprehensive_eda(
            self,
            df: pd.DataFrame,
            analysis_config: Optional[Dict] = None
    ) -> Dict:
        """Perform comprehensive EDA with AI assistance"""
        try:
            # First perform standard statistical analysis
            base_analysis = {
                'data_overview': self._analyze_data_structure(df),
                'data_quality': self._assess_data_quality(df),
                'basic_stats': self._calculate_basic_statistics(df)
            }

            # Use Claude for advanced insights
            ai_insights = await self._generate_ai_insights(df, base_analysis)

            # Combine everything into comprehensive analysis
            complete_analysis = {
                **base_analysis,
                'ai_insights': ai_insights,
                'recommendations': await self._generate_recommendations(df, base_analysis, ai_insights)
            }

            return complete_analysis

        except Exception as e:
            logging.error(f"Comprehensive EDA error: {str(e)}")
            raise

    async def _generate_ai_insights(self, df: pd.DataFrame, base_analysis: Dict) -> Dict:
        """Generate AI-powered insights using Claude"""
        try:
            message = await self.anthropic.messages.create(
                model="claude-3-sonnet-20240229",
                max_tokens=2000,
                system="""Analyze the dataset and provide comprehensive insights including:
                         1. Hidden Patterns & Relationships
                            - Complex variable interactions
                            - Non-linear relationships
                            - Multivariate patterns
                         2. Data Distribution Analysis
                            - Distribution characteristics
                            - Skewness and kurtosis interpretation
                            - Multimodal distributions
                         3. Anomaly Detection
                            - Statistical anomalies
                            - Contextual anomalies
                            - Pattern violations
                         4. Feature Importance
                            - Key drivers
                            - Redundant features
                            - Derived feature suggestions
                         Return detailed analysis as JSON.""",
                messages=[{
                    "role": "user",
                    "content": f"""DataFrame Info: {df.info()}
                                 Basic Analysis: {base_analysis}"""
                }]
            )

            return message.content[0].text
        except Exception as e:
            logging.error(f"AI insight generation error: {str(e)}")
            raise

    async def analyze_data_patterns(self, df: pd.DataFrame) -> Dict:
        """Analyze complex data patterns using Claude"""
        try:
            message = await self.anthropic.messages.create(
                model="claude-3-sonnet-20240229",
                max_tokens=2000,
                system="""Analyze complex data patterns including:
                         1. Time-based Patterns
                            - Trends
                            - Seasonality
                            - Cycles
                         2. Group-based Patterns
                            - Cluster tendencies
                            - Group characteristics
                            - Outlier groups
                         3. Interaction Patterns
                            - Feature interactions
                            - Conditional dependencies
                            - Sequential patterns
                         Return analysis as JSON.""",
                messages=[{
                    "role": "user",
                    "content": f"DataFrame Info: {df.info()}"
                }]
            )

            return message.content[0].text
        except Exception as e:
            logging.error(f"Pattern analysis error: {str(e)}")
            raise

    async def analyze_feature_relationships(self, df: pd.DataFrame) -> Dict:
        """Analyze feature relationships using Claude"""
        try:
            message = await self.anthropic.messages.create(
                model="claude-3-sonnet-20240229",
                max_tokens=2000,
                system="""Analyze feature relationships including:
                         1. Direct Relationships
                            - Linear correlations
                            - Non-linear associations
                            - Categorical associations
                         2. Complex Interactions
                            - Multivariate relationships
                            - Interaction effects
                            - Hierarchical relationships
                         3. Dependency Analysis
                            - Causal indicators
                            - Redundancy detection
                            - Feature hierarchy
                         Return analysis as JSON.""",
                messages=[{
                    "role": "user",
                    "content": f"DataFrame Info: {df.info()}"
                }]
            )

            return message.content[0].text
        except Exception as e:
            logging.error(f"Relationship analysis error: {str(e)}")
            raise

    async def _generate_recommendations(
            self,
            df: pd.DataFrame,
            base_analysis: Dict,
            ai_insights: Dict
    ) -> Dict:
        """Generate data-driven recommendations using Claude"""
        try:
            message = await self.anthropic.messages.create(
                model="claude-3-sonnet-20240229",
                max_tokens=2000,
                system="""Generate comprehensive recommendations including:
                         1. Data Quality Improvements
                            - Missing data handling
                            - Outlier treatment
                            - Feature engineering
                         2. Analysis Suggestions
                            - Statistical tests
                            - Visualization recommendations
                            - Deep-dive areas
                         3. Modeling Recommendations
                            - Feature selection
                            - Algorithm suggestions
                            - Validation approaches
                         Return recommendations as JSON.""",
                messages=[{
                    "role": "user",
                    "content": f"""Base Analysis: {base_analysis}
                                 AI Insights: {ai_insights}"""
                }]
            )

            return message.content[0].text
        except Exception as e:
            logging.error(f"Recommendation generation error: {str(e)}")
            raise

    def _analyze_data_structure(self, df: pd.DataFrame) -> Dict:
        """Analyze basic data structure"""
        return {
            'shape': df.shape,
            'columns': list(df.columns),
            'dtypes': df.dtypes.astype(str).to_dict(),
            'missing_values': df.isnull().sum().to_dict(),
            'memory_usage': df.memory_usage(deep=True).sum()
        }

    def _assess_data_quality(self, df: pd.DataFrame) -> Dict:
        """Assess data quality metrics"""
        return {
            'completeness': {
                'missing_values': df.isnull().sum().to_dict(),
                'missing_percentages': (df.isnull().sum() / len(df) * 100).to_dict()
            },
            'uniqueness': {
                'unique_counts': df.nunique().to_dict(),
                'duplicate_rows': df.duplicated().sum()
            },
            'validity': {
                'zero_variance_columns': [col for col in df.columns if df[col].nunique() == 1],
                'high_cardinality_columns': [col for col in df.columns if df[col].nunique() > 0.9 * len(df)]
            }
        }

    def _calculate_basic_statistics(self, df: pd.DataFrame) -> Dict:
        """Calculate basic statistical measures"""
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        stats = {}

        for col in numeric_cols:
            stats[col] = {
                'descriptive': df[col].describe().to_dict(),
                'skewness': float(stats.skew(df[col].dropna())),
                'kurtosis': float(stats.kurtosis(df[col].dropna()))
            }

        return stats