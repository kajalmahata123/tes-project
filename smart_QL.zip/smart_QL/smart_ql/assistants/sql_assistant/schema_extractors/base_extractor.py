from abc import ABC, abstractmethod
from typing import List, Dict
from smart_ql.assistants.sql_assistant.config.db_config import DBConfig
from smart_ql.assistants.sql_assistant.schema_extractors.schemas import DatabaseSchema, TableInfo


class BaseSchemaExtractor(ABC):
    """Base class for database schema schema_extractors."""

    def __init__(self,config:DBConfig):
        self.config = config


    @abstractmethod
    async def extract_schema(self) -> DatabaseSchema:
        """Extract complete database schema."""
        pass

    @abstractmethod
    async def extract_table_info(self, table_name: str, schema: str) -> TableInfo:
        """Extract detailed table information."""
        pass

    @abstractmethod
    async def get_relationships(self) -> List[Dict]:
        """Extract relationships between tables."""
        pass

    @abstractmethod
    async def get_sample_data(
            self,
            table_name: str,
            schema: str,
            limit: int = 5
    ) -> List[Dict]:
        """Get sample data from table."""
        pass