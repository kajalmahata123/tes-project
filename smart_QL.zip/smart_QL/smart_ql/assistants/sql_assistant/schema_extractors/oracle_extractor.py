
from sqlalchemy import create_engine, text, MetaData
from sqlalchemy.engine import URL, Engine
from sqlalchemy.pool import QueuePool
from typing import List, Dict, Optional, Any
from dataclasses import dataclass
from datetime import datetime
import asyncio
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
import logging

from smart_ql.features.data_source.repositories.data_source_entity import DatabaseVendor
from .base_extractor import BaseSchemaExtractor
from .schemas import DatabaseSchema, TableInfo, ColumnInfo

from ..config.db_config import DBConfig

logger = logging.getLogger(__name__)


@dataclass
class OracleTableStats:
    """Oracle table statistics."""
    num_rows: int
    blocks: int
    avg_row_len: int
    sample_size: int
    last_analyzed: datetime
    partition_count: int
    temporary: bool
    compression: str
    tablespace_name: str
    logging: bool
    degree: str
    row_movement: str


@dataclass
class OracleColumnStats:
    """Oracle column statistics."""
    num_distinct: int
    num_nulls: int
    avg_col_len: int
    density: float
    num_buckets: int
    histogram: str
    sample_size: int
    last_analyzed: datetime
    low_value: Optional[str]
    high_value: Optional[str]


@dataclass
class OracleIndexInfo:
    """Oracle index information."""
    name: str
    type: str
    uniqueness: str
    tablespace_name: str
    columns: List[str]
    blevel: int
    leaf_blocks: int
    distinct_keys: int
    clustering_factor: int
    status: str
    compression: str
    visibility: str


@dataclass
class OraclePartitionInfo:
    """Oracle partition information."""
    partition_type: str
    partition_count: int
    subpartition_type: Optional[str]
    partitioning_key_columns: List[str]
    subpartitioning_key_columns: List[str]
    partition_details: List[Dict]


class OracleSchemaExtractor(BaseSchemaExtractor):
    """Advanced Oracle schema extractor using SQLAlchemy."""

    def __init__(self, config: DBConfig):
        super().__init__(config)
        self._engine = None
        self.schema = config.SCHEMA or config.USERNAME.upper()
        self.metadata = MetaData()
        self.executor = ThreadPoolExecutor(max_workers=4)
        self.include_system_tables = False

    @property
    def engine(self) -> Engine:
        """Lazy engine initialization."""
        if self._engine is None:
            self._engine = self._create_engine()
        return self._engine

    def _create_engine(self) -> Engine:
        """Create SQLAlchemy engine with advanced configuration."""
        try:
            url = URL.create(
                "oracle+cx_oracle",
                username=self.config.USERNAME,
                password=self.config.PASSWORD,
                host=self.config.HOST,
                port=self.config.PORT,
                database=self.config.DATABASE,
                query={
                    "encoding": "UTF-8",
                    "nencoding": "UTF-8",
                    "mode": "SYSDBA",
                    "events": "true"
                }
            )

            engine = create_engine(
                url,
                poolclass=QueuePool,
                pool_size=10,
                max_overflow=20,
                pool_timeout=30,
                pool_recycle=1800,
                pool_pre_ping=True,
                echo=False,
                connect_args={
                    "encoding": "UTF-8",
                    "nencoding": "UTF-8"
                }
            )

            self._setup_engine_events(engine)
            return engine

        except Exception as e:
            logger.error(f"Failed to create Oracle engine: {str(e)}")
            raise

    @contextmanager
    def _db_cursor(self):
        """Context manager for database connections."""
        conn = self.engine.connect()
        try:
            yield conn
        finally:
            conn.close()

    async def extract_schema(self) -> DatabaseSchema:
        """Extract complete Oracle schema."""
        try:
            # Get all tables in parallel
            tables_future = self.executor.submit(self._get_all_tables)
            tables_data = await asyncio.wrap_future(tables_future)

            # Process tables in parallel
            table_futures = []
            for table_data in tables_data:
                future = self.executor.submit(
                    self.extract_table_info,
                    table_data['table_name'],
                    self.schema
                )
                table_futures.append(future)

            # Gather results
            tables = []
            for future in table_futures:
                table_info = await asyncio.wrap_future(future)
                if table_info:
                    tables.append(table_info)

            # Get relationships
            relationships = await self._get_all_relationships()

            # Get database metadata
            metadata = await self._extract_metadata()

            schema = DatabaseSchema(
                name=self.config.DATABASE,
                vendor=DatabaseVendor.ORACLE,
                tables=tables,
                relationships=relationships,
                schemas=[self.schema],
                metadata=metadata
            )

            return schema

        except Exception as e:
            logger.error(f"Error extracting schema: {str(e)}")
            raise

    def _get_all_tables(self) -> List[Dict[str, Any]]:
        """Get all tables from the schema."""
        with self._db_cursor() as conn:
            query = """
                SELECT 
                    t.TABLE_NAME,
                    t.TABLESPACE_NAME,
                    t.STATUS,
                    t.NUM_ROWS,
                    t.BLOCKS,
                    t.AVG_ROW_LEN,
                    t.SAMPLE_SIZE,
                    t.LAST_ANALYZED,
                    t.COMPRESSION,
                    t.COMPRESS_FOR,
                    t.DEGREE,
                    t.PARTITIONED,
                    t.TEMPORARY,
                    t.LOGGING,
                    t.ROW_MOVEMENT,
                    c.COMMENTS
                FROM ALL_TABLES t
                LEFT JOIN ALL_TAB_COMMENTS c 
                    ON t.TABLE_NAME = c.TABLE_NAME 
                    AND t.OWNER = c.OWNER
                WHERE t.OWNER = :schema
                ORDER BY t.TABLE_NAME
            """

            result = conn.execute(text(query), {"schema": self.schema})

            return [
                {
                    'table_name': row.TABLE_NAME,
                    'tablespace': row.TABLESPACE_NAME,
                    'status': row.STATUS,
                    'num_rows': row.NUM_ROWS,
                    'blocks': row.BLOCKS,
                    'avg_row_len': row.AVG_ROW_LEN,
                    'last_analyzed': row.LAST_ANALYZED,
                    'compression': row.COMPRESSION,
                    'compress_for': row.COMPRESS_FOR,
                    'partitioned': row.PARTITIONED,
                    'temporary': row.TEMPORARY,
                    'logging': row.LOGGING,
                    'comments': row.COMMENTS
                }
                for row in result
            ]

    async def extract_table_info(self, table_name: str, schema: str) -> Optional[TableInfo]:
        """Extract comprehensive table information."""
        try:
            with self._db_cursor() as conn:
                # Get column information
                columns = await self._get_column_info(conn, table_name, schema)

                # Get table statistics
                stats = await self._get_table_statistics(conn, table_name, schema)

                # Get constraints
                constraints = await self._get_table_constraints(conn, table_name, schema)

                # Get indexes
                indexes = await self._get_indexes(conn, table_name, schema)

                # Get partitioning info
                partitioning = await self._get_partitioning_info(conn, table_name, schema)

                # Get triggers
                triggers = await self._get_triggers(conn, table_name, schema)

                # Get dependencies
                dependencies = await self._get_dependencies(conn, table_name, schema)

                return TableInfo(
                    name=table_name,
                    schema=schema,
                    columns=columns,
                    statistics=stats,
                    indexes=indexes,
                    partitioning=partitioning,
                    triggers=triggers,
                    dependencies=dependencies,
                    constraints=constraints,
                    primary_keys=self._extract_primary_keys(constraints),
                    foreign_keys=self._extract_foreign_keys(constraints)
                )

        except Exception as e:
            logger.error(f"Error extracting table info for {table_name}: {str(e)}")
            return None

    async def _get_column_info(self, conn: Any, table_name: str, schema: str) -> List[ColumnInfo]:
        """Get detailed column information."""
        query = """
            SELECT 
                c.COLUMN_NAME,
                c.DATA_TYPE,
                c.DATA_LENGTH,
                c.DATA_PRECISION,
                c.DATA_SCALE,
                c.NULLABLE,
                c.COLUMN_ID,
                c.DEFAULT_LENGTH,
                c.DATA_DEFAULT,
                c.CHARACTER_SET_NAME,
                c.CHAR_LENGTH,
                m.COMMENTS,
                s.NUM_DISTINCT,
                s.NUM_NULLS,
                s.DENSITY,
                s.NUM_BUCKETS,
                s.HISTOGRAM,
                s.SAMPLE_SIZE,
                s.LAST_ANALYZED,
                s.AVG_COL_LEN
            FROM ALL_TAB_COLUMNS c
            LEFT JOIN ALL_COL_COMMENTS m 
                ON c.TABLE_NAME = m.TABLE_NAME 
                AND c.COLUMN_NAME = m.COLUMN_NAME 
                AND c.OWNER = m.OWNER
            LEFT JOIN ALL_TAB_COL_STATISTICS s
                ON c.TABLE_NAME = s.TABLE_NAME 
                AND c.COLUMN_NAME = s.COLUMN_NAME 
                AND c.OWNER = s.OWNER
            WHERE c.OWNER = :schema 
            AND c.TABLE_NAME = :table
            ORDER BY c.COLUMN_ID
        """

        result = conn.execute(text(query), {
            "schema": schema,
            "table": table_name
        })

        columns = []
        for row in result:
            column = ColumnInfo(
                name=row.COLUMN_NAME,
                data_type=self._normalize_data_type(row.DATA_TYPE),
                native_type=row.DATA_TYPE,
                max_length=row.DATA_LENGTH,
                precision=row.DATA_PRECISION,
                scale=row.DATA_SCALE,
                is_nullable=row.NULLABLE == 'Y',
                ordinal_position=row.COLUMN_ID,
                default_value=row.DATA_DEFAULT,
                description=row.COMMENTS,
                character_set=row.CHARACTER_SET_NAME,
                char_length=row.CHAR_LENGTH,
                statistics=OracleColumnStats(
                    num_distinct=row.NUM_DISTINCT,
                    num_nulls=row.NUM_NULLS,
                    density=row.DENSITY,
                    num_buckets=row.NUM_BUCKETS,
                    histogram=row.HISTOGRAM,
                    sample_size=row.SAMPLE_SIZE,
                    last_analyzed=row.LAST_ANALYZED,
                    avg_col_len=row.AVG_COL_LEN,
                    low_value=None,  # Would need additional processing
                    high_value=None  # Would need additional processing
                )
            )
            columns.append(column)

        return columns

    async def _get_indexes(self, conn: Any, table_name: str, schema: str) -> List[OracleIndexInfo]:
        """Get comprehensive index information."""
        query = """
            SELECT 
                i.INDEX_NAME,
                i.INDEX_TYPE,
                i.UNIQUENESS,
                i.TABLESPACE_NAME,
                i.BLEVEL,
                i.LEAF_BLOCKS,
                i.DISTINCT_KEYS,
                i.CLUSTERING_FACTOR,
                i.STATUS,
                i.COMPRESSION,
                i.VISIBILITY,
                LISTAGG(c.COLUMN_NAME, ',') WITHIN GROUP (ORDER BY c.COLUMN_POSITION) as COLUMNS
            FROM ALL_INDEXES i
            JOIN ALL_IND_COLUMNS c 
                ON i.INDEX_NAME = c.INDEX_NAME 
                AND i.OWNER = c.INDEX_OWNER
            WHERE i.TABLE_OWNER = :schema 
            AND i.TABLE_NAME = :table
            GROUP BY 
                i.INDEX_NAME, i.INDEX_TYPE, i.UNIQUENESS, i.TABLESPACE_NAME,
                i.BLEVEL, i.LEAF_BLOCKS, i.DISTINCT_KEYS, i.CLUSTERING_FACTOR,
                i.STATUS, i.COMPRESSION, i.VISIBILITY
        """

        result = conn.execute(text(query), {
            "schema": schema,
            "table": table_name
        })

        return [
            OracleIndexInfo(
                name=row.INDEX_NAME,
                type=row.INDEX_TYPE,
                uniqueness=row.UNIQUENESS,
                tablespace_name=row.TABLESPACE_NAME,
                columns=row.COLUMNS.split(','),
                blevel=row.BLEVEL,
                leaf_blocks=row.LEAF_BLOCKS,
                distinct_keys=row.DISTINCT_KEYS,
                clustering_factor=row.CLUSTERING_FACTOR,
                status=row.STATUS,
                compression=row.COMPRESSION,
                visibility=row.VISIBILITY
            )
            for row in result
        ]

    async def _get_partitioning_info(
            self,
            conn: Any,
            table_name: str,
            schema: str
    ) -> Optional[OraclePartitionInfo]:
        """Get detailed partitioning information."""
        query = """
            SELECT 
                PARTITIONING_TYPE,
                SUBPARTITIONING_TYPE,
                PARTITION_COUNT,
                DEF_TABLESPACE_NAME,
                DEF_COMPRESSION,
                DEF_COMPRESS_FOR
            FROM ALL_PART_TABLES
            WHERE OWNER = :schema AND TABLE_NAME = :table
        """

        result = conn.execute(text(query), {
            "schema": schema,
            "table": table_name
        })

        row = result.first()
        if not row:
            return None

        # Get partitioning keys
        part_keys_query = """
            SELECT COLUMN_NAME
            FROM ALL_PART_KEY_COLUMNS
            WHERE OWNER = :schema 
            AND NAME = :table 
            AND OBJECT_TYPE = 'TABLE'
            ORDER BY COLUMN_POSITION
        """

        part_keys = conn.execute(text(part_keys_query), {
            "schema": schema,
            "table": table_name
        }).scalars().all()

        # Get partition details
        partitions_query = """
            SELECT 
                PARTITION_NAME,
                HIGH_VALUE,
                TABLESPACE_NAME,
                COMPRESSION,
                NUM_ROWS,
                BLOCKS
            FROM ALL_TAB_PARTITIONS
        ```python
                    WHERE TABLE_OWNER = :schema 
                    AND TABLE_NAME = :table
                    ORDER BY PARTITION_POSITION
                """

        partitions = [
            {
                'name': p.PARTITION_NAME,
                'high_value': p.HIGH_VALUE,
                'tablespace': p.TABLESPACE_NAME,
                'compression': p.COMPRESSION,
                'num_rows': p.NUM_ROWS,
                'blocks': p.BLOCKS
            }
            for p in conn.execute(text(partitions_query), {
                "schema": schema,
                "table": table_name
            })
        ]

        return OraclePartitionInfo(
            partition_type=row.PARTITIONING_TYPE,
            partition_count=row.PARTITION_COUNT,
            subpartition_type=row.SUBPARTITIONING_TYPE,
            partitioning_key_columns=part_keys,
            subpartitioning_key_columns=[],  # Would need additional query
            partition_details=partitions
        )

    async def _get_table_statistics(
            self,
            conn: Any,
            table_name: str,
            schema: str
    ) -> OracleTableStats:
        """Get comprehensive table statistics."""
        query = """
                    SELECT 
                        t.NUM_ROWS,
                        t.BLOCKS,
                        t.AVG_ROW_LEN,
                        t.SAMPLE_SIZE,
                        t.LAST_ANALYZED,
                        t.PARTITIONED,
                        t.TEMPORARY,
                        t.COMPRESSION,
                        t.TABLESPACE_NAME,
                        t.LOGGING,
                        t.DEGREE,
                        t.ROW_MOVEMENT,
                        s.PARTITION_COUNT
                    FROM ALL_TABLES t
                    LEFT JOIN (
                        SELECT TABLE_NAME, COUNT(*) as PARTITION_COUNT
                        FROM ALL_TAB_PARTITIONS
                        WHERE TABLE_OWNER = :schema
                        GROUP BY TABLE_NAME
                    ) s ON t.TABLE_NAME = s.TABLE_NAME
                    WHERE t.OWNER = :schema 
                    AND t.TABLE_NAME = :table
                """

        result = conn.execute(text(query), {
            "schema": schema,
            "table": table_name
        })

        row = result.first()
        return OracleTableStats(
            num_rows=row.NUM_ROWS or 0,
            blocks=row.BLOCKS or 0,
            avg_row_len=row.AVG_ROW_LEN or 0,
            sample_size=row.SAMPLE_SIZE or 0,
            last_analyzed=row.LAST_ANALYZED,
            partition_count=row.PARTITION_COUNT or 0,
            temporary=row.TEMPORARY == 'Y',
            compression=row.COMPRESSION,
            tablespace_name=row.TABLESPACE_NAME,
            logging=row.LOGGING == 'YES',
            degree=row.DEGREE,
            row_movement=row.ROW_MOVEMENT
        )

    async def _get_table_constraints(self, conn: Any, table_name: str, schema: str) -> List[Dict]:
        """Get table constraints including check constraints."""
        query = """
                    SELECT 
                        c.CONSTRAINT_NAME,
                        c.CONSTRAINT_TYPE,
                        c.SEARCH_CONDITION,
                        c.STATUS,
                        c.DEFERRABLE,
                        c.DEFERRED,
                        c.VALIDATED,
                        c.GENERATED,
                        c.BAD,
                        c.RELY,
                        c.LAST_CHANGE,
                        LISTAGG(cc.COLUMN_NAME, ',') WITHIN GROUP (ORDER BY cc.POSITION) as COLUMNS,
                        r.OWNER as R_OWNER,
                        r.TABLE_NAME as R_TABLE_NAME,
                        LISTAGG(rc.COLUMN_NAME, ',') WITHIN GROUP (ORDER BY rc.POSITION) as R_COLUMNS
                    FROM ALL_CONSTRAINTS c
                    LEFT JOIN ALL_CONS_COLUMNS cc 
                        ON c.CONSTRAINT_NAME = cc.CONSTRAINT_NAME 
                        AND c.OWNER = cc.OWNER
                    LEFT JOIN ALL_CONSTRAINTS r 
                        ON c.R_CONSTRAINT_NAME = r.CONSTRAINT_NAME 
                        AND c.R_OWNER = r.OWNER
                    LEFT JOIN ALL_CONS_COLUMNS rc 
                        ON r.CONSTRAINT_NAME = rc.CONSTRAINT_NAME 
                        AND r.OWNER = rc.OWNER
                    WHERE c.OWNER = :schema 
                    AND c.TABLE_NAME = :table
                    GROUP BY 
                        c.CONSTRAINT_NAME, c.CONSTRAINT_TYPE, c.SEARCH_CONDITION,
                        c.STATUS, c.DEFERRABLE, c.DEFERRED, c.VALIDATED, c.GENERATED,
                        c.BAD, c.RELY, c.LAST_CHANGE, r.OWNER, r.TABLE_NAME
                """

        result = conn.execute(text(query), {
            "schema": schema,
            "table": table_name
        })

        constraints = []
        for row in result:
            constraint = {
                'name': row.CONSTRAINT_NAME,
                'type': row.CONSTRAINT_TYPE,
                'status': row.STATUS,
                'deferrable': row.DEFERRABLE,
                'deferred': row.DEFERRED,
                'validated': row.VALIDATED,
                'generated': row.GENERATED,
                'bad': row.BAD,
                'rely': row.RELY,
                'last_change': row.LAST_CHANGE,
                'columns': row.COLUMNS.split(',') if row.COLUMNS else []
            }

            # Add check constraint condition
            if row.CONSTRAINT_TYPE == 'C':
                constraint['condition'] = row.SEARCH_CONDITION

            # Add foreign key reference
            if row.CONSTRAINT_TYPE == 'R':
                constraint['references'] = {
                    'schema': row.R_OWNER,
                    'table': row.R_TABLE_NAME,
                    'columns': row.R_COLUMNS.split(',') if row.R_COLUMNS else []
                }

            constraints.append(constraint)

        return constraints

    async def _get_triggers(self, conn: Any, table_name: str, schema: str) -> List[Dict]:
        """Get table triggers with their definitions."""
        query = """
                    SELECT 
                        TRIGGER_NAME,
                        TRIGGER_TYPE,
                        TRIGGERING_EVENT,
                        STATUS,
                        TRIGGER_BODY,
                        DESCRIPTION,
                        WHEN_CLAUSE,
                        CROSS_EDITION,
                        BEFORE_STATEMENT,
                        BEFORE_ROW,
                        AFTER_ROW,
                        AFTER_STATEMENT,
                        INSTEAD_OF_ROW
                    FROM ALL_TRIGGERS
                    WHERE TABLE_OWNER = :schema 
                    AND TABLE_NAME = :table
                """

        result = conn.execute(text(query), {
            "schema": schema,
            "table": table_name
        })

        return [
            {
                'name': row.TRIGGER_NAME,
                'type': row.TRIGGER_TYPE,
                'event': row.TRIGGERING_EVENT,
                'status': row.STATUS,
                'body': row.TRIGGER_BODY,
                'description': row.DESCRIPTION,
                'when_clause': row.WHEN_CLAUSE,
                'timing': {
                    'before_statement': row.BEFORE_STATEMENT == 'YES',
                    'before_row': row.BEFORE_ROW == 'YES',
                    'after_row': row.AFTER_ROW == 'YES',
                    'after_statement': row.AFTER_STATEMENT == 'YES',
                    'instead_of_row': row.INSTEAD_OF_ROW == 'YES'
                },
                'cross_edition': row.CROSS_EDITION == 'YES'
            }
            for row in result
        ]

    async def _get_dependencies(self, conn: Any, table_name: str, schema: str) -> Dict[str, List]:
        """Get table dependencies (both dependent and referenced objects)."""
        dependent_query = """
                    SELECT 
                        TYPE,
                        OWNER,
                        NAME,
                        REFERENCED_OWNER,
                        REFERENCED_NAME,
                        REFERENCED_TYPE,
                        DEPENDENCY_TYPE
                    FROM ALL_DEPENDENCIES
                    WHERE REFERENCED_OWNER = :schema 
                    AND REFERENCED_NAME = :table
                """

        referenced_query = """
                    SELECT 
                        TYPE,
                        OWNER,
                        NAME,
                        REFERENCED_OWNER,
                        REFERENCED_NAME,
                        REFERENCED_TYPE,
                        DEPENDENCY_TYPE
                    FROM ALL_DEPENDENCIES
                    WHERE OWNER = :schema 
                    AND NAME = :table
                """

        dependent_objects = [
            {
                'type': row.TYPE,
                'owner': row.OWNER,
                'name': row.NAME,
                'dependency_type': row.DEPENDENCY_TYPE
            }
            for row in conn.execute(text(dependent_query), {
                "schema": schema,
                "table": table_name
            })
        ]

        referenced_objects = [
            {
                'type': row.REFERENCED_TYPE,
                'owner': row.REFERENCED_OWNER,
                'name': row.REFERENCED_NAME,
                'dependency_type': row.DEPENDENCY_TYPE
            }
            for row in conn.execute(text(referenced_query), {
                "schema": schema,
                "table": table_name
            })
        ]

        return {
            'dependent_objects': dependent_objects,
            'referenced_objects': referenced_objects
        }

    async def _extract_metadata(self) -> Dict:
        """Extract database-wide metadata."""
        try:
            with self._db_cursor() as conn:
                metadata = {}

                # Get database version
                version_query = "SELECT * FROM V$VERSION"
                version = conn.execute(text(version_query)).scalar()
                metadata['version'] = version

                # Get database parameters
                params_query = """
                            SELECT NAME, VALUE, DESCRIPTION
                            FROM V$PARAMETER
                            WHERE ISMODIFIED != 'FALSE'
                        """
                parameters = [
                    {
                        'name': row.NAME,
                        'value': row.VALUE,
                        'description': row.DESCRIPTION
                    }
                    for row in conn.execute(text(params_query))
                ]
                metadata['parameters'] = parameters

                # Get tablespace information
                tablespace_query = """
                            SELECT 
                                t.TABLESPACE_NAME,
                                t.BLOCK_SIZE,
                                t.INITIAL_EXTENT,
                                t.MAX_EXTENTS,
                                t.STATUS,
                                df.BYTES,
                                df.MAXBYTES,
                                df.USER_BYTES
                            FROM DBA_TABLESPACES t
                            JOIN DBA_DATA_FILES df ON t.TABLESPACE_NAME = df.TABLESPACE_NAME
                        """
                tablespaces = [
                    {
                        'name': row.TABLESPACE_NAME,
                        'block_size': row.BLOCK_SIZE,
                        'initial_extent': row.INITIAL_EXTENT,
                        'max_extents': row.MAX_EXTENTS,
                        'status': row.STATUS,
                        'size_bytes': row.BYTES,
                        'max_size_bytes': row.MAXBYTES,
                        'user_bytes': row.USER_BYTES
                    }
                    for row in conn.execute(text(tablespace_query))
                ]
                metadata['tablespaces'] = tablespaces

                return metadata

        except Exception as e:
            logger.error(f"Error extracting metadata: {str(e)}")
            return {}

    def _normalize_data_type(self, oracle_type: str) -> str:
        """Normalize Oracle data types to standard types."""
        type_mapping = {
            'NUMBER': 'NUMBER',
            'VARCHAR2': 'STRING',
            'NVARCHAR2': 'STRING',
            'CHAR': 'STRING',
            'NCHAR': 'STRING',
            'DATE': 'DATE',
            'TIMESTAMP': 'TIMESTAMP',
            'CLOB': 'TEXT',
            'NCLOB': 'TEXT',
            'BLOB': 'BINARY',
            'RAW': 'BINARY',
            'LONG RAW': 'BINARY',
            'FLOAT': 'FLOAT',
            'BINARY_FLOAT': 'FLOAT',
            'BINARY_DOUBLE': 'DOUBLE',
            'XMLTYPE': 'XML',
            'INTERVAL YEAR TO MONTH': 'INTERVAL',
            'INTERVAL DAY TO SECOND': 'INTERVAL',
            'BFILE': 'BINARY',
            'ROWID': 'STRING',
            'UROWID': 'STRING'
        }
        return type_mapping.get(oracle_type.upper(), 'OTHER')

   