
from sqlalchemy import create_engine, MetaData, inspect, text
from sqlalchemy.engine import Engine, Connection
from sqlalchemy.schema import Table
from typing import List, Dict, Optional, Any
from dataclasses import dataclass
from datetime import datetime
import asyncio
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import logging
from contextlib import contextmanager
from .base_extractor import BaseSchemaExtractor
from .schemas import DatabaseSchema, DatabaseVendor, TableInfo, ColumnInfo

from ..config.db_config import DBConfig

logger = logging.getLogger(__name__)


@dataclass
class AccessTableMetadata:
    """Enhanced Access table metadata."""
    table_type: str
    connect_string: Optional[str] = None
    date_created: Optional[datetime] = None
    date_modified: Optional[datetime] = None
    records_count: int = 0
    table_guid: Optional[str] = None
    validation_rule: Optional[str] = None
    validation_text: Optional[str] = None


@dataclass
class AccessIndex:
    """Access index information."""
    name: str
    columns: List[str]
    unique: bool = False
    primary: bool = False
    clustered: bool = False
    ignore_nulls: bool = False
    foreign_key: bool = False
    index_type: str = 'BTREE'


@dataclass
class AccessConstraint:
    """Access constraint information."""
    name: str
    type: str
    columns: List[str]
    referenced_table: Optional[str] = None
    referenced_columns: Optional[List[str]] = None
    check_clause: Optional[str] = None
    deferrable: bool = False
    validated: bool = True


class AccessSQLAlchemyExtractor(BaseSchemaExtractor):
    """Advanced Microsoft Access schema extractor using SQLAlchemy."""

    def __init__(self, config: DBConfig):
        super().__init__(config)
        self._engine = None
        self.metadata = MetaData()
        self.executor = ThreadPoolExecutor(max_workers=4)
        self._system_tables = {
            'MSysAccessStorage', 'MSysACEs', 'MSysObjects',
            'MSysQueries', 'MSysRelationships', 'MSysNavPaneGroups'
        }

    @property
    def engine(self) -> Engine:
        """Lazy engine initialization."""
        if self._engine is None:
            self._engine = self._create_engine()
        return self._engine

    def _create_engine(self) -> Engine:
        """Create SQLAlchemy engine for Access database."""
        try:
            db_path = Path(self.config.DATABASE).absolute()
            if not db_path.exists():
                raise FileNotFoundError(f"Access database not found: {db_path}")

            connection_string = (
                f"access+pyodbc:///?odbc_connect="
                f"DRIVER={{Microsoft Access Driver (*.mdb, *.accdb)}};"
                f"DBQ={db_path};"
            )

            engine = create_engine(
                connection_string,
                echo=False,
                pool_pre_ping=True,
                pool_recycle=3600,
                connect_args={
                    'autocommit': True
                }
            )

            # Test connection
            with engine.connect() as conn:
                conn.execute(text("SELECT 1"))

            logger.info(f"Successfully created engine for: {db_path.name}")
            return engine

        except Exception as e:
            logger.error(f"Failed to create Access engine: {str(e)}")
            raise

    @contextmanager
    def _db_connection(self) -> Connection:
        """Context manager for database connections."""
        connection = self.engine.connect()
        try:
            yield connection
        finally:
            connection.close()

    async def extract_schema(self) -> DatabaseSchema:
        """Extract complete Access database schema."""
        try:
            inspector = inspect(self.engine)

            # Get user tables
            table_names = [
                name for name in inspector.get_table_names()
                if name not in self._system_tables
            ]

            # Process tables in parallel
            table_futures = []
            for table_name in table_names:
                future = self.executor.submit(
                    self._extract_table_info,
                    table_name,
                    inspector
                )
                table_futures.append(future)

            # Gather results
            tables = []
            for future in asyncio.as_completed(table_futures):
                table_info = await asyncio.wrap_future(future)
                if table_info:
                    tables.append(table_info)

            # Get relationships
            relationships = await self._extract_relationships()

            # Get database metadata
            metadata = await self._extract_metadata()

            schema = DatabaseSchema(
                name=Path(self.config.DATABASE).stem,
                vendor=DatabaseVendor.ACCESS,
                tables=tables,
                relationships=relationships,
                schemas=["default"],
                metadata=metadata
            )

            return schema

        except Exception as e:
            logger.error(f"Error extracting Access schema: {str(e)}")
            raise

    def _extract_table_info(
            self,
            table_name: str,
            inspector: Any
    ) -> Optional[TableInfo]:
        """Extract comprehensive table information."""
        try:
            # Get table from metadata
            table = Table(table_name, self.metadata, autoload_with=self.engine)

            # Get columns
            columns = self._extract_columns(table, inspector)

            # Get constraints
            constraints = self._extract_constraints(table, inspector)

            # Get indexes
            indexes = self._extract_indexes(table, inspector)

            # Get table metadata
            table_metadata = self._extract_table_metadata(table_name)

            # Extract PKs and FKs
            primary_keys = set()
            foreign_keys = {}

            for constraint in constraints:
                if constraint.type == 'PRIMARY KEY':
                    primary_keys.update(constraint.columns)
                elif constraint.type == 'FOREIGN KEY':
                    for i, col in enumerate(constraint.columns):
                        foreign_keys[col] = (
                            f"{constraint.referenced_table}."
                            f"{constraint.referenced_columns[i]}"
                        )

            return TableInfo(
                name=table_name,
                schema="default",
                columns=columns,
                primary_keys=primary_keys,
                foreign_keys=foreign_keys,
                indexes=indexes,
                constraints=constraints,
                metadata=table_metadata
            )

        except Exception as e:
            logger.error(f"Error extracting info for table {table_name}: {str(e)}")
            return None

    def _extract_columns(
            self,
            table: Table,
            inspector: Any
    ) -> List[ColumnInfo]:
        """Extract detailed column information."""
        columns = []

        for column in inspector.get_columns(table.name):
            # Get extended column properties from MSysColumns
            extended_props = self._get_extended_column_props(
                table.name,
                column['name']
            )

            col_info = ColumnInfo(
                name=column['name'],
                data_type=self._normalize_data_type(str(column['type'])),
                native_type=str(column['type']),
                max_length=column.get('length'),
                precision=column.get('precision'),
                scale=column.get('scale'),
                is_nullable=column.get('nullable', True),
                default_value=column.get('default'),
                description=extended_props.get('Description'),
                ordinal_position=len(columns) + 1,
                extra={
                    'validation_rule': extended_props.get('ValidationRule'),
                    'validation_text': extended_props.get('ValidationText'),
                    'input_mask': extended_props.get('InputMask'),
                    'display_format': extended_props.get('Format')
                }
            )
            columns.append(col_info)

        return columns

    def _extract_constraints(
            self,
            table: Table,
            inspector: Any
    ) -> List[AccessConstraint]:
        """Extract table constraints."""
        constraints = []

        # Get primary key constraints
        pk_constraint = inspector.get_pk_constraint(table.name)
        if pk_constraint:
            constraints.append(AccessConstraint(
                name=pk_constraint['name'] or f'PK_{table.name}',
                type='PRIMARY KEY',
                columns=pk_constraint['constrained_columns']
            ))

        # Get foreign key constraints
        for fk in inspector.get_foreign_keys(table.name):
            constraints.append(AccessConstraint(
                name=fk['name'],
                type='FOREIGN KEY',
                columns=fk['constrained_columns'],
                referenced_table=fk['referred_table'],
                referenced_columns=fk['referred_columns']
            ))

        # Get check constraints (if available)
        with self._db_connection() as conn:
            try:
                result = conn.execute(text(f"""
                    SELECT 
                        Name, 
                        Expression
                    FROM MSysObjects
                    WHERE Type=3 AND Container='{table.name}'
                """))

                for row in result:
                    constraints.append(AccessConstraint(
                        name=row.Name,
                        type='CHECK',
                        columns=[],  # Would need additional parsing
                        check_clause=row.Expression
                    ))
            except:
                pass

        return constraints

    def _extract_indexes(
            self,
            table: Table,
            inspector: Any
    ) -> List[AccessIndex]:
        """Extract table indexes."""
        indexes = []

        for idx in inspector.get_indexes(table.name):
            # Get extended index properties
            extended_props = self._get_extended_index_props(
                table.name,
                idx['name']
            )

            index = AccessIndex(
                name=idx['name'],
                columns=idx['column_names'],
                unique=idx['unique'],
                primary=False,  # Updated below if it's a PK
                clustered=extended_props.get('Clustered', False),
                ignore_nulls=extended_props.get('IgnoreNulls', False),
                foreign_key=extended_props.get('Foreign', False),
                index_type=extended_props.get('Type', 'BTREE')
            )

            # Check if this is the primary key index
            pk_constraint = inspector.get_pk_constraint(table.name)
            if (pk_constraint and pk_constraint['name'] == idx['name']):
                index.primary = True

            indexes.append(index)

        return indexes

    def _get_extended_column_props(
            self,
            table_name: str,
            column_name: str
    ) -> Dict:
        """Get extended column properties from MSysColumns."""
        try:
            with self._db_connection() as conn:
                result = conn.execute(text(f"""
                    SELECT 
                        ValidationRule,
                        ValidationText,
                        Description,
                        InputMask,
                        Format
                    FROM MSysColumns
                    WHERE TableName='{table_name}'
                    AND Name='{column_name}'
                """))
                row = result.first()
                if row:
                    return {
                        'ValidationRule': row.ValidationRule,
                        'ValidationText': row.ValidationText,
                        'Description': row.Description,
                        'InputMask': row.InputMask,
                        'Format': row.Format
                    }
                return {}
        except:
            return {}

    def _get_extended_index_props(
            self,
            table_name: str,
            index_name: str
    ) -> Dict:
        """Get extended index properties from MSysIndexes."""
        try:
            with self._db_connection() as conn:
                result = conn.execute(text(f"""
                    SELECT 
                        Primary,
                        Unique,
                        Clustered,
                        IgnoreNulls,
                        Foreign,
                        Name
                    FROM MSysIndexes
                    WHERE TableName='{table_name}'
                    AND Name='{index_name}'
                """))
                row = result.first()
                if row:
                    return {
                        'Primary': row.Primary,
                        'Unique': row.Unique,
                        'Clustered': row.Clustered,
                        'IgnoreNulls': row.IgnoreNulls,
                        'Foreign': row.Foreign
                    }
                return {}
        except:
            return {}

    async def _extract_relationships(self) -> List[Dict]:
        """Extract table relationships."""
        try:
            with self._db_connection() as conn:
                result = conn.execute(text("""
                    SELECT 
                        szRelationship as RelationName,
                        szObject as SourceTable,
                        szReferencedObject as TargetTable,
                        grbit as RelationType
                    FROM MSysRelationships
                """))

                relationships = []
                for row in result:
                    relationships.append({
                        'name': row.RelationName,
                        'source_table': row.SourceTable,
                        'target_table': row.TargetTable,
                        'type': 'one_to_many' if row.RelationType & 0x01 else 'many_to_many'
                    })

                return relationships

        except Exception as e:
            logger.error(f"Error extracting relationships: {str(e)}")
            return []

    async def _extract_metadata(self) -> Dict:
        """Extract database metadata."""
        try:
            metadata = {
                'file_info': {
                    'path': str(Path(self.config.DATABASE).absolute()),
                    'size': Path(self.config.DATABASE).stat().st_size,
                    'created': datetime.fromtimestamp(
                        Path(self.config.DATABASE).stat().st_ctime
                    ),
                    'modified': datetime.fromtimestamp(
                        Path(self.config.DATABASE).stat().st_mtime
                    )
                },
                'connection_info': {
                    'driver': self.engine.driver,
                    'dialect': self.engine.dialect.name
                }
            }

            # Get database properties
            with self._db_connection() as conn:
                try:
                    result = conn.execute(text("SELECT * FROM MSysDB"))
                    row = result.first()
                    if row:
                        metadata['properties'] = {
                            'version': getattr(row, 'Version', None),
                            'collating_order': getattr(row, 'CollatingOrder', None),
                            'query_timeout': getattr(row, 'QueryTimeout', None)
                        }
                except:
                    pass

            return metadata

        except Exception as e:
            logger.error(f"Error extracting metadata: {str(e)}")
            return {}

    def _normalize_data_type(self, access_type: str) -> str:
        """Normalize Access data types."""
        type_mapping = {
            'TEXT': 'STRING',
            'MEMO': 'TEXT',
            'BYTE': 'INTEGER',
            'INTEGER': 'INTEGER',
            'LONG': 'INTEGER',
            'SINGLE': 'FLOAT',
            'DOUBLE': 'DOUBLE',
            'CURRENCY': 'DECIMAL',
            'DATETIME': 'DATETIME',
            'BIT': 'BOOLEAN',
            'YESNO': 'BOOLEAN',
            'OLEOBJECT': 'BINARY',
            'LONGBINARY': 'BINARY',
            'GUID': 'STRING',
            'VARBINARY': 'BINARY',
            'DECIMAL': 'DECIMAL',
            'NUMERIC': 'DECIMAL',
            'SHORT': 'INTEGER',
            'FLOAT': 'FLOAT',
            'TIME': 'TIME',
            'DATE': 'DATE'
            }
        # Clean up the type string and extract base type
        base_type = access_type.split('(')[0].upper()
        return type_mapping.get(base_type, 'OTHER')

    def _extract_table_metadata(self, table_name: str) -> AccessTableMetadata:
        """Extract detailed table metadata."""
        try:
            with self._db_connection() as conn:
                # Query MSysObjects for table properties
                result = conn.execute(text("""
                            SELECT 
                                Connect,
                                DateCreate,
                                DateUpdate,
                                Type,
                                Id,
                                ValidationRule,
                                ValidationText,
                                Flags
                            FROM MSysObjects 
                            WHERE Name=:table_name
                        """), {"table_name": table_name})

                row = result.first()
                if not row:
                    return AccessTableMetadata(table_type='TABLE')

                # Get record count
                count_result = conn.execute(text(
                    f"SELECT COUNT(*) as cnt FROM [{table_name}]"
                ))
                record_count = count_result.scalar() or 0

                return AccessTableMetadata(
                    table_type='LINK' if row.Connect else 'TABLE',
                    connect_string=row.Connect,
                    date_created=row.DateCreate,
                    date_modified=row.DateUpdate,
                    records_count=record_count,
                    table_guid=str(row.Id) if row.Id else None,
                    validation_rule=row.ValidationRule,
                    validation_text=row.ValidationText
                )

        except Exception as e:
            logger.error(f"Error extracting table metadata for {table_name}: {str(e)}")
            return AccessTableMetadata(table_type='TABLE')

    async def _analyze_table_data(self, table_name: str) -> Dict:
        """Analyze table data for statistics."""
        try:
            with self._db_connection() as conn:
                stats = {}

                # Get basic counts
                count_query = f"SELECT COUNT(*) as total FROM [{table_name}]"
                result = conn.execute(text(count_query))
                stats['total_rows'] = result.scalar()

                # Analyze each column
                columns = inspect(self.engine).get_columns(table_name)
                column_stats = {}

                for column in columns:
                    col_name = column['name']
                    col_stats = {}

                    # Get null count
                    null_query = f"""
                                SELECT COUNT(*) as null_count 
                                FROM [{table_name}] 
                                WHERE [{col_name}] IS NULL
                            """
                    result = conn.execute(text(null_query))
                    col_stats['null_count'] = result.scalar()

                    # Get distinct count
                    distinct_query = f"""
                                SELECT COUNT(DISTINCT [{col_name}]) as distinct_count 
                                FROM [{table_name}]
                            """
                    result = conn.execute(text(distinct_query))
                    col_stats['distinct_count'] = result.scalar()

                    # Get min/max for numeric/date columns
                    if column['type'].__visit_name__ in ['INTEGER', 'FLOAT', 'NUMERIC', 'DATETIME']:
                        minmax_query = f"""
                                    SELECT 
                                        MIN([{col_name}]) as min_val,
                                        MAX([{col_name}]) as max_val
                                    FROM [{table_name}]
                                """
                        result = conn.execute(text(minmax_query))
                        row = result.first()
                        if row:
                            col_stats['min_value'] = row.min_val
                            col_stats['max_value'] = row.max_val

                    column_stats[col_name] = col_stats

                stats['column_statistics'] = column_stats
                return stats

        except Exception as e:
            logger.error(f"Error analyzing table data for {table_name}: {str(e)}")
            return {}

    async def get_table_dependencies(self, table_name: str) -> Dict[str, List[str]]:
        """Get table dependencies."""
        try:
            dependencies = {
                'tables_referenced': [],
                'tables_referencing': [],
                'queries_using': [],
                'forms_using': [],
                'reports_using': []
            }

            with self._db_connection() as conn:
                # Get table references
                refs_query = """
                            SELECT DISTINCT 
                                szReferencedObject as referenced_table
                            FROM MSysRelationships
                            WHERE szObject = :table_name
                            UNION
                            SELECT DISTINCT 
                                szObject as referenced_table
                            FROM MSysRelationships
                            WHERE szReferencedObject = :table_name
                        """

                result = conn.execute(text(refs_query), {"table_name": table_name})
                for row in result:
                    if row.referenced_table != table_name:
                        dependencies['tables_referenced'].append(row.referenced_table)

                # Get queries using this table
                try:
                    queries_query = """
                                SELECT Name
                                FROM MSysQueries
                                WHERE Expression LIKE :pattern
                            """
                    pattern = f"%[{table_name}]%"
                    result = conn.execute(text(queries_query), {"pattern": pattern})
                    dependencies['queries_using'] = [row.Name for row in result]
                except:
                    pass

                # Get forms using this table
                try:
                    forms_query = """
                                SELECT Name
                                FROM MSysForms
                                WHERE SourceObject = :table_name
                            """
                    result = conn.execute(text(forms_query), {"table_name": table_name})
                    dependencies['forms_using'] = [row.Name for row in result]
                except:
                    pass

            return dependencies

        except Exception as e:
            logger.error(f"Error getting dependencies for {table_name}: {str(e)}")
            return {}

    async def analyze_database_structure(self) -> Dict:
        """Analyze overall database structure."""
        try:
            analysis = {
                'table_count': 0,
                'total_records': 0,
                'total_indexes': 0,
                'total_relationships': 0,
                'largest_tables': [],
                'most_referenced_tables': [],
                'orphaned_tables': [],
                'circular_references': [],
                'data_types_used': set(),
                'security_info': {}
            }

            with self._db_connection() as conn:
                # Get table counts
                tables_query = """
                            SELECT COUNT(*) as table_count
                            FROM MSysObjects
                            WHERE Type=1 AND Flags=0
                        """
                result = conn.execute(text(tables_query))
                analysis['table_count'] = result.scalar() or 0

                # Get relationship count
                rels_query = "SELECT COUNT(*) as rel_count FROM MSysRelationships"
                result = conn.execute(text(rels_query))
                analysis['total_relationships'] = result.scalar() or 0

                # Get index count
                idx_query = "SELECT COUNT(*) as idx_count FROM MSysIndexes"
                result = conn.execute(text(idx_query))
                analysis['total_indexes'] = result.scalar() or 0

                # Analyze table sizes
                size_query = """
                            SELECT 
                                Name,
                                CAST(ROUND(SUM(Size)/1024.0, 2) as DECIMAL(10,2)) as size_kb
                            FROM MSysObjects
                            WHERE Type=1 AND Flags=0
                            GROUP BY Name
                            ORDER BY size_kb DESC
                            LIMIT 5
                        """
                result = conn.execute(text(size_query))
                analysis['largest_tables'] = [
                    {'name': row.Name, 'size_kb': row.size_kb}
                    for row in result
                ]

                # Find tables without relationships
                orphan_query = """
                            SELECT o.Name
                            FROM MSysObjects o
                            LEFT JOIN MSysRelationships r 
                                ON o.Name = r.szObject 
                                OR o.Name = r.szReferencedObject
                            WHERE o.Type=1 
                            AND o.Flags=0 
                            AND r.szObject IS NULL
                        """
                result = conn.execute(text(orphan_query))
                analysis['orphaned_tables'] = [row.Name for row in result]

                return analysis

        except Exception as e:
            logger.error(f"Error analyzing database structure: {str(e)}")
            return {}

    async def get_access_control_list(self) -> Dict[str, List[Dict]]:
        """Get Access Control List (ACL) information."""
        try:
            acl_info = {
                'users': [],
                'groups': [],
                'permissions': []
            }

            with self._db_connection() as conn:
                # Get user permissions
                try:
                    perms_query = """
                                SELECT 
                                    Username,
                                    ObjectName,
                                    ObjectType,
                                    Permissions
                                FROM MSysAccessObjects
                                ORDER BY Username, ObjectName
                            """
                    result = conn.execute(text(perms_query))
                    for row in result:
                        acl_info['permissions'].append({
                            'user': row.Username,
                            'object': row.ObjectName,
                            'type': row.ObjectType,
                            'permissions': row.Permissions
                        })
                except:
                    pass

            return acl_info

        except Exception as e:
            logger.error(f"Error getting ACL information: {str(e)}")
            return {}
