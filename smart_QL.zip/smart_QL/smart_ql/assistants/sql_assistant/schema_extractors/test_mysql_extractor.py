from smart_ql.assistants.sql_assistant.schema_extractors.mysql_extractor import MySQLSchemaExtractor
from smart_ql.assistants.sql_assistant.config.db_config import DBConfig
from smart_ql.features.data_source.schemas.enums import DatabaseVendor


def mysql_extractor():
    """Test MySQL schema extraction."""

    # Configuration
    config = DBConfig(
        VENDOR=DatabaseVendor.MYSQL,
        HOST="103.185.74.157",
        PORT=3306,
        DATABASE="winner_elearning_db",
        USERNAME="root",
        PASSWORD="Onlykajal111#"
    )

    try:
        # Initialize extractor
        extractor = MySQLSchemaExtractor(config)

        # Extract schema
        schema =  extractor.extract_schema()

        # Print schema information
        print(f"\nDatabase: {schema.name}")
        print(f"MySQL Version: {schema.metadata['version']}")
        print(f"Character Set: {schema.metadata['variables']['character_set_database']}")
        print(f"Total Size: {schema.metadata['size']['total'] / 1024 / 1024:.2f} MB")

        print("\nTables:")
        for table in schema.tables:
            print(f"\nTable: {table.name}")
            print(f"Engine: {table.statistics.engine}")
            print(f"Rows: {table.statistics.rows}")
            print(f"Size: {table.statistics.data_length / 1024:.2f} KB")
            print(f"Created: {table.statistics.created_at}")

            print("\nColumns:")
            for column in table.columns:
                print(f"  - {column.name}: {column.native_type}")
                if column.is_primary_key:
                    print("    (Primary Key)")
                if column.foreign_key_reference:
                    print(f"    (Foreign Key -> {column.foreign_key_reference})")

            if table.indexes:
                print("\nIndexes:")
                for index in table.indexes:
                    print(f"  - {index['name']}: {', '.join(index['columns'])}")
                    if index['unique']:
                        print("    (Unique)")

        print("\nRelationships:")
        for rel in schema.relationships:
            print(f"- {rel['source_table']}.{rel['source_columns'][0]} -> "
                  f"{rel['target_table']}.{rel['target_columns'][0]}")

    except Exception as e:
        print(f"Error testing MySQL extractor: {str(e)}")
config = DBConfig(
        VENDOR=DatabaseVendor.MYSQL,
        HOST="103.185.74.157",
        PORT=3306,
        DATABASE="winner_elearning_db",
        USERNAME="root",
        PASSWORD="Onlykajal111#"
    )
mysql_extractor()