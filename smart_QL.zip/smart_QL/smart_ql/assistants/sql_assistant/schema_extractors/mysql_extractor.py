from typing import List, Dict, Set
import logging
from sqlalchemy import create_engine, inspect, text
from sqlalchemy.engine import Connection
from smart_ql.assistants.sql_assistant.config.db_config import DBConfig
from smart_ql.assistants.sql_assistant.schema_extractors.schemas import DatabaseSchema, TableInfo, DatabaseVendor, \
    ColumnInfo


class MySQLSchemaExtractor:
    """MySQL specific schema extractor using SQLAlchemy."""

    def __init__(self, config: 'DBConfig'):
        self.config = config
        self.engine = self._create_engine()

    def _create_engine(self):
        """Create MySQL engine using SQLAlchemy."""
        try:
            connection_url = self.config.connection_url()
            print(f"Connecting to: {connection_url}")
            engine = create_engine(connection_url)
            logging.info(f"Successfully connected to MySQL database: {self.config.database}")
            return engine
        except Exception as e:
            logging.error(f"Failed to connect to MySQL database: {str(e)}")
            raise

    async def extract_schema(self) -> DatabaseSchema:
        """Extract complete MySQL database schema."""
        try:
            # Create a connection context
            with self.engine.connect() as connection:
                inspector = inspect(self.engine)

                # Get all tables
                tables = []
                for table_name in inspector.get_table_names():
                    table_info = await self.extract_table_info(
                        table_name,
                        self.config.database,
                        inspector,
                        connection
                    )
                    tables.append(table_info)

                # Get relationships
                relationships = await self.get_relationships(inspector)

                # Build complete schema
                schema = DatabaseSchema(
                    name=self.config.database,
                    vendor="mysql",
                    tables=tables,
                    relationships=relationships,
                    schemas=[self.config.database],
                    metadata=await self._extract_metadata(connection)
                )

                return schema

        except Exception as e:
            logging.error(f"Error extracting MySQL schema: {str(e)}")
            raise

    async def extract_table_info(
            self,
            table_name: str,
            schema: str,
            inspector,
            connection: Connection
    ) -> TableInfo:
        """Extract detailed information for a specific table."""
        try:
            columns = []
            primary_keys: Set[str] = set()
            foreign_keys: Dict[str, str] = {}

            # Get primary key information
            pk_constraint = inspector.get_pk_constraint(table_name)
            pk_columns = set(pk_constraint.get('constrained_columns', []))

            # Get column information
            for col in inspector.get_columns(table_name):
                is_primary = col['name'] in pk_columns
                if is_primary:
                    primary_keys.add(col['name'])

                column = ColumnInfo(
                    name=col['name'],
                    data_type=self._normalize_data_type(col['type']),
                    native_type=str(col['type']),
                    max_length=getattr(col['type'], 'length', None),
                    precision=getattr(col['type'], 'precision', None),
                    scale=getattr(col['type'], 'scale', None),
                    is_nullable=col.get('nullable', True),
                    is_primary_key=is_primary,
                    default_value=col.get('default'),
                    description=col.get('comment'),
                    ordinal_position=columns.index(col) if col in columns else len(columns)
                )
                columns.append(column)

            # Get constraints, indexes, and foreign keys
            constraints = await self._get_constraints(table_name, inspector)
            indexes = await self._get_indexes(table_name, inspector)
            foreign_keys = await self._get_foreign_keys(table_name, inspector)

            # Update columns with foreign key information
            for col in columns:
                if col.name in foreign_keys:
                    col.is_foreign_key = True
                    col.foreign_key_reference = foreign_keys[col.name]

            return TableInfo(
                name=table_name,
                db_schema=schema,  # Using renamed field
                columns=columns,
                primary_keys=primary_keys,
                foreign_keys=foreign_keys,
                indexes=indexes,
                constraints=constraints
            )

        except Exception as e:
            logging.error(f"Error extracting table info for {table_name}: {str(e)}")
            raise

    async def get_relationships(self, inspector) -> List[Dict]:
        """Extract table relationships."""
        try:
            relationships = []
            for table_name in inspector.get_table_names():
                for fk in inspector.get_foreign_keys(table_name):
                    relationships.append({
                        'source_table': table_name,
                        'source_column': fk['constrained_columns'][0],
                        'target_table': fk['referred_table'],
                        'target_column': fk['referred_columns'][0],
                        'constraint_name': fk['name'],
                        'type': 'many_to_one'
                    })
            return relationships
        except Exception as e:
            logging.error(f"Error extracting relationships: {str(e)}")
            raise

    async def _get_constraints(self, table_name: str, inspector) -> List[Dict]:
        """Get table constraints."""
        try:
            return inspector.get_check_constraints(table_name)
        except Exception as e:
            logging.error(f"Error getting constraints for {table_name}: {str(e)}")
            return []

    async def _get_indexes(self, table_name: str, inspector) -> List[Dict]:
        """Get table indexes."""
        try:
            return inspector.get_indexes(table_name)
        except Exception as e:
            logging.error(f"Error getting indexes for {table_name}: {str(e)}")
            return []

    async def _get_foreign_keys(self, table_name: str, inspector) -> Dict[str, str]:
        """Get foreign key information."""
        try:
            foreign_keys = {}
            for fk in inspector.get_foreign_keys(table_name):
                foreign_keys[fk['constrained_columns'][0]] = (
                    f"{fk['referred_table']}.{fk['referred_columns'][0]}"
                )
            return foreign_keys
        except Exception as e:
            logging.error(f"Error getting foreign keys for {table_name}: {str(e)}")
            return {}

    async def _extract_metadata(self, connection: Connection) -> Dict:
        """Extract MySQL specific metadata."""
        try:
            metadata = {}

            # Get version using text()
            result = connection.execute(text("SELECT VERSION()"))
            metadata['version'] = result.scalar()

            # Get character set and collation
            result = connection.execute(text(
                "SELECT @@character_set_database, @@collation_database"
            ))
            charset_info = result.fetchone()
            metadata['character_set'] = charset_info[0]
            metadata['collation'] = charset_info[1]

            # Get database variables
            result = connection.execute(text("""
                SHOW VARIABLES WHERE Variable_name IN 
                ('max_connections', 'wait_timeout', 'max_allowed_packet')
            """))
            metadata['variables'] = {
                row[0]: row[1] for row in result.fetchall()
            }

            # Get database size
            result = connection.execute(text(f"""
                SELECT 
                    SUM(data_length + index_length) AS size,
                    SUM(data_length) AS data_size,
                    SUM(index_length) AS index_size
                FROM information_schema.TABLES
                WHERE table_schema = :schema
            """).bindparams(schema=self.config.database))

            size_info = result.fetchone()
            if size_info:
                metadata['database_size'] = {
                    'total_size': size_info[0],
                    'data_size': size_info[1],
                    'index_size': size_info[2]
                }

            return metadata
        except Exception as e:
            logging.error(f"Error extracting metadata: {str(e)}")
            return {}

    def _normalize_data_type(self, data_type) -> str:
        """Normalize MySQL data types to standard types."""
        type_mapping = {
            'INTEGER': 'INTEGER',
            'SMALLINT': 'INTEGER',
            'BIGINT': 'INTEGER',
            'DECIMAL': 'DECIMAL',
            'FLOAT': 'FLOAT',
            'DOUBLE': 'DOUBLE',
            'VARCHAR': 'STRING',
            'CHAR': 'STRING',
            'TEXT': 'TEXT',
            'DATETIME': 'TIMESTAMP',
            'TIMESTAMP': 'TIMESTAMP',
            'DATE': 'DATE',
            'TIME': 'TIME',
            'BOOLEAN': 'BOOLEAN',
            'JSON': 'JSON',
            'BLOB': 'BINARY',
            'ENUM': 'ENUM',
            'SET': 'SET'
        }
        return type_mapping.get(str(data_type).upper(), 'OTHER')