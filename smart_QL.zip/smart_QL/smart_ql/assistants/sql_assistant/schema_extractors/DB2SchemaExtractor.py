
from sqlalchemy import create_engine, text, MetaData, event
from sqlalchemy.engine import URL, Engine
from sqlalchemy.pool import QueuePool
from typing import List, Dict, Optional, Any
from dataclasses import dataclass
from datetime import datetime
import asyncio
from concurrent.futures import ThreadPoolExecutor
from .base_extractor import BaseSchemaExtractor

import logging
from contextlib import contextmanager

from .schemas import DatabaseSchema
from ..config.db_config import DBConfig

logger = logging.getLogger(__name__)


@dataclass
class DB2Statistics:
    """Container for DB2 statistics."""
    row_count: int
    page_count: int
    avg_row_size: float
    compression_ratio: Optional[float]
    data_size: int
    index_size: int
    last_stats_update: datetime
    avg_sequential_fetch_time: Optional[float]
    avg_random_fetch_time: Optional[float]


@dataclass
class DB2TableSpace:
    """Container for tablespace information."""
    name: str
    type: str
    state: str
    total_pages: int
    usable_pages: int
    used_pages: int
    free_pages: int
    auto_resize: bool
    auto_storage: bool


class DB2SchemaExtractor(BaseSchemaExtractor):
    """Advanced DB2 schema extractor using SQLAlchemy."""

    def __init__(self, config: DBConfig):
        super().__init__(config)
        self._engine = None
        self.schema = config.SCHEMA or config.USERNAME.upper()
        self.metadata = MetaData()
        self.executor = ThreadPoolExecutor(max_workers=4)

    @property
    def engine(self) -> Engine:
        """Lazy engine initialization."""
        if self._engine is None:
            self._engine = self._create_engine()
        return self._engine

    def _create_engine(self) -> Engine:
        """Create SQLAlchemy engine with advanced configuration."""
        try:
            url = URL.create(
                "db2+ibm_db",
                username=self.config.USERNAME,
                password=self.config.PASSWORD,
                host=self.config.HOST,
                port=self.config.PORT,
                database=self.config.DATABASE,
                query={
                    "CONNECTTIMEOUT": "20",
                    "TIMEOUT": "30"
                }
            )

            engine = create_engine(
                url,
                poolclass=QueuePool,
                pool_size=10,
                max_overflow=20,
                pool_timeout=30,
                pool_recycle=1800,
                pool_pre_ping=True,
                echo=False
            )

            # Add engine event listeners
            self._setup_engine_events(engine)

            logger.info(f"Successfully created DB2 engine for: {self.config.DATABASE}")
            return engine

        except Exception as e:
            logger.error(f"Failed to create DB2 engine: {str(e)}")
            raise

    def _setup_engine_events(self, engine: Engine):
        """Setup SQLAlchemy engine events."""

        @event.listens_for(engine, 'connect')
        def connect(dbapi_connection, connection_record):
            logger.debug("New DB2 connection established")

        @event.listens_for(engine, 'checkout')
        def checkout(dbapi_connection, connection_record, connection_proxy):
            logger.debug("Connection checked out from pool")

        @event.listens_for(engine, 'checkin')
        def checkin(dbapi_connection, connection_record):
            logger.debug("Connection returned to pool")

    @contextmanager
    def _db_cursor(self):
        """Context manager for database connections."""
        conn = self.engine.connect()
        try:
            yield conn
        finally:
            conn.close()

    async def extract_schema(self) -> DatabaseSchema:
        """Extract complete DB2 schema with advanced features."""
        try:
            tables = []
            relationships = []

            # Get all tables using thread pool
            tables_future = self.executor.submit(self._get_all_tables)
            tables_data = await asyncio.wrap_future(tables_future)

            # Process tables in parallel
            table_futures = []
            for table_data in tables_data:
                future = self.executor.submit(
                    self.extract_table_info,
                    table_data['name'],
                    table_data['schema']
                )
                table_futures.append(future)

            # Gather results
            for future in table_futures:
                table_info = await asyncio.wrap_future(future)
                if table_info:
                    tables.append(table_info)

            # Get relationships
            relationships = await self._get_all_relationships()

            # Get database metadata
            metadata = await self._extract_metadata()

            # Create schema object
            schema = DatabaseSchema(
                name=self.config.DATABASE,
                vendor=DatabaseVendor.DB2,
                tables=tables,
                relationships=relationships,
                schemas=[self.schema],
                metadata=metadata
            )

            return schema

        except Exception as e:
            logger.error(f"Error extracting schema: {str(e)}")
            raise

    def _get_all_tables(self) -> List[Dict[str, Any]]:
        """Get all tables from the database."""
        with self._db_cursor() as conn:
            result = conn.execute(text("""
                SELECT 
                    T.TABSCHEMA, 
                    T.TABNAME, 
                    T.TYPE, 
                    T.CREATE_TIME, 
                    T.REMARKS,
                    T.CARD AS ROW_COUNT,
                    T.NPAGES,
                    T.FPAGES,
                    T.OVERFLOW,
                    TS.TBSPACE AS TABLESPACE,
                    STATS_TIME,
                    LASTUSED
                FROM SYSCAT.TABLES T
                LEFT JOIN SYSCAT.TABLESPACES TS 
                    ON T.TBSPACE = TS.TBSPACE
                WHERE T.TABSCHEMA = :schema
                AND T.TYPE IN ('T', 'V', 'M')
                ORDER BY T.TABNAME
            """), {"schema": self.schema})

            return [
                {
                    'schema': row.TABSCHEMA,
                    'name': row.TABNAME,
                    'type': row.TYPE,
                    'created_at': row.CREATE_TIME,
                    'description': row.REMARKS,
                    'row_count': row.ROW_COUNT,
                    'pages': row.NPAGES,
                    'tablespace': row.TABLESPACE,
                    'last_stats_update': row.STATS_TIME,
                    'last_used': row.LASTUSED
                }
                for row in result
            ]

    async def extract_table_info(self, table_name: str, schema: str) -> Optional[TableInfo]:
        """Extract comprehensive table information."""
        try:
            with self._db_cursor() as conn:
                # Get column information
                columns = await self._get_column_info(conn, table_name, schema)

                # Get table statistics
                stats = await self._get_table_statistics(conn, table_name, schema)

                # Get table constraints
                constraints = await self._get_table_constraints(conn, table_name, schema)

                # Get indexes
                indexes = await self._get_indexes(conn, table_name, schema)

                # Get partitioning information
                partitioning = await self._get_partitioning_info(conn, table_name, schema)

                # Get storage information
                storage = await self._get_storage_info(conn, table_name, schema)

                # Get access patterns
                access_patterns = await self._get_access_patterns(conn, table_name, schema)

                return TableInfo(
                    name=table_name,
                    schema=schema,
                    columns=columns,
                    primary_keys=self._extract_primary_keys(constraints),
                    foreign_keys=self._extract_foreign_keys(constraints),
                    indexes=indexes,
                    statistics=stats,
                    partitioning=partitioning,
                    storage=storage,
                    access_patterns=access_patterns,
                    metadata={
                        'constraints': constraints,
                        'last_analyzed': stats.last_stats_update if stats else None
                    }
                )

        except Exception as e:
            logger.error(f"Error extracting table info for {table_name}: {str(e)}")
            return None

    async def _get_column_info(self, conn: Any, table_name: str, schema: str) -> List[ColumnInfo]:
        """Get detailed column information."""
        result = conn.execute(text("""
            SELECT 
                C.COLNAME,
                C.TYPENAME,
                C.LENGTH,
                C.SCALE,
                C.NULLS,
                C.DEFAULT,
                C.KEYSEQ,
                C.REMARKS,
                C.COLNO,
                C.IDENTITY,
                C.GENERATED,
                C.HIDDEN,
                C.INLINE_LENGTH,
                CASE 
                    WHEN C.DEFAULT LIKE 'CURRENT%' THEN 'SYSTEM'
                    WHEN C.GENERATED != '' THEN 'GENERATED'
                    ELSE 'USER'
                END as DEFAULT_TYPE,
                STATS.COLCARD,
                STATS.HIGH2KEY,
                STATS.LOW2KEY
            FROM SYSCAT.COLUMNS C
            LEFT JOIN SYSCAT.COLDIST STATS 
                ON C.TABSCHEMA = STATS.TABSCHEMA 
                AND C.TABNAME = STATS.TABNAME 
                AND C.COLNAME = STATS.COLNAME
            WHERE C.TABSCHEMA = :schema 
            AND C.TABNAME = :table
            ORDER BY C.COLNO
        """), {"schema": schema, "table": table_name})

        columns = []
        for row in result:
            column = ColumnInfo(
                name=row.COLNAME,
                data_type=self._normalize_data_type(row.TYPENAME),
                native_type=row.TYPENAME,
                max_length=row.LENGTH,
                scale=row.SCALE,
                is_nullable=row.NULLS == 'Y',
                is_primary_key=row.KEYSEQ is not None,
                default_value=row.DEFAULT,
                description=row.REMARKS,
                ordinal_position=row.COLNO,
                is_identity=row.IDENTITY == 'Y',
                is_generated=row.GENERATED != '',
                is_hidden=row.HIDDEN == 'Y',
                inline_length=row.INLINE_LENGTH,
                statistics={
                    'cardinality': row.COLCARD,
                    'high_value': row.HIGH2KEY,
                    'low_value': row.LOW2KEY
                }
            )
            columns.append(column)

        return columns

    async def _get_table_statistics(
            self,
            conn: Any,
            table_name: str,
            schema: str
    ) -> Optional[DB2Statistics]:
        """Get comprehensive table statistics."""
        result = conn.execute(text("""
            SELECT 
                CARD,
                NPAGES,
                FPAGES,
                OVERFLOW,
                TBSPACE,
                INDEXSPACE,
                LONG_TBSPACE,
                PCTROWSCOMPRESSED,
                AVGROWSIZE,
                PCTPAGESAVED,
                STATS_TIME
            FROM SYSCAT.TABLES
            WHERE TABSCHEMA = :schema 
            AND TABNAME = :table
        """), {"schema": schema, "table": table_name})

        row = result.first()
        if row:
            return DB2Statistics(
                row_count=row.CARD,
                page_count=row.NPAGES,
                avg_row_size=row.AVGROWSIZE,
                compression_ratio=row.PCTROWSCOMPRESSED,
                data_size=row.FPAGES * 4096,  # Assuming 4K page size
                index_size=row.INDEXSPACE,
                last_stats_update=row.STATS_TIME,
                avg_sequential_fetch_time=None,  # Would need additional query
                avg_random_fetch_time=None  # Would need additional query
            )
        return None

    def _normalize_data_type(self, db2_type: str) -> str:
        """Normalize DB2 data types to standard types."""
        type_mapping = {
            'SMALLINT': 'INTEGER',
            'INTEGER': 'INTEGER',
            'BIGINT': 'INTEGER',
            'DECIMAL': 'DECIMAL',
            'NUMERIC': 'DECIMAL',
            'REAL': 'FLOAT',
            'DOUBLE': 'DOUBLE',
            'FLOAT': 'FLOAT',
            'CHAR': 'STRING',
            'VARCHAR': 'STRING',
            'LONG VARCHAR': 'TEXT',
            'CLOB': 'TEXT',
            'GRAPHIC': 'STRING',
            'VARGRAPHIC': 'STRING',
            'LONG VARGRAPHIC': 'TEXT',
            'DBCLOB': 'TEXT',
            'BLOB': 'BINARY',
            'DATE': 'DATE',
            'TIME': 'TIME',
            'TIMESTAMP': 'TIMESTAMP',
            'XML': 'XML',
            'BINARY': 'BINARY',
            'VARBINARY': 'BINARY',
            'DECFLOAT': 'DECIMAL'
        }
        return type_mapping.get(db2_type.upper(), 'OTHER')

