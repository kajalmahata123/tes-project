from enum import Enum
from typing import List, Set, Dict

from pydantic import BaseModel, Field


class DatabaseVendor(str, Enum):
    """Supported database vendors."""
    MYSQL = "mysql"
    POSTGRES = "postgres"
    SQLITE = "sqlite"
    ORACLE = "oracle"
    SQLSERVER = "sqlserver"

class ColumnInfo(BaseModel):
    name: str
    data_type: str
    native_type: str
    max_length: int | None = None
    precision: int | None = None
    scale: int | None = None
    is_nullable: bool = True
    is_primary_key: bool = False
    is_foreign_key: bool = False
    foreign_key_reference: str | None = None
    default_value: str | None = None
    description: str | None = None
    ordinal_position: int | None = None


class TableInfo(BaseModel):
    name: str
    db_schema: str = Field(..., description="Database schema name")  # Renamed from 'schema' to avoid conflict
    columns: List[ColumnInfo]
    primary_keys: Set[str]
    foreign_keys: Dict[str, str]
    indexes: List[Dict]
    constraints: List[Dict]

    model_config = {
        "json_schema_extra": {
            "examples": [{
                "name": "users",
                "db_schema": "public",
                "columns": [],
                "primary_keys": {"id"},
                "foreign_keys": {},
                "indexes": [],
                "constraints": []
            }]
        }
    }


class DatabaseSchema(BaseModel):
    name: str
    vendor: str
    tables: List[TableInfo]
    relationships: List[Dict]
    schemas: List[str]
    metadata: Dict

    model_config = {
        "json_schema_extra": {
            "examples": [{
                "name": "test_db",
                "vendor": "mysql",
                "tables": [],
                "relationships": [],
                "schemas": ["public"],
                "metadata": {}
            }]
        }
    }