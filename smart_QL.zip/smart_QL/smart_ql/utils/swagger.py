from pathlib import Path

from apispec import APISpec
from apispec.ext.marshmallow import MarshmallowPlugin
from flask_apispec.extension import FlaskApiSpec

class CustomFlaskApiSpec(FlaskApiSpec):
    def __init__(self, app=None, **kwargs):
        super().__init__(app, **kwargs)

    def path_helper(self, *args, **kwargs):
        operations = kwargs.get('operations', {})
        # Remove OPTIONS from operations
        if 'options' in operations:
            del operations['options']
        kwargs['operations'] = operations
        return Path(*args, **kwargs)

def init_swagger(app):
    app.config.update({
        'APISPEC_SPEC': APISpec(
            title='Quick Sense API Documentation',
            version='v1',
            openapi_version='2.0',
            plugins=[MarshmallowPlugin()],
            info={
                'description': 'API documentation for Quick Sense Backend',
                'termsOfService': 'http://quicksense.com/terms/',
                'contact': {'email': 'support@quicksense.com'},
                'license': {'name': 'MIT'},
            },
            security=[{'ApiKeyAuth': []}],
            components={
                'securitySchemes': {
                    'ApiKeyAuth': {
                        'type': 'apiKey',
                        'in': 'header',
                        'name': 'X-API-Key',
                        'description': 'API key for authentication'
                    }
                }
            }
        ),
        'APISPEC_SWAGGER_URL': '/api/swagger.json',
        'APISPEC_SWAGGER_UI_URL': '/api/swagger'
    })

    return CustomFlaskApiSpec(app)