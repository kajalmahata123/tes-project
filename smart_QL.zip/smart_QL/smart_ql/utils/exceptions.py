class QuickSenseError(Exception):
    """Base exception for Quick Sense"""
    def __init__(self, message="An error occurred"):
        self.message = message
        super().__init__(self.message)

class DatabaseError(QuickSenseError):
    """Raised when database operations fail"""
    def __init__(self, message="Database operation failed"):
        super().__init__(message)

class DuplicateError(QuickSenseError):
    """Raised when trying to create a duplicate record"""
    def __init__(self, message="Record already exists"):
        super().__init__(message)

class NotFoundError(QuickSenseError):
    """Raised when a record is not found"""
    def __init__(self, message="Record not found"):
        super().__init__(message)

class ValidationError(QuickSenseError):
    """Raised when validation fails"""
    def __init__(self, message="Validation failed"):
        super().__init__(message)