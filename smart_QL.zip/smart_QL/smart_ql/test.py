import pymysql

try:
    connection = pymysql.connect(
        host='103.185.74.157',
        user='root',
        password='Onlykajal111#',
        database='smart_ql',
        port=3306
    )
    print("Successfully connected to the database!")
except Exception as e:
    print(f"Error connecting to the database: {str(e)}")