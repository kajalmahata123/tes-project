from datetime import datetime
import platform
import psutil
import sys
import os
import socket
from fastapi import APIRouter
health_router = APIRouter()
def get_detailed_system_info():
    """Get detailed system information"""
    try:
        # CPU Information
        cpu_info = {
            'physical_cores': psutil.cpu_count(logical=False),
            'total_cores': psutil.cpu_count(logical=True),
            'cpu_percent_per_core': [percentage for percentage in psutil.cpu_percent(percpu=True)],
            'cpu_freq': {
                'current': psutil.cpu_freq().current,
                'min': psutil.cpu_freq().min,
                'max': psutil.cpu_freq().max
            },
            'cpu_stats': dict(psutil.cpu_stats()._asdict()),
            'cpu_percent': psutil.cpu_percent()
        }

        # Memory Information
        memory = psutil.virtual_memory()
        memory_info = {
            'total': memory.total,
            'available': memory.available,
            'used': memory.used,
            'free': memory.free,
            'percent': memory.percent,
            'active': memory.active,
            'inactive': memory.inactive,
            'buffers': memory.buffers if hasattr(memory, 'buffers') else None,
            'cached': memory.cached if hasattr(memory, 'cached') else None,
            'shared': memory.shared if hasattr(memory, 'shared') else None
        }

        # Disk Information
        disk_info = []
        for partition in psutil.disk_partitions():
            try:
                usage = psutil.disk_usage(partition.mountpoint)
                disk_info.append({
                    'device': partition.device,
                    'mountpoint': partition.mountpoint,
                    'filesystem_type': partition.fstype,
                    'total': usage.total,
                    'used': usage.used,
                    'free': usage.free,
                    'percent': usage.percent
                })
            except Exception:
                continue

        # Network Information
        network_info = {}
        for interface_name, interface_addresses in psutil.net_if_addrs().items():
            addresses = []
            for addr in interface_addresses:
                addresses.append({
                    'address': addr.address,
                    'netmask': addr.netmask,
                    'broadcast': getattr(addr, 'broadcast', None),
                    'family': str(addr.family)
                })
            network_info[interface_name] = addresses

        # Network Statistics
        network_stats = {}
        for interface_name, stats in psutil.net_io_counters(pernic=True).items():
            network_stats[interface_name] = dict(stats._asdict())

        # Process Information
        process = psutil.Process()
        process_info = {
            'pid': process.pid,
            'memory_percent': process.memory_percent(),
            'cpu_percent': process.cpu_percent(),
            'threads': process.num_threads(),
            'connections': len(process.connections())
        }

        # System Information
        system_info = {
            'hostname': socket.gethostname(),
            'platform': {
                'system': platform.system(),
                'release': platform.release(),
                'version': platform.version(),
                'machine': platform.machine(),
                'processor': platform.processor(),
                'architecture': platform.architecture(),
                'python_version': sys.version,
            },
            'boot_time': datetime.fromtimestamp(psutil.boot_time()).isoformat()
        }

        # Environment Information (excluding sensitive data)
        env_info = {
            'python_path': sys.executable,
            'working_directory': os.getcwd(),
            'environment_variables': {
                key: value for key, value in os.environ.items()
                if not any(sensitive in key.lower() for sensitive in ['key', 'secret', 'password', 'token'])
            }
        }

        return {
            'timestamp': datetime.utcnow().isoformat(),
            'system': system_info,
            'cpu': cpu_info,
            'memory': memory_info,
            'disk': disk_info,
            'network': {
                'interfaces': network_info,
                'statistics': network_stats
            },
            'process': process_info,
            'environment': env_info
        }
    except Exception as e:
        return {'error': str(e)}

@health_router.get('/system')
def system_health():
    """Detailed system health check"""
    return get_detailed_system_info()

@health_router.get('/')
def basic_health():
    """Basic health check"""
    return {
        'status': 'healthy',
        'timestamp': datetime.utcnow().isoformat()
    }