from langchain_huggingface import HuggingFaceEndpoint
from typing import Optional

class HuggingFaceClient:
    """
    A singleton class to manage the HuggingFace language model endpoint.

    Attributes:
        _instance (Optional[HuggingFaceClient]): The singleton instance of the HuggingFaceClient.
        llm (Optional[HuggingFaceEndpoint]): The HuggingFace language model endpoint.
    """

    _instance: Optional['HuggingFaceClient'] = None
    llm: Optional[HuggingFaceEndpoint] = None

    def __new__(cls, *args, **kwargs) -> 'HuggingFaceClient':
        """
        Creates a new instance of HuggingFaceClient if one does not already exist.

        Args:
            *args: Variable length argument list.
            **kwargs: Arbitrary keyword arguments.

        Returns:
            HuggingFaceClient: The singleton instance of HuggingFaceClient.
        """
        if not cls._instance:
            cls._instance = super(HuggingFaceClient, cls).__new__(cls)
            cls._instance._initialize(*args, **kwargs)
        return cls._instance

    def _initialize(self, repo_id: str, max_length: int, temperature: float, api_token: str) -> None:
        """
        Initializes the HuggingFaceEndpoint with the given parameters.

        Args:
            repo_id: The repository ID of the HuggingFace model.
            max_length: The maximum length of the generated text.
            temperature: The sampling temperature for text generation.
            api_token: The API token for accessing the HuggingFace model.
        """
        if not self.llm:
            self.llm = HuggingFaceEndpoint(
                repo_id=repo_id,
                max_length=max_length,
                temperature=temperature,
                huggingfacehub_api_token=api_token
            )

    def get_llm(self) -> HuggingFaceEndpoint:
        """
        Gets the initialized HuggingFaceEndpoint instance.

        Returns:
            HuggingFaceEndpoint: The initialized language model endpoint.

        Raises:
            RuntimeError: If the LLM hasn't been initialized.
        """
        if not self.llm:
            raise RuntimeError("HuggingFace LLM has not been initialized")
        return self.llm
