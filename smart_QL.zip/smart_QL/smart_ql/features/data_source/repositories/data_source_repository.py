from typing import List, Optional
from sqlalchemy.orm import Session
from sqlalchemy.exc import SQLAlchemyError
from datetime import datetime

from smart_ql.features.data_source.repositories.data_source_entity import DatabaseConnectionEntity, \
    DatabaseCredentialEntity, DatabaseConfigEntity, DatabaseHealthEntity, DatabaseVendor, ConnectionType, \
    DatabaseHealthStatus


class BaseRepository:
    def __init__(self, db: Session):
        self.db = db

    def commit(self) -> bool:
        try:
            self.db.commit()
            return True
        except SQLAlchemyError as e:
            self.db.rollback()
            raise e

class DatabaseConnectionRepository(BaseRepository):
    def create(self, connection_data: dict) -> DatabaseConnectionEntity:
        try:
            # Convert vendor string to enum value
            vendor_value = connection_data['vendor'].upper()
            if not hasattr(DatabaseVendor, vendor_value):
                raise ValueError(f"Invalid vendor: {connection_data['vendor']}")
            vendor_enum = getattr(DatabaseVendor, vendor_value)

            # Convert connection_type string to enum value
            connection_type_value = connection_data['connection_type'].upper()
            if not hasattr(ConnectionType, connection_type_value):
                raise ValueError(f"Invalid connection type: {connection_data['connection_type']}")
            connection_type_enum = getattr(ConnectionType, connection_type_value)

            # Create main connection entity
            connection = DatabaseConnectionEntity(
                name=connection_data['name'],
                description=connection_data.get('description', ''),
                vendor=vendor_enum,  # Use the enum value
                connection_type=connection_type_enum,  # Use the enum value
                is_active=connection_data.get('is_active', True)
            )
            self.db.add(connection)
            self.db.flush()  # Flush to get the connection ID

            # Create credentials
            if 'credentials' in connection_data:
                credentials = DatabaseCredentialEntity(
                    connection_id=connection.id,
                    **connection_data['credentials']
                )
                self.db.add(credentials)
                self.db.flush()

            # Create config
            if 'database_config' in connection_data:
                config = DatabaseConfigEntity(
                    connection_id=connection.id,
                    **connection_data['database_config']
                )
                self.db.add(config)
                self.db.flush()

            self.commit()
            return connection

        except SQLAlchemyError as e:
            self.db.rollback()
            raise e

    def update(self, connection_id: int, connection_data: dict) -> Optional[DatabaseConnectionEntity]:
        try:
            connection = self.get_by_id(connection_id)
            if not connection:
                return None

            # Update main connection attributes
            for key, value in connection_data.items():
                if hasattr(connection, key) and key not in ['id', 'created_at']:
                    setattr(connection, key, value)

            # Update credentials if provided
            if 'credentials' in connection_data and connection.credentials:
                for key, value in connection_data['credentials'].items():
                    setattr(connection.credentials, key, value)

            # Update config if provided
            if 'database_config' in connection_data and connection.config:
                for key, value in connection_data['database_config'].items():
                    setattr(connection.config, key, value)

            connection.updated_at = datetime.utcnow()
            self.commit()
            return connection

        except SQLAlchemyError as e:
            self.db.rollback()
            raise e

    def delete(self, connection_id: int) -> bool:
        try:
            connection = self.get_by_id(connection_id)
            if not connection:
                return False

            self.db.delete(connection)
            self.commit()
            return True

        except SQLAlchemyError as e:
            self.db.rollback()
            raise e

    def get_by_id(self, connection_id: int) -> Optional[DatabaseConnectionEntity]:
        return self.db.query(DatabaseConnectionEntity)\
            .filter(DatabaseConnectionEntity.id == connection_id)\
            .first()

    def get_all(self) -> List[DatabaseConnectionEntity]:
        return self.db.query(DatabaseConnectionEntity).all()

    def get_by_vendor(self, vendor: str) -> List[DatabaseConnectionEntity]:
        return self.db.query(DatabaseConnectionEntity)\
            .filter(DatabaseConnectionEntity.vendor == vendor)\
            .all()

    def get_active_connections(self) -> List[DatabaseConnectionEntity]:
        return self.db.query(DatabaseConnectionEntity)\
            .filter(DatabaseConnectionEntity.is_active == True)\
            .all()

class DatabaseHealthRepository(BaseRepository):
    def create_or_update(self, health_data: dict) -> DatabaseHealthEntity:
        try:
            # Check if health record exists
            health = self.db.query(DatabaseHealthEntity) \
                .filter(DatabaseHealthEntity.connection_id == health_data['connection_id']) \
                .first()

            if health:
                # Update existing record
                for key, value in health_data.items():
                    if key == 'status':
                        # Convert string status to enum if needed
                        value = DatabaseHealthStatus(value) if isinstance(value, str) else value
                    setattr(health, key, value)
                health.updated_at = datetime.utcnow()
            else:
                # Create new record
                if 'status' in health_data and isinstance(health_data['status'], str):
                    health_data['status'] = DatabaseHealthStatus(health_data['status'])
                health = DatabaseHealthEntity(**health_data)
                self.db.add(health)

            self.db.commit()
            return health

        except SQLAlchemyError as e:
            self.db.rollback()
            raise e

    def get_by_connection_id(self, connection_id: int) -> Optional[DatabaseHealthEntity]:
        return self.db.query(DatabaseHealthEntity)\
            .filter(DatabaseHealthEntity.connection_id == connection_id)\
            .first()

    def get_all_health_metrics(self) -> List[DatabaseHealthEntity]:
        return self.db.query(DatabaseHealthEntity).all()

    def get_critical_connections(self) -> List[DatabaseHealthEntity]:
        return self.db.query(DatabaseHealthEntity)\
            .filter(DatabaseHealthEntity.status == 'critical')\
            .all()

    def get_connections_by_status(self, status: str) -> List[DatabaseHealthEntity]:
        return self.db.query(DatabaseHealthEntity)\
            .filter(DatabaseHealthEntity.status == status)\
            .all()

    def update_connection_status(self, connection_id: int, status: str, metrics: dict = None) -> Optional[DatabaseHealthEntity]:
        try:
            health = self.get_by_connection_id(connection_id)
            if not health:
                return None

            health.status = status
            health.last_checked_at = datetime.utcnow()
            if metrics:
                health.metrics = metrics

            self.commit()
            return health

        except SQLAlchemyError as e:
            self.db.rollback()
            raise e

# Usage example:
"""
# Create repositories with database session
connection_repo = DatabaseConnectionRepository(db_session)
health_repo = DatabaseHealthRepository(db_session)

# Create new connection
connection_data = {
    'name': 'Production MySQL',
    'vendor': 'mysql',
    'connection_type': 'direct',
    'credentials': {
        'username': 'admin',
        'password': 'secure_password'
    },
    'database_config': {
        'host': 'localhost',
        'port': 3306,
        'database_name': 'production_db'
    }
}
new_connection = connection_repo.create(connection_data)

# Update health status
health_data = {
    'connection_id': new_connection.id,
    'status': 'healthy',
    'latency': 45,
    'connections': 10,
    'uptime': '99.99%',
    'last_checked_at': datetime.utcnow()
}
health_metrics = health_repo.create_or_update(health_data)
"""