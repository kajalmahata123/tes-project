from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Boolean, Text, JSON, Enum as SQLEnum
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
import enum

Base = declarative_base()


class BaseEntity(Base):
    __abstract__ = True

    id = Column(Integer, primary_key=True, autoincrement=True)
    created_at = Column(DateTime(timezone=True), default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime(timezone=True), default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)


class ConnectionType(enum.Enum):
    DIRECT = "direct"
    SSH_TUNNEL = "ssh_tunnel"
    CLOUD_SERVICE = "cloud_service"
    IAM = "iam"
    SERVICE_ACCOUNT = "service_account"


class DatabaseVendor(enum.Enum):
    MYSQL = "mysql"
    POSTGRESQL = "postgresql"
    MONGODB = "mongodb"
    MSSQL = "mssql"
    ORACLE = "oracle"
    CLICKHOUSE = "clickhouse"
    REDSHIFT = "redshift"
    SNOWFLAKE = "snowflake"


class DatabaseHealthStatus(enum.Enum):
    HEALTHY = "healthy"
    WARNING = "warning"
    CRITICAL = "critical"


class DatabaseConnectionEntity(BaseEntity):
    __tablename__ = 'database_connections'

    name = Column(String(255), nullable=False)
    description = Column(Text)
    vendor = Column(SQLEnum(DatabaseVendor), nullable=False)
    connection_type = Column(SQLEnum(ConnectionType), nullable=False)
    is_active = Column(Boolean, default=True)
    last_connected_at = Column(DateTime(timezone=True))

    credentials = relationship("DatabaseCredentialEntity", back_populates="connection", uselist=False,
                               cascade="all, delete-orphan")
    config = relationship("DatabaseConfigEntity", back_populates="connection", uselist=False,
                          cascade="all, delete-orphan")
    health_metrics = relationship("DatabaseHealthEntity", back_populates="connection", cascade="all, delete-orphan")

    __table_args__ = (
        {'mysql_engine': 'InnoDB', 'mysql_charset': 'utf8mb4', 'mysql_collate': 'utf8mb4_unicode_ci'}
    )


class DatabaseCredentialEntity(BaseEntity):
    __tablename__ = 'database_credentials'

    connection_id = Column(Integer, ForeignKey('database_connections.id', ondelete='CASCADE'), nullable=False)
    username = Column(String(255))
    password = Column(String(255))
    access_key = Column(String(255))
    secret_key = Column(String(255))
    token = Column(Text)
    service_account_json = Column(JSON)
    certificate = Column(Text)

    connection = relationship("DatabaseConnectionEntity", back_populates="credentials")

    __table_args__ = (
        {'mysql_engine': 'InnoDB', 'mysql_charset': 'utf8mb4', 'mysql_collate': 'utf8mb4_unicode_ci'}
    )


class DatabaseConfigEntity(BaseEntity):
    __tablename__ = 'database_configs'

    connection_id = Column(Integer, ForeignKey('database_connections.id', ondelete='CASCADE'), nullable=False)
    host = Column(String(255))
    port = Column(Integer)
    database_name = Column(String(255), nullable=False)
    db_schema = Column(String(255))
    params = Column(JSON)
    connection_timeout = Column(Integer, default=30)
    query_timeout = Column(Integer, default=60)
    pool_size = Column(Integer, default=5)
    max_overflow = Column(Integer, default=10)
    pool_timeout = Column(Integer, default=30)
    pool_recycle = Column(Integer, default=1800)
    ssl_enabled = Column(Boolean, default=False)
    ssl_verify = Column(Boolean, default=True)
    ssl_ca = Column(Text)

    connection = relationship("DatabaseConnectionEntity", back_populates="config")

    __table_args__ = (
        {'mysql_engine': 'InnoDB', 'mysql_charset': 'utf8mb4', 'mysql_collate': 'utf8mb4_unicode_ci'}
    )


class DatabaseHealthEntity(BaseEntity):
    __tablename__ = 'database_health'

    connection_id = Column(Integer, ForeignKey('database_connections.id', ondelete='CASCADE'), nullable=False)
    status = Column(SQLEnum(DatabaseHealthStatus), nullable=False)
    uptime = Column(String(10))
    latency = Column(Integer)
    connections = Column(Integer)
    last_error = Column(Text)
    last_checked_at = Column(DateTime(timezone=True), nullable=False)
    consecutive_failures = Column(Integer, default=0)
    metrics = Column(JSON)

    connection = relationship("DatabaseConnectionEntity", back_populates="health_metrics")

    __table_args__ = (
        {'mysql_engine': 'InnoDB', 'mysql_charset': 'utf8mb4', 'mysql_collate': 'utf8mb4_unicode_ci'}
    )