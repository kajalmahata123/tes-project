from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional
from pydantic import BaseModel, Field, ConfigDict
from datetime import datetime
from smart_ql.db.database import get_db
from smart_ql.features.data_source.services.datasource_service import DatabaseService

datasource_router = APIRouter()


# Pydantic Models for Request/Response
class DatabaseCredentialsSchema(BaseModel):
    username: Optional[str] = None
    password: Optional[str] = None
    access_key: Optional[str] = None
    secret_key: Optional[str] = None
    token: Optional[str] = None
    service_account_json: Optional[dict] = None
    certificate: Optional[str] = None


class DatabaseConfigSchema(BaseModel):
    host: Optional[str] = None
    port: Optional[int] = None
    database_name: str
    db_schema: Optional[str] = None
    params: dict = Field(default_factory=dict)
    connection_timeout: int = 30
    query_timeout: int = 60
    pool_size: int = 5
    max_overflow: int = 10
    pool_timeout: int = 30
    pool_recycle: int = 1800
    ssl_enabled: bool = False
    ssl_verify: bool = True
    ssl_ca: Optional[str] = None


class DatabaseConnectionCreate(BaseModel):
    name: str
    description: Optional[str] = None
    vendor: str
    connection_type: str
    credentials: Optional[DatabaseCredentialsSchema] = None
    database_config: DatabaseConfigSchema


class DatabaseConnectionUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    vendor: Optional[str] = None
    connection_type: Optional[str] = None
    credentials: Optional[DatabaseCredentialsSchema] = None
    database_config: Optional[DatabaseConfigSchema] = None


class DatabaseHealthResponse(BaseModel):
    id: int
    connection_id: int
    status: str
    uptime: Optional[str] = None
    latency: Optional[float] = None
    connections: Optional[int] = None
    last_error: Optional[str] = None
    last_checked_at: datetime
    consecutive_failures: int = 0
    metrics: Optional[dict] = None

    class Config:
        orm_mode = True


class DatabaseConnectionResponse(BaseModel):
    id: int
    name: str
    description: Optional[str] = None
    vendor: str  # Changed from enum to str
    connection_type: str  # Changed from enum to str
    is_active: bool
    last_connected_at: Optional[datetime] = None
    health_metrics: Optional[List[DatabaseHealthResponse]] = None

    model_config = ConfigDict(from_attributes=True)


# Endpoints
@datasource_router.post("/create", response_model=DatabaseConnectionResponse, status_code=status.HTTP_201_CREATED)
async def create_database_connection(
        connection: DatabaseConnectionCreate,
        db: Session = Depends(get_db)
):
    """Create a new database connection"""
    try:
        service = DatabaseService(db)
        new_connection = await service.create_database_connection(connection.dict())
        response_data = {
            "id": new_connection.id,
            "name": new_connection.name,
            "description": new_connection.description,
            "vendor": new_connection.vendor.value,
            "connection_type": new_connection.connection_type.value,
            "is_active": new_connection.is_active,
            "last_connected_at": new_connection.last_connected_at,
            "health_metrics": [
                {
                    "id": metric.id,
                    "connection_id": metric.connection_id,
                    "status": metric.status.value,
                    "uptime": metric.uptime,
                    "latency": metric.latency,
                    "connections": metric.connections,
                    "last_error": metric.last_error,
                    "last_checked_at": metric.last_checked_at,
                    "consecutive_failures": metric.consecutive_failures,
                    "metrics": metric.metrics
                }
                for metric in new_connection.health_metrics
            ] if new_connection.health_metrics else None
        }

        return DatabaseConnectionResponse(**response_data)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create database connection"
        )


@datasource_router.get("/list", response_model=List[DatabaseConnectionResponse])
async def list_database_connections(
        db: Session = Depends(get_db),
        vendor: Optional[str] = None,
        active_only: bool = False
):
    """List all database connections with optional filtering"""
    try:
        service = DatabaseService(db)
        connections = service.list_connections()

        if vendor:
            connections = [conn for conn in connections if conn.vendor == vendor]
        if active_only:
            connections = [conn for conn in connections if conn.is_active]

        return connections
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to fetch database connections"
        )


@datasource_router.get("/{connection_id}", response_model=DatabaseConnectionResponse)
async def get_database_connection(
        connection_id: int,
        db: Session = Depends(get_db)
):
    """Get a specific database connection by ID"""
    try:
        service = DatabaseService(db)
        connection = service.get_connection(connection_id)
        if not connection:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Database connection not found: {connection_id}"
            )
        return connection
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to fetch database connection"
        )


@datasource_router.put("/{connection_id}", response_model=DatabaseConnectionResponse)
async def update_database_connection(
        connection_id: int,
        connection: DatabaseConnectionUpdate,
        db: Session = Depends(get_db)
):
    """Update an existing database connection"""
    try:
        service = DatabaseService(db)
        updated_connection = await service.update_database_connection(
            connection_id,
            connection.dict(exclude_unset=True)
        )
        if not updated_connection:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Database connection not found: {connection_id}"
            )
        return updated_connection
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update database connection"
        )


@datasource_router.delete("/{connection_id}", status_code=status.HTTP_200_OK)
async def delete_database_connection(
        connection_id: int,
        db: Session = Depends(get_db)
):
    """Delete a database connection"""
    try:
        service = DatabaseService(db)
        if not service.delete_connection(connection_id):
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Database connection not found: {connection_id}"
            )

        return {
            "status": "success",
            "message": f"Database connection  has been successfully deleted"
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete database connection"
        )


@datasource_router.get("/{connection_id}/health", response_model=DatabaseHealthResponse)
async def get_connection_health(
        connection_id: int,
        db: Session = Depends(get_db)
):
    """Get health metrics for a specific database connection"""
    try:
        service = DatabaseService(db)
        health = await service.monitor_database_health(connection_id)
        if not health:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Health metrics not found for connection: {connection_id}"
            )
        return health
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to fetch health metrics"
        )


@datasource_router.get("/health/critical", response_model=List[DatabaseHealthResponse])
async def list_critical_connections(
        db: Session = Depends(get_db)
):
    """List all database connections in critical state"""
    try:
        service = DatabaseService(db)
        return service.get_critical_connections()
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to fetch critical connections"
        )


@datasource_router.post("/{connection_id}/test", status_code=status.HTTP_200_OK)
async def test_connection(
        connection_id: int,
        db: Session = Depends(get_db)
):
    """Test a database connection"""
    try:
        service = DatabaseService(db)
        connection = service.get_connection(connection_id)
        if not connection:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Database connection not found: {connection_id}"
            )

        # This will throw an error if connection fails
        await service.monitor_database_health(connection_id)

        return {"message": "Connection test successful"}
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Connection test failed"
        )