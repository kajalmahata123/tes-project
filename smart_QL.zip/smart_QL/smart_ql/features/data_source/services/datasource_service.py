from typing import List, Optional, Dict, Any
from datetime import datetime
import sqlalchemy
from sqlalchemy.orm import Session
from sqlalchemy.exc import SQLAlchemyError

from smart_ql.features.data_source.repositories.data_source_entity import DatabaseConnectionEntity, \
    DatabaseHealthStatus, DatabaseVendor, DatabaseHealthEntity
from smart_ql.features.data_source.repositories.data_source_repository import DatabaseConnectionRepository, \
    DatabaseHealthRepository


class DatabaseService:
    def __init__(self, db: Session):
        self.db = db
        self.connection_repository = DatabaseConnectionRepository(db)
        self.health_repository = DatabaseHealthRepository(db)

    async def create_database_connection(self, connection_data: Dict[str, Any]) -> DatabaseConnectionEntity:
        """Create a new database connection with validation and testing."""
        try:
            # Validate connection data
            self._validate_connection_data(connection_data)

            # Test the connection before saving
            #await self._test_connection(connection_data)

            # Create connection in database
            connection = self.connection_repository.create(connection_data)
            print('Connection Id',connection.id)
            # Initialize health metrics
            health_data = {
                'connection_id': connection.id,
                'status': DatabaseHealthStatus.HEALTHY,  # Use the Enum directly, not .value
                'uptime': '100%',
                'latency': 0,
                'connections': 0,
                'last_checked_at': datetime.utcnow(),  # Required field (nullable=False)
                'consecutive_failures': 0,
                'metrics': {},
                'last_error': None
            }
            print('Health Data',health_data)
            self.health_repository.create_or_update(health_data)

            return connection

        except ValueError as e:
            raise ValueError(f"Invalid connection data: {str(e)}")
        except SQLAlchemyError as e:
            raise ValueError(f"Database error: {str(e)}")

    def _validate_connection_data(self, connection_data: Dict[str, Any]) -> None:
        """Validate connection data based on vendor requirements."""
        required_fields = ['name', 'vendor', 'connection_type']
        for field in required_fields:
            if field not in connection_data:
                raise ValueError(f"Missing required field: {field}")

        if 'database_config' not in connection_data:
            raise ValueError("Missing database configuration")

        config = connection_data['database_config']
        vendor = connection_data['vendor']

        # Vendor-specific validation
        if vendor == DatabaseVendor.MYSQL:
            required_config = ['host', 'port', 'database_name']
            for field in required_config:
                if field not in config:
                    raise ValueError(f"Missing required MySQL config: {field}")

    async def _test_connection(self, connection_data: Dict[str, Any]) -> None:
        """Test database connection before saving."""
        try:
            config = connection_data['database_config']
            credentials = connection_data.get('credentials', {})
            vendor = connection_data['vendor']

            # Build connection string based on vendor
            if vendor == DatabaseVendor.MYSQL:
                conn_str = f"mysql+pymysql://{credentials.get('username')}:{credentials.get('password')}@{config['host']}:{config['port']}/{config['database_name']}"
            elif vendor == DatabaseVendor.POSTGRESQL:
                conn_str = f"postgresql://{credentials.get('username')}:{credentials.get('password')}@{config['host']}:{config['port']}/{config['database_name']}"
            else:
                raise ValueError(f"Unsupported vendor: {vendor}")

            # Test connection
            engine = sqlalchemy.create_engine(conn_str)
            with engine.connect() as conn:
                conn.execute(sqlalchemy.text("SELECT 1"))

        except Exception as e:
            raise ValueError(f"Connection test failed: {str(e)}")

    async def update_database_connection(
            self, connection_id: int, connection_data: Dict[str, Any]
    ) -> Optional[DatabaseConnectionEntity]:
        """Update an existing database connection."""
        try:
            # Validate update data
            if connection_data.get('vendor'):
                self._validate_connection_data(connection_data)

            # Test new connection settings if configuration changed
            if 'database_config' in connection_data or 'credentials' in connection_data:
                current_connection = self.connection_repository.get_by_id(connection_id)
                if current_connection:
                    test_data = {
                        'vendor': connection_data.get('vendor', current_connection.vendor),
                        'database_config': {
                            **(current_connection.config.__dict__ if current_connection.config else {}),
                            **(connection_data.get('database_config', {}))
                        },
                        'credentials': {
                            **(current_connection.credentials.__dict__ if current_connection.credentials else {}),
                            **(connection_data.get('credentials', {}))
                        }
                    }
                    await self._test_connection(test_data)

            return self.connection_repository.update(connection_id, connection_data)

        except ValueError as e:
            raise ValueError(f"Invalid update data: {str(e)}")
        except SQLAlchemyError as e:
            raise ValueError(f"Database error: {str(e)}")

    async def monitor_database_health(self, connection_id: int) -> DatabaseHealthEntity:
        """Monitor and update database health metrics."""
        try:
            connection = self.connection_repository.get_by_id(connection_id)
            if not connection:
                raise ValueError(f"Connection not found: {connection_id}")

            start_time = datetime.utcnow()
            try:
                # Test connection and measure latency
                await self._test_connection({
                    'vendor': connection.vendor,
                    'database_config': connection.config.__dict__,
                    'credentials': connection.credentials.__dict__
                })
                latency = (datetime.utcnow() - start_time).total_seconds() * 1000

                # Get connection metrics
                metrics = await self._get_connection_metrics(connection)

                # Update health status
                health_data = {
                    'connection_id': connection_id,
                    'status': DatabaseHealthStatus.HEALTHY if latency < 100 else DatabaseHealthStatus.WARNING,
                    'latency': latency,
                    'connections': metrics.get('active_connections', 0),
                    'uptime': metrics.get('uptime', '0%'),
                    'last_checked_at': datetime.utcnow(),
                    'consecutive_failures': 0,
                    'metrics': metrics
                }

            except Exception as e:
                # Handle connection failure
                current_health = self.health_repository.get_by_connection_id(connection_id)
                health_data = {
                    'connection_id': connection_id,
                    'status': DatabaseHealthStatus.CRITICAL,
                    'latency': 0,
                    'connections': 0,
                    'last_error': str(e),
                    'last_checked_at': datetime.utcnow(),
                    'consecutive_failures': (current_health.consecutive_failures + 1 if current_health else 1),
                    'metrics': {}
                }

            return self.health_repository.create_or_update(health_data)

        except Exception as e:
            raise ValueError(f"Health check failed: {str(e)}")

    async def _get_connection_metrics(self, connection: DatabaseConnectionEntity) -> Dict[str, Any]:
        """Get detailed connection metrics based on vendor."""
        try:
            if connection.vendor == DatabaseVendor.MYSQL:
                # Example MySQL metrics query
                engine = sqlalchemy.create_engine(
                    f"mysql+pymysql://{connection.credentials.username}:{connection.credentials.password}"
                    f"@{connection.config.host}:{connection.config.port}/{connection.config.database_name}"
                )
                with engine.connect() as conn:
                    # Get process list
                    result = conn.execute(sqlalchemy.text("SHOW PROCESSLIST"))
                    processes = result.fetchall()

                    # Get status variables
                    result = conn.execute(sqlalchemy.text("SHOW GLOBAL STATUS"))
                    status = dict(result.fetchall())

                    return {
                        'active_connections': len([p for p in processes if p.Command != 'Sleep']),
                        'total_connections': len(processes),
                        'uptime': f"{float(status.get('Uptime', 0)) / 86400:.2f} days",
                        'queries_per_second': float(status.get('Queries', 0)) / float(status.get('Uptime', 1)),
                        'bytes_received': status.get('Bytes_received', 0),
                        'bytes_sent': status.get('Bytes_sent', 0)
                    }

            # Add support for other vendors here
            return {}

        except Exception as e:
            raise ValueError(f"Failed to get metrics: {str(e)}")

    def get_connection(self, connection_id: int) -> Optional[DatabaseConnectionEntity]:
        """Get database connection by ID."""
        return self.connection_repository.get_by_id(connection_id)

    def list_connections(self) -> List[DatabaseConnectionEntity]:
        """List all database connections."""
        return self.connection_repository.get_all()

    def delete_connection(self, connection_id: int) -> bool:
        """Delete a database connection."""
        return self.connection_repository.delete(connection_id)

    def get_health_metrics(self, connection_id: int) -> Optional[DatabaseHealthEntity]:
        """Get health metrics for a specific connection."""
        return self.health_repository.get_by_connection_id(connection_id)

    def list_health_metrics(self) -> List[DatabaseHealthEntity]:
        """List health metrics for all connections."""
        return self.health_repository.list_health_metrics()

    def get_critical_connections(self) -> List[DatabaseHealthEntity]:
        """Get all connections in critical state."""
        return self.health_repository.get_critical_connections()