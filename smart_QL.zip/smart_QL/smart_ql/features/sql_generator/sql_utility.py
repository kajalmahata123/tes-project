import anthropic
from typing import  Dict
from smart_ql.features.semantic_search.vector_store import SchemaStore


class SQLGenerator:
    def __init__(self):
        self.schema_store = SchemaStore()
        self.claude_client = anthropic.Anthropic(api_key="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")

    def _create_prompt(self, question: str, schema_context: Dict) -> str:
        context_parts = []

        if schema_context['tables']:
            context_parts.append("RELEVANT TABLES:")
            for item in sorted(schema_context['tables'],
                             key=lambda x: x['relevance'], reverse=True):
                context_parts.append(f"""
                [Relevance: {item['relevance']:.2f}]
                {item['content']}
                """)

        if schema_context['relationships']:
            context_parts.append("\nRELEVANT RELATIONSHIPS:")
            for item in sorted(schema_context['relationships'],
                             key=lambda x: x['relevance'], reverse=True):
                context_parts.append(f"""
                [Relevance: {item['relevance']:.2f}]
                {item['content']}
                """)

        return f"""Based on this database schema:

{chr(10).join(context_parts)}

Generate a SQL query to answer this question: {question}

Requirements:
- Use only the tables and columns mentioned in the schema
- Create proper JOINs based on the relationships
- Use appropriate WHERE clauses
- Include clear column selections
- Use table aliases for readability
- Consider query performance

Return ONLY the SQL query without any explanation."""

    async def generate_query(
            self,
            question: str,
            user_id: str,
            connection_id: str
    ) -> str:
        try:
            schema_context = await self.schema_store.search_schema(
                query=question,
                user_id=user_id,
                connection_id=connection_id,
                include_embeddings=True
            )

            if not schema_context['tables']:
                raise ValueError("No relevant schema context found for the query")

            prompt = self._create_prompt(question, schema_context)

            response = self.claude_client.messages.create(
                model="claude-3-sonnet-20240229",
                max_tokens=500,
                temperature=0.2,
                system="You are an expert SQL query generator. Return only the SQL query without any explanation.",
                messages=[
                    {"role": "user", "content": prompt}
                ]
            )

            return response.content[0].text.strip()

        except Exception as e:
            print(f"Error generating query: {str(e)}")
            raise