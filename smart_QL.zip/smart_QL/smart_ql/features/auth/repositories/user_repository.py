# repositories/user_repository.py
from typing import Optional
from sqlalchemy.orm import Session

from smart_ql.features.auth.models.user import User


class UserRepository:
    def __init__(self, db_session: Session):
        self.db_session = db_session

    def get_by_id(self, user_id: int) -> Optional[User]:
        return self.db_session.query(User).filter(User.id == user_id).first()

    def get_by_email(self, email: str) -> Optional[User]:
        return self.db_session.query(User).filter(User.email == email).first()

    def create(self, user: User) -> User:
        self.db_session.add(user)
        self.db_session.commit()
        self.db_session.refresh(user)
        return user

    def update(self, user: User) -> User:
        self.db_session.commit()
        self.db_session.refresh(user)
        return user

    def delete(self, user_id: int) -> bool:
        user = self.get_by_id(user_id)
        if user:
            self.db_session.delete(user)
            self.db_session.commit()
            return True
        return False