# services/auth_service.py
from datetime import timedelta
from typing import Optional
from fastapi import HTTPException, status
from config import settings
from smart_ql.features.auth.models.user import User
from smart_ql.features.auth.repositories.user_repository import UserRepository
from smart_ql.features.auth.schemas.schemas import UserCreate, TokenResponse
from smart_ql.features.auth.utils.jwt import create_access_token, create_refresh_token, decode_refresh_token, decode_access_token


class AuthService:
    def __init__(self, user_repository: UserRepository):
        self.user_repository = user_repository

    def register(self, user_data: UserCreate) -> User:
        # Check if user exists
        if self.user_repository.get_by_email(user_data.email):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Email already registered"
            )

        # Create new user
        new_user = User(
            email=user_data.email,
            username=user_data.username,
        )
        new_user.set_password(user_data.password)  # Using the set_password method

        return self.user_repository.create(new_user)

    def authenticate(self, email: str, password: str) -> Optional[User]:
        user = self.user_repository.get_by_email(email)
        if not user or not user.verify_password(password):  # Using verify_password method
            return None
        return user

    def create_tokens(self, user_id: int) -> TokenResponse:
        access_token_expires = timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
        access_token = create_access_token(
            subject=user_id,
            expires_delta=access_token_expires
        )

        refresh_token = create_refresh_token(subject=user_id)

        return TokenResponse(
            access_token=access_token,
            refresh_token=refresh_token,
            token_type="bearer"
        )

    def refresh_tokens(self, refresh_token: str) -> TokenResponse:
        try:
            user_id = decode_refresh_token(refresh_token)
            user = self.user_repository.get_by_id(user_id)

            if not user:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="User not found"
                )

            if not user.is_active:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Inactive user"
                )

            return self.create_tokens(user.id)

        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid refresh token"
            )


    def get_current_user(self, access_token: str) -> User:
        user_id = decode_access_token(access_token)
        user = self.user_repository.get_by_id(user_id)

        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found"
            )

        if not user.is_active:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Inactive user"
            )

        return user