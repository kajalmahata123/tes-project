from sqlalchemy.orm import Session
from smart_ql.features.auth.repositories.user_repository import UserRepository
from smart_ql.features.auth.schemas.schemas import UserCreate, TokenResponse, LoginRequest, RefreshTokenRequest, \
    UserResponse
from smart_ql.features.auth.services.auth_service import AuthService
from smart_ql.db.database import get_db
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from typing import Any
user_router = APIRouter()
security = HTTPBearer()

def get_auth_service(db: Session = Depends(get_db)) -> AuthService:
    user_repository = UserRepository(db)
    return AuthService(user_repository)


@user_router.post("/register", response_model=UserResponse)
async def register(
        user_in: UserCreate,
        auth_service: AuthService = Depends(get_auth_service)
) -> Any:
    """Register new user"""
    user = auth_service.register(user_in)
    return user


@user_router.post("/login", response_model=TokenResponse)
async def login(
        login_data: LoginRequest,
        auth_service: AuthService = Depends(get_auth_service)
) -> Any:
    """Login user and return tokens"""
    user = auth_service.authenticate(login_data.email, login_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password"
        )

    return auth_service.create_tokens(user.id)

@user_router.post("/refresh-token", response_model=TokenResponse)
async def refresh_token(
    refresh_data: RefreshTokenRequest,
    auth_service: AuthService = Depends(get_auth_service)
) -> Any:
    return auth_service.refresh_tokens(refresh_data.refresh_token)

@user_router.get("/me", response_model=UserResponse)
async def get_current_user(
        credentials: HTTPAuthorizationCredentials = Depends(security),
        auth_service: AuthService = Depends(get_auth_service)
) -> Any:
    """
    Get current user details from access token
    """
    try:
        if not credentials:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Missing authentication credentials",
                headers={"WWW-Authenticate": "Bearer"},
            )

        # Token will be automatically extracted from Bearer scheme
        user = auth_service.get_current_user(credentials.credentials)
        return user

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )