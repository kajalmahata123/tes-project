from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from typing import Dict, Any, Optional
from datetime import datetime
from sqlalchemy.orm import Session
from smart_ql.assistants.sql_assistant.config.db_config import DBConfig
from smart_ql.assistants.sql_assistant.schema_extractors.mysql_extractor import MySQLSchemaExtractor
from smart_ql.assistants.sql_assistant.schema_extractors.schemas import DatabaseVendor
from smart_ql.db.database import get_db
from smart_ql.features.data_source.services.datasource_service import DatabaseService
from smart_ql.features.semantic_search.vector_store import SchemaStore
from smart_ql.features.sql_generator.sql_utility import SQLGenerator


class SchemaImportRequest(BaseModel):
    user_id: int = Field(..., description="ID of the user importing the schema")
    connection_id: int = Field(..., description="ID of the connection to associate with")

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": 123,
                "connection_id": 456
            }
        }


class QueryRequest(BaseModel):
    """Model for query generation requests"""
    query_text: str
    user_id: str
    connection_id: str


store_search_router = APIRouter()


class QueryResponse(BaseModel):
    """Model for query generation response"""
    generated_query: str
    timestamp: datetime = datetime.now()


@store_search_router.post("/import", response_model=Dict[str, Any])
async def store_schema(
        import_request: SchemaImportRequest,
        db: Session = Depends(get_db)
):
    """
    Store a schema in the vector database
    """
    try:
        schema_store = SchemaStore()
        service = DatabaseService(db)
        connection = service.get_connection(import_request.connection_id)
        if not connection:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Database connection not found: {import_request.connection_id}"
            )

        # Create config from connection details
        config = DBConfig(
            vendor=connection.vendor.value,
            host=connection.config.host,
            port=connection.config.port,
            database=connection.config.database_name,
            username=connection.credentials.username,
            password=connection.credentials.password
        )
        if connection.vendor == DatabaseVendor.MYSQL:
            extractor = MySQLSchemaExtractor(config)
            schema = await extractor.extract_schema()
        else:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Unsupported database vendor: {connection.vendor}")
        stored_schema = await schema_store.store_schema(
            schema.dict(),
            import_request.user_id,
            import_request.connection_id
        )
        return {
            "status": "success",
            "message": "Schema imported successfully",
            "schema_id": connection.name,
            "timestamp": datetime.now()
        }
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to store schema: {str(e)}"
        )


@store_search_router.post("/generate-query", response_model=QueryResponse)
async def generate_query(
        query_request: QueryRequest
):
    """
    Generate a query based on natural language input
    """
    try:
        generator = SQLGenerator()
        generated_query = await generator.generate_query(
            query_request.query_text,
            query_request.user_id,
            query_request.connection_id
        )

        return QueryResponse(
            generated_query=generated_query
        )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to generate query: {str(e)}"
        )
