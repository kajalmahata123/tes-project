# Database Migration Guide for Quick Sense Backend

## 1. Prerequisites
```bash
# Required packages in requirements.txt
Flask-Migrate==4.0.5
Flask-SQLAlchemy==3.1.1
alembic==1.13.1
mysqlclient==2.2.4
```

## 2. Initial Setup

### 2.1 Database Configuration (config.py)
```python
class DevelopmentConfig(Config):
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://smart_ql:quick-sense123@103.185.74.157:3306/quick_sense_dev'
```

### 2.2 Initialize Migration in Flask App (quick_sense/__init__.py)
```python
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from config import config

db = SQLAlchemy()
migrate = Migrate()

def create_app():
    app = Flask(__name__)
    app.config.from_object(config['development'])
    
    db.init_app(app)
    migrate.init_app(app, db)
    
    return app
```

## 3. Migration Commands

### 3.1 Initialize Migrations
```bash
# Creates migrations folder and configuration
flask db init
```
This creates:
```
migrations/
├── README
├── alembic.ini
├── env.py
├── script.py.mako
└── versions/
```

### 3.2 Create First Migration
```bash
# Create migration for existing models
flask db migrate -m "Initial migration"
```
This generates a migration file in `migrations/versions/` with:
- Upgrade operations (apply changes)
- Downgrade operations (revert changes)

### 3.3 Apply Migrations
```bash
# Apply pending migrations
flask db upgrade
```

### 3.4 Verify Migrations
```sql
-- Connect to MySQL
mysql -h 103.185.74.157 -u quick_sense -p

-- Check tables
USE quick_sense_dev;
SHOW TABLES;
```

## 4. Common Migration Operations

### 4.1 Check Migration Status
```bash
# Show migration history
flask db history

# Show current revision
flask db current

# Show pending migrations
flask db show
```

### 4.2 Rollback Migrations
```bash
# Rollback one migration
flask db downgrade

# Rollback to specific migration
flask db downgrade <migration_id>
```

### 4.3 Creating New Migrations
```bash
# After modifying models, create new migration
flask db migrate -m "Add new field to users"

# Review the generated migration file
# Then apply it
flask db upgrade
```

## 5. Troubleshooting

### 5.1 Common Issues and Solutions

#### Database Connection Issues
```bash
# Check MySQL connection
mysql -h 103.185.74.157 -u smart_ql -p quick_sense_dev -e "SELECT 1"

# Verify environment variables
echo $SQLALCHEMY_DATABASE_URI
```

#### Migration Errors
```bash
# Remove failed migration
flask db revision delete <revision_id>

# Stamp database without running migrations
flask db stamp <revision_id>
```

### 5.2 Verify Database State
```sql
-- Check existing tables
SHOW TABLES;

-- Check table structure
DESCRIBE users;
DESCRIBE applications;
DESCRIBE api_keys;

-- Check alembic version
SELECT * FROM alembic_version;
```

## 6. Best Practices

### 6.1 Before Creating Migrations
```bash
# 1. Update your models
# 2. Review changes
# 3. Create migration with descriptive message
flask db migrate -m "Add user authentication fields"

# 4. Review generated migration file
# 5. Run tests before applying
# 6. Apply migration
flask db upgrade
```

### 6.2 Migration Safety
```bash
# 1. Always backup database before migrations
mysqldump -h 103.185.74.157 -u smart_ql -p quick_sense_dev > backup_$(date +%Y%m%d).sql

# 2. Test migrations in development first
# 3. Use transactions for safer migrations
```

### 6.3 Version Control
```bash
# Always commit these files:
git add migrations/
git add app/models/
git commit -m "Add user authentication migration"
```

## 7. Environment-Specific Migrations

### 7.1 Development
```bash
export FLASK_ENV=development
flask db upgrade
```

### 7.2 Production
```bash
# 1. Backup database
# 2. Test migration in staging
# 3. Apply in production
export FLASK_ENV=production
flask db upgrade
```

## 8. Database Cleanup

### 8.1 Reset Database (Development Only)
```sql
-- Drop all tables
DROP DATABASE quick_sense_dev;
CREATE DATABASE quick_sense_dev;

-- Recreate from scratch
flask db upgrade
```

### 8.2 Clean Migration History
```bash
# Remove old migrations
flask db merge heads
```

Would you like me to add:
1. More complex migration scenarios?
2. Data migration examples?
3. Automated migration testing?
4. Production deployment strategies?