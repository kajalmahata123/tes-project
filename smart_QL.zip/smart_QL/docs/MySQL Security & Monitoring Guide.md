# 1. Advanced Security Configurations

## Password & Authentication
```sql
-- Set strong password policy
SET GLOBAL validate_password.policy = STRONG;
SET GLOBAL validate_password.length = 12;
SET GLOBAL validate_password.mixed_case_count = 1;
SET GLOBAL validate_password.number_count = 1;
SET GLOBAL validate_password.special_char_count = 1;

-- Create user with strong password
CREATE USER 'quick_sense'@'%' IDENTIFIED BY 'StrongPass123!@#' 
    WITH 
    MAX_QUERIES_PER_HOUR 1000
    MAX_CONNECTIONS_PER_HOUR 100
    MAX_USER_CONNECTIONS 10;

-- Require SSL connection
ALTER USER 'quick_sense'@'%' REQUIRE SSL;
```

## Resource Limits & Restrictions
```sql
-- Set connection limits
ALTER USER 'quick_sense'@'%' 
    WITH 
    MAX_QUERIES_PER_HOUR 1000
    MAX_UPDATES_PER_HOUR 500
    MAX_CONNECTIONS_PER_HOUR 100
    MAX_USER_CONNECTIONS 10;

-- Set specific table privileges
GRANT SELECT, INSERT ON quick_sense_dev.applications TO 'quick_sense'@'%';
GRANT SELECT, UPDATE ON quick_sense_dev.api_keys TO 'quick_sense'@'%';
```

## IP-Based Access Control
```sql
-- Allow specific IP range
CREATE USER 'quick_sense'@'192.168.1.%' IDENTIFIED BY 'StrongPass123!@#';

-- Allow multiple specific IPs
CREATE USER 'quick_sense'@'192.168.1.10' IDENTIFIED BY 'StrongPass123!@#';
CREATE USER 'quick_sense'@'192.168.1.11' IDENTIFIED BY 'StrongPass123!@#';
```

# 2. Monitoring User Connections

## Active Connections
```sql
-- Show current connections
SHOW PROCESSLIST;

-- Show only your application connections
SELECT * FROM INFORMATION_SCHEMA.PROCESSLIST 
WHERE USER = 'quick_sense';

-- Show connected users and their host
SELECT user, host, db, command 
FROM INFORMATION_SCHEMA.PROCESSLIST;
```

## Connection Statistics
```sql
-- Show global status
SHOW GLOBAL STATUS LIKE '%connection%';
SHOW GLOBAL STATUS LIKE '%thread%';

-- Show max used connections
SHOW GLOBAL STATUS LIKE 'Max_used_connections';

-- Show connection errors
SHOW GLOBAL STATUS LIKE '%connection_errors%';
```

## User Statistics
```sql
-- Enable user statistics
SET GLOBAL userstat = 1;

-- View user statistics
SELECT * FROM INFORMATION_SCHEMA.USER_STATISTICS;
SELECT * FROM INFORMATION_SCHEMA.CLIENT_STATISTICS;
```

# 3. Backup and Restore Procedures

## Backup Database
```bash
# Full backup
mysqldump -h hostname -u smart_ql -p quick_sense_dev > backup_dev_$(date +%Y%m%d).sql

# Backup specific tables
mysqldump -h hostname -u smart_ql -p quick_sense_dev users applications > backup_tables.sql

# Backup with compression
mysqldump -h hostname -u smart_ql -p quick_sense_dev | gzip > backup_dev_$(date +%Y%m%d).sql.gz
```

## Automated Backup Script
```bash
#!/bin/bash
# backup_script.sh

BACKUP_DIR="/path/to/backups"
DATE=$(date +%Y%m%d)
MYSQL_USER="quick_sense"
MYSQL_PASSWORD="your_password"
MYSQL_HOST="hostname"
DATABASE="quick_sense_dev"

# Create backup
mysqldump -h $MYSQL_HOST -u $MYSQL_USER -p$MYSQL_PASSWORD $DATABASE | gzip > "$BACKUP_DIR/backup_$DATABASE_$DATE.sql.gz"

# Keep only last 7 days of backups
find $BACKUP_DIR -name "backup_$DATABASE_*.sql.gz" -mtime +7 -delete
```

## Restore Database
```bash
# Restore from backup
mysql -h hostname -u smart_ql -p quick_sense_dev < backup_dev.sql

# Restore compressed backup
gunzip < backup_dev.sql.gz | mysql -h hostname -u smart_ql -p quick_sense_dev
```

# 4. Troubleshooting Connection Issues

## Common Issues and Solutions

### Connection Timeout
```sql
-- Check wait_timeout
SHOW VARIABLES LIKE '%timeout%';

-- Increase timeout if needed
SET GLOBAL wait_timeout = 28800;
SET GLOBAL interactive_timeout = 28800;
```

### Too Many Connections
```sql
-- Check max connections
SHOW VARIABLES LIKE 'max_connections';

-- Increase if needed
SET GLOBAL max_connections = 200;

-- Check current connections
SHOW STATUS WHERE Variable_name = 'Threads_connected';
```

### Access Denied Issues
```sql
-- Check user exists
SELECT User, Host FROM mysql.user WHERE User = 'quick_sense';

-- Check user privileges
SHOW GRANTS FOR 'quick_sense'@'%';

-- Verify SSL requirements
SELECT ssl_type FROM mysql.user WHERE User = 'quick_sense';
```

## Monitoring Queries
```sql
-- Enable slow query log
SET GLOBAL slow_query_log = 1;
SET GLOBAL long_query_time = 2;

-- Check slow queries
SHOW VARIABLES LIKE '%slow%';
```

## Performance Monitoring
```sql
-- Check table status
SHOW TABLE STATUS FROM quick_sense_dev;

-- Check index usage
SELECT * FROM INFORMATION_SCHEMA.STATISTICS 
WHERE TABLE_SCHEMA = 'quick_sense_dev';

-- Check table sizes
SELECT 
    table_name,
    table_rows,
    data_length/1024/1024 as data_size_mb,
    index_length/1024/1024 as index_size_mb
FROM information_schema.TABLES 
WHERE table_schema = 'quick_sense_dev';
```
# Basic Setup Commands

1. Create User
```sql
-- Create user allowing connections from any host (%)
CREATE USER 'quick_sense'@'%' IDENTIFIED BY 'quick-sense123';
```
- `'quick_sense'`: Username
- `'%'`: Allows connection from any host
- `'quick-sense123'`: Password

2. Grant Privileges
```sql
-- Grant all privileges on the development database
GRANT ALL PRIVILEGES ON quick_sense_dev.* TO 'quick_sense'@'%';

-- Don't forget to flush privileges
FLUSH PRIVILEGES;
```

# Verify Setup

1. Check User Creation
```sql
-- Check if user exists
SELECT User, Host FROM mysql.user WHERE User = 'quick_sense';

-- Check user's privileges
SHOW GRANTS FOR 'quick_sense'@'%';
```

2. Test Connection
```bash
# Connect to MySQL using the new user
mysql -h 103.185.74.157 -u smart_ql -p
# Enter password when prompted: quick-sense123

# Or in one line (not recommended in production)
mysql -h 103.185.74.157 -u smart_ql -pquick-sense123
```

3. Create and Use Database
```sql
-- Create database if it doesn't exist
CREATE DATABASE IF NOT EXISTS quick_sense_dev;

-- Switch to the database
USE quick_sense_dev;

-- Show tables (will be empty initially)
SHOW TABLES;
```

# Additional Useful Commands

1. Reset Password If Needed
```sql
-- Reset user password
ALTER USER 'quick_sense'@'%' IDENTIFIED BY 'new_password';
```

2. Revoke Privileges If Needed
```sql
-- Remove all privileges
REVOKE ALL PRIVILEGES ON quick_sense_dev.* FROM 'quick_sense'@'%';
```

3. Drop User If Needed
```sql
-- Remove user completely
DROP USER 'quick_sense'@'%';
```

4. Check Database Status
```sql
-- Show all databases
SHOW DATABASES;

-- Check database size
SELECT 
    table_schema "Database Name",
    ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) "Size (MB)"
FROM information_schema.tables
WHERE table_schema = "quick_sense_dev"
GROUP BY table_schema;
```

5. Common Troubleshooting
```sql
-- Check if database exists
SHOW DATABASES LIKE 'quick_sense_dev';

-- Check user's current privileges
SHOW GRANTS;

-- Check current user and host
SELECT CURRENT_USER();

-- Check database character set
SELECT @@character_set_database, @@collation_database;
```