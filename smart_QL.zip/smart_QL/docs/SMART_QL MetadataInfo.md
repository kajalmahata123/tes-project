# Database Schema Documentation

## Tables Overview

The database consists of three main tables:
- `data_sources`: Stores information about database connections
- `schema_analysis`: Tracks schema analysis operations
- `sync_history`: Records synchronization history

## Table Schemas

### Data Sources Table

Table `data_sources` stores database connection and configuration details.

```sql
CREATE TABLE data_sources (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    vendor ENUM('mysql', 'postgresql', 'mongodb', 'oracle', 'sqlserver') NOT NULL,
    connection_type ENUM('direct', 'ssh', 'cloud') NOT NULL,
    credentials JSON NOT NULL,
    database_config JSON NOT NULL,
    ssh_config JSON,
    cloud_config JSON,
    status ENUM('pending', 'active', 'inactive', 'error') DEFAULT 'pending',
    
    -- Metadata
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by VARCHAR(255),
    updated_by VARCHAR(255),
    tags JSON DEFAULT (JSON_ARRAY()),
    
    -- Connection stats
    active_connections INT DEFAULT 0,
    total_connections INT DEFAULT 0,
    last_connected_at DATETIME,
    last_error TEXT,
    error_count INT DEFAULT 0,
    
    -- Sync History
    last_sync_at DATETIME,
    last_sync_status ENUM('pending', 'in_progress', 'completed', 'failed'),
    last_sync_error TEXT,
    total_sync_count INT DEFAULT 0,
    current_schema_hash VARCHAR(64),
    
    INDEX idx_datasource_name (name),
    INDEX idx_datasource_status (status),
    INDEX idx_datasource_last_sync (last_sync_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Add column comments
ALTER TABLE data_sources
    MODIFY COLUMN credentials JSON NOT NULL COMMENT 'Database credentials in JSON format',
    MODIFY COLUMN database_config JSON NOT NULL COMMENT 'Database configuration details',
    MODIFY COLUMN ssh_config JSON COMMENT 'SSH tunnel configuration if applicable',
    MODIFY COLUMN cloud_config JSON COMMENT 'Cloud provider specific configuration',
    MODIFY COLUMN tags JSON COMMENT 'Custom tags for organization',
    MODIFY COLUMN current_schema_hash VARCHAR(64) COMMENT 'Hash of current schema for change detection';

-- Create triggers for audit purposes
DELIMITER //

CREATE TRIGGER before_data_source_update
    BEFORE UPDATE ON data_sources
    FOR EACH ROW
BEGIN
    SET NEW.updated_at = CURRENT_TIMESTAMP;
END//

DELIMITER ;
```

#### Field Descriptions:

[... rest of the README content remains the same ...]

#### Field Descriptions:

- **Primary Information**
  - `id`: Unique identifier for the data source (UUID)
  - `name`: Display name of the data source
  - `description`: Optional description
  - `vendor`: Database vendor (MySQL, PostgreSQL, etc.)
  - `connection_type`: Type of connection (direct, SSH tunnel, cloud)
  - `credentials`: JSON object containing authentication details
  - `database_config`: JSON object with database configuration
  - `ssh_config`: Optional SSH tunnel configuration
  - `cloud_config`: Optional cloud provider configuration
  - `status`: Current status of the data source

- **Metadata**
  - `created_at`: Creation timestamp
  - `updated_at`: Last update timestamp
  - `created_by`: User who created the data source
  - `updated_by`: User who last updated the data source
  - `tags`: Array of tags for organization

- **Connection Statistics**
  - `active_connections`: Current number of active connections
  - `total_connections`: Total number of connections made
  - `last_connected_at`: Last successful connection timestamp
  - `last_error`: Last error message
  - `error_count`: Total number of connection errors

- **Sync Information**
  - `last_sync_at`: Last synchronization timestamp
  - `last_sync_status`: Status of last sync operation
  - `last_sync_error`: Last synchronization error message
  - `total_sync_count`: Total number of synchronizations
  - `current_schema_hash`: Hash for schema change detection

### Schema Analysis Table

Table `schema_analysis` tracks schema analysis operations.

```sql
CREATE TABLE schema_analysis (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    database_source_id VARCHAR(36) NOT NULL,
    analysis_type ENUM('basic', 'enhanced') NOT NULL,
    status ENUM('pending', 'in_progress', 'completed', 'failed') NOT NULL,
    analysis_result JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP,
    error_message TEXT,
    FOREIGN KEY (database_source_id) REFERENCES data_sources(id) ON DELETE CASCADE,
    KEY idx_status (status),
    KEY idx_analysis_type (analysis_type),
    KEY idx_database_source (database_source_id)
);
```

#### Field Descriptions:

- `id`: Unique identifier for the analysis
- `database_source_id`: Reference to data_sources table
- `analysis_type`: Type of analysis performed
- `status`: Current status of the analysis
- `analysis_result`: JSON object containing analysis results
- `created_at`: Analysis start timestamp
- `completed_at`: Analysis completion timestamp
- `error_message`: Error details if analysis failed

### Sync History Table

Table `sync_history` records synchronization operations.

```sql
CREATE TABLE sync_history (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    database_source_id VARCHAR(36) NOT NULL,
    sync_type ENUM('full', 'incremental') NOT NULL,
    status ENUM('pending', 'in_progress', 'completed', 'failed') NOT NULL,
    changes_detected JSON,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    error_message TEXT,
    FOREIGN KEY (database_source_id) REFERENCES data_sources(id) ON DELETE CASCADE,
    KEY idx_status (status),
    KEY idx_database_source (database_source_id)
);
```

#### Field Descriptions:

- `id`: Unique identifier for the sync operation
- `database_source_id`: Reference to data_sources table
- `sync_type`: Type of synchronization (full or incremental)
- `status`: Current status of the sync operation
- `changes_detected`: JSON object containing detected schema changes
- `started_at`: Sync start timestamp
- `completed_at`: Sync completion timestamp
- `error_message`: Error details if sync failed

## Indexes

### data_sources
- `idx_datasource_name`: For searching by name
- `idx_datasource_status`: For filtering by status
- `idx_datasource_last_sync`: For sync history queries

### schema_analysis
- `idx_status`: For status filtering
- `idx_analysis_type`: For analysis type filtering
- `idx_database_source`: For joining with data_sources

### sync_history
- `idx_status`: For status filtering
- `idx_database_source`: For joining with data_sources