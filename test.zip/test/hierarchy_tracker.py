from typing import Dict, List, Optional
from dataclasses import dataclass, field
import logging
from app.test.models import DocumentHierarchy
logger = logging.getLogger(__name__)


@dataclass
class HierarchyTracker:
    """
    Tracks document hierarchy during processing.

    This class maintains the state of document processing, tracking the current
    article, section, subsection, and table being processed.
    """

    articles: Dict = field(default_factory=dict)
    current_article: Optional[str] = None
    current_section: Optional[str] = None
    current_subsection: Optional[str] = None
    current_table: Optional[Dict] = None
    table_buffer: List[str] = field(default_factory=list)

    def start_article(self, article_title: str) -> None:
        """
        Start processing a new article.

        Args:
            article_title: Title of the article
        """
        try:
            self.current_article = article_title
            if article_title not in self.articles:
                self.articles[article_title] = {
                    'content': article_title,
                    'sections': {},
                    'tables': []
                }
            self.current_section = None
            self.current_subsection = None
            logger.debug(f"Started processing article: {article_title}")
        except Exception as e:
            logger.error(f"Error starting article {article_title}: {str(e)}")
            raise

    def start_section(self, section_title: str) -> None:
        """
        Start processing a new section within the current article.

        Args:
            section_title: Title of the section

        Raises:
            ValueError: If no article is currently being processed
        """
        if not self.current_article:
            logger.error("Attempted to start section without active article")
            raise ValueError("Cannot start section without article")

        try:
            self.current_section = section_title
            self.current_subsection = None

            if section_title not in self.articles[self.current_article]['sections']:
                self.articles[self.current_article]['sections'][section_title] = {
                    'content': section_title,
                    'subsections': {},
                    'tables': []
                }
            logger.debug(f"Started processing section: {section_title}")
        except Exception as e:
            logger.error(f"Error starting section {section_title}: {str(e)}")
            raise

    def start_subsection(self, subsection_title: str) -> None:
        """
        Start processing a new subsection within the current section.

        Args:
            subsection_title: Title of the subsection

        Raises:
            ValueError: If no section is currently being processed
        """
        if not self.current_section:
            logger.error("Attempted to start subsection without active section")
            raise ValueError("Cannot start subsection without section")

        try:
            self.current_subsection = subsection_title

            if subsection_title not in self.articles[self.current_article]['sections'][self.current_section][
                'subsections']:
                self.articles[self.current_article]['sections'][self.current_section]['subsections'][
                    subsection_title] = {
                    'content': subsection_title,
                    'tables': []
                }
            logger.debug(f"Started processing subsection: {subsection_title}")
        except Exception as e:
            logger.error(f"Error starting subsection {subsection_title}: {str(e)}")
            raise

    def add_table(self, table_data: Dict) -> None:
        """
        Add a table to the current context (subsection, section, or article).

        Args:
            table_data: Dictionary containing table information
        """
        try:
            if self.current_subsection:
                # Add to subsection
                self.articles[self.current_article]['sections'][self.current_section]['subsections'][
                    self.current_subsection]['tables'].append(table_data)
            elif self.current_section:
                # Add to section
                self.articles[self.current_article]['sections'][self.current_section]['tables'].append(table_data)
            elif self.current_article:
                # Add to article
                self.articles[self.current_article]['tables'].append(table_data)

            logger.debug(f"Added table: {table_data.get('title', 'Untitled')}")
        except Exception as e:
            logger.error(f"Error adding table: {str(e)}")
            raise

    def get_current_hierarchy(self) -> DocumentHierarchy:
        """
        Get the current position in the document hierarchy.

        Returns:
            DocumentHierarchy object representing current position
        """
        return DocumentHierarchy(
            article_id=self.current_article,
            section_id=self.current_section,
            subsection_id=self.current_subsection,
            table_id=self.current_table['title'] if self.current_table else None
        )

    def reset_table_context(self) -> None:
        """Reset the current table context."""
        self.current_table = None
        self.table_buffer = []
        logger.debug("Reset table context")