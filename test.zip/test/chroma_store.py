import chromadb
from chromadb.config import Settings
import hashlib
import json
import logging
from typing import List, Dict, Optional
from datetime import datetime
from .models import DocumentChunk, SearchResult, SearchResponse

logger = logging.getLogger(__name__)


class ChromaDocumentStore:
    """
    ChromaDB-based document store for semantic search capabilities.
    """

    def __init__(self, persist_directory: str = "chroma_store"):
        """
        Initialize the ChromaDB document store.

        Args:
            persist_directory: Directory for ChromaDB persistence
        """
        try:
            self.client = chromadb.Client(Settings(
                persist_directory=persist_directory,
                chroma_db_impl="duckdb+parquet"
            ))

            # Initialize collections
            self.collections = {
                "articles": self.client.get_or_create_collection("articles"),
                "sections": self.client.get_or_create_collection("sections"),
                "tables": self.client.get_or_create_collection("tables"),
                "content": self.client.get_or_create_collection("content")
            }

            logger.info(f"Initialized ChromaDB store in {persist_directory}")
        except Exception as e:
            logger.error(f"Failed to initialize ChromaDB: {str(e)}")
            raise

    def _generate_chunk_id(self, chunk: DocumentChunk) -> str:
        """
        Generate a unique ID for a document chunk.

        Args:
            chunk: DocumentChunk object

        Returns:
            str: Unique identifier
        """
        unique_string = f"{chunk.content}{json.dumps(chunk.metadata.__dict__, sort_keys=True)}"
        return hashlib.md5(unique_string.encode()).hexdigest()

    def _prepare_metadata(self, chunk: DocumentChunk) -> Dict:
        """
        Prepare metadata for ChromaDB storage.

        Args:
            chunk: DocumentChunk object

        Returns:
            Dict: Processed metadata
        """
        return {
            "article_id": chunk.metadata.parent_article or "",
            "section": chunk.metadata.parent_section or "",
            "subsection": chunk.metadata.parent_subsection or "",
            "chunk_type": chunk.metadata.chunk_type.value,
            "page_number": chunk.metadata.page_number,
            "table_title": chunk.metadata.table_title or "",
            "created_at": chunk.metadata.created_at
        }

    def _get_collection_for_chunk(self, chunk: DocumentChunk) -> str:
        """
        Determine appropriate collection for a chunk.

        Args:
            chunk: DocumentChunk object

        Returns:
            str: Collection name
        """
        chunk_type = chunk.metadata.chunk_type
        if chunk_type == "article":
            return "articles"
        elif chunk_type in ["section", "subsection"]:
            return "sections"
        elif "table" in chunk_type:
            return "tables"
        return "content"

    async def store_chunks(self, chunks: List[DocumentChunk]) -> None:
        """
        Store document chunks in appropriate collections.

        Args:
            chunks: List of DocumentChunk objects
        """
        try:
            # Group chunks by collection
            grouped_chunks: Dict[str, List[DocumentChunk]] = {
                collection: [] for collection in self.collections.keys()
            }

            for chunk in chunks:
                collection = self._get_collection_for_chunk(chunk)
                grouped_chunks[collection].append(chunk)

            # Store chunks in appropriate collections
            for collection_name, collection_chunks in grouped_chunks.items():
                if not collection_chunks:
                    continue

                documents = []
                metadatas = []
                ids = []

                for chunk in collection_chunks:
                    documents.append(chunk.content)
                    metadatas.append(self._prepare_metadata(chunk))
                    ids.append(self._generate_chunk_id(chunk))

                self.collections[collection_name].add(
                    documents=documents,
                    metadatas=metadatas,
                    ids=ids
                )

            logger.info(f"Stored {len(chunks)} chunks across collections")
        except Exception as e:
            logger.error(f"Error storing chunks: {str(e)}")
            raise

    async def search(
            self,
            query_text: str,
            article_id: Optional[str] = None,
            n_results: int = 5,
            collection_filter: Optional[List[str]] = None,
            min_relevance_score: float = 0.0
    ) -> SearchResponse:
        """
        Search across collections with optional filtering.

        Args:
            query_text: Search query
            article_id: Optional article ID to filter results
            n_results: Maximum number of results to return
            collection_filter: Optional list of collections to search
            min_relevance_score: Minimum relevance score threshold

        Returns:
            SearchResponse object containing results
        """
        try:
            start_time = datetime.now()
            results = []
            collections_to_query = collection_filter or list(self.collections.keys())

            # Prepare where clause
            where = {"article_id": article_id} if article_id else {}

            # Query each collection
            for collection_name in collections_to_query:
                collection_results = self.collections[collection_name].query(
                    query_texts=[query_text],
                    n_results=n_results,
                    where=where
                )

                # Process results
                for idx, (doc, metadata, distance) in enumerate(zip(
                        collection_results['documents'][0],
                        collection_results['metadatas'][0],
                        collection_results['distances'][0]
                )):
                    relevance_score = 1 - distance
                    if relevance_score >= min_relevance_score:
                        results.append(SearchResult(
                            content=doc,
                            metadata=metadata,
                            relevance_score=relevance_score,
                            collection_type=collection_name
                        ))

            # Sort by relevance and limit results
            results.sort(key=lambda x: x.relevance_score, reverse=True)
            results = results[:n_results]

            query_time = (datetime.now() - start_time).total_seconds() * 1000

            return SearchResponse(
                results=results,
                total_found=len(results),
                query_time_ms=query_time
            )

        except Exception as e:
            logger.error(f"Error performing search: {str(e)}")
            raise

    async def search_within_article(
            self,
            query_text: str,
            article_id: str,
            include_tables: bool = True,
            n_results: int = 5
    ) -> SearchResponse:
        """
        Search within a specific article.

        Args:
            query_text: Search query
            article_id: Article ID to search within
            include_tables: Whether to include table results
            n_results: Maximum number of results to return

        Returns:
            SearchResponse object containing results
        """
        try:
            collection_filter = ["articles", "sections", "content"]
            if include_tables:
                collection_filter.append("tables")

            return await self.search(
                query_text=query_text,
                article_id=article_id,
                n_results=n_results,
                collection_filter=collection_filter
            )

        except Exception as e:
            logger.error(f"Error searching within article: {str(e)}")
            raise

    def get_article_structure(self, article_id: str) -> Dict:
        """
        Retrieve the structure of a specific article.

        Args:
            article_id: Article ID

        Returns:
            Dict containing article structure
        """
        try:
            results = {}

            # Get article content
            article_results = self.collections["articles"].query(
                query_texts=[""],
                where={"article_id": article_id},
                n_results=1
            )

            if article_results['documents'][0]:
                results["content"] = article_results['documents'][0][0]

                # Get sections
                section_results = self.collections["sections"].query(
                    query_texts=[""],
                    where={"article_id": article_id},
                    n_results=100
                )

                results["sections"] = {
                    metadata["section"]: {
                        "content": doc,
                        "subsections": {}
                    }
                    for doc, metadata in zip(
                        section_results['documents'][0],
                        section_results['metadatas'][0]
                    )
                }

                # Get tables
                table_results = self.collections["tables"].query(
                    query_texts=[""],
                    where={"article_id": article_id},
                    n_results=100
                )

                results["tables"] = [
                    {
                        "title": metadata["table_title"],
                        "content": doc,
                        "section": metadata["section"],
                        "subsection": metadata["subsection"]
                    }
                    for doc, metadata in zip(
                        table_results['documents'][0],
                        table_results['metadatas'][0]
                    )
                ]

            return results

        except Exception as e:
            logger.error(f"Error retrieving article structure: {str(e)}")
            raise

    async def delete_article(self, article_id: str) -> None:
        """
        Delete all content related to an article.

        Args:
            article_id: Article ID to delete
        """
        try:
            for collection in self.collections.values():
                collection.delete(
                    where={"article_id": article_id}
                )
            logger.info(f"Deleted article {article_id} from all collections")
        except Exception as e:
            logger.error(f"Error deleting article: {str(e)}")
            raise

    def _calculate_relevance_statistics(self, results: List[SearchResult]) -> Dict:
        """
        Calculate statistics about search results.

        Args:
            results: List of SearchResult objects

        Returns:
            Dict containing statistics
        """
        if not results:
            return {
                "average_score": 0.0,
                "max_score": 0.0,
                "min_score": 0.0,
                "collection_distribution": {}
            }

        scores = [r.relevance_score for r in results]
        collection_counts = {}

        for result in results:
            collection_counts[result.collection_type] = collection_counts.get(result.collection_type, 0) + 1

        return {
            "average_score": sum(scores) / len(scores),
            "max_score": max(scores),
            "min_score": min(scores),
            "collection_distribution": collection_counts
        }