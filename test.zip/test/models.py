from dataclasses import dataclass, field
from typing import Dict, List, Optional
from enum import Enum
from datetime import datetime
from uuid import UUID

class ContentType(Enum):
    """Enumeration of different content types in the document."""
    ARTICLE = "article"
    SECTION = "section"
    SUBSECTION = "subsection"
    TABLE = "table"
    TABLE_ROW = "table_row"
    CONTENT = "content"

@dataclass
class DocumentMetadata:
    """Metadata for document chunks."""
    document_id: str
    chunk_type: ContentType
    page_number: int
    parent_article: Optional[str] = None
    parent_section: Optional[str] = None
    parent_subsection: Optional[str] = None
    table_title: Optional[str] = None
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())

@dataclass
class DocumentChunk:
    """Represents a chunk of document content."""
    chunk_id: str
    content: str
    metadata: DocumentMetadata
    page_number: int

@dataclass
class DocumentHierarchy:
    """Represents document hierarchy information."""
    article_id: Optional[str] = None
    section_id: Optional[str] = None
    subsection_id: Optional[str] = None
    table_id: Optional[str] = None

@dataclass
class ProcessedDocument:
    """Contains processed document information."""
    chunks: List[DocumentChunk]
    structure: Dict
    statistics: Dict

@dataclass
class SearchResult:
    """Represents a search result."""
    content: str
    metadata: DocumentMetadata
    relevance_score: float
    collection_type: str

@dataclass
class SearchResponse:
    """Contains search response information."""
    results: List[SearchResult]
    total_found: int
    query_time_ms: float