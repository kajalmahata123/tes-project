import fitz
import logging
from typing import List, Dict, Optional
from uuid import UUID, uuid4
import re
from datetime import datetime
from app.test.hierarchy_tracker import HierarchyTracker
from app.test.models import ContentType, DocumentChunk, DocumentMetadata, ProcessedDocument

logger = logging.getLogger(__name__)

class DocumentProcessor:
    """
    Processes PDF documents and extracts structured content.
    """

    def __init__(self):
        """Initialize the document processor."""
        self.hierarchy = HierarchyTracker()
        self.patterns = {
            'article': r'^\d+\.\d+\s+[A-Z]',  # e.g., "10.2 ARTICLE TITLE"
            'section': r'^[A-Z][A-Z\s]+$',  # e.g., "BUSINESS OVERVIEW"
            'subsection': r'^[A-Z][a-z]+(\s+[A-Z][a-z]+)*$',  # e.g., "Business Reason"
            'table_header': r'Table\s+\d+[-‐]\d+',
            'table_markers': [
                r'.*\|.*',  # Pipe-separated
                r'.*\t.*',  # Tab-separated
                r'^\s*[\w\s]+\s{3,}[\w\s]+'  # Space-aligned
            ]
        }

    def _generate_chunk_id(self, document_id: UUID, page_num: int, content: str) -> str:
        """Generate a unique chunk ID."""
        content_hash = hash(content) & 0xffffffff  # Convert to 32-bit unsigned int
        return f"{document_id}-p{page_num}-{content_hash:08x}"

    def _extract_text(self, block: Dict) -> str:
        """Extract text from a PDF block while preserving formatting."""
        try:
            text_parts = []
            for line in block.get("lines", []):
                line_text = []
                for span in line.get("spans", []):
                    text = span.get("text", "")
                    text = text.replace("•", "• ")  # Preserve bullet points
                    line_text.append(text)
                text_parts.append(" ".join(line_text))
            return "\n".join(text_parts)
        except Exception as e:
            logger.error(f"Error extracting text from block: {str(e)}")
            return ""

    def _get_font_info(self, block: Dict) -> Dict:
        """Extract font information from a PDF block."""
        try:
            if "lines" in block and block["lines"]:
                line = block["lines"][0]
                if "spans" in line and line["spans"]:
                    span = line["spans"][0]
                    return {
                        "size": span.get("size", 0),
                        "font": span.get("font", ""),
                        "is_bold": bool(span.get("flags", 0) & 16),
                        "is_italic": bool(span.get("flags", 0) & 1)
                    }
        except Exception as e:
            logger.error(f"Error getting font info: {str(e)}")
        return {}

    def _classify_block(self, text: str, font_info: Dict) -> ContentType:
        """Classify the type of content block."""
        text = text.strip()

        # Check article pattern
        if re.match(self.patterns['article'], text):
            return ContentType.ARTICLE

        # Check section pattern
        if re.match(self.patterns['section'], text):
            return ContentType.SECTION

        # Check subsection pattern
        if re.match(self.patterns['subsection'], text):
            return ContentType.SUBSECTION

        # Check table patterns
        if (re.match(self.patterns['table_header'], text) or
                any(re.match(pattern, text) for pattern in self.patterns['table_markers'])):
            return ContentType.TABLE

        return ContentType.CONTENT

    def _create_chunk(
            self,
            content: str,
            chunk_type: ContentType,
            document_id: UUID,
            page_num: int,
            metadata: Optional[Dict] = None
    ) -> DocumentChunk:
        """Create a document chunk with metadata."""
        chunk_metadata = DocumentMetadata(
            document_id=str(document_id),
            chunk_type=chunk_type,
            page_number=page_num,
            parent_article=self.hierarchy.current_article,
            parent_section=self.hierarchy.current_section,
            parent_subsection=self.hierarchy.current_subsection,
            created_at=datetime.now().isoformat()
        )

        if metadata:
            for key, value in metadata.items():
                setattr(chunk_metadata, key, value)

        return DocumentChunk(
            chunk_id=self._generate_chunk_id(document_id, page_num, content),
            content=content.strip(),
            metadata=chunk_metadata,
            page_number=page_num
        )

    async def process_page(
            self,
            doc: fitz.Document,
            page_num: int,
            document_id: UUID
    ) -> List[DocumentChunk]:
        """Process a single page of the document."""
        try:
            page = doc[page_num]
            blocks = page.get_text("dict")["blocks"]
            chunks = []

            for block in blocks:
                if "lines" not in block:
                    continue

                text = self._extract_text(block)
                if not text.strip():
                    continue

                font_info = self._get_font_info(block)
                block_type = self._classify_block(text, font_info)

                if block_type == ContentType.ARTICLE:
                    chunks.extend(self._handle_article(text, document_id, page_num))
                elif block_type == ContentType.SECTION:
                    chunks.extend(self._handle_section(text, document_id, page_num))
                elif block_type == ContentType.SUBSECTION:
                    chunks.extend(self._handle_subsection(text, document_id, page_num))
                elif block_type == ContentType.TABLE:
                    chunks.extend(self._handle_table_content(text, document_id, page_num))
                else:
                    chunks.extend(self._handle_content(text, document_id, page_num))

            # Process any remaining table buffer
            if self.hierarchy.table_buffer:
                chunks.extend(self._finalize_table(document_id, page_num))

            return chunks

        except Exception as e:
            logger.error(f"Error processing page {page_num}: {str(e)}")
            return []

    def _handle_article(self, text: str, document_id: UUID, page_num: int) -> List[DocumentChunk]:
        """Handle article-level content."""
        chunks = []
        if self.hierarchy.table_buffer:
            chunks.extend(self._finalize_table(document_id, page_num))

        self.hierarchy.start_article(text)
        chunks.append(self._create_chunk(text, ContentType.ARTICLE, document_id, page_num))
        return chunks

    def _handle_section(self, text: str, document_id: UUID, page_num: int) -> List[DocumentChunk]:
        """Handle section-level content."""
        chunks = []
        if self.hierarchy.table_buffer:
            chunks.extend(self._finalize_table(document_id, page_num))

        self.hierarchy.start_section(text)
        chunks.append(self._create_chunk(text, ContentType.SECTION, document_id, page_num))
        return chunks

    def _handle_subsection(self, text: str, document_id: UUID, page_num: int) -> List[DocumentChunk]:
        """Handle subsection-level content."""
        chunks = []
        if self.hierarchy.table_buffer:
            chunks.extend(self._finalize_table(document_id, page_num))

        self.hierarchy.start_subsection(text)
        chunks.append(self._create_chunk(text, ContentType.SUBSECTION, document_id, page_num))
        return chunks

    def _handle_table_content(self, text: str, document_id: UUID, page_num: int) -> List[DocumentChunk]:
        """Handle table content."""
        if not self.hierarchy.current_table:
            self.hierarchy.current_table = {
                'title': text if 'Table' in text else 'Untitled Table',
                'header': text,
                'rows': []
            }

        self.hierarchy.table_buffer.append(text)
        return []

    def _finalize_table(self, document_id: UUID, page_num: int) -> List[DocumentChunk]:
        """Finalize and process complete table."""
        if not self.hierarchy.table_buffer:
            return []

        chunks = []
        table_content = "\n".join(self.hierarchy.table_buffer)

        # Create table header chunk
        chunks.append(self._create_chunk(
            self.hierarchy.current_table['header'],
            ContentType.TABLE,
            document_id,
            page_num,
            {"table_title": self.hierarchy.current_table['title']}
        ))

        # Create table row chunks
        for row in self.hierarchy.table_buffer[1:]:
            chunks.append(self._create_chunk(
                row,
                ContentType.TABLE_ROW,
                document_id,
                page_num,
                {
                    "table_title": self.hierarchy.current_table['title'],
                    "parent_table": self.hierarchy.current_table['title']
                }
            ))

        # Add complete table to hierarchy
        self.hierarchy.add_table({
            'title': self.hierarchy.current_table['title'],
            'content': table_content
        })

        # Reset table context
        self.hierarchy.reset_table_context()

        return chunks

    async def process_document(self, file_path: str) -> ProcessedDocument:
        """Process entire document."""
        try:
            doc = fitz.open(file_path)
            document_id = uuid4()
            all_chunks = []

            for page_num in range(len(doc)):
                chunks = await self.process_page(doc, page_num, document_id)
                all_chunks.extend(chunks)

            statistics = self._generate_statistics(all_chunks)

            return ProcessedDocument(
                chunks=all_chunks,
                structure=self.hierarchy.articles,
                statistics=statistics
            )

        except Exception as e:
            logger.error(f"Error processing document: {str(e)}")
            raise
        finally:
            if 'doc' in locals():
                doc.close()

    def _generate_statistics(self, chunks: List[DocumentChunk]) -> Dict:
        """Generate processing statistics."""
        stats = {
            "total_chunks": len(chunks),
            "chunk_types": {},
            "articles": set(),
            "sections": set(),
            "subsections": set(),
            "tables": set(),
            "pages": set()
        }

        for chunk in chunks:
            # Count chunk types
            chunk_type = chunk.metadata.chunk_type
            stats["chunk_types"][chunk_type] = stats["chunk_types"].get(chunk_type, 0) + 1

            # Track unique elements
            if chunk.metadata.parent_article:
                stats["articles"].add(chunk.metadata.parent_article)
            if chunk.metadata.parent_section:
                stats["sections"].add(chunk.metadata.parent_section)
            if chunk.metadata.parent_subsection:
                stats["subsections"].add(chunk.metadata.parent_subsection)
            if hasattr(chunk.metadata, 'table_title') and chunk.metadata.table_title:
                stats["tables"].add(chunk.metadata.table_title)

            stats["pages"].add(chunk.page_number)

        # Convert sets to counts
        stats["total_articles"] = len(stats["articles"])
        stats["total_sections"] = len(stats["sections"])
        stats["total_subsections"] = len(stats["subsections"])
        stats["total_tables"] = len(stats["tables"])
        stats["total_pages"] = len(stats["pages"])

        # Remove sets from final stats
        del stats["articles"], stats["sections"], stats["subsections"], stats["tables"], stats["pages"]

        return stats

    def _handle_content(self, text: str, document_id: UUID, page_num: int) -> List[DocumentChunk]:
        """Handle regular content."""
        return [self._create_chunk(text, ContentType.CONTENT, document_id, page_num)]