from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.middleware.gzip import GZipMiddleware
import logging
from datetime import datetime, timezone
import time

from app.config import Settings
from app.routes import document, search
from app.services.document_processor import DocumentProcessor
from app.services.llm_service import LLMService
from app.services.vector_store import VectorStore

# Load settings
settings = Settings()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Global service instances
vector_store = None
document_processor = None
llm_service = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Lifespan context manager for FastAPI application
    Handles startup and shutdown events
    """
    # Startup
    logger.info("Initializing services...")
    try:
        # Initialize services
        global vector_store, document_processor, llm_service

        vector_store = VectorStore()
        llm_service = LLMService()
        document_processor = DocumentProcessor(
            vector_store=vector_store,
            llm_service=llm_service
        )

        # Store services in app state
        app.state.vector_store = vector_store
        app.state.document_processor = document_processor
        app.state.llm_service = llm_service

        logger.info("Services initialized successfully")
        yield

    except Exception as e:
        logger.error(f"Error initializing services: {str(e)}")
        raise

    finally:
        # Shutdown
        logger.info("Shutting down services...")
        try:
            if vector_store:
                await vector_store.cleanup()
            logger.info("Services shut down successfully")
        except Exception as e:
            logger.error(f"Error during shutdown: {str(e)}")


def create_app() -> FastAPI:
    """Create and configure FastAPI application"""
    app = FastAPI(
        title="Payment Documentation Processor",
        description="API for processing payment documentation and generating test cases",
        version="1.0.0",
        lifespan=lifespan
    )

    # Add middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.CORS_ORIGINS,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    app.add_middleware(GZipMiddleware, minimum_size=1000)

    # Add exception handlers
    @app.exception_handler(HTTPException)
    async def http_exception_handler(request: Request, exc: HTTPException):
        return JSONResponse(
            status_code=exc.status_code,
            content={
                "error": {
                    "code": exc.status_code,
                    "message": str(exc.detail),
                    "timestamp": datetime.now(timezone.utc).isoformat()
                }
            }
        )

    @app.exception_handler(Exception)
    async def general_exception_handler(request: Request, exc: Exception):
        logger.error(f"Unhandled exception: {str(exc)}", exc_info=True)
        return JSONResponse(
            status_code=500,
            content={
                "error": {
                    "code": 500,
                    "message": "Internal server error",
                    "timestamp": datetime.now(timezone.utc).isoformat()
                }
            }
        )

    # Add middleware for request timing
    @app.middleware("http")
    async def add_process_time_header(request: Request, call_next):
        start_time = time.time()
        response = await call_next(request)
        process_time = time.time() - start_time
        response.headers["X-Process-Time"] = str(process_time)
        return response

    # Include routers
    app.include_router(
        document.router,
        prefix="/api/v1/documents",
        tags=["documents"]
    )
    app.include_router(
        search.router,
        prefix="/api/v1/search",
        tags=["search"]
    )

    # Health check endpoint
    @app.get("/health")
    async def health_check():
        return {
            "status": "healthy",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "version": settings.VERSION,
            "services": {
                "vector_store": bool(vector_store),
                "document_processor": bool(document_processor),
                "llm_service": bool(llm_service)
            }
        }

    return app


app = create_app()

if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8001,
        reload=True
    )