from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime
from enum import Enum
from uuid import UUID

class DocumentType(str, Enum):
    PAYMENT_ARTICLE = "payment_article"
    TECHNICAL_SPEC = "technical_spec"
    IMPLEMENTATION_GUIDE = "implementation_guide"

class Region(str, Enum):
    AP = "AP"
    US = "US"
    CEMA = "CEMA"
    EU = "EU"
    LAC = "LAC"

class PartyType(str, Enum):
    ACQUIRER = "Acquirer"
    ISSUER = "Issuer"
    BOTH = "Both"

class TransactionType(str, Enum):
    AUTH = "Authorization"
    REVERSAL = "Reversal"
    CAPTURE = "Capture"
    REFUND = "Refund"
    CHARGEBACK = "Chargeback"

# Request Models
class DocumentUploadRequest(BaseModel):
    doc_type: DocumentType
    regions: List[Region]
    party_types: List[PartyType]
    metadata: Optional[Dict[str, Any]] = None

class SearchRequest(BaseModel):
    query: str
    filters: Optional[Dict[str, Any]] = None
    limit: int = Field(default=5, ge=1, le=20)
    include_metadata: bool = True

class TestCaseGenerationRequest(BaseModel):
    document_id: UUID
    transaction_types: List[TransactionType]
    regions: List[Region]
    party_types: List[PartyType]

# Response Models
class DocumentChunk(BaseModel):
    chunk_id: str
    content: str
    page_number: int
    metadata: Dict[str, Any]

class ProcessingStatus(BaseModel):
    status: str
    total_chunks: int
    processed_chunks: int
    errors: List[str] = []
    processing_time: float

class DocumentUploadResponse(BaseModel):
    document_id: UUID
    status: ProcessingStatus
    metadata: Dict[str, Any]
    created_at: datetime

class SearchResult(BaseModel):
    chunk_id: str
    content: str
    metadata: Dict[str, Any]
    relevance_score: float
    page_number: int
    document_id: UUID

class SearchResponse(BaseModel):
    results: List[SearchResult]
    total_results: int
    processing_time: float
    next_page_token: Optional[str] = None

class TestCase(BaseModel):
    test_id: str
    title: str
    description: str
    preconditions: List[str]
    steps: List[str]
    expected_results: List[str]
    metadata: Dict[str, Any]
    priority: str

class TestSuite(BaseModel):
    suite_id: UUID
    document_id: UUID
    test_cases: List[TestCase]
    coverage_metrics: Dict[str, float]
    generated_at: datetime
    total_test_cases: int

# Error Models
class ErrorDetail(BaseModel):
    code: str
    message: str
    details: Optional[Dict[str, Any]] = None

class ErrorResponse(BaseModel):
    error: ErrorDetail
    request_id: UUID
    timestamp: datetime

# Validation Models
class ValidationRule(BaseModel):
    field: str
    rule_type: str
    parameters: Dict[str, Any]
    error_message: str

class DocumentValidation(BaseModel):
    document_id: UUID
    validation_rules: List[ValidationRule]
    metadata_requirements: Dict[str, Any]