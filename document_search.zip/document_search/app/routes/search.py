from time import timezone

from fastapi import APIRouter, Depends, HTTPException, Query, BackgroundTasks
from typing import List, Optional, Dict, Any
from uuid import UUID
from datetime import datetime, timezone
from pydantic import BaseModel, Field

from app.core.schemas import Region, PartyType, TransactionType, DocumentType, SearchResponse, SearchRequest
from app.dependencies import VectorStoreDepends, LLMServiceDepends


router = APIRouter()


class SearchFilter(BaseModel):
    regions: Optional[List[Region]] = None
    party_types: Optional[List[PartyType]] = None
    transaction_types: Optional[List[TransactionType]] = None
    document_types: Optional[List[DocumentType]] = None
    date_range: Optional[Dict[str, str]] = None
    metadata: Optional[Dict[str, Any]] = None


class SearchOptions(BaseModel):
    limit: int = Field(default=10, ge=1, le=100)
    offset: int = Field(default=0, ge=0)
    min_score: float = Field(default=0.0, ge=0.0, le=1.0)
    include_metadata: bool = True
    summarize_results: bool = False
    highlight_matches: bool = True


@router.post("/semantic", response_model=SearchResponse)
async def semantic_search(
        query: str = Query(..., min_length=3),
        regions: Optional[List[Region]] = Query(None),
        party_types: Optional[List[PartyType]] = Query(None),
        transaction_types: Optional[List[TransactionType]] = Query(None),
        vector_store: VectorStoreDepends = None,
        llm_service: LLMServiceDepends = None
):
    """Perform semantic search across documents"""
    try:
        # Prepare filters
        filters = {}
        if regions:
            filters["regions"] = [r.value for r in regions]
        if party_types:
            filters["party_types"] = [p.value for p in party_types]
        if transaction_types:
            filters["transaction_types"] = [t.value for t in transaction_types]

        # Create search request
        search_request = SearchRequest(
            query=query,
            filters=filters,
            include_metadata=True
        )

        # Perform search
        search_results = await vector_store.search(search_request)
        print(search_results)
        # Enhance results with LLM if available
        if search_results and llm_service:
            enhanced_results = await llm_service.analyze_search_results(
                search_results=search_results,
                query=query
            )
            return SearchResponse(
                results=enhanced_results,
                total_results=len(enhanced_results),
                processing_time=0.0
            )

        return SearchResponse(
            results=search_results,
            total_results=len(search_results),
            processing_time=0.0
        )

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Search error: {str(e)}"
        )


@router.get("/similar-documents/{document_id}")
async def find_similar_documents(
        document_id: UUID,
        limit: int = Query(5, ge=1, le=20),
        min_similarity: float = Query(0.7, ge=0.0, le=1.0),
        vector_store: VectorStoreDepends = None
):
    """Find similar documents based on content similarity"""
    try:
        similar_docs = await vector_store.find_similar_documents(
            document_id=document_id,
            limit=limit,
            min_similarity=min_similarity
        )

        return {
            "similar_documents": similar_docs,
            "total_found": len(similar_docs),
            "timestamp": datetime.now(timezone.utc).isoformat()
        }

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error finding similar documents: {str(e)}"
        )


@router.post("/batch")
async def batch_search(
        queries: List[str],
        common_filters: Optional[Dict[str, Any]] = None,
        vector_store: VectorStoreDepends = None,
        llm_service: LLMServiceDepends = None
):
    """Perform batch search with multiple queries"""
    try:
        results = []
        for query in queries:
            search_request = SearchRequest(
                query=query,
                filters=common_filters,
                include_metadata=True
            )

            search_result = await vector_store.search(search_request)

            if search_result and llm_service:
                enhanced_result = await llm_service.analyze_search_results(
                    search_results=search_result,
                    query=query
                )
            else:
                enhanced_result = search_result

            results.append({
                "query": query,
                "results": enhanced_result,
                "total_results": len(enhanced_result)
            })

        return {
            "batch_results": results,
            "total_queries": len(queries),
            "successful_queries": len([r for r in results if r["total_results"] > 0]),
            "timestamp": datetime.now(timezone.utc).isoformat()
        }

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error performing batch search: {str(e)}"
        )


@router.post("/aggregate")
async def aggregate_search(
        query: str,
        aggregation_fields: List[str] = Query(...),
        filters: Optional[Dict[str, Any]] = None,
        vector_store: VectorStoreDepends = None,
        llm_service: LLMServiceDepends = None
):
    """Search and aggregate results by specified fields"""
    try:
        # Perform search
        search_request = SearchRequest(
            query=query,
            filters=filters,
            include_metadata=True,
            limit=100  # Higher limit for aggregation
        )

        search_results = await vector_store.search(search_request)

        if not search_results:
            return {
                "aggregations": {},
                "total_results": 0,
                "timestamp": datetime.now(timezone.utc).isoformat()
            }

        # Perform aggregations
        aggregations = {}
        for field in aggregation_fields:
            field_values = {}
            for result in search_results:
                value = result.metadata.get(field)
                if value:
                    if isinstance(value, list):
                        for v in value:
                            field_values[v] = field_values.get(v, 0) + 1
                    else:
                        field_values[value] = field_values.get(value, 0) + 1
            aggregations[field] = field_values

        # Enhance aggregations with LLM insights if available
        if llm_service:
            enhanced_aggregations = await llm_service.analyze_aggregations(
                aggregations=aggregations,
                query=query,
                context=filters or {}
            )
        else:
            enhanced_aggregations = aggregations

        return {
            "aggregations": enhanced_aggregations,
            "total_results": len(search_results),
            "query": query,
            "aggregation_fields": aggregation_fields,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error performing aggregation: {str(e)}"
        )


