from fastapi import APIRouter, UploadFile, File, HTTPException, Query, Depends
from fastapi.responses import JSONResponse
from typing import List, Dict, Any, Optional
from uuid import UUID
from datetime import datetime, timezone

from app.core.schemas import DocumentUploadResponse, DocumentType, PartyType, Region, SearchResponse, SearchRequest, \
    TransactionType, TestSuite
from app.dependencies import DocumentProcessorDepends, VectorStoreDepends, LLMServiceDepends

router = APIRouter()


@router.post("/upload", response_model=DocumentUploadResponse)
async def upload_document(
        file: UploadFile = File(...),
        doc_type: DocumentType = Query(..., description="Type of the document"),
        regions: Optional[List[Region]] = Query(None, description="Applicable regions"),
        party_types: Optional[List[PartyType]] = Query(None, description="Applicable party types"),
        processor: DocumentProcessorDepends = None
):
    """Upload and process a PDF document"""
    if not file.filename.endswith('.pdf'):
        raise HTTPException(
            status_code=400,
            detail="Only PDF files are supported"
        )

    try:
        content = await file.read()

        metadata = {
            "filename": file.filename,
            "doc_type": doc_type.value,
            "regions": [r.value for r in regions] if regions else [],
            "party_types": [p.value for p in party_types] if party_types else [],
            "uploaded_at": datetime.now(timezone.utc).isoformat()
        }

        result = await processor.process_document(
            file_content=content,
            doc_type=doc_type,
            metadata=metadata,
            regions=regions,
            party_types=party_types
        )

        return result

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error processing document: {str(e)}"
        )


@router.get("/info/{document_id}")
async def get_document_info(
        document_id: UUID,
        vector_store: VectorStoreDepends = None
):
    """Get information about a processed document"""
    try:
        stats = await vector_store.get_document_statistics(document_id)
        if not stats:
            raise HTTPException(
                status_code=404,
                detail=f"Document {document_id} not found"
            )
        return stats
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error retrieving document info: {str(e)}"
        )


@router.post("/search", response_model=SearchResponse)
async def search_documents(
        request: SearchRequest,
        vector_store: VectorStoreDepends = None,
        llm_service: LLMServiceDepends = None
):
    """Search across processed documents"""
    try:
        search_results = await vector_store.search(request)

        if search_results and request.include_metadata:
            enhanced_results = await llm_service.analyze_search_results(
                search_results=search_results,
                query=request.query
            )
            return SearchResponse(
                results=enhanced_results,
                total_results=len(enhanced_results),
                processing_time=0.0
            )

        return SearchResponse(
            results=search_results,
            total_results=len(search_results),
            processing_time=0.0
        )

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Search error: {str(e)}"
        )


@router.post("/generate-tests/{document_id}", response_model=TestSuite)
async def generate_test_cases(
        document_id: UUID,
        regions: List[Region],
        party_types: List[PartyType],
        transaction_types: List[TransactionType],
        vector_store: VectorStoreDepends = None,
        llm_service: LLMServiceDepends = None
):
    """Generate test cases for a document"""
    try:
        # Get document content
        chunks = await vector_store.get_document_chunks(document_id)
        if not chunks:
            raise HTTPException(
                status_code=404,
                detail="Document not found"
            )

        document_content = "\n".join(chunk.content for chunk in chunks)

        # Generate test cases
        test_suite = await llm_service.generate_test_cases(
            document_content=document_content,
            regions=regions,
            party_types=party_types,
            transaction_types=transaction_types
        )

        # Validate test cases
        validation_results = await llm_service.validate_test_cases(
            test_cases=test_suite.test_cases
        )

        # Generate documentation
        documentation = await llm_service.generate_test_documentation(
            test_suite=test_suite
        )

        return {
            **test_suite.dict(),
            "validation_results": validation_results,
            "documentation": documentation
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error generating test cases: {str(e)}"
        )


@router.delete("/{document_id}")
async def delete_document(
        document_id: UUID,
        vector_store: VectorStoreDepends = None
):
    """Delete a document and its associated data"""
    try:
        success = await vector_store.delete_document(document_id)
        if not success:
            raise HTTPException(
                status_code=500,
                detail="Failed to delete document"
            )
        return JSONResponse(
            content={"message": "Document deleted successfully"},
            status_code=200
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error deleting document: {str(e)}"
        )


@router.patch("/{document_id}/metadata")
async def update_metadata(
        document_id: UUID,
        metadata: Dict[str, Any],
        vector_store: VectorStoreDepends = None
):
    """Update document metadata"""
    try:
        success = await vector_store.update_metadata(
            document_id=document_id,
            metadata=metadata
        )
        if not success:
            raise HTTPException(
                status_code=500,
                detail="Failed to update metadata"
            )
        return JSONResponse(
            content={"message": "Metadata updated successfully"},
            status_code=200
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error updating metadata: {str(e)}"
        )