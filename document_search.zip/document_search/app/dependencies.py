from typing import Annotated
from fastapi import Depends
from .services.vector_store import VectorStore
from .services.llm_service import LLMService
from .services.document_processor import DocumentProcessor

# Initialize services as global instances
_vector_store = VectorStore()
_llm_service = LLMService()
_document_processor = DocumentProcessor(
    vector_store=_vector_store,
    llm_service=_llm_service
)

def get_vector_store() -> VectorStore:
    return _vector_store

def get_llm_service() -> LLMService:
    return _llm_service

def get_document_processor() -> DocumentProcessor:
    return _document_processor

# Create type annotations for dependency injection
VectorStoreDepends = Annotated[VectorStore, Depends(get_vector_store)]
LLMServiceDepends = Annotated[LLMService, Depends(get_llm_service)]
DocumentProcessorDepends = Annotated[DocumentProcessor, Depends(get_document_processor)]