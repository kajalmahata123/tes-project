from typing import List, Dict, Any, Optional
import aiohttp
import logging
from datetime import datetime
import json

from app.config import settings
from app.core.schemas import TestSuite, TestCase, SearchResult


class LLMService:
    def __init__(self):
        """Initialize LLM service"""
        self.logger = logging.getLogger(__name__)
        self.api_endpoint = settings.LLM_API_ENDPOINT
        self.api_key = settings.LLM_API_KEY
        self.max_tokens = 2000
        self.temperature = 0.1

    async def analyze_search_results(
            self,
            search_results: List[SearchResult],
            query: str
    ) -> List[Dict[str, Any]]:
        """Analyze search results using LLM"""
        try:
            # Prepare context from results
            context = self._prepare_context(search_results)

            # Construct prompt
            prompt = self._construct_analysis_prompt(context, query)

            # Get LLM response
            response = await self._call_llm(prompt)

            try:
                return json.loads(response)
            except json.JSONDecodeError:
                self.logger.error("Failed to parse LLM response as JSON")
                return search_results

        except Exception as e:
            self.logger.error(f"Error analyzing search results: {str(e)}")
            return search_results

    async def generate_test_cases(
            self,
            document_content: str,
            regions: List[str],
            party_types: List[str],
            transaction_types: List[str]
    ) -> TestSuite:
        """Generate test cases from document content"""
        try:
            prompt = self._construct_test_case_prompt(
                document_content,
                regions,
                party_types,
                transaction_types
            )

            response = await self._call_llm(prompt)

            test_data = json.loads(response)
            return TestSuite(**test_data)

        except Exception as e:
            self.logger.error(f"Error generating test cases: {str(e)}")
            raise

    async def validate_test_cases(
            self,
            test_cases: List[TestCase]
    ) -> Dict[str, Any]:
        """Validate generated test cases"""
        try:
            prompt = self._construct_validation_prompt(test_cases)
            response = await self._call_llm(prompt)
            return json.loads(response)

        except Exception as e:
            self.logger.error(f"Error validating test cases: {str(e)}")
            raise

    async def generate_test_documentation(
            self,
            test_suite: TestSuite
    ) -> Dict[str, Any]:
        """Generate documentation for test cases"""
        try:
            prompt = self._construct_documentation_prompt(test_suite)
            response = await self._call_llm(prompt)
            return json.loads(response)

        except Exception as e:
            self.logger.error(f"Error generating test documentation: {str(e)}")
            raise

    def _prepare_context(self, search_results: List[SearchResult]) -> str:
        """Prepare context from search results"""
        context_parts = []
        for result in search_results:
            context_part = f"""
            Content (Page {result.page_number}):
            {result.content}

            Metadata:
            {json.dumps(result.metadata, indent=2)}
            """
            context_parts.append(context_part)

        return "\n\n".join(context_parts)

    def _construct_analysis_prompt(self, context: str, query: str) -> str:
        """Construct prompt for analyzing search results"""
        return f"""
        Analyze the following payment documentation content and extract relevant information.

        Query: {query}

        Content:
        {context}

        Provide analysis in JSON format:
        {{
            "relevant_sections": [
                {{
                    "content": "extracted text",
                    "relevance": "explanation"
                }}
            ],
            "key_requirements": [
                {{
                    "requirement": "string",
                    "type": "string",
                    "affected_parties": ["string"]
                }}
            ]
        }}
        """

    async def _call_llm(self, prompt: str) -> str:
        """Call LLM API with error handling"""
        try:
            async with aiohttp.ClientSession() as session:
                headers = {
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json"
                }

                payload = {
                    "prompt": prompt,
                    "max_tokens": self.max_tokens,
                    "temperature": self.temperature
                }

                async with session.post(
                        self.api_endpoint,
                        headers=headers,
                        json=payload
                ) as response:
                    response.raise_for_status()
                    result = await response.json()
                    return result["text"]

        except Exception as e:
            self.logger.error(f"LLM API call failed: {str(e)}")
            raise

    def _construct_test_case_prompt(
            self,
            content: str,
            regions: List[str],
            party_types: List[str],
            transaction_types: List[str]
    ) -> str:
        """Construct prompt for test case generation"""
        return f"""
        Generate test cases for the following payment documentation content.

        Regions: {regions}
        Party Types: {party_types}
        Transaction Types: {transaction_types}

        Content:
        {content}

        Generate test cases in JSON format:
        {{
            "test_cases": [
                {{
                    "test_id": "unique identifier",
                    "title": "descriptive title",
                    "description": "detailed description",
                    "preconditions": ["list of preconditions"],
                    "steps": ["detailed test steps"],
                    "expected_results": ["expected outcomes"],
                    "metadata": {{
                        "region": "string",
                        "party_type": "string",
                        "transaction_type": "string"
                    }},
                    "priority": "P1|P2|P3|P4"
                }}
            ]
        }}
        """

    def _construct_validation_prompt(self, test_cases: List[TestCase]) -> str:
        """Construct prompt for test case validation"""
        return f"""
        Validate the following test cases:
        {json.dumps([tc.dict() for tc in test_cases], indent=2)}

        Provide validation results in JSON format:
        {{
            "valid_cases": [
                {{
                    "test_id": "string",
                    "quality_score": float,
                    "suggestions": ["string"]
                }}
            ],
            "invalid_cases": [
                {{
                    "test_id": "string",
                    "issues": ["string"]
                }}
            ]
        }}
        """

    def _construct_documentation_prompt(self, test_suite: TestSuite) -> str:
        """Construct prompt for test documentation generation"""
        return f"""
        Generate detailed documentation for the test suite:
        {json.dumps(test_suite.dict(), indent=2)}

        Provide documentation in JSON format:
        {{
            "overview": {{
                "title": "string",
                "description": "string",
                "scope": "string"
            }},
            "test_cases": [
                {{
                    "test_id": "string",
                    "detailed_description": "string",
                    "setup_guide": ["string"],
                    "execution_steps": [
                        {{
                            "step": "string",
                            "details": "string"
                        }}
                    ]
                }}
            ]
        }}
        """