import json
from collections import defaultdict
from typing import List, Dict, Any, Optional
import chromadb
import logging
from datetime import  timezone
from datetime import datetime
from uuid import UUID
from pathlib import Path
from app.config import settings
from app.core.schemas import SearchRequest, SearchResult, DocumentChunk
from app.services.embeddings import BasicEmbeddingFunction


class VectorStore:
    def __init__(self):
        """Initialize vector store with ChromaDB"""
        self.logger = logging.getLogger(__name__)
        self._setup_chromadb()

    def _setup_chromadb(self):
        """Initialize ChromaDB with updated configuration"""
        persist_dir = Path(settings.VECTOR_STORE_PATH)
        persist_dir.mkdir(parents=True, exist_ok=True)

        # Initialize ChromaDB client with new configuration
        self.client = chromadb.PersistentClient(
            path=str(persist_dir)
        )

        # Setup embedding function
        self.embedding_function = BasicEmbeddingFunction()

        # Create or get collection
        self.collection = self.client.get_or_create_collection(
            name="payment_content",
            embedding_function=self.embedding_function,
            metadata={"type": "document_chunks"}
        )

    def _sanitize_metadata(self, metadata: Dict[str, Any]) -> Dict[str, Any]:
        """
        Sanitize metadata to ensure ChromaDB compatibility
        - Convert lists to strings
        - Ensure all values are primitive types
        """
        sanitized = {}

        for key, value in metadata.items():
            if isinstance(value, (str, int, float, bool)):
                sanitized[key] = value
            elif isinstance(value, list):
                sanitized[key] = ','.join(str(v) for v in value)
            elif isinstance(value, dict):
                sanitized[key] = json.dumps(value)
            else:
                sanitized[key] = str(value)

        return sanitized

    async def store_chunks(
            self,
            chunks: List[DocumentChunk],
            document_id: UUID,
            metadata: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Store document chunks in vector database"""
        try:
            # Prepare batch data
            documents = []
            metadatas = []
            ids = []

            base_metadata = {
                "document_id": str(document_id),
                "stored_at": datetime.now(timezone.utc).isoformat(),
                **(metadata or {})
            }

            # Sanitize base metadata
            base_metadata = self._sanitize_metadata(base_metadata)

            for chunk in chunks:
                documents.append(chunk.content)

                # Combine and sanitize chunk metadata
                chunk_metadata = {
                    **base_metadata,
                    "page_number": chunk.page_number,
                    "chunk_id": chunk.chunk_id
                }
                if chunk.metadata:
                    chunk_metadata.update(self._sanitize_metadata(chunk.metadata))

                metadatas.append(chunk_metadata)
                ids.append(chunk.chunk_id)

            # Store in ChromaDB
            self.collection.add(
                documents=documents,
                metadatas=metadatas,
                ids=ids
            )

            return {
                "status": "success",
                "chunks_stored": len(chunks),
                "document_id": str(document_id)
            }

        except Exception as e:
            self.logger.error(f"Error storing chunks: {str(e)}")
            raise

    async def search(
            self,
            request: SearchRequest
    ) -> List[SearchResult]:
        """Perform semantic search on stored content"""
        try:
            # Sanitize filters if present
            filters = None
            if request.filters:
                filters = self._sanitize_metadata(request.filters)

            results = self.collection.query(
                query_texts=[request.query],
                n_results=request.limit,
                where=filters,
                include=["metadatas", "documents", "distances"]
            )

            search_results = []
            for i, (doc, metadata, distance) in enumerate(zip(
                    results['documents'][0],
                    results['metadatas'][0],
                    results.get('distances', [[]])[0]
            )):
                # Convert comma-separated strings back to lists where needed
                processed_metadata = self._process_stored_metadata(metadata)

                search_results.append(SearchResult(
                    chunk_id=metadata['chunk_id'],
                    content=doc,
                    metadata=processed_metadata,
                    relevance_score=1.0 - (distance if distance else 0),
                    page_number=metadata['page_number'],
                    document_id=UUID(metadata['document_id'])
                ))

            return search_results

        except Exception as e:
            self.logger.error(f"Error performing search: {str(e)}")
            raise

    def _process_stored_metadata(self, metadata: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process stored metadata back into appropriate types
        - Convert comma-separated strings back to lists where appropriate
        - Parse JSON strings back to dictionaries
        """
        processed = {}

        for key, value in metadata.items():
            if key in ['regions', 'party_types', 'transaction_types']:
                # Convert back to list
                processed[key] = value.split(',') if value else []
            elif isinstance(value, str) and value.startswith('{') and value.endswith('}'):
                # Try to parse JSON strings back to dict
                try:
                    processed[key] = json.loads(value)
                except json.JSONDecodeError:
                    processed[key] = value
            else:
                processed[key] = value

        return processed

    async def get_document_chunks(
            self,
            document_id: UUID
    ) -> List[DocumentChunk]:
        """Retrieve all chunks for a specific document"""
        try:
            results = self.collection.get(
                where={"document_id": str(document_id)}
            )

            chunks = []
            for doc, metadata in zip(results['documents'], results['metadatas']):
                chunks.append(DocumentChunk(
                    chunk_id=metadata['chunk_id'],
                    content=doc,
                    page_number=metadata['page_number'],
                    metadata=metadata
                ))

            return sorted(
                chunks,
                key=lambda x: (x.page_number, x.metadata.get('chunk_number', 0))
            )

        except Exception as e:
            self.logger.error(f"Error retrieving document chunks: {str(e)}")
            raise

    async def delete_document(self, document_id: UUID) -> bool:
        """Delete all chunks associated with a document"""
        try:
            self.collection.delete(
                where={"document_id": str(document_id)}
            )
            return True
        except Exception as e:
            self.logger.error(f"Error deleting document: {str(e)}")
            return False

    async def update_metadata(
            self,
            document_id: UUID,
            metadata: Dict[str, Any]
    ) -> bool:
        """Update metadata for all chunks of a document"""
        try:
            chunks = await self.get_document_chunks(document_id)

            for chunk in chunks:
                updated_metadata = {**chunk.metadata, **metadata}
                self.collection.update(
                    ids=[chunk.chunk_id],
                    metadatas=[updated_metadata]
                )

            return True
        except Exception as e:
            self.logger.error(f"Error updating metadata: {str(e)}")
            return False

    async def get_document_statistics(
            self,
            document_id: UUID
    ) -> Dict[str, Any]:
        """Get statistics for a document"""
        try:
            chunks = await self.get_document_chunks(document_id)

            if not chunks:
                return {
                    "document_id": str(document_id),
                    "total_chunks": 0,
                    "page_coverage": 0,
                    "total_content_length": 0,
                    "average_chunk_size": 0,
                    "metadata_fields": []
                }

            return {
                "document_id": str(document_id),
                "total_chunks": len(chunks),
                "page_coverage": len(set(chunk.page_number for chunk in chunks)),
                "total_content_length": sum(len(chunk.content) for chunk in chunks),
                "average_chunk_size": sum(len(chunk.content) for chunk in chunks) / len(chunks),
                "metadata_fields": list(chunks[0].metadata.keys())
            }
        except Exception as e:
            self.logger.error(f"Error getting document statistics: {str(e)}")
            raise

    async def find_similar_documents(
            self,
            document_id: UUID,
            limit: int = 5,
            min_similarity: float = 0.7,
            exclude_same_type: bool = True
    ) -> List[Dict[str, Any]]:
        """Find similar documents based on content similarity"""
        try:
            ref_chunks = await self.get_document_chunks(document_id)
            if not ref_chunks:
                raise ValueError(f"No chunks found for document {document_id}")

            ref_metadata = await self.get_document_metadata(document_id)
            if not ref_metadata:
                raise ValueError(f"No metadata found for document {document_id}")

            combined_content = " ".join(chunk.content for chunk in ref_chunks)

            # Prepare filters
            filters = {}
            if exclude_same_type and "doc_type" in ref_metadata:
                filters["doc_type"] = {"$ne": ref_metadata["doc_type"]}

            results = self.collection.query(
                query_texts=[combined_content],
                n_results=limit * 2,
                where=filters,
                include=["metadatas", "documents", "distances"]
            )

            # Process results
            doc_results = defaultdict(list)
            for doc, metadata, distance in zip(
                    results['documents'][0],
                    results['metadatas'][0],
                    results.get('distances', [[]])[0]
            ):
                if metadata['document_id'] != str(document_id):
                    similarity = 1.0 - float(distance)
                    if similarity >= min_similarity:
                        doc_results[metadata['document_id']].append({
                            'content': doc,
                            'metadata': metadata,
                            'similarity': similarity
                        })

            similar_docs = []
            for doc_id, chunks in doc_results.items():
                avg_similarity = sum(c['similarity'] for c in chunks) / len(chunks)
                best_chunk = max(chunks, key=lambda x: x['similarity'])
                doc_metadata = await self.get_document_metadata(UUID(doc_id))

                similar_docs.append({
                    'document_id': doc_id,
                    'title': doc_metadata.get('title', ''),
                    'similarity_score': avg_similarity,
                    'doc_type': doc_metadata.get('doc_type', ''),
                    'regions': doc_metadata.get('regions', []),
                    'party_types': doc_metadata.get('party_types', []),
                    'sample_content': best_chunk['content'],
                    'metadata': doc_metadata,
                    'matching_chunks': len(chunks)
                })

            similar_docs.sort(key=lambda x: x['similarity_score'], reverse=True)
            return similar_docs[:limit]

        except Exception as e:
            self.logger.error(f"Error finding similar documents: {str(e)}")
            raise

    async def get_document_metadata(
            self,
            document_id: UUID
    ) -> Optional[Dict[str, Any]]:
        """Get metadata for a specific document"""
        try:
            results = self.collection.get(
                where={"document_id": str(document_id)},
                limit=1
            )

            if results['metadatas']:
                base_metadata = results['metadatas'][0]
                return {
                    k: v for k, v in base_metadata.items()
                    if k not in ['chunk_id', 'chunk_number', 'page_number']
                }
            return None

        except Exception as e:
            self.logger.error(f"Error getting document metadata: {str(e)}")
            raise