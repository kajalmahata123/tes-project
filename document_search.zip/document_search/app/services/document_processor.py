import asyncio
from typing import List, Dict, Any, Optional, Generator, BinaryIO
import fitz  # PyMuPDF
from pathlib import Path
import tempfile
import logging
from datetime import datetime, timezone
import hashlib
from uuid import UUID, uuid4
from concurrent.futures import ThreadPoolExecutor
import numpy as np
import aiofiles
import os
from collections import defaultdict
from app.core.schemas import DocumentType, Region, DocumentUploadResponse, PartyType, DocumentChunk, ProcessingStatus
from app.services.llm_service import LLMService
from app.services.vector_store import VectorStore


class DocumentProcessor:
    def __init__(
            self,
            vector_store: VectorStore,
            llm_service: Optional[LLMService] = None,
            chunk_size: int = 1000,
            chunk_overlap: int = 200,
            max_workers: int = 4,
            upload_dir: str = "uploads"
    ):
        """Initialize document processor"""
        self.vector_store = vector_store
        self.llm_service = llm_service
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.executor = ThreadPoolExecutor(max_workers=max_workers)
        self.upload_dir = Path(upload_dir)
        self.upload_dir.mkdir(parents=True, exist_ok=True)

        # Setup logging
        self.logger = logging.getLogger(__name__)
        self._setup_logging()

        # Processing statistics
        self.stats = defaultdict(int)

    def _setup_logging(self):
        """Configure logging"""
        handler = logging.StreamHandler()
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        handler.setFormatter(formatter)
        self.logger.addHandler(handler)
        self.logger.setLevel(logging.INFO)

    async def process_document(
            self,
            file_content: bytes,
            doc_type: DocumentType,
            metadata: Optional[Dict[str, Any]] = None,
            regions: Optional[List[Region]] = None,
            party_types: Optional[List[PartyType]] = None
    ) -> DocumentUploadResponse:
        """
        Process a PDF document

        Args:
            file_content: Binary content of the PDF file
            doc_type: Type of the document
            metadata: Optional metadata dictionary
            regions: List of applicable regions
            party_types: List of applicable party types

        Returns:
            DocumentUploadResponse with processing results
        """
        document_id = uuid4()
        start_time = datetime.now(timezone.utc)

        try:
            # Save to temporary file
            temp_path = None
            with tempfile.NamedTemporaryFile(suffix='.pdf', delete=False) as temp_file:
                temp_file.write(file_content)
                temp_path = temp_file.name

            # Process PDF
            processing_result = await self._process_pdf_file(
                temp_path,
                document_id,
                doc_type,
                metadata,
                regions,
                party_types
            )

            # Calculate processing time
            processing_time = (datetime.now(timezone.utc) - start_time).total_seconds()

            # Save permanent copy
            permanent_path = self.upload_dir / f"{document_id}.pdf"
            await self._save_permanent_copy(temp_path, permanent_path)

            # Update metadata
            metadata = metadata or {}
            metadata.update({
                "document_id": str(document_id),
                "doc_type": doc_type.value,
                "regions": [r.value for r in regions] if regions else [],
                "party_types": [p.value for p in party_types] if party_types else [],
                "processed_at": start_time.isoformat(),
                "processing_time": processing_time,
                "file_path": str(permanent_path),
                "chunk_size": self.chunk_size,
                "chunk_overlap": self.chunk_overlap,
                "file_size": len(file_content),
                "file_hash": hashlib.sha256(file_content).hexdigest()
            })

            return DocumentUploadResponse(
                document_id=document_id,
                status=ProcessingStatus(
                    status="completed",
                    total_chunks=processing_result["total_chunks"],
                    processed_chunks=processing_result["processed_chunks"],
                    errors=processing_result["errors"],
                    processing_time=processing_time
                ),
                metadata=metadata,
                created_at=start_time
            )

        except Exception as e:
            self.logger.error(f"Error processing document: {str(e)}")
            raise

        finally:
            # Clean up temporary file
            if temp_path:
                try:
                    os.unlink(temp_path)
                except Exception as e:
                    self.logger.warning(f"Error cleaning up temporary file: {str(e)}")

    async def _save_permanent_copy(self, temp_path: str, permanent_path: Path):
        """
        Save a permanent copy of the document

        Args:
            temp_path: Path to temporary file
            permanent_path: Path for permanent storage
        """
        try:
            # Ensure directory exists
            permanent_path.parent.mkdir(parents=True, exist_ok=True)

            # Copy file using aiofiles
            async with aiofiles.open(temp_path, 'rb') as source:
                content = await source.read()
                async with aiofiles.open(permanent_path, 'wb') as target:
                    await target.write(content)

            # Set appropriate permissions
            os.chmod(permanent_path, 0o644)  # rw-r--r--

        except Exception as e:
            self.logger.error(f"Error saving permanent copy: {str(e)}")
            raise

    async def _process_pdf_file(
            self,
            file_path: str,
            document_id: UUID,
            doc_type: DocumentType,
            metadata: Optional[Dict[str, Any]],
            regions: Optional[List[Region]],
            party_types: Optional[List[PartyType]]
    ) -> Dict[str, Any]:
        """
        Process PDF file and generate chunks

        Args:
            file_path: Path to PDF file
            document_id: Unique document identifier
            doc_type: Type of document
            metadata: Optional metadata
            regions: Applicable regions
            party_types: Applicable party types

        Returns:
            Dictionary with processing results
        """
        result = {
            "total_chunks": 0,
            "processed_chunks": 0,
            "errors": [],
            "page_count": 0
        }

        try:
            # Open PDF with PyMuPDF
            doc = await asyncio.get_event_loop().run_in_executor(
                self.executor,
                fitz.open,
                file_path
            )

            result["page_count"] = len(doc)
            chunks = []

            # Process pages
            for page_num in range(len(doc)):
                try:
                    page_chunks = await self._process_page(
                        doc,
                        page_num,
                        document_id
                    )
                    chunks.extend(page_chunks)
                    result["processed_chunks"] += len(page_chunks)
                except Exception as e:
                    error_msg = f"Error processing page {page_num}: {str(e)}"
                    result["errors"].append(error_msg)
                    self.logger.error(error_msg)

            result["total_chunks"] = len(chunks)

            # Store chunks in vector store
            await self.vector_store.store_chunks(
                chunks=chunks,
                document_id=document_id,
                metadata={
                    **(metadata or {}),
                    "doc_type": doc_type.value,
                    "regions": [r.value for r in regions] if regions else [],
                    "party_types": [p.value for p in party_types] if party_types else []
                }
            )

            return result

        except Exception as e:
            self.logger.error(f"Error in PDF processing: {str(e)}")
            raise

        finally:
            if 'doc' in locals():
                doc.close()

    async def _process_page(
            self,
            doc: fitz.Document,
            page_num: int,
            document_id: UUID
    ) -> List[DocumentChunk]:
        """Process a single page and generate chunks"""
        page = doc[page_num]
        text = await asyncio.get_event_loop().run_in_executor(
            self.executor,
            page.get_text
        )

        # Skip empty pages
        if not text.strip():
            return []

        chunks = []
        current_chunk = []
        current_length = 0

        # Split into semantic segments
        segments = self._split_into_segments(text)

        for segment in segments:
            segment_length = len(segment)

            if current_length + segment_length > self.chunk_size:
                if current_chunk:
                    chunk_text = " ".join(current_chunk)
                    chunk_id = self._generate_chunk_id(
                        document_id,
                        page_num,
                        chunk_text
                    )

                    chunks.append(DocumentChunk(
                        chunk_id=chunk_id,
                        content=chunk_text,
                        page_number=page_num + 1,
                        metadata={
                            "document_id": str(document_id),
                            "page_number": page_num + 1,
                            "chunk_number": len(chunks) + 1,
                            "created_at": datetime.now().isoformat()
                        }
                    ))

                    # Start new chunk with overlap
                    if self.chunk_overlap > 0:
                        overlap_tokens = current_chunk[-2:]
                        current_chunk = overlap_tokens + [segment]
                        current_length = sum(len(s) for s in current_chunk)
                    else:
                        current_chunk = [segment]
                        current_length = segment_length
            else:
                current_chunk.append(segment)
                current_length += segment_length

        # Handle remaining text
        if current_chunk:
            chunk_text = " ".join(current_chunk)
            chunk_id = self._generate_chunk_id(document_id, page_num, chunk_text)

            chunks.append(DocumentChunk(
                chunk_id=chunk_id,
                content=chunk_text,
                page_number=page_num + 1,
                metadata={
                    "document_id": str(document_id),
                    "page_number": page_num + 1,
                    "chunk_number": len(chunks) + 1,
                    "created_at": datetime.now().isoformat()
                }
            ))

        return chunks

    def _split_into_segments(self, text: str) -> List[str]:
        """Split text into semantic segments"""
        segments = []
        current_segment = []

        lines = text.split('\n')
        for line in lines:
            line = line.strip()
            if not line:
                if current_segment:
                    segments.append(' '.join(current_segment))
                    current_segment = []
                continue

            # Check if line is a potential section header
            if (line.isupper() or
                    line.endswith(':') or
                    any(marker in line.lower() for marker in ['section', 'article', 'chapter'])):
                if current_segment:
                    segments.append(' '.join(current_segment))
                    current_segment = []
                segments.append(line)
            else:
                current_segment.append(line)

        if current_segment:
            segments.append(' '.join(current_segment))

        return segments

    def _generate_chunk_id(self, document_id: UUID, page_num: int, content: str) -> str:
        """Generate unique chunk ID"""
        content_hash = hashlib.sha256(content.encode()).hexdigest()[:8]
        return f"{document_id}_p{page_num}_{content_hash}"

    async def _save_permanent_copy(self, temp_path: str, permanent_path: Path):
        """Save permanent copy of the document"""
        async with aiofiles.open(temp_path, 'rb') as source:
            content = await source.read()
            async with aiofiles.open(permanent_path, 'wb') as target:
                await target.write(content)

    async def _analyze_content(
            self,
            chunks: List[DocumentChunk],
            document_id: UUID
    ):
        """Analyze document content using LLM"""
        try:
            # Combine chunks for analysis
            full_content = "\n".join(chunk.content for chunk in chunks)

            # Perform analysis
            analysis = await self.llm_service.analyze_document_content(
                content=full_content,
                document_id=document_id
            )

            # Store analysis results
            await self.vector_store.update_metadata(
                document_id=document_id,
                metadata={"content_analysis": analysis}
            )

        except Exception as e:
            self.logger.error(f"Error analyzing content: {str(e)}")

    async def reprocess_document(
            self,
            document_id: UUID,
            new_chunk_size: Optional[int] = None,
            new_chunk_overlap: Optional[int] = None
    ) -> DocumentUploadResponse:
        """Reprocess an existing document with new parameters"""
        try:
            # Update processing parameters if provided
            if new_chunk_size is not None:
                self.chunk_size = new_chunk_size
            if new_chunk_overlap is not None:
                self.chunk_overlap = new_chunk_overlap

            # Get document path
            doc_path = self.upload_dir / f"{document_id}.pdf"
            if not doc_path.exists():
                raise FileNotFoundError(f"Document {document_id} not found")

            # Read content
            async with aiofiles.open(doc_path, 'rb') as f:
                content = await f.read()

            # Get existing metadata
            metadata = await self.vector_store.get_document_metadata(document_id)

            # Delete existing chunks
            await self.vector_store.delete_document(document_id)

            # Reprocess document
            return await self.process_document(
                file_content=content,
                doc_type=DocumentType(metadata.get('doc_type', 'payment_article')),
                metadata=metadata,
                regions=[Region(r) for r in metadata.get('regions', [])],
                party_types=[PartyType(p) for p in metadata.get('party_types', [])]
            )

        except Exception as e:
            self.logger.error(f"Error reprocessing document: {str(e)}")
            raise

    async def extract_document_structure(
            self,
            document_id: UUID
    ) -> Dict[str, Any]:
        """Extract document structure and hierarchy"""
        try:
            chunks = await self.vector_store.get_document_chunks(document_id)
            if not chunks:
                raise ValueError(f"No chunks found for document {document_id}")

            structure = {
                "document_id": str(document_id),
                "total_pages": max(chunk.page_number for chunk in chunks),
                "sections": [],
                "hierarchy": {}
            }

            current_section = None
            current_subsection = None

            for chunk in sorted(chunks, key=lambda x: (x.page_number, x.metadata.get('chunk_number', 0))):
                content = chunk.content.strip()

                # Check if chunk starts with a section header
                if content.isupper() or content.endswith(':'):
                    if len(content.split()) <= 10:  # Reasonable length for a header
                        current_section = {
                            "title": content,
                            "page_number": chunk.page_number,
                            "subsections": []
                        }
                        structure["sections"].append(current_section)
                        current_subsection = None
                elif current_section:
                    # Check for subsection
                    if content.startswith(('1.', '2.', '3.')) or content.endswith(':'):
                        current_subsection = {
                            "title": content,
                            "page_number": chunk.page_number,
                            "content": []
                        }
                        current_section["subsections"].append(current_subsection)
                    elif current_subsection:
                        current_subsection["content"].append(content)
                    else:
                        if "content" not in current_section:
                            current_section["content"] = []
                        current_section["content"].append(content)

            return structure

        except Exception as e:
            self.logger.error(f"Error extracting document structure: {str(e)}")
            raise

    async def extract_metadata(self, document_id: UUID) -> Dict[str, Any]:
        """
        Extract and analyze document metadata
        """
        try:
            # Get document path
            doc_path = self.upload_dir / f"{document_id}.pdf"
            if not doc_path.exists():
                raise FileNotFoundError(f"Document {document_id} not found")

            async with aiofiles.open(doc_path, 'rb') as f:
                content = await f.read()

            # Open PDF for metadata extraction
            with fitz.open(stream=content) as doc:
                metadata = {
                    "document_id": str(document_id),
                    "title": doc.metadata.get("title", ""),
                    "author": doc.metadata.get("author", ""),
                    "subject": doc.metadata.get("subject", ""),
                    "keywords": doc.metadata.get("keywords", ""),
                    "created_date": doc.metadata.get("creationDate", ""),
                    "modified_date": doc.metadata.get("modDate", ""),
                    "page_count": len(doc),
                    "file_size": os.path.getsize(doc_path),
                    "pdf_version": doc.version,
                    "is_encrypted": doc.is_encrypted,
                    "page_layout": doc.page_layout,
                    "permissions": doc.permissions,
                    "form_fields": bool(doc.form_fields),
                    "has_links": any(page.get_links() for page in doc),
                    "has_images": any(page.get_images() for page in doc),
                    "extracted_at": datetime.now().isoformat()
                }

                # Extract table of contents if available
                try:
                    toc = doc.get_toc()
                    if toc:
                        metadata["table_of_contents"] = [
                            {"level": level, "title": title, "page": page}
                            for level, title, page in toc
                        ]
                except Exception as e:
                    self.logger.warning(f"Error extracting table of contents: {str(e)}")

                return metadata

        except Exception as e:
            self.logger.error(f"Error extracting metadata: {str(e)}")
            raise

    async def validate_document(self, document_id: UUID) -> Dict[str, Any]:
        """
        Validate document content and structure
        """
        try:
            validation_results = {
                "document_id": str(document_id),
                "validated_at": datetime.now().isoformat(),
                "is_valid": True,
                "issues": [],
                "warnings": [],
                "statistics": {}
            }

            # Get document chunks
            chunks = await self.vector_store.get_document_chunks(document_id)
            if not chunks:
                validation_results["is_valid"] = False
                validation_results["issues"].append("No chunks found for document")
                return validation_results

            # Calculate statistics
            stats = {
                "total_chunks": len(chunks),
                "total_pages": max(chunk.page_number for chunk in chunks),
                "average_chunk_size": sum(len(chunk.content) for chunk in chunks) / len(chunks),
                "content_distribution": {}
            }

            # Validate content distribution
            for chunk in chunks:
                page_num = chunk.page_number
                if page_num not in stats["content_distribution"]:
                    stats["content_distribution"][page_num] = {
                        "chunk_count": 0,
                        "total_content_length": 0
                    }

                stats["content_distribution"][page_num]["chunk_count"] += 1
                stats["content_distribution"][page_num]["total_content_length"] += len(chunk.content)

            # Check for potential issues
            for page_num, dist in stats["content_distribution"].items():
                # Check for pages with very little content
                if dist["total_content_length"] < 100:  # Arbitrary threshold
                    validation_results["warnings"].append(
                        f"Page {page_num} has very little content ({dist['total_content_length']} characters)"
                    )

                # Check for uneven chunk distribution
                if dist["chunk_count"] > stats["total_chunks"] / stats["total_pages"] * 2:
                    validation_results["warnings"].append(
                        f"Page {page_num} has unusually high number of chunks ({dist['chunk_count']})"
                    )

            validation_results["statistics"] = stats
            return validation_results

        except Exception as e:
            self.logger.error(f"Error validating document: {str(e)}")
            raise

    async def cleanup_old_documents(self, days_threshold: int = 30) -> List[str]:
        """
        Clean up old documents and their associated data
        """
        try:
            cleaned_docs = []
            threshold_date = datetime.now().timestamp() - (days_threshold * 24 * 60 * 60)

            # Scan upload directory
            for file_path in self.upload_dir.glob("*.pdf"):
                try:
                    # Check file modification time
                    if file_path.stat().st_mtime < threshold_date:
                        document_id = file_path.stem

                        # Delete from vector store
                        await self.vector_store.delete_document(UUID(document_id))

                        # Delete file
                        file_path.unlink()
                        cleaned_docs.append(document_id)

                        self.logger.info(f"Cleaned up document: {document_id}")
                except Exception as e:
                    self.logger.error(f"Error cleaning up document {file_path}: {str(e)}")

            return cleaned_docs

        except Exception as e:
            self.logger.error(f"Error during cleanup: {str(e)}")
            raise

    async def get_document_statistics(self, document_id: UUID) -> Dict[str, Any]:
        """
        Get comprehensive statistics for a document
        """
        try:
            stats = {
                "document_id": str(document_id),
                "generated_at": datetime.now().isoformat(),
                "basic_stats": {},
                "content_stats": {},
                "chunk_stats": {},
                "processing_stats": {}
            }

            # Get document chunks
            chunks = await self.vector_store.get_document_chunks(document_id)
            if not chunks:
                raise ValueError(f"No chunks found for document {document_id}")

            # Basic statistics
            stats["basic_stats"] = {
                "total_pages": max(chunk.page_number for chunk in chunks),
                "total_chunks": len(chunks),
                "total_content_length": sum(len(chunk.content) for chunk in chunks)
            }

            # Content statistics
            content_stats = {
                "average_chunk_size": stats["basic_stats"]["total_content_length"] / len(chunks),
                "sections": len([c for c in chunks if c.content.isupper() or c.content.endswith(':')]),
                "content_by_page": defaultdict(int)
            }

            for chunk in chunks:
                content_stats["content_by_page"][chunk.page_number] += len(chunk.content)

            stats["content_stats"] = content_stats

            # Chunk statistics
            chunk_lengths = [len(chunk.content) for chunk in chunks]
            stats["chunk_stats"] = {
                "min_chunk_size": min(chunk_lengths),
                "max_chunk_size": max(chunk_lengths),
                "median_chunk_size": np.median(chunk_lengths),
                "std_chunk_size": np.std(chunk_lengths)
            }

            # Processing statistics
            doc_metadata = await self.vector_store.get_document_metadata(document_id)
            if doc_metadata:
                stats["processing_stats"] = {
                    "processing_time": doc_metadata.get("processing_time", 0),
                    "chunk_size": doc_metadata.get("chunk_size", self.chunk_size),
                    "chunk_overlap": doc_metadata.get("chunk_overlap", self.chunk_overlap)
                }

            return stats

        except Exception as e:
            self.logger.error(f"Error getting document statistics: {str(e)}")
            raise

    async def optimize_chunks(self, document_id: UUID) -> Dict[str, Any]:
        """
        Optimize document chunks based on content analysis
        """
        try:
            # Get current chunks
            chunks = await self.vector_store.get_document_chunks(document_id)
            if not chunks:
                raise ValueError(f"No chunks found for document {document_id}")

            optimization_results = {
                "document_id": str(document_id),
                "original_chunks": len(chunks),
                "optimized_chunks": 0,
                "changes": []
            }

            # Analyze chunk sizes and distribution
            chunk_lengths = [len(chunk.content) for chunk in chunks]
            mean_length = np.mean(chunk_lengths)
            std_length = np.std(chunk_lengths)

            # Identify chunks that need optimization
            chunks_to_optimize = []
            for chunk in chunks:
                chunk_len = len(chunk.content)

                # Check if chunk is too small or too large
                if chunk_len < mean_length - std_length or chunk_len > mean_length + std_length:
                    chunks_to_optimize.append(chunk)

            if chunks_to_optimize:
                # Delete old chunks
                for chunk in chunks_to_optimize:
                    await self.vector_store.delete_chunk(chunk.chunk_id)

                # Reprocess content with adjusted parameters
                new_chunks = []
                for chunk in chunks_to_optimize:
                    optimized_chunks = self._optimize_chunk_content(
                        chunk.content,
                        chunk.page_number,
                        document_id,
                        mean_length
                    )
                    new_chunks.extend(optimized_chunks)

                # Store new chunks
                await self.vector_store.store_chunks(new_chunks, document_id)

                optimization_results["optimized_chunks"] = len(new_chunks)
                optimization_results["changes"] = [
                    {
                        "original_chunk_id": chunk.chunk_id,
                        "new_chunk_count": len(self._optimize_chunk_content(
                            chunk.content,
                            chunk.page_number,
                            document_id,
                            mean_length
                        ))
                    }
                    for chunk in chunks_to_optimize
                ]

            return optimization_results

        except Exception as e:
            self.logger.error(f"Error optimizing chunks: {str(e)}")
            raise

    def _optimize_chunk_content(
            self,
            content: str,
            page_number: int,
            document_id: UUID,
            target_length: float
    ) -> List[DocumentChunk]:
        """
        Optimize a single chunk's content
        """
        optimized_chunks = []
        segments = self._split_into_segments(content)

        current_chunk = []
        current_length = 0

        for segment in segments:
            segment_length = len(segment)

            if current_length + segment_length > target_length:
                if current_chunk:
                    chunk_text = " ".join(current_chunk)
                    chunk_id = self._generate_chunk_id(
                        document_id,
                        page_number,
                        chunk_text
                    )

                    optimized_chunks.append(DocumentChunk(
                        chunk_id=chunk_id,
                        content=chunk_text,
                        page_number=page_number,
                        metadata={
                            "document_id": str(document_id),
                            "page_number": page_number,
                            "chunk_number": len(optimized_chunks) + 1,
                            "optimized": True,
                            "created_at": datetime.now().isoformat()
                        }
                    ))

                    current_chunk = [segment]
                    current_length = segment_length
            else:
                current_chunk.append(segment)
                current_length += segment_length

        # Handle remaining content
        if current_chunk:
            chunk_text = " ".join(current_chunk)
            chunk_id = self._generate_chunk_id(
                document_id,
                page_number,
                chunk_text
            )

            optimized_chunks.append(DocumentChunk(
                chunk_id=chunk_id,
                content=chunk_text,
                page_number=page_number,
                metadata={
                    "document_id": str(document_id),
                    "page_number": page_number,
                    "chunk_number": len(optimized_chunks) + 1,
                    "optimized": True,
                    "created_at": datetime.now().isoformat()
                }
            ))

        return optimized_chunks

    async def __aenter__(self):
        """Async context manager entry"""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        await self.cleanup()

    async def cleanup(self):
        """Cleanup resources"""
        self.executor.shutdown(wait=True)
        await self.vector_store.cleanup()