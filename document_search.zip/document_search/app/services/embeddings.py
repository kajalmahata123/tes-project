from typing import List, Dict, Any
import numpy as np
import hashlib
import re
from chromadb.api.types import Documents
from chromadb import EmbeddingFunction


class BasicEmbeddingFunction(EmbeddingFunction):
    def __init__(self, dimension: int = 512):
        """
        Initialize basic embedding function

        Args:
            dimension: Dimension of embedding vectors
        """
        self.dimension = dimension
        self.word_vectors = {}

    def __call__(self, texts: Documents) -> List[List[float]]:
        """
        Generate embeddings for input texts

        Args:
            texts: List of text documents

        Returns:
            List of embedding vectors
        """
        embeddings = []
        for text in texts:
            if not text:
                embeddings.append([0.0] * self.dimension)
                continue

            # Tokenize text
            words = self._tokenize(str(text))
            if not words:
                embeddings.append([0.0] * self.dimension)
                continue

            # Get word vectors
            vectors = np.array([self._hash_word(word) for word in words])

            # Compute mean embedding
            embedding = np.mean(vectors, axis=0)

            # Normalize
            norm = float(np.linalg.norm(embedding))
            if norm > 0:
                embedding = embedding / norm

            embeddings.append(embedding.tolist())

        return embeddings

    def _tokenize(self, text: str) -> List[str]:
        """
        Tokenize text into words

        Args:
            text: Input text

        Returns:
            List of tokens
        """
        # Convert to lowercase
        text = text.lower()

        # Remove special characters
        text = re.sub(r'[^\w\s]', ' ', text)

        # Split into words
        words = text.split()

        # Filter short words and numbers
        words = [w for w in words if len(w) > 2 and not w.isdigit()]

        return words

    def _hash_word(self, word: str) -> np.ndarray:
        """
        Generate or retrieve word vector

        Args:
            word: Input word

        Returns:
            Word vector
        """
        if word not in self.word_vectors:
            # Generate deterministic seed from word
            seed = int(hashlib.sha256(word.encode()).hexdigest(), 16) % (2 ** 32)

            # Generate stable vector
            np.random.seed(seed)
            self.word_vectors[word] = np.random.randn(self.dimension)

        return self.word_vectors[word]

    def _get_vector_size(self) -> int:
        """Get size of cached vectors"""
        return len(self.word_vectors)

    def clear_cache(self):
        """Clear word vector cache"""
        self.word_vectors.clear()