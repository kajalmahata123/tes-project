import requests
from enum import Enum
import logging
import json
from typing import List, Dict, Any, Optional

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class PartyType(str, Enum):
    ACQUIRER = "Acquirer"
    ISSUER = "Issuer"
    BOTH = "Both"


class DocumentType(str, Enum):
    PAYMENT_ARTICLE = "payment_article"
    TECHNICAL_SPEC = "technical_spec"
    IMPLEMENTATION_GUIDE = "implementation_guide"


class Region(str, Enum):
    AP = "AP"
    US = "US"
    CEMA = "CEMA"
    EU = "EU"
    LAC = "LAC"


def test_document_upload_simple():
    """Test document upload with simple query parameters"""
    url = "http://localhost:8001/api/v1/documents/upload"
    pdf_path = "/Users/kajalmahata/smart_QL/smart_ql/assistants/sql_assistant/vector_store/pdfs/Flight_ETicket_DEL_SING.pdf"

    try:
        # Prepare files
        files = {
            'file': ('Flight_ETicket_DEL_SING.pdf', open(pdf_path, 'rb'), 'application/pdf')
        }

        # Query parameters
        params = {
            'doc_type': DocumentType.PAYMENT_ARTICLE.value,
            'regions': [Region.AP.value, Region.US.value],
            'party_types': [PartyType.ACQUIRER.value]
        }

        logger.info(f"Making request with params: {params}")

        # Make request
        response = requests.post(url, files=files, params=params)

        logger.info(f"Response status: {response.status_code}")
        logger.info(f"Response content: {response.text}")

        return handle_response(response)

    except Exception as e:
        logger.error(f"Error: {str(e)}")
        return None
    finally:
        if 'files' in locals():
            files['file'][1].close()


def test_document_upload_with_metadata():
    """Test document upload with metadata in form data"""
    url = "http://localhost:8001/api/v1/documents/upload"
    pdf_path = "/Users/kajalmahata/smart_QL/smart_ql/assistants/sql_assistant/vector_store/pdfs/Flight_ETicket_DEL_SING.pdf"

    try:
        # Prepare files
        files = {
            'file': ('Flight_ETicket_DEL_SING.pdf', open(pdf_path, 'rb'), 'application/pdf')
        }

        # Form data
        form_data = {
            'doc_type': DocumentType.PAYMENT_ARTICLE.value,
            'regions': Region.AP.value,  # Single value for testing
            'party_types': PartyType.ACQUIRER.value,  # Single value for testing
            'metadata': json.dumps({
                'source': 'test_upload',
                'version': '1.0',
                'description': 'Test document with metadata'
            })
        }

        logger.info(f"Making request with form data: {form_data}")

        # Make request
        response = requests.post(url, files=files, data=form_data)

        logger.info(f"Response status: {response.status_code}")
        logger.info(f"Response content: {response.text}")

        return handle_response(response)

    except Exception as e:
        logger.error(f"Error: {str(e)}")
        return None
    finally:
        if 'files' in locals():
            files['file'][1].close()


def handle_response(response: requests.Response) -> Optional[Dict[str, Any]]:
    """Handle API response"""
    try:
        if response.status_code == 200:
            logger.info("Upload successful!")
            result = response.json()
            logger.info(f"Document ID: {result.get('document_id')}")
            logger.info(f"Status: {result.get('status')}")
            return result
        else:
            logger.error(f"Upload failed with status code: {response.status_code}")
            try:
                error_detail = response.json()
                logger.error(f"Error details: {error_detail}")
            except:
                logger.error(f"Raw error response: {response.text}")
            return None
    except Exception as e:
        logger.error(f"Error handling response: {str(e)}")
        return None


if __name__ == "__main__":
    logger.info("\nTesting simple document upload...")
    result1 = test_document_upload_simple()

    '''logger.info("\nTesting document upload with metadata...")
    result2 = test_document_upload_with_metadata()

    if result1 and result2:
        logger.info("\nAll tests completed successfully!")
    else:
        logger.error("\nSome tests failed!")'''