// src/services/api.ts
import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000/api/v1';
let APP_ID = process.env.REACT_APP_APP_ID || 'Visa_api_Bot';
let API_KEY = process.env.REACT_APP_API_KEY || 'sk_2c23d0795fce8e84bf9f4e3f4401ebf910727a13dd82a0a4';

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
    'X-App-ID': APP_ID,
    'X-API-Key': API_KEY,
  },
});

// Request interceptor for API calls
api.interceptors.request.use(
  (config) => {
    // Ensure headers are included in every request
    if (config.headers) {
      config.headers['X-App-ID'] = APP_ID;
      config.headers['X-API-Key'] = API_KEY;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor for API calls
api.interceptors.response.use(
  (response) => {
    return response;
  },
  async (error) => {
    const originalRequest = error.config;
    
    if (error.response) {
      // Handle error responses
      console.error('API Error:', error.response.data);
    }
    
    return Promise.reject(error);
  }
);

/**
 * Update the API key used for requests
 * @param newApiKey The new API key to use
 */
export const setApiKey = (newApiKey: string): void => {
  API_KEY = newApiKey;
};

/**
 * Update the App ID used for requests
 * @param newAppId The new App ID to use
 */
export const setAppId = (newAppId: string): void => {
  APP_ID = newAppId;
};

export default api;



