// src/services/chatService.ts
import api from './api';
import { ChatRequest, ChatResponse } from '../types/chat';

export const chatService = {
  /**
   * Send a chat message to the API
   * @param message The message text to send
   * @param sessionId Optional session ID for continuing a conversation
   * @returns Promise with chat response
   */
  sendMessage: async (message: string, sessionId?: string): Promise<ChatResponse> => {
    const payload = {
      message,
      session_id: sessionId || undefined
    };
    const response = await api.post<ChatResponse>('/chat/message', payload);
    return response.data;
  },

  /**
   * Delete a chat session
   * @param sessionId ID of the session to delete
   * @returns Promise resolving to void on success
   */
  deleteSession: async (sessionId: string): Promise<void> => {
    await api.delete(`/chat/${sessionId}`);
  },
};