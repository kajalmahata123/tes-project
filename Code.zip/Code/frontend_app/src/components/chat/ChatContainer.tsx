import React, { useState, useRef, useEffect } from 'react';
import { Message } from '../../types/chat';
import ChatBubble from './ChatBubble';
import ChatInput from './ChatInput';
import Loader from '../common/Loader';
import { chatService } from '../../services/chatService';

interface ChatContainerProps {
  className?: string;
  sessionId?: string;
  onSessionIdChange?: (sessionId: string) => void;
}

// Define interface for chat messages with metadata
interface EnhancedMessage extends Message {
  metadata?: {
    agent_type?: string;
    app_id?: string;
    message_id?: string;
  };
}

const ChatContainer: React.FC<ChatContainerProps> = ({
  className = '',
  sessionId: initialSessionId,
  onSessionIdChange,
}) => {
  const [messages, setMessages] = useState<EnhancedMessage[]>([]);
  const [sessionId, setSessionId] = useState<string | undefined>(initialSessionId);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    // Scroll to bottom when messages change
    scrollToBottom();
  }, [messages]);
  
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };
  
  const handleSendMessage = async (content: string) => {
    // Add user message to UI immediately
    const userMessage: EnhancedMessage = {
      role: 'user',
      content,
      timestamp: new Date().toISOString(),
    };
    
    setMessages((prevMessages) => [...prevMessages, userMessage]);
    setIsLoading(true);
    setError(null);
    
    try {
      // Send request to API with just the message text and session ID
      const response = await chatService.sendMessage(content, sessionId);
      
      // Update session ID if changed
      if (response.session_id !== sessionId) {
        setSessionId(response.session_id);
        if (onSessionIdChange) {
          onSessionIdChange(response.session_id);
        }
      }
      
      // Add assistant response to messages with metadata
      const assistantMessage: EnhancedMessage = {
        role: 'assistant',
        content: response.response,
        timestamp: new Date().toISOString(),
        metadata: {
          agent_type: response.agent_type,
          app_id: response.app_id,
          message_id: response.message_id
        }
      };
      
      setMessages((prevMessages) => [...prevMessages, assistantMessage]);
      
    } catch (err: any) {
      console.error('Error sending message:', err);
      setError(err.response?.data?.detail || 'Failed to send message');
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <div className={`flex flex-col bg-white rounded-lg shadow-md overflow-hidden h-full ${className}`}>
      {/* Chat Header */}
      <div className="bg-primary-600 text-white px-4 py-3 flex items-center justify-between">
        <h2 className="text-lg font-semibold">API Agent Chat</h2>
        {sessionId && (
          <div className="text-xs bg-primary-700 px-2 py-1 rounded">
            Session ID: {sessionId.substring(0, 8)}...
          </div>
        )}
      </div>
      
      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 bg-secondary-50">
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center text-secondary-500 p-6">
            <svg
              className="w-12 h-12 mb-4 text-secondary-400"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={1.5}
                d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"
              />
            </svg>
            <p className="font-medium">No messages yet</p>
            <p className="text-sm mt-1">
              Start a conversation with the API agent. You can ask about API workflows, generate code, or ask questions about the uploaded documentation.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {messages.map((message, index) => (
              <ChatBubble key={index} message={message} />
            ))}
            {isLoading && (
              <div className="flex justify-center py-2">
                <Loader size="sm" />
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        )}
      </div>
      
      {/* Error Message */}
      {error && (
        <div className="bg-error-50 border-t border-error-200 p-3">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg
                className="h-5 w-5 text-error-400"
                fill="currentColor"
                viewBox="0 0 20 20"
              >
                <path
                  fillRule="evenodd"
                  d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z"
                  clipRule="evenodd"
                />
              </svg>
            </div>
            <div className="ml-3">
              <p className="text-sm text-error-700">{error}</p>
            </div>
          </div>
        </div>
      )}
      
      {/* Input Area */}
      <ChatInput
        onSendMessage={handleSendMessage}
        isLoading={isLoading}
        placeholder="Ask about API workflows, generate code, or ask questions..."
      />
    </div>
  );
};

export default ChatContainer;
