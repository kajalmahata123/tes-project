#!/usr/bin/env python3
# run_migration.py
# Script to run database migrations

import sys
import logging
from db.migration import add_app_id_column

def main():
    """Run database migrations."""
    # Set up logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    logger = logging.getLogger(__name__)
    
    logger.info("Starting database migrations...")
    
    # Run migrations
    try:
        # Add app_id column to sessions table
        add_app_id_column()
        
        logger.info("All migrations completed successfully.")
        return 0
    
    except Exception as e:
        logger.error(f"Migration failed: {e}", exc_info=True)
        return 1

if __name__ == "__main__":
    sys.exit(main()) 