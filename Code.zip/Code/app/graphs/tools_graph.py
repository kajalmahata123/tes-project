from typing import List, Dict, Any, Callable, Optional, Tuple
from langchain.schema import BaseMessage, HumanMessage, AIMessage, SystemMessage
from langgraph.graph import StateGraph, END
from pydantic import BaseModel, Field

from app.graphs.base_graph import BaseAgentGraph

import logging

logger = logging.getLogger(__name__)


class ToolsState(BaseModel):
    """State for the tools orchestration graph."""
    input: str = Field(description="The original user input")
    chat_history: List[BaseMessage] = Field(default_factory=list, description="Chat history")
    selected_tools: List[str] = Field(default_factory=list, description="Tools selected for use")
    tool_results: Dict[str, Any] = Field(default_factory=dict, description="Results from tools")
    current_tool: Optional[str] = Field(default=None, description="Currently executing tool")
    errors: List[str] = Field(default_factory=list, description="Errors encountered")
    output: Optional[str] = Field(default=None, description="Final response to user")
    completed: bool = Field(default=False, description="Whether processing is complete")


class ToolsGraph(BaseAgentGraph):
    """
    Tool orchestration graph for sequential tool execution.
    Allows automating complex workflows with multiple tools.
    """

    async def build(self) -> StateGraph:
        """
        Build the tools orchestration graph.

        Returns:
            Compiled StateGraph
        """
        # Create the state graph
        workflow = StateGraph(ToolsState)

        # Define nodes

        # 1. Tool selection node - determine which tools to use
        async def select_tools(state: ToolsState) -> ToolsState:
            """Select tools to use based on input."""
            messages = []
            if self.system_prompt:
                messages.append(SystemMessage(content=self.system_prompt))

            # Add chat history
            if state.chat_history:
                messages.extend(state.chat_history)

            # Create tool selection prompt
            tool_descriptions = "\n".join([
                f"Tool {i + 1}: {tool.name} - {tool.description}"
                for i, tool in enumerate(self.tools)
            ])

            selection_prompt = f"""
Based on the user's request, select which tools you need to use to complete the task.
Respond with a comma-separated list of tool names.

User request: {state.input}

Available tools:
{tool_descriptions}

Selected tools (comma-separated):
"""

            messages.append(HumanMessage(content=selection_prompt))

            # Get LLM response
            response = await self.llm.ainvoke(messages)
            selected_tools_text = response.content.strip()

            # Parse selected tools
            selected_tools = [
                tool_name.strip()
                for tool_name in selected_tools_text.split(",")
            ]

            # Validate selected tools (only include tools that exist)
            valid_tools = []
            for tool_name in selected_tools:
                if self.get_tool_by_name(tool_name):
                    valid_tools.append(tool_name)

            # Update state
            state.selected_tools = valid_tools
            logger.info(f"Selected tools: {state.selected_tools}")

            return state

        # 2. Tool execution node - execute each tool in sequence
        async def execute_tool(state: ToolsState) -> ToolsState:
            """Execute the current tool."""
            if not state.selected_tools:
                # No tools to execute
                state.completed = True
                return state

            # Get next tool to execute
            tool_name = state.selected_tools[0]
            state.current_tool = tool_name
            state.selected_tools = state.selected_tools[1:]  # Remove from list

            # Get the tool
            tool = self.get_tool_by_name(tool_name)
            if not tool:
                logger.warning(f"Tool {tool_name} not found")
                state.errors.append(f"Tool {tool_name} not found")
                return state

            try:
                # Create input for the tool based on user input and prior results
                messages = []
                if self.system_prompt:
                    messages.append(SystemMessage(content=self.system_prompt))

                input_prompt = f"""
Create the input for the {tool_name} tool based on the user's request.
Return only the input text, nothing else.

User request: {state.input}
"""

                # Add any previous tool results for context
                if state.tool_results:
                    input_prompt += "\nPrevious tool results:\n"
                    for prev_tool, result in state.tool_results.items():
                        input_prompt += f"{prev_tool}: {str(result)[:200]}...\n"

                messages.append(HumanMessage(content=input_prompt))

                # Get LLM response for tool input
                response = await self.llm.ainvoke(messages)
                tool_input = response.content.strip()

                # Execute the tool
                logger.info(f"Executing tool {tool_name} with input: {tool_input[:100]}...")
                result = await tool.ainvoke({"query": tool_input})

                # Store the result
                state.tool_results[tool_name] = result

            except Exception as e:
                logger.error(f"Error executing tool {tool_name}: {e}", exc_info=True)
                state.errors.append(f"Error executing tool {tool_name}: {str(e)}")

            return state

        # 3. Response generation node - create final response from tool results
        async def generate_response(state: ToolsState) -> ToolsState:
            """Generate response based on tool results."""
            messages = []
            if self.system_prompt:
                messages.append(SystemMessage(content=self.system_prompt))

            # Add chat history
            if state.chat_history:
                messages.extend(state.chat_history)

            # Create response prompt
            results_text = ""
            for tool_name, result in state.tool_results.items():
                results_text += f"\n\n--- {tool_name} results ---\n{str(result)}"

            errors_text = ""
            if state.errors:
                errors_text = "\n\nErrors encountered:\n" + "\n".join(state.errors)

            response_prompt = f"""
Based on the following information, provide a helpful response to the user's request.

User request: {state.input}

Tool results: {results_text}
{errors_text}

Synthesize the information above into a clear, helpful response that addresses the user's request.
"""

            messages.append(HumanMessage(content=response_prompt))

            # Get LLM response
            response = await self.llm.ainvoke(messages)

            # Update state
            state.output = response.content
            state.completed = True

            return state

        # Define the edges

        # 1. Define condition functions for edges
        def should_continue_execution(state: ToolsState) -> str:
            """Determine if we should continue executing tools or generate response."""
            if state.completed or not state.selected_tools:
                return "generate_response"
            return "execute_tool"

        def after_tool_execution(state: ToolsState) -> str:
            """Determine what to do after executing a tool."""
            if state.selected_tools:
                return "execute_tool"  # More tools to execute
            return "generate_response"  # No more tools, generate response

        # 2. Add nodes to the graph
        workflow.add_node("select_tools", select_tools)
        workflow.add_node("execute_tool", execute_tool)
        workflow.add_node("generate_response", generate_response)

        # 3. Add edges to the graph
        workflow.add_edge("select_tools", should_continue_execution)
        workflow.add_edge("execute_tool", after_tool_execution)
        workflow.add_edge("generate_response", END)

        # 4. Set the entry point
        workflow.set_entry_point("select_tools")

        # Compile the graph
        return workflow.compile()

    async def run(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Run the tools graph with input data.

        Args:
            input_data: Input data with user input and chat history

        Returns:
            Output with response and tool results
        """
        if not self.graph:
            self.graph = await self.build()

        # Run the graph
        result = await self.graph.ainvoke(input_data)

        return {
            "output": result.output,
            "tool_results": result.tool_results,
            "errors": result.errors
        }