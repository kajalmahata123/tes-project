import logging
from typing import List, Dict, Any, Optional, Tuple
from langchain.schema.language_model import BaseLanguageModel
from langchain.schema import BaseMessage, HumanMessage, AIMessage, SystemMessage
from langchain.tools import BaseTool
from langgraph.graph import StateGraph, END
from pydantic import BaseModel, Field
import hashlib

logger = logging.getLogger(__name__)


class ReActState(BaseModel):
    """State for the ReAct agent graph."""
    input: str = Field(description="The original user input")
    chat_history: List[BaseMessage] = Field(default_factory=list, description="Chat history")
    thought: str = Field(default="", description="Agent's current thought")
    action_name: Optional[str] = Field(default=None, description="Tool to use")
    action_input: Optional[Dict[str, Any]] = Field(default=None, description="Input for the tool")
    observation: Optional[str] = Field(default=None, description="Result from the tool")
    output: Optional[str] = Field(default=None, description="Final response to the user")
    iterations: int = Field(default=0, description="Number of ReAct cycles")
    # Add accumulated knowledge tracking
    accumulated_knowledge: Dict[str, str] = Field(default_factory=dict, description="Knowledge gathered from tools")
    previous_queries: List[str] = Field(default_factory=list, description="Previous search queries")
    new_request: bool = Field(default=True, description="Flag indicating if this is a new request")
    # Session-level caches
    tool_cache: Dict[str, str] = Field(default_factory=dict, description="Cache for tool results")
    llm_cache: Dict[str, str] = Field(default_factory=dict, description="Cache for LLM responses")


def get_cache_key(elements: Tuple[Any, ...]) -> str:
    """Generate a deterministic cache key from input elements."""
    combined = "".join(str(element) for element in elements if element is not None)
    return hashlib.md5(combined.encode()).hexdigest()


async def create_react_graph(
        llm: BaseLanguageModel,
        tools: List[BaseTool],
        system_prompt: str,
        max_iterations: int = 5
) -> StateGraph:
    """
    Create a LangGraph implementation of the ReAct agent pattern.

    Args:
        llm: Language model to use
        tools: List of available tools
        system_prompt: System prompt for the agent
        max_iterations: Maximum number of reasoning-action cycles

    Returns:
        StateGraph for the ReAct agent
    """
    # Create the state graph
    workflow = StateGraph(ReActState)

    # Define nodes

    # 1. Reasoning node: Decide what to do next
    async def reasoning(state: ReActState) -> ReActState:
        """Agent reasoning step."""
        # Format messages for LLM
        messages = [SystemMessage(content=system_prompt)]

        # Add chat history
        if state.chat_history:
            messages.extend(state.chat_history)

        # Check if this is a new request in an existing session
        if state.new_request:
            # Reset query-specific state but keep accumulated knowledge
            state.previous_queries = []
            # We're now processing this request
            state.new_request = False

        # Create prompt for decision making
        tool_descriptions = "\n".join([
            f"Tool {i + 1}: {tool.name} - {tool.description}"
            for i, tool in enumerate(tools)
        ])

        # Format accumulated knowledge if any
        knowledge_context = ""
        if state.accumulated_knowledge:
            knowledge_items = []
            for topic, info in state.accumulated_knowledge.items():
                # Limit length to prevent context overflow
                if len(info) > 1000:
                    info = info[:1000] + "... [truncated]"
                knowledge_items.append(f"Information about {topic}:\n{info}")

            knowledge_context = "Previously gathered information:\n" + "\n\n".join(knowledge_items)

        # Add current conversation with accumulated knowledge
        query = f"""
User Question: {state.input}

Available Tools:
{tool_descriptions}

{knowledge_context}

Think step by step to answer the question. You can use tools when needed.
If you need to use a tool, respond with:
THOUGHT: <your reasoning>
ACTION: <tool_name>
ACTION_INPUT: <tool input>

If you can answer directly, respond with:
THOUGHT: <your reasoning>
ANSWER: <your answer to the user>
"""

        # Add previous observations if any
        if state.observation:
            query += f"\nPrevious Observation: {state.observation}\n"

        # Check if we have this exact prompt cached already
        cache_key = get_cache_key((str(system_prompt), query, str(state.iterations)))

        if cache_key in state.llm_cache:
            logger.info("Using cached LLM response")
            response_text = state.llm_cache[cache_key]
        else:
            # Get LLM response
            messages.append(HumanMessage(content=query))
            response = await llm.ainvoke(messages)
            response_text = response.content

            # Cache the response
            state.llm_cache[cache_key] = response_text

        # Parse the response to extract thought, action, and action_input
        state.iterations += 1

        if "THOUGHT:" in response_text:
            # Extract thought
            thought_parts = response_text.split("THOUGHT:")
            if len(thought_parts) > 1:
                thought_text = thought_parts[1].split("\n")[0].strip()
                state.thought = thought_text

        if "ACTION:" in response_text:
            # Extract action (tool name)
            action_parts = response_text.split("ACTION:")
            if len(action_parts) > 1:
                action_text = action_parts[1].split("\n")[0].strip()
                state.action_name = action_text

            # Extract action input
            if "ACTION_INPUT:" in response_text:
                action_input_parts = response_text.split("ACTION_INPUT:")
                if len(action_input_parts) > 1:
                    action_input_text = action_input_parts[1].strip()
                    # Simple parsing - in production use a more robust parser
                    state.action_input = {"query": action_input_text}

                    # Only check for duplicate searches within the same request
                    # Don't block searches across different requests
                    if state.action_name == "documentation_search":
                        query = action_input_text.lower().strip()
                        # Check if we've already searched for this in THIS request
                        for prev_query in state.previous_queries:
                            if query == prev_query:  # Only exact matches are considered duplicates
                                logger.info(f"Detected duplicate query within this request: {query}")
                                state.observation = "This information was already searched for in this conversation. Please review the previous results or ask a different question."
                                state.action_name = None  # Don't execute the duplicate search
                                state.action_input = None
                                break

        if "ANSWER:" in response_text:
            # Extract final answer
            answer_parts = response_text.split("ANSWER:")
            if len(answer_parts) > 1:
                answer_text = answer_parts[1].strip()
                state.output = answer_text

        return state

    # 2. Action node: Execute the selected tool
    async def action(state: ReActState) -> ReActState:
        """Execute the selected tool."""
        action_name = state.action_name
        action_input = state.action_input or {}

        # Only proceed if we have a valid action
        if not action_name:
            return state

        # Track search queries for the current request
        if action_name == "documentation_search" and "query" in action_input:
            query = action_input["query"].lower().strip()

            # Store the query for future reference
            if query not in state.previous_queries:
                state.previous_queries.append(query)

        # Find the matching tool
        matching_tool = None
        for tool in tools:
            if tool.name.lower() == action_name.lower():
                matching_tool = tool
                break

        if not matching_tool:
            state.observation = f"Error: Tool '{action_name}' not found."
            return state

        try:
            # Create a cache key for this tool invocation
            tool_cache_key = get_cache_key((action_name, str(action_input)))

            # Check if result is already cached
            if tool_cache_key in state.tool_cache:
                logger.info(f"Using cached result for tool: {action_name}")
                state.observation = state.tool_cache[tool_cache_key]
            else:
                # Execute the tool
                logger.info(f"Executing tool: {matching_tool.name} with input: {action_input}")
                result = await matching_tool.ainvoke(action_input)
                state.observation = str(result)

                # Cache the result
                state.tool_cache[tool_cache_key] = state.observation

                logger.debug(f"Tool result: {state.observation[:100]}...")

            # Store the result in accumulated knowledge
            if action_name == "documentation_search" and "query" in action_input:
                query = action_input["query"]
                # Create a descriptive key for the knowledge
                topic = query.replace("api", "API").strip()
                state.accumulated_knowledge[topic] = state.observation

        except Exception as e:
            logger.error(f"Error executing tool {matching_tool.name}: {e}", exc_info=True)
            state.observation = f"Error executing tool: {str(e)}"

        return state

    # 3. Response node: Generate final response to user
    async def generate_response(state: ReActState) -> ReActState:
        """Generate final response to the user."""
        messages = [SystemMessage(content=system_prompt)]

        # Add chat history
        if state.chat_history:
            messages.extend(state.chat_history)

        # Create prompt for response generation with accumulated knowledge
        knowledge_summary = ""
        if state.accumulated_knowledge:
            knowledge_items = []
            for topic, info in state.accumulated_knowledge.items():
                # Include summarized knowledge to prevent context overflow
                if len(info) > 1500:
                    info = info[:1500] + "... [additional details available]"
                knowledge_items.append(f"Information about {topic}:\n{info}")

            knowledge_summary = "\n\n".join(knowledge_items)

        prompt = f"""
Based on the following information, provide a helpful response to the user's question.

User Question: {state.input}

Your Thought Process: {state.thought}

Information Retrieved:
{knowledge_summary if state.accumulated_knowledge else (state.observation if state.observation else "No additional information retrieved.")}

Provide a clear, concise, and helpful response based on the information above.
"""

        # Check if we have this exact prompt cached already
        response_cache_key = get_cache_key((str(system_prompt), prompt, str(state.input)))

        if response_cache_key in state.llm_cache:
            logger.info("Using cached final response")
            state.output = state.llm_cache[response_cache_key]
        else:
            # Get LLM response
            messages.append(HumanMessage(content=prompt))
            response = await llm.ainvoke(messages)
            response_text = response.content

            # Cache the response
            state.llm_cache[response_cache_key] = response_text

            # Set the output
            state.output = response_text

        return state

    # Define the edges of the graph

    # Add nodes to the graph
    workflow.add_node("reasoning", reasoning)
    workflow.add_node("action", action)
    workflow.add_node("generate_response", generate_response)

    # Add conditional edges
    workflow.add_conditional_edges(
        "reasoning",
        lambda state: "end" if state.output is not None else
        "generate_response" if state.iterations >= max_iterations else
        "action" if state.action_name is not None else
        "generate_response",
        {
            "action": "action",
            "generate_response": "generate_response",
            "end": END
        }
    )

    workflow.add_conditional_edges(
        "action",
        lambda state: "generate_response" if state.iterations >= max_iterations else "reasoning",
        {
            "reasoning": "reasoning",
            "generate_response": "generate_response"
        }
    )

    workflow.add_edge("generate_response", END)

    # Set the entry point
    workflow.set_entry_point("reasoning")

    # Compile the graph
    return workflow.compile()