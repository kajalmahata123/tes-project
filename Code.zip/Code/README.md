Admin Secrect {
  "id": "e78e840a-85c5-4a49-8a1d-2da8472e19da",
  "app_id": "Visa_api_Bot",
  "api_key": "sk_7c9a4b792db9296e86fdaf6efc98d550f6cbb3dd11ba16e5",
  "app_name": "Visa API Bot Application",
  "description": "Initial admin API key",
  "is_active": true,
  "created_at": "2025-03-18T02:37:25.268241",
  "expires_at": null,
  "rate_limit": 500
}


Create a Cliet Application 

{
  "id": "eb466a71-d649-4620-b2c6-5664e8ba2aae",
  "app_id": "Visa_api_Bot",
  "api_key": "sk_2c23d0795fce8e84bf9f4e3f4401ebf910727a13dd82a0a4",
  "app_name": "ClientApp1",
  "description": "This is a Client Application",
  "is_active": true,
  "created_at": "2025-03-18T03:07:32.397497",
  "last_used_at": null,
  "expires_at": null,
  "rate_limit": 100
}