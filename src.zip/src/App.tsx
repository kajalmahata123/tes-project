import React, { Suspense } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useNavigate, useLocation } from 'react-router-dom';
import Layout from './components/layout/Layout';
import LoginPage from './pages/LoginPage';
import Dashboard from './pages/Dashboard';
import Databases from './pages/Databases';
import Visualizations from './pages/Visualizations';
import { AuthProvider, useAuth } from './contexts/AuthContext';

// Protected Route Component
const ProtectedRoute: React.FC<{ element: React.ReactElement }> = ({ element }) => {
  const { isAuthenticated } = useAuth();
  const location = useLocation();

  if (!isAuthenticated) {
    // Redirect to login page while saving the attempted URL
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return element;
};

// Root component that provides auth context
const Root: React.FC = () => {
  return (
    <AuthProvider>
      <Router>
        <AppRoutes />
      </Router>
    </AuthProvider>
  );
};

// Main Routes component
const AppRoutes: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { isAuthenticated, login } = useAuth();

  const handleLoginSuccess = (token: string, user: any) => {
    login(token, user);
    // Redirect to the originally requested URL or dashboard
    const origin = location.state?.from?.pathname || '/dashboard';
    navigate(origin);
  };

  const handleSignUp = () => {
    navigate('/signup');
  };

  const handleForgotPassword = () => {
    navigate('/forgot-password');
  };

  if (!isAuthenticated && location.pathname !== '/login') {
    return (
      <LoginPage
        onSignUp={handleSignUp}
        onForgotPassword={handleForgotPassword}
        onLoginSuccess={handleLoginSuccess}
      />
    );
  }

  return (
    <Routes>
      <Route path="/login" element={
        isAuthenticated ? 
        <Navigate to="/dashboard" replace /> : 
        <LoginPage
          onSignUp={handleSignUp}
          onForgotPassword={handleForgotPassword}
          onLoginSuccess={handleLoginSuccess}
        />
      } />

      {/* Protected Routes */}
      <Route
        path="/"
        element={
          <ProtectedRoute
            element={
              <Layout>
                <Suspense
                  fallback={
                    <div className="flex items-center justify-center min-h-screen">
                      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
                    </div>
                  }
                >
                  <Routes>
                    <Route path="/dashboard" element={<Dashboard />} />
                    <Route path="/databases" element={<Databases />} />
                    <Route path="/visualizations" element={<Visualizations />} />
                    
                    <Route path="*" element={<Navigate to="/login" replace />} />
                  </Routes>
                </Suspense>
              </Layout>
            }
          />
        }
      >
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/databases" element={<Databases />} />
        <Route path="/visualizations" element={<Visualizations />} />
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Route>
    </Routes>
  );
};

export default Root;