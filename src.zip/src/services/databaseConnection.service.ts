// src/services/datasource.service.ts
import { authFetch } from '../utils/api';

export interface Datasource {
  id: string;
  name: string;
  type: string;
  host: string;
  port: number;
  username: string;
  database: string;
  status?: 'healthy' | 'warning' | 'critical';
  uptime?: string;
  latency?: number;
  connections?: number;
  createdAt?: string;
  updatedAt?: string;
}

export interface CreateDatasourceDto {
  name: string;
  type: string;
  host: string;
  port: number;
  username: string;
  password: string;
  database: string;
}

export interface UpdateDatasourceDto extends Partial<CreateDatasourceDto> {
  id: string;
}

export interface TestDatasourceDto {
  host: string;
  port: number;
  username: string;
  password: string;
  database: string;
  type: string;
}

class DatasourceService {
  private baseUrl = '/datasources';

  // Create a new datasource
  async createDatasource(datasource: CreateDatasourceDto): Promise<Datasource | null> {
    const response = await authFetch<Datasource>(this.baseUrl, {
      method: 'POST',
      body: JSON.stringify(datasource)
    });

    if (response.error) {
      throw new Error(response.error);
    }

    return response.data || null;
  }

  // Get all datasources
  async getAllDatasources(): Promise<Datasource[]> {
    const response = await authFetch<Datasource[]>(this.baseUrl, {
      method: 'GET'
    });

    if (response.error) {
      throw new Error(response.error);
    }

    return response.data || [];
  }

  // Get a single datasource by ID
  async getDatasourceById(id: string): Promise<Datasource | null> {
    const response = await authFetch<Datasource>(`${this.baseUrl}/${id}`, {
      method: 'GET'
    });

    if (response.error) {
      throw new Error(response.error);
    }

    return response.data || null;
  }

  // Update a datasource
  async updateDatasource(datasource: UpdateDatasourceDto): Promise<Datasource | null> {
    const response = await authFetch<Datasource>(
      `${this.baseUrl}/${datasource.id}`,
      {
        method: 'PUT',
        body: JSON.stringify(datasource)
      }
    );

    if (response.error) {
      throw new Error(response.error);
    }

    return response.data || null;
  }

  // Delete a datasource
  async deleteDatasource(id: string): Promise<boolean> {
    const response = await authFetch<{ success: boolean }>(`${this.baseUrl}/${id}`, {
      method: 'DELETE'
    });

    if (response.error) {
      throw new Error(response.error);
    }

    return true;
  }

  // Test a datasource connection
  async testDatasource(testData: TestDatasourceDto): Promise<boolean> {
    const response = await authFetch<{ success: boolean }>(
      `${this.baseUrl}/test`,
      {
        method: 'POST',
        body: JSON.stringify(testData)
      }
    );

    if (response.error) {
      throw new Error(response.error);
    }

    return response.data?.success || false;
  }

  // Get datasource health status
  async getDatasourceHealth(id: string): Promise<Datasource | null> {
    const response = await authFetch<Datasource>(
      `${this.baseUrl}/${id}/health`,
      {
        method: 'GET'
      }
    );

    if (response.error) {
      throw new Error(response.error);
    }

    return response.data || null;
  }

  // Refresh datasource status
  async refreshDatasource(id: string): Promise<Datasource | null> {
    const response = await authFetch<Datasource>(
      `${this.baseUrl}/${id}/refresh`,
      {
        method: 'POST'
      }
    );

    if (response.error) {
      throw new Error(response.error);
    }

    return response.data || null;
  }
}

export const datasourceService = new DatasourceService();