// src/services/authService.ts

import { setTokens } from "../utils/auth";

interface LoginResponse {
    token: string;
    user: {
      id: string;
      email: string;
      name: string;
    };
  }
  
  interface LoginCredentials {
    email: string;
    password: string;
  }
  
  interface SocialLoginCredentials {
    provider: 'google' | 'github';
    token: string;
  }
  
  class AuthService {
    private baseUrl: string;
    
    constructor() {
      this.baseUrl = process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:8000/api/v1';
    }
  
    private async handleResponse<T>(response: Response): Promise<T> {
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.message || 'An error occurred');
      }
      setTokens(data.access_token, data.refresh_token);
      
      return data;
    }
  
    async login(credentials: LoginCredentials): Promise<LoginResponse> {
      const response = await fetch(`${this.baseUrl}/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(credentials),
        credentials: 'include', // Needed for cookies
      });
  
      return this.handleResponse<LoginResponse>(response);
    }
  
    async socialLogin(credentials: SocialLoginCredentials): Promise<LoginResponse> {
      const response = await fetch(`${this.baseUrl}/auth/${credentials.provider}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ token: credentials.token }),
        credentials: 'include',
      });
  
      return this.handleResponse<LoginResponse>(response);
    }
  
    async logout(): Promise<void> {
      const response = await fetch(`${this.baseUrl}/auth/logout`, {
        method: 'POST',
        credentials: 'include',
      });
  
      return this.handleResponse<void>(response);
    }
  
    async refreshToken(): Promise<LoginResponse> {
      const response = await fetch(`${this.baseUrl}/auth/refresh`, {
        method: 'POST',
        credentials: 'include',
      });
  
      return this.handleResponse<LoginResponse>(response);
    }
  }
  
  export const authService = new AuthService();