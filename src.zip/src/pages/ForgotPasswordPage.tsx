import React, { useState, FormEvent, ChangeEvent } from 'react';
import { Mail, ArrowLeft, CheckCircle } from 'lucide-react';

interface SuccessStateProps {
  email: string;
  onResend: () => Promise<void>;
  onBackToSignIn: () => void;
}

const SuccessState: React.FC<SuccessStateProps> = ({ 
  email, 
  onResend, 
  onBackToSignIn 
}) => (
  <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
    <div className="sm:mx-auto sm:w-full sm:max-w-md">
      <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
        <div className="text-center">
          <CheckCircle className="mx-auto h-12 w-12 text-green-500" />
          <h2 className="mt-4 text-2xl font-medium text-gray-900">Check your email</h2>
          <p className="mt-2 text-sm text-gray-500">
            We've sent a password reset link to<br />
            <span className="font-medium text-gray-900">{email}</span>
          </p>
          <div className="mt-6">
            <p className="text-sm text-gray-500">
              Didn't receive the email?{' '}
              <button
                onClick={onResend}
                type="button"
                className="font-medium text-blue-600 hover:text-blue-500"
              >
                Click to resend
              </button>
            </p>
          </div>
          <div className="mt-6">
            <button
              onClick={onBackToSignIn}
              type="button"
              className="text-sm font-medium text-blue-600 hover:text-blue-500"
            >
              Return to sign in
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
);

const ForgotPasswordPage: React.FC = () => {
  const [email, setEmail] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>('');
  const [success, setSuccess] = useState<boolean>(false);

  const handleEmailChange = (e: ChangeEvent<HTMLInputElement>) => {
    setEmail(e.target.value);
  };

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    
    try {
      // Password reset logic would go here
      console.log('Sending reset email to:', email);
      setSuccess(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  const handleResend = async () => {
    setLoading(true);
    try {
      // Resend logic would go here
      console.log('Resending reset email to:', email);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  const handleBackToSignIn = () => {
    // Handle navigation to sign in
    console.log('Navigate to sign in');
  };

  if (success) {
    return (
      <SuccessState
        email={email}
        onResend={handleResend}
        onBackToSignIn={handleBackToSignIn}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="flex justify-center">
          <div className="text-3xl font-bold text-blue-600">QwikSense</div>
        </div>
        <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
          Reset your password
        </h2>
        <p className="mt-2 text-center text-sm text-gray-600">
          Enter your email address and we'll send you a link to reset your password
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-lg text-sm">
                {error}
              </div>
            )}

            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                Email address
              </label>
              <div className="mt-1 relative">
                <input
                  id="email"
                  name="email"
                  type="email"
                  autoComplete="email"
                  required
                  value={email}
                  onChange={handleEmailChange}
                  className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                  placeholder="Enter your email"
                />
                <div className="absolute inset-y-0 right-0 flex items-center pr-3">
                  <Mail className="h-5 w-5 text-gray-400" />
                </div>
              </div>
            </div>

            <div>
              <button
                type="submit"
                disabled={loading}
                className="w-full flex justify-center py-2 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? 'Sending reset link...' : 'Send reset link'}
              </button>
            </div>
          </form>

          <div className="mt-6">
            <button
              onClick={handleBackToSignIn}
              type="button"
              className="flex items-center text-sm font-medium text-blue-600 hover:text-blue-500"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to sign in
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ForgotPasswordPage;