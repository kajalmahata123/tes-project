import React, { useState } from 'react';
import { 
  ChevronDown, 
  ChevronUp, 
  Database, 
  GitBranch, 
  Terminal, 
  AlertCircle,
  Code,
  CheckCircle2,
  GitFork
} from 'lucide-react';

interface QueryUnderstanding {
  identified_entities: string[];
  relationships: string[];
  conditions: string[];
  aggregations: string[];
}

interface TransformationStep {
  step: string;
  action: string;
  explanation: string;
  sql_component: string;
}

interface AlternativeApproach {
  sql: string;
  explanation: string;
  trade_offs: string;
}

interface ComplexityAnalysis {
  level: 'simple' | 'moderate' | 'complex';
  factors: string[];
  optimization_opportunities: string[];
}

interface QueryAnalysisProps {
  query_understanding?: QueryUnderstanding;
  transformation_steps?: TransformationStep[];
  generated_sql?: string;
  natural_explanation?: string;
  alternative_approaches?: AlternativeApproach[];
  complexity_analysis?: ComplexityAnalysis;
}

const defaultProps: QueryAnalysisProps = {
  query_understanding: {
    identified_entities: [],
    relationships: [],
    conditions: [],
    aggregations: []
  },
  transformation_steps: [],
  generated_sql: '',
  natural_explanation: '',
  alternative_approaches: [],
  complexity_analysis: {
    level: 'simple',
    factors: [],
    optimization_opportunities: []
  }
};

const QueryAnalysisDisplay: React.FC<QueryAnalysisProps> = (props) => {
  // Merge provided props with default props
  const {
    query_understanding,
    transformation_steps,
    generated_sql,
    natural_explanation,
    alternative_approaches,
    complexity_analysis
  } = { ...defaultProps, ...props };

  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    understanding: true,
    steps: true,
    sql: true,
    alternatives: false,
    complexity: false
  });

  const toggleSection = (section: string) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const getComplexityColor = (level: string) => {
    switch(level) {
      case 'simple': return 'text-green-600';
      case 'moderate': return 'text-yellow-600';
      case 'complex': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const SectionHeader = ({ title, section, icon: Icon }: { title: string; section: string; icon: React.ComponentType<{ className?: string }> }) => (
    <div 
      className="flex items-center justify-between p-4 cursor-pointer bg-white hover:bg-gray-50"
      onClick={() => toggleSection(section)}
    >
      <div className="flex items-center space-x-2">
        <Icon className="w-5 h-5 text-blue-600" />
        <h2 className="text-lg font-semibold text-gray-900">{title}</h2>
      </div>
      {expandedSections[section] ? <ChevronUp /> : <ChevronDown />}
    </div>
  );

  if (!query_understanding || !complexity_analysis) {
    return <div className="p-4 text-gray-600">No query analysis data available</div>;
  }

  return (
    <div className="max-w-4xl mx-auto space-y-4">
      {/* Query Understanding Section */}
      <div className="border rounded-lg shadow-sm bg-white">
        <SectionHeader 
          title="Query Understanding" 
          section="understanding"
          icon={Database}
        />
        {expandedSections.understanding && (
          <div className="p-4 space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <h3 className="font-medium text-gray-700 mb-2">Entities</h3>
                <ul className="list-disc list-inside space-y-1">
                  {query_understanding.identified_entities.map((entity, idx) => (
                    <li key={idx} className="text-gray-600">{entity}</li>
                  ))}
                </ul>
              </div>
              <div>
                <h3 className="font-medium text-gray-700 mb-2">Relationships</h3>
                <ul className="list-disc list-inside space-y-1">
                  {query_understanding.relationships.map((rel, idx) => (
                    <li key={idx} className="text-gray-600">{rel}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Transformation Steps */}
      <div className="border rounded-lg shadow-sm bg-white">
        <SectionHeader 
          title="Transformation Steps" 
          section="steps"
          icon={GitBranch}
        />
        {expandedSections.steps && transformation_steps && transformation_steps.length > 0 && (
          <div className="p-4">
            <div className="space-y-4">
              {transformation_steps.map((step, idx) => (
                <div key={idx} className="border-l-2 border-blue-500 pl-4">
                  <h3 className="font-medium text-gray-900">Step {step.step}: {step.action}</h3>
                  <p className="text-gray-600 mt-1">{step.explanation}</p>
                  <code className="block bg-gray-50 p-2 mt-2 rounded text-sm">
                    {step.sql_component}
                  </code>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Generated SQL */}
      <div className="border rounded-lg shadow-sm bg-white">
        <SectionHeader 
          title="Generated SQL" 
          section="sql"
          icon={Terminal}
        />
        {expandedSections.sql && generated_sql && (
          <div className="p-4">
            <code className="block bg-gray-50 p-4 rounded text-sm whitespace-pre-wrap">
              {generated_sql}
            </code>
            {natural_explanation && (
              <div className="mt-4 p-4 bg-blue-50 rounded">
                <p className="text-gray-700">{natural_explanation}</p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Alternative Approaches */}
      <div className="border rounded-lg shadow-sm bg-white">
        <SectionHeader 
          title="Alternative Approaches" 
          section="alternatives"
          icon={GitFork}
        />
        {expandedSections.alternatives && alternative_approaches && alternative_approaches.length > 0 && (
          <div className="p-4 space-y-4">
            {alternative_approaches.map((approach, idx) => (
              <div key={idx} className="border-l-2 border-gray-300 pl-4">
                <code className="block bg-gray-50 p-2 rounded text-sm">
                  {approach.sql}
                </code>
                <p className="mt-2 text-gray-700">{approach.explanation}</p>
                <p className="mt-1 text-gray-600 text-sm">{approach.trade_offs}</p>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Complexity Analysis */}
      <div className="border rounded-lg shadow-sm bg-white">
        <SectionHeader 
          title="Complexity Analysis" 
          section="complexity"
          icon={AlertCircle}
        />
        {expandedSections.complexity && (
          <div className="p-4">
            <div className="flex items-center mb-4">
              <span className="font-medium mr-2">Complexity Level:</span>
              <span className={`${getComplexityColor(complexity_analysis.level)} font-medium`}>
                {complexity_analysis.level.toUpperCase()}
              </span>
            </div>
            <div className="space-y-4">
              <div>
                <h3 className="font-medium text-gray-700 mb-2">Contributing Factors</h3>
                <ul className="list-disc list-inside space-y-1">
                  {complexity_analysis.factors.map((factor, idx) => (
                    <li key={idx} className="text-gray-600">{factor}</li>
                  ))}
                </ul>
              </div>
              <div>
                <h3 className="font-medium text-gray-700 mb-2">Optimization Opportunities</h3>
                <ul className="list-disc list-inside space-y-1">
                  {complexity_analysis.optimization_opportunities.map((opt, idx) => (
                    <li key={idx} className="text-gray-600">{opt}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default QueryAnalysisDisplay;