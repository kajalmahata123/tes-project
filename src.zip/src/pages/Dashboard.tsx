import React from 'react';
import  ChartView  from '../components/visualization/ChartView';
import  TableView  from '../components/visualization/TableView';
import  QueryEditor  from '../components/query/QueryEditor';

// Sample data for demonstration
const chartData = [
  { month: 'Jan', queries: 4000, users: 2400, databases: 8 },
  { month: 'Feb', queries: 3000, users: 1398, databases: 10 },
  { month: 'Mar', queries: 2000, users: 9800, databases: 12 },
  { month: 'Apr', queries: 2780, users: 3908, databases: 15 },
  { month: 'May', queries: 1890, users: 4800, databases: 18 },
  { month: 'Jun', queries: 2390, users: 3800, databases: 20 },
];

const recentQueries = [
  { id: 1, query: 'SELECT * FROM sales WHERE date > "2023-01-01"', timestamp: '2 mins ago', status: 'completed' },
  { id: 2, query: 'SELECT COUNT(*) FROM users GROUP BY country', timestamp: '15 mins ago', status: 'completed' },
  { id: 3, query: 'SELECT product_name, SUM(quantity) FROM orders', timestamp: '1 hour ago', status: 'failed' },
];

const Dashboard: React.FC = () => {
  return (
    <div className="space-y-6">
      {/* Overview Section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <h3 className="text-sm font-medium text-gray-500">Total Queries</h3>
          <p className="mt-2 text-3xl font-semibold text-gray-900">15,482</p>
          <div className="mt-2 text-sm text-green-600">+12.5% from last month</div>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <h3 className="text-sm font-medium text-gray-500">Active Databases</h3>
          <p className="mt-2 text-3xl font-semibold text-gray-900">24</p>
          <div className="mt-2 text-sm text-green-600">+3 new connections</div>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <h3 className="text-sm font-medium text-gray-500">Query Success Rate</h3>
          <p className="mt-2 text-3xl font-semibold text-gray-900">98.2%</p>
          <div className="mt-2 text-sm text-green-600">+0.5% from last week</div>
        </div>
      </div>

     

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <ChartView
          data={chartData}
          type="line"
          title="Query Performance"
          config={{
            xAxis: 'month',
            series: [
              { dataKey: 'queries', color: '#2563eb' }
            ],
            description: 'Number of queries executed over time'
          }}
        />
        <ChartView
          data={chartData}
          type="bar"
          title="Database Growth"
          config={{
            xAxis: 'month',
            series: [
              { dataKey: 'databases', color: '#10b981' }
            ],
            description: 'Number of connected databases over time'
          }}
        />
      </div>

      {/* Recent Queries Table */}
      <TableView
        data={recentQueries}
        columns={[
          { key: 'query', label: 'Query' },
          { key: 'timestamp', label: 'Time' },
          { 
            key: 'status', 
            label: 'Status', 
            render: (value: string | number | boolean | React.ReactElement<any, string | React.JSXElementConstructor<any>> | Iterable<React.ReactNode> | null | undefined) => (
              <span className={`px-2 py-1 rounded-full text-xs ${
                value === 'completed' 
                  ? 'bg-green-100 text-green-800' 
                  : 'bg-red-100 text-red-800'
              }`}>
                {value}
              </span>
            )
          }
        ]}
        title="Recent Queries"
        pageSize={5}
      />
    </div>
  );
};

export default Dashboard;
