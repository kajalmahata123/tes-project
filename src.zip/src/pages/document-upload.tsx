import React, { useState, useRef } from 'react';
import { Upload, X, File, FileText, AlertCircle, Check, Download, Trash2, Search } from 'lucide-react';

interface UploadedFile {
  id: string;
  name: string;
  size: number;
  type: string;
  uploadDate: Date;
  status: 'processing' | 'ready' | 'error';
  url?: string;
}

interface FileWithPreview extends File {
  preview?: string;
}

// Sample data for uploaded files
const sampleUploadedFiles: UploadedFile[] = [
  {
    id: '1',
    name: 'Project_Proposal_2024.pdf',
    size: 2.5 * 1024 * 1024, // 2.5MB
    type: 'application/pdf',
    uploadDate: new Date('2024-03-15'),
    status: 'ready',
    url: '#'
  },
  {
    id: '2',
    name: 'Financial_Report_Q1.docx',
    size: 1.8 * 1024 * 1024, // 1.8MB
    type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    uploadDate: new Date('2024-03-14'),
    status: 'ready',
    url: '#'
  },
  {
    id: '3',
    name: 'Meeting_Minutes_March.pdf',
    size: 890 * 1024, // 890KB
    type: 'application/pdf',
    uploadDate: new Date('2024-03-13'),
    status: 'ready',
    url: '#'
  },
  {
    id: '4',
    name: 'Product_Specifications.docx',
    size: 3.2 * 1024 * 1024, // 3.2MB
    type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    uploadDate: new Date('2024-03-12'),
    status: 'ready',
    url: '#'
  },
  {
    id: '5',
    name: 'Client_Presentation.pdf',
    size: 5.7 * 1024 * 1024, // 5.7MB
    type: 'application/pdf',
    uploadDate: new Date('2024-03-11'),
    status: 'error',
    url: '#'
  },
  {
    id: '6',
    name: 'Budget_2024.docx',
    size: 1.1 * 1024 * 1024, // 1.1MB
    type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    uploadDate: new Date('2024-03-10'),
    status: 'processing',
    url: '#'
  }
];


const DocumentUpload = () => {
  const [files, setFiles] = useState<FileWithPreview[]>([]);
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>(sampleUploadedFiles);
  const [isDragging, setIsDragging] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const allowedTypes = [
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
  ];

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const validateFile = (file: File) => {
    if (!allowedTypes.includes(file.type)) {
      setError('Please upload only PDF or Word documents');
      return false;
    }
    if (file.size > 10 * 1024 * 1024) {
      setError('File size should be less than 10MB');
      return false;
    }
    return true;
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    setError(null);

    const droppedFiles = Array.from(e.dataTransfer.files);
    const validFiles = droppedFiles.filter(validateFile);
    if (validFiles.length > 0) {
      setFiles(prev => [...prev, ...validFiles]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    setError(null);
    const selectedFiles = e.target.files;
    if (selectedFiles) {
      const filesArray = Array.from(selectedFiles);
      const validFiles = filesArray.filter(validateFile);
      if (validFiles.length > 0) {
        setFiles(prev => [...prev, ...validFiles]);
      }
    }
  };

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleUpload = async () => {
    if (files.length === 0) return;

    setUploading(true);
    
    // Simulate file upload process
    const newUploadedFiles: UploadedFile[] = files.map(file => ({
      id: Math.random().toString(36).substr(2, 9),
      name: file.name,
      size: file.size,
      type: file.type,
      uploadDate: new Date(),
      status: 'processing',
      url: '#' // In real implementation, this would be the server URL
    }));

    setUploadedFiles(prev => [...prev, ...newUploadedFiles]);

    // Simulate processing delay
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Update status to ready
    setUploadedFiles(prev => 
      prev.map(file => 
        newUploadedFiles.find(f => f.id === file.id)
          ? { ...file, status: 'ready' }
          : file
      )
    );

    setUploading(false);
    setFiles([]);
    setError(null);
  };

  const handleDeleteUploadedFile = (id: string) => {
    setUploadedFiles(prev => prev.filter(file => file.id !== id));
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getFileIcon = (fileType: string) => {
    if (fileType.includes('pdf')) {
      return <File className="h-8 w-8 text-red-500" />;
    }
    return <FileText className="h-8 w-8 text-blue-500" />;
  };

  const filteredUploadedFiles = uploadedFiles.filter(file =>
    file.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-4 max-w-4xl mx-auto space-y-6">
      

      {/* Uploaded Files Section */}
      {uploadedFiles.length > 0 && (
          <div className="p-4 max-w-4xl mx-auto space-y-6">
          {/* Upload Area */}
          <div 
            className={`p-8 bg-white rounded-lg shadow-md border-2 border-dashed relative ${
              isDragging ? 'border-blue-500 bg-blue-50' : 'border-gray-300'
            }`}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
          >
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileInput}
              accept=".pdf,.doc,.docx"
              className="hidden"
              multiple
            />
            
            <div className="text-center">
              <Upload className="h-12 w-12 mx-auto text-gray-400" aria-hidden="true" />
              <h3 className="mt-2 text-lg font-medium">Drag & Drop Documents</h3>
              <p className="mt-1 text-sm text-gray-500">
                Or click to browse for PDF and Word documents
              </p>
              <button
                onClick={() => fileInputRef.current?.click()}
                className="mt-4 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
                type="button"
              >
                Select Files
              </button>
            </div>
          </div>
    
          {/* Error Message */}
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center space-x-2 text-red-600">
              <AlertCircle className="h-5 w-5 flex-shrink-0" aria-hidden="true" />
              <p>{error}</p>
            </div>
          )}
    
          {/* Uploaded Files Section */}
          <div className="bg-white rounded-lg shadow-md p-4">
            <div className="flex justify-between items-center mb-4">
              <div>
                <h3 className="text-lg font-medium">Uploaded Documents</h3>
                <p className="text-sm text-gray-500 mt-1">
                  {uploadedFiles.length} documents
                </p>
              </div>
              <div className="relative">
                <Search className="h-5 w-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2" aria-hidden="true" />
                <input
                  type="text"
                  placeholder="Search files..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
            
            <div className="space-y-3">
              {uploadedFiles
                .filter(file => file.name.toLowerCase().includes(searchTerm.toLowerCase()))
                .map((file) => (
                  <div
                    key={file.id}
                    className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                  >
                    <div className="flex items-center space-x-3 flex-1">
                      {file.type.includes('pdf') ? (
                        <File className="h-8 w-8 text-red-500" aria-hidden="true" />
                      ) : (
                        <FileText className="h-8 w-8 text-blue-500" aria-hidden="true" />
                      )}
                      <div className="min-w-0 flex-1">
                        <p className="font-medium truncate">{file.name}</p>
                        <div className="flex items-center text-sm text-gray-500 space-x-2">
                          <span>{(file.size / (1024 * 1024)).toFixed(2)} MB</span>
                          <span>•</span>
                          <span>{file.uploadDate.toLocaleDateString()}</span>
                          <span>•</span>
                          <span className={`
                            ${file.status === 'ready' ? 'text-green-500' : ''}
                            ${file.status === 'processing' ? 'text-blue-500' : ''}
                            ${file.status === 'error' ? 'text-red-500' : ''}
                          `}>
                            {file.status.charAt(0).toUpperCase() + file.status.slice(1)}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      {file.status === 'processing' ? (
                        <div className="w-5 h-5 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
                      ) : file.status === 'ready' ? (
                        <button
                          className="p-2 hover:bg-gray-200 rounded-full transition-colors text-blue-500"
                          aria-label="Download file"
                        >
                          <Download className="h-5 w-5" aria-hidden="true" />
                        </button>
                      ) : (
                        <div className="p-2 text-red-500" aria-label="Error processing file">
                          <AlertCircle className="h-5 w-5" aria-hidden="true" />
                        </div>
                      )}
                      <button
                        onClick={() => setUploadedFiles(prev => prev.filter(f => f.id !== file.id))}
                        className="p-2 hover:bg-gray-200 rounded-full transition-colors text-gray-500"
                        aria-label="Delete file"
                      >
                        <Trash2 className="h-5 w-5" aria-hidden="true" />
                      </button>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DocumentUpload;
