import React, { useState } from 'react';
import { 
  ChevronDown, 
  ChevronRight, 
  Download, 
  Info,
  Clock,
  Database
} from 'lucide-react';

interface UseCase {
  title: string;
  description: string;
  implementation: string;
}

interface TroubleshootingItem {
  problem: string;
  solution: string;
}

interface InstallationStep {
  step: string;
  description: string;
  commands: string;
}

interface Documentation {
  technical: {
    content: {
      overview: string;
      relationships: string;
      constraints: string;
      performance: string;
      security: string;
    };
    metadata: {
      version: string;
      last_updated: string;
      schema_hash: string;
    };
  };
  developer: {
    content: {
      getting_started: string;
      best_practices: string;
      use_cases: UseCase[];
      integration: string;
      troubleshooting: TroubleshootingItem[];
    };
    metadata: {
      context: string;
      last_updated: string;
    };
  };
  admin: {
    content: {
      requirements: {
        hardware: string;
        software: string;
      };
      installation: InstallationStep[];
      configuration: string;
      maintenance: string;
      backup_recovery: string;
      security: string;
    };
    metadata: {
      version: string;
      last_updated: string;
    };
  };
}

const DatabaseDocumentation = () => {
  const [activeTab, setActiveTab] = useState<'technical' | 'developer' | 'admin'>('technical');
  const [expandedSections, setExpandedSections] = useState<string[]>([]);

  // Sample data - replace with actual documentation data
  const documentation: Documentation = {
    technical: {
      content: {
        overview: "This schema represents a modern e-commerce platform...",
        relationships: "Core relationships include Product-Order, Customer-Order...",
        constraints: "Foreign key constraints ensure data integrity...",
        performance: "Indexes are optimized for common query patterns...",
        security: "Row-level security policies are implemented..."
      },
      metadata: {
        version: "1.0.0",
        last_updated: "2024-02-02T12:00:00Z",
        schema_hash: "abc123..."
      }
    },
    developer: {
      content: {
        getting_started: "To begin working with the database...",
        best_practices: "Follow these guidelines for optimal performance...",
        use_cases: [
          {
            title: "Order Processing",
            description: "Handling customer orders",
            implementation: "Use the following queries..."
          }
        ],
        integration: "Integration steps with existing systems...",
        troubleshooting: [
          {
            problem: "Slow query performance",
            solution: "Optimize indexes and check query plans"
          }
        ]
      },
      metadata: {
        context: "E-commerce platform",
        last_updated: "2024-02-02T12:00:00Z"
      }
    },
    admin: {
      content: {
        requirements: {
          hardware: "Minimum 8GB RAM, 4 CPU cores...",
          software: "PostgreSQL 14+, Python 3.8+..."
        },
        installation: [
          {
            step: "1",
            description: "Install PostgreSQL",
            commands: "sudo apt install postgresql"
          }
        ],
        configuration: "Configure the following parameters...",
        maintenance: "Regular maintenance tasks include...",
        backup_recovery: "Backup strategy and recovery procedures...",
        security: "Security best practices and configurations..."
      },
      metadata: {
        version: "1.0.0",
        last_updated: "2024-02-02T12:00:00Z"
      }
    }
  };

  const toggleSection = (section: string) => {
    setExpandedSections(prev =>
      prev.includes(section)
        ? prev.filter(s => s !== section)
        : [...prev, section]
    );
  };

  const renderSection = (title: string, content: string | React.ReactNode) => (
    <div className="border rounded-lg mb-4">
      <button
        onClick={() => toggleSection(title)}
        className="w-full p-4 flex items-center justify-between text-left hover:bg-gray-50 rounded-lg"
      >
        <span className="font-medium">{title}</span>
        {expandedSections.includes(title) ? (
          <ChevronDown size={20} className="text-gray-400" />
        ) : (
          <ChevronRight size={20} className="text-gray-400" />
        )}
      </button>
      {expandedSections.includes(title) && (
        <div className="p-4 border-t">
          {content}
        </div>
      )}
    </div>
  );

  const renderTechnicalDoc = () => (
    <div>
      {renderSection("Overview", 
        <p className="text-gray-700">{documentation.technical.content.overview}</p>
      )}
      {renderSection("Relationships", 
        <p className="text-gray-700">{documentation.technical.content.relationships}</p>
      )}
      {renderSection("Constraints", 
        <p className="text-gray-700">{documentation.technical.content.constraints}</p>
      )}
      {renderSection("Performance", 
        <p className="text-gray-700">{documentation.technical.content.performance}</p>
      )}
      {renderSection("Security", 
        <p className="text-gray-700">{documentation.technical.content.security}</p>
      )}
    </div>
  );

  const renderDeveloperDoc = () => (
    <div>
      {renderSection("Getting Started", 
        <p className="text-gray-700">{documentation.developer.content.getting_started}</p>
      )}
      {renderSection("Best Practices", 
        <p className="text-gray-700">{documentation.developer.content.best_practices}</p>
      )}
      {renderSection("Use Cases", 
        <div className="space-y-4">
          {documentation.developer.content.use_cases.map((useCase, index) => (
            <div key={index} className="border-b last:border-0 pb-4">
              <h4 className="font-medium mb-2">{useCase.title}</h4>
              <p className="text-gray-700 mb-2">{useCase.description}</p>
              <pre className="bg-gray-50 p-4 rounded-lg overflow-x-auto">
                {useCase.implementation}
              </pre>
            </div>
          ))}
        </div>
      )}
      {renderSection("Integration", 
        <p className="text-gray-700">{documentation.developer.content.integration}</p>
      )}
      {renderSection("Troubleshooting", 
        <div className="space-y-4">
          {documentation.developer.content.troubleshooting.map((item, index) => (
            <div key={index} className="border-b last:border-0 pb-4">
              <h4 className="font-medium mb-2">{item.problem}</h4>
              <p className="text-gray-700">{item.solution}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );

  const renderAdminDoc = () => (
    <div>
      {renderSection("Requirements", 
        <div className="space-y-4">
          <div>
            <h4 className="font-medium mb-2">Hardware Requirements</h4>
            <p className="text-gray-700">{documentation.admin.content.requirements.hardware}</p>
          </div>
          <div>
            <h4 className="font-medium mb-2">Software Requirements</h4>
            <p className="text-gray-700">{documentation.admin.content.requirements.software}</p>
          </div>
        </div>
      )}
      {renderSection("Installation", 
        <div className="space-y-4">
          {documentation.admin.content.installation.map((step, index) => (
            <div key={index} className="border-b last:border-0 pb-4">
              <h4 className="font-medium mb-2">Step {step.step}</h4>
              <p className="text-gray-700 mb-2">{step.description}</p>
              <pre className="bg-gray-50 p-4 rounded-lg overflow-x-auto">
                {step.commands}
              </pre>
            </div>
          ))}
        </div>
      )}
      {renderSection("Configuration", 
        <p className="text-gray-700">{documentation.admin.content.configuration}</p>
      )}
      {renderSection("Maintenance", 
        <p className="text-gray-700">{documentation.admin.content.maintenance}</p>
      )}
      {renderSection("Backup & Recovery", 
        <p className="text-gray-700">{documentation.admin.content.backup_recovery}</p>
      )}
      {renderSection("Security", 
        <p className="text-gray-700">{documentation.admin.content.security}</p>
      )}
    </div>
  );

  return (
    <div className="p-6">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">Database Documentation</h1>
          <button className="flex items-center gap-2 px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg">
            <Download size={20} />
            Export Documentation
          </button>
        </div>
        <div className="flex items-center gap-4 text-sm text-gray-500 mt-2">
          <div className="flex items-center gap-1">
            <Database size={16} />
            <span>Version: {documentation.technical.metadata.version}</span>
          </div>
          <div className="flex items-center gap-1">
            <Clock size={16} />
            <span>Updated: {new Date(documentation.technical.metadata.last_updated).toLocaleDateString()}</span>
          </div>
        </div>
      </div>

      <div className="border-b mb-6">
        <div className="flex gap-4">
          {(['technical', 'developer', 'admin'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 -mb-px text-sm font-medium ${
                activeTab === tab
                  ? 'text-blue-600 border-b-2 border-blue-600'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {activeTab === 'technical' && renderTechnicalDoc()}
      {activeTab === 'developer' && renderDeveloperDoc()}
      {activeTab === 'admin' && renderAdminDoc()}
    </div>
  );
};

export default DatabaseDocumentation;