import React, { useState } from 'react';
import { 
  BarChart2, 
  LineChart as LineChartIcon, 
  PieChart as PieChartIcon, 
  ScatterChart, 
  Table 
} from 'lucide-react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend,
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { Card } from '../components/common/Card';

interface ChartData {
  name: string;
  value: number;
  category?: string;
}

const CHART_TYPES = {
  LINE: 'line',
  BAR: 'bar',
  PIE: 'pie',
  TABLE: 'table'
} as const;

type ChartType = typeof CHART_TYPES[keyof typeof CHART_TYPES];

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

const Visualizations: React.FC = () => {
  const [selectedChart, setSelectedChart] = useState<ChartType>(CHART_TYPES.LINE);
  const [showPreview, setShowPreview] = useState(false);

  // Sample data - replace with your actual data
  const sampleData: ChartData[] = [
    { name: 'Jan', value: 4000, category: 'Sales' },
    { name: 'Feb', value: 3000, category: 'Sales' },
    { name: 'Mar', value: 5000, category: 'Sales' },
    { name: 'Apr', value: 2780, category: 'Sales' },
    { name: 'May', value: 1890, category: 'Sales' },
    { name: 'Jun', value: 2390, category: 'Sales' },
  ];

  const pieData = [
    { name: 'Category A', value: 400 },
    { name: 'Category B', value: 300 },
    { name: 'Category C', value: 300 },
    { name: 'Category D', value: 200 },
  ];

  const renderChartPreview = () => {
    switch (selectedChart) {
      case CHART_TYPES.LINE:
        return (
          <ResponsiveContainer width="100%" height={400}>
            <LineChart data={sampleData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="value" stroke="#8884d8" activeDot={{ r: 8 }} />
            </LineChart>
          </ResponsiveContainer>
        );

      case CHART_TYPES.BAR:
        return (
          <ResponsiveContainer width="100%" height={400}>
            <BarChart data={sampleData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="value" fill="#8884d8" />
            </BarChart>
          </ResponsiveContainer>
        );

      case CHART_TYPES.PIE:
        return (
          <ResponsiveContainer width="100%" height={400}>
            <PieChart>
              <Pie
                data={pieData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                outerRadius={150}
                fill="#8884d8"
                dataKey="value"
              >
                {pieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        );

      case CHART_TYPES.TABLE:
        return (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Period
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Value
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Category
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {sampleData.map((row, index) => (
                  <tr key={index}>
                    <td className="px-6 py-4 whitespace-nowrap">{row.name}</td>
                    <td className="px-6 py-4 whitespace-nowrap">{row.value}</td>
                    <td className="px-6 py-4 whitespace-nowrap">{row.category}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Chart Type Selection */}
      <Card className="p-6">
        <h2 className="text-xl font-semibold mb-6">Data Visualizations</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Select Visualization Type</h3>
            <div className="grid grid-cols-2 gap-4">
              <button
                onClick={() => setSelectedChart(CHART_TYPES.LINE)}
                className={`p-4 border rounded-lg flex flex-col items-center gap-2 ${
                  selectedChart === CHART_TYPES.LINE ? 'border-blue-500 bg-blue-50' : 'hover:bg-gray-50'
                }`}
              >
                <LineChartIcon size={24} />
                <span>Line Chart</span>
              </button>

              <button
                onClick={() => setSelectedChart(CHART_TYPES.BAR)}
                className={`p-4 border rounded-lg flex flex-col items-center gap-2 ${
                  selectedChart === CHART_TYPES.BAR ? 'border-blue-500 bg-blue-50' : 'hover:bg-gray-50'
                }`}
              >
                <BarChart2 size={24} />
                <span>Bar Chart</span>
              </button>

              <button
                onClick={() => setSelectedChart(CHART_TYPES.PIE)}
                className={`p-4 border rounded-lg flex flex-col items-center gap-2 ${
                  selectedChart === CHART_TYPES.PIE ? 'border-blue-500 bg-blue-50' : 'hover:bg-gray-50'
                }`}
              >
                <PieChartIcon size={24} />
                <span>Pie Chart</span>
              </button>

              <button
                onClick={() => setSelectedChart(CHART_TYPES.TABLE)}
                className={`p-4 border rounded-lg flex flex-col items-center gap-2 ${
                  selectedChart === CHART_TYPES.TABLE ? 'border-blue-500 bg-blue-50' : 'hover:bg-gray-50'
                }`}
              >
                <Table size={24} />
                <span>Table View</span>
              </button>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-medium">Data Configuration</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Data Source</label>
                <select className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md">
                  <option>Sample Dataset</option>
                  <option>Database Query</option>
                  <option>CSV Upload</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Chart Title</label>
                <input
                  type="text"
                  className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                  placeholder="Enter chart title"
                />
              </div>

              <button
                onClick={() => setShowPreview(true)}
                className="w-full px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                Generate Preview
              </button>
            </div>
          </div>
        </div>
      </Card>

      {/* Chart Preview */}
      {showPreview && (
        <Card className="p-6">
          <h3 className="text-lg font-medium mb-4">Chart Preview</h3>
          {renderChartPreview()}
        </Card>
      )}

      {/* Saved Visualizations */}
      <Card className="p-6">
        <h3 className="text-lg font-medium mb-4">Saved Visualizations</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[1, 2, 3].map((item) => (
            <div key={item} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
              <div className="h-32 bg-gray-100 rounded-md mb-3"></div>
              <h4 className="font-medium">Visualization {item}</h4>
              <p className="text-sm text-gray-500">Created on Nov 10, 2024</p>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};

export default Visualizations;