import React, { useState } from 'react';
import { ChevronDown, ChevronRight, Download, Search, Database, Info } from 'lucide-react';

interface TableAnalysis {
  tableName: string;
  columns: Array<{
    name: string;
    type: string;
    description: string;
    constraints: string[];
  }>;
  relationships: Array<{
    relatedTable: string;
    type: string;
    through: string;
  }>;
  purpose: string;
  recommendations: string[];
}

interface SchemaAnalysisResult {
  schemaName: string;
  schemaAnalysis: string;
  tableAnalyses: TableAnalysis[];
}

const SchemaAnalysisPage = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedTables, setExpandedTables] = useState<string[]>([]);

  const toggleTable = (tableName: string) => {
    setExpandedTables(prev => 
      prev.includes(tableName)
        ? prev.filter(t => t !== tableName)
        : [...prev, tableName]
    );
  };

  // Sample data - replace with actual data from your backend
  const analysisResult: SchemaAnalysisResult = {
    schemaName: "ecommerce_db",
    schemaAnalysis: "This is an e-commerce database schema focused on managing product inventory, customer orders, and user accounts. The schema follows a normalized structure with clear relationships between entities. Key features include inventory tracking, order processing, and customer management.",
    tableAnalyses: [
      {
        tableName: "products",
        columns: [
          { name: "id", type: "uuid", description: "Primary key", constraints: ["PRIMARY KEY"] },
          { name: "name", type: "varchar(255)", description: "Product name", constraints: ["NOT NULL"] },
          { name: "price", type: "decimal", description: "Product price", constraints: ["NOT NULL"] }
        ],
        relationships: [
          { relatedTable: "order_items", type: "one-to-many", through: "product_id" }
        ],
        purpose: "Stores product information including names, prices, and inventory levels",
        recommendations: [
          "Consider adding a product category relationship",
          "Add inventory tracking fields"
        ]
      }
    ]
  };

  const filteredTables = analysisResult.tableAnalyses.filter(table =>
    table.tableName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-2xl font-bold mb-2">Schema Analysis</h1>
        <div className="flex items-center gap-2 text-gray-600 mb-4">
          <Database size={20} />
          <span>{analysisResult.schemaName}</span>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
        <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <Info size={20} className="text-blue-600" />
          Overall Analysis
        </h2>
        <p className="text-gray-700 leading-relaxed">
          {analysisResult.schemaAnalysis}
        </p>
      </div>

      <div className="mb-6 flex justify-between items-center">
        <div className="relative w-96">
          <Search size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Search tables..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
        <button className="flex items-center gap-2 px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg">
          <Download size={20} />
          Export Analysis
        </button>
      </div>

      <div className="space-y-4">
        {filteredTables.map((table) => (
          <div key={table.tableName} className="bg-white rounded-lg shadow-sm">
            <button
              onClick={() => toggleTable(table.tableName)}
              className="w-full p-4 flex items-center justify-between text-left hover:bg-gray-50"
            >
              <div className="flex items-center gap-3">
                <Database size={20} className="text-gray-500" />
                <span className="font-medium">{table.tableName}</span>
                <span className="text-sm text-gray-500">
                  ({table.columns.length} columns)
                </span>
              </div>
              {expandedTables.includes(table.tableName) ? (
                <ChevronDown size={20} className="text-gray-400" />
              ) : (
                <ChevronRight size={20} className="text-gray-400" />
              )}
            </button>

            {expandedTables.includes(table.tableName) && (
              <div className="p-4 border-t">
                <div className="mb-6">
                  <h3 className="text-sm font-medium text-gray-500 mb-2">Purpose</h3>
                  <p className="text-gray-700">{table.purpose}</p>
                </div>

                <div className="mb-6">
                  <h3 className="text-sm font-medium text-gray-500 mb-2">Columns</h3>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left pb-2 pr-4 font-medium">Name</th>
                          <th className="text-left pb-2 pr-4 font-medium">Type</th>
                          <th className="text-left pb-2 pr-4 font-medium">Description</th>
                          <th className="text-left pb-2 font-medium">Constraints</th>
                        </tr>
                      </thead>
                      <tbody>
                        {table.columns.map((column, index) => (
                          <tr key={index} className="border-b last:border-0">
                            <td className="py-2 pr-4 font-mono text-sm">{column.name}</td>
                            <td className="py-2 pr-4 text-gray-600">{column.type}</td>
                            <td className="py-2 pr-4">{column.description}</td>
                            <td className="py-2">
                              <div className="flex flex-wrap gap-2">
                                {column.constraints.map((constraint, i) => (
                                  <span
                                    key={i}
                                    className="px-2 py-1 text-xs rounded-full bg-blue-50 text-blue-700"
                                  >
                                    {constraint}
                                  </span>
                                ))}
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {table.relationships.length > 0 && (
                  <div className="mb-6">
                    <h3 className="text-sm font-medium text-gray-500 mb-2">Relationships</h3>
                    <div className="space-y-2">
                      {table.relationships.map((rel, index) => (
                        <div key={index} className="flex items-center gap-2 text-sm">
                          <span className="text-gray-600">{rel.type}</span>
                          <span>relationship with</span>
                          <span className="font-medium">{rel.relatedTable}</span>
                          <span className="text-gray-600">through</span>
                          <code className="px-2 py-1 bg-gray-100 rounded">{rel.through}</code>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {table.recommendations.length > 0 && (
                  <div>
                    <h3 className="text-sm font-medium text-gray-500 mb-2">Recommendations</h3>
                    <ul className="list-disc list-inside space-y-1 text-gray-700">
                      {table.recommendations.map((rec, index) => (
                        <li key={index}>{rec}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default SchemaAnalysisPage;