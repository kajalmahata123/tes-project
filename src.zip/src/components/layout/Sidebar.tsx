import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { authFetch } from '../../utils/api';
import {
  Menu,
  Home,
  Edit,
  Database,
  BarChart2,
  LogOut,
  ChevronDown,
  ChevronRight,
  Star,
  CircleDot
} from 'lucide-react';

interface HealthMetrics {
  id: number;
  connection_id: number;
  status: 'healthy' | 'warning' | 'critical';
  uptime: string;
  latency: number;
  connections: number;
  last_error: string | null;
  last_checked_at: string;
  consecutive_failures: number;
  metrics: Record<string, any>;
}

interface DataSource {
  id: number;
  name: string;
  description: string;
  vendor: string;
  connection_type: string;
  is_active: boolean;
  last_connected_at: string | null;
  health_metrics: HealthMetrics[];
  isDefault?: boolean;
  isSelected?: boolean;
}

interface SidebarProps {
  isOpen: boolean;
  onToggle: () => void;
  activeItem: string;
  onMenuClick: (menuId: string) => void;
}

interface NavItemProps {
  icon: React.ReactNode;
  label: string;
  active?: boolean;
  expanded: boolean;
  onClick?: () => void;
}

const NavItem: React.FC<NavItemProps> = ({
  icon,
  label,
  active = false,
  expanded,
  onClick
}) => (
  <li>
    <button
      onClick={onClick}
      className={`flex items-center w-full p-2 rounded-lg transition-colors ${
        active ? 'bg-blue-50 text-blue-600' : 'text-gray-700 hover:bg-gray-100'
      }`}
    >
      {icon}
      {expanded && <span className="ml-3">{label}</span>}
    </button>
  </li>
);

const menuItems = [
  { id: 'dashboard', label: 'Dashboard', icon: <Home size={20} /> },
  { id: 'databases', label: 'Databases', icon: <Database size={20} /> },
  { id: 'queryeditor', label: 'SQL Assistant', icon: <Edit size={20} /> },
  { id: 'visualizations', label: 'Visualizations', icon: <BarChart2 size={20} /> }
];

const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  onToggle,
  activeItem,
  onMenuClick
}) => {
  const navigate = useNavigate();
  const { logout } = useAuth();
  const [showDatasources, setShowDatasources] = useState(false);
  const [datasources, setDatasources] = useState<DataSource[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchDatasources = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const response = await authFetch<DataSource[]>('/datasources/list?active_only=true');
      
      if (Array.isArray(response)) {
        // Transform response to include isDefault and isSelected
        const transformedDatasources = response.map((ds, index) => ({
          ...ds,
          isDefault: index === 0, // Set first one as default initially
          isSelected: false
        }));
        setDatasources(transformedDatasources);
      } else if (response.error) {
        throw new Error(response.error);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch datasources');
      console.error('Error fetching datasources:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchDatasources();
  }, []);

  const handleLogout = async () => {
    try {
      await logout();
      navigate('/login');
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  const handleSelectDatasource = (datasourceId: number) => {
    setDatasources(prevDatasources =>
      prevDatasources.map(ds => ({
        ...ds,
        isSelected: ds.id === datasourceId
      }))
    );
  };

  const handleSetDefault = (datasourceId: number, event: React.MouseEvent) => {
    event.stopPropagation();
    setDatasources(prevDatasources =>
      prevDatasources.map(ds => ({
        ...ds,
        isDefault: ds.id === datasourceId
      }))
    );
  };

  const defaultDatasource = datasources.find(ds => ds.isDefault);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'healthy':
        return 'text-green-500';
      case 'warning':
        return 'text-yellow-500';
      case 'critical':
        return 'text-red-500';
      default:
        return 'text-gray-500';
    }
  };

  return (
    <div className={`${isOpen ? 'w-64' : 'w-20'} bg-white shadow-lg transition-all duration-300 h-full flex flex-col`}>
      <div className="flex items-center justify-between p-4 border-b">
        {isOpen ? (
          <h1 className="text-xl font-bold text-blue-600">QueryMate</h1>
        ) : (
          <span className="text-xl font-bold text-blue-600">Q</span>
        )}
        <button
          onClick={onToggle}
          className="p-2 rounded-lg hover:bg-gray-100"
          aria-label="Toggle sidebar"
        >
          <Menu size={20} />
        </button>
      </div>

      <nav className="flex-1 p-4 overflow-y-auto">
        <ul className="space-y-2">
          {menuItems.map((item) => (
            <NavItem
              key={item.id}
              icon={item.icon}
              label={item.label}
              active={activeItem === item.id}
              expanded={isOpen}
              onClick={() => onMenuClick(item.id)}
            />
          ))}
        </ul>

        {isOpen && (
          <div className="mt-6">
            <button
              onClick={() => setShowDatasources(!showDatasources)}
              className="flex items-center w-full p-2 text-gray-700 hover:bg-gray-100 rounded-lg"
            >
              <Database size={20} />
              <span className="ml-3 flex-1 text-left">
                {defaultDatasource?.name || 'No datasource'} 
                {defaultDatasource && <span className="text-xs text-gray-500 ml-1">(Default)</span>}
              </span>
              {showDatasources ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
            </button>
            
            {showDatasources && (
              <div className="mt-2 ml-2">
                {isLoading ? (
                  <div className="text-sm text-gray-500 p-2">Loading datasources...</div>
                ) : error ? (
                  <div className="text-sm text-red-500 p-2">{error}</div>
                ) : (
                  <ul className="space-y-1">
                    {datasources.map((ds) => (
                      <li key={ds.id}>
                        <button
                          onClick={() => handleSelectDatasource(ds.id)}
                          className={`flex items-center w-full p-2 rounded-lg text-sm group transition-colors ${
                            ds.isSelected ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-100'
                          }`}
                        >
                          <span className="w-6">
                            {ds.isSelected ? (
                              <CircleDot size={16} className="text-blue-600" />
                            ) : (
                              <div className={`w-2 h-2 rounded-full ${getStatusColor(ds.health_metrics[0]?.status || 'warning')}`} />
                            )}
                          </span>
                          <span className="flex-1">
                            {ds.name}
                            {ds.isDefault && (
                              <span className="text-xs text-gray-500 ml-1">(Default)</span>
                            )}
                          </span>
                          {ds.isSelected && !ds.isDefault && (
                            <button
                              onClick={(e) => handleSetDefault(ds.id, e)}
                              className="ml-2 p-1 rounded-lg text-gray-400 hover:text-yellow-500"
                              title="Set as default"
                            >
                              <Star size={16} />
                            </button>
                          )}
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            )}
          </div>
        )}
      </nav>

      <div className="p-4 border-t">
        <button
          onClick={handleLogout}
          className="flex items-center w-full p-2 rounded-lg hover:bg-gray-100 text-gray-700 transition-colors"
        >
          <LogOut size={20} className="text-gray-500" />
          {isOpen && <span className="ml-3">Logout</span>}
        </button>
      </div>
    </div>
  );
};

export default Sidebar;