import React, { ReactNode, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import Sidebar from './Sidebar';
import Dashboard from '../../pages/Dashboard';
import Databases from '../../pages/Databases';
import Visualizations from '../../pages/Visualizations';
import QueryEditor from '../query/QueryEditor';
import ChatInterface from '../../pages/enhanced-chat';
import DocumentUpload from '../../pages/document-upload';

interface LayoutProps {
  children: ReactNode;
}

const Layout: React.FC<LayoutProps> = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [activeItem, setActiveItem] = useState('dashboard');
  const navigate = useNavigate();
  const { user, logout } = useAuth();

  const handleMenuClick = (menuId: string) => {
    setActiveItem(menuId);
  };

  const handleSidebarToggle = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  const handleLogout = async () => {
    try {
      await logout();
      navigate('/login');
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  const renderContent = () => {
    switch (activeItem) {
      case 'dashboard':
        return <Dashboard />;
      case 'databases':
        return <Databases />;
      case 'queryeditor':
        return <QueryEditor />;
      case 'visualizations':
        return <Visualizations />;
      case 'docchat':
        return <ChatInterface />
      case 'docrepository':
        return <DocumentUpload />;
      case 'settings':
        return <div>Settings Page</div>;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <Sidebar 
        isOpen={isSidebarOpen}
        onToggle={handleSidebarToggle}
        activeItem={activeItem}
        onMenuClick={handleMenuClick}
      />

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        <header className="bg-white shadow-sm">
          <div className="px-6 py-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold text-gray-800">
                {activeItem.charAt(0).toUpperCase() + activeItem.slice(1)}
              </h2>
              
              {/* User Profile and Logout */}
              <div className="flex items-center space-x-4">
                <span className="text-sm text-gray-700">
                  Welcome, {user?.name || 'User'}
                </span>
                <button
                  onClick={handleLogout}
                  className="px-3 py-1.5 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors"
                >
                  Logout
                </button>
              </div>
            </div>
          </div>
        </header>
        
        <main className="p-6">
          {renderContent()}
        </main>
      </div>
    </div>
  );
};

export default Layout;