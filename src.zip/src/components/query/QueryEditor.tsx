import React, { useState } from 'react';
import { Send, Sparkles, History, BarChart2, LineChart, Table, ChevronRight, Copy, Check, Clock, Database, Zap } from 'lucide-react';
import { LineChart as RechartsLineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart, Bar } from 'recharts';

interface DataPoint {
  month: string;
  sales: number;
  revenue: number;
}

interface QueryMetadata {
  estimatedTime: string;
  rowsScanned: string;
  tablesAccessed: string[];
  cacheStatus: string;
}

interface QuerySummary {
  totalRecords: number;
  timeRange: string;
  avgSales: number;
  avgRevenue: number;
}

interface QueryResult {
  naturalLanguageQuery: string;
  generatedSQL: string;
  queryMetadata: QueryMetadata;
  data: DataPoint[];
  summary: QuerySummary;
}

type AnalysisType = 'summary' | 'visualization' | null;
type VisualizationType = 'line' | 'bar';

const QueryEditor = () => {
  const [query, setQuery] = useState('');
  const [queryResult, setQueryResult] = useState<QueryResult | null>(null);
  const [showAnalysisOptions, setShowAnalysisOptions] = useState(false);
  const [analysisType, setAnalysisType] = useState<AnalysisType>(null);
  const [visualizationType, setVisualizationType] = useState<VisualizationType>('line');
  const [copied, setCopied] = useState(false);

  const suggestions = [
    'Show me all sales from last month',
    'What are the top performing products?',
    'Compare revenue across regions'
  ];

  const sampleData: DataPoint[] = [
    { month: 'Jan', sales: 4000, revenue: 2400 },
    { month: 'Feb', sales: 3000, revenue: 1398 },
    { month: 'Mar', sales: 2000, revenue: 9800 },
    { month: 'Apr', sales: 2780, revenue: 3908 },
    { month: 'May', sales: 1890, revenue: 4800 },
  ];

  const handleQuerySubmit = () => {
    const newQueryResult: QueryResult = {
      naturalLanguageQuery: query,
      generatedSQL: `SELECT 
  DATE_TRUNC('month', date) as month,
  SUM(sales) as sales,
  SUM(revenue) as revenue
FROM transactions
WHERE date >= '2024-01-01' AND date <= '2024-05-31'
GROUP BY DATE_TRUNC('month', date)
ORDER BY month ASC`,
      queryMetadata: {
        estimatedTime: '1.2s',
        rowsScanned: '125,000',
        tablesAccessed: ['transactions', 'products'],
        cacheStatus: 'miss'
      },
      data: sampleData,
      summary: {
        totalRecords: 5,
        timeRange: 'Jan 2024 - May 2024',
        avgSales: 2734,
        avgRevenue: 4461
      }
    };
    
    setQueryResult(newQueryResult);
    setShowAnalysisOptions(true);
    setAnalysisType('summary');
  };

  const handleCopyQuery = () => {
    if (queryResult) {
      navigator.clipboard.writeText(queryResult.generatedSQL);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="w-full p-4">
      <div className="bg-white rounded-lg shadow-sm">
        <div className="p-4 border-b">
          <h3 className="text-lg font-medium text-gray-800">Natural Language Query</h3>
          <p className="text-sm text-gray-500">Ask questions about your data in plain English</p>
        </div>
        
        <div className="p-4">
          <div className="relative">
            <textarea
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Ask a question about your data..."
              className="w-full p-3 text-gray-700 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent min-h-[100px]"
            />
            <button 
              onClick={handleQuerySubmit}
              className="absolute bottom-3 right-3 p-2 text-white bg-blue-600 rounded-lg hover:bg-blue-700 flex items-center gap-2"
            >
              <Send size={16} />
              <span>Send</span>
            </button>
          </div>

          <div className="mt-6 border-b pb-6">
            <div className="flex items-center gap-2 text-sm text-gray-500">
              <Sparkles size={16} />
              <span>Suggested queries</span>
            </div>
            <div className="mt-2 flex flex-wrap gap-2">
              {suggestions.map((suggestion, index) => (
                <button
                  key={index}
                  onClick={() => setQuery(suggestion)}
                  className="px-3 py-1 text-sm text-gray-700 bg-gray-100 rounded-full hover:bg-gray-200"
                >
                  {suggestion}
                </button>
              ))}
            </div>
          </div>

          {queryResult && (
            <>
              <div className="mt-6">
                <div className="border rounded-lg shadow-sm bg-white">
                  <div className="border-b p-4">
                    <div className="flex justify-between items-center">
                      <h3 className="text-lg font-medium">Generated SQL Query</h3>
                      <button
                        onClick={handleCopyQuery}
                        className="flex items-center gap-2 px-3 py-1 text-sm bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
                      >
                        {copied ? (
                          <>
                            <Check size={14} className="text-green-600" />
                            <span className="text-green-600">Copied!</span>
                          </>
                        ) : (
                          <>
                            <Copy size={14} />
                            <span>Copy SQL</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                  <div className="border-b bg-gray-50 p-3 flex gap-4 text-sm text-gray-600">
                    <div className="flex items-center gap-1">
                      <Clock size={14} />
                      <span>Est. Time: {queryResult.queryMetadata.estimatedTime}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Database size={14} />
                      <span>Rows: {queryResult.queryMetadata.rowsScanned}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Zap size={14} />
                      <span>Cache: {queryResult.queryMetadata.cacheStatus}</span>
                    </div>
                  </div>
                  <div className="p-4 font-mono text-sm overflow-x-auto bg-gray-50">
                    <pre className="whitespace-pre">{queryResult.generatedSQL}</pre>
                  </div>
                </div>
              </div>

              <div className="mt-6">
                <div className="border rounded-lg shadow-sm bg-white">
                  <div className="border-b p-4">
                    <div className="flex justify-between items-center">
                      <h3 className="text-lg font-medium">Results</h3>
                      <button
                        onClick={() => setShowAnalysisOptions(!showAnalysisOptions)}
                        className="text-sm text-blue-600 hover:text-blue-700 flex items-center gap-1"
                      >
                        Analyze Results <ChevronRight size={16} />
                      </button>
                    </div>
                  </div>
                  <div className="p-4">
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr>
                            <th className="text-left p-2 border-b">Month</th>
                            <th className="text-right p-2 border-b">Sales</th>
                            <th className="text-right p-2 border-b">Revenue</th>
                          </tr>
                        </thead>
                        <tbody>
                          {queryResult.data.map((row: DataPoint, index: number) => (
                            <tr key={index} className="border-b">
                              <td className="p-2">{row.month}</td>
                              <td className="p-2 text-right">{row.sales}</td>
                              <td className="p-2 text-right">{row.revenue}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>

              {showAnalysisOptions && (
                <div className="mt-6">
                  <div className="border rounded-lg shadow-sm bg-white p-4">
                    <h4 className="text-sm font-medium text-gray-700 mb-3">Analysis Options</h4>
                    <div className="flex gap-4">
                      <button
                        onClick={() => setAnalysisType('summary')}
                        className={`p-4 rounded-lg border flex flex-col items-center gap-2 hover:bg-gray-50 ${
                          analysisType === 'summary' ? 'border-blue-500 bg-blue-50' : ''
                        }`}
                      >
                        <Table size={24} />
                        <span className="text-sm">Summary Stats</span>
                      </button>
                      <button
                        onClick={() => setAnalysisType('visualization')}
                        className={`p-4 rounded-lg border flex flex-col items-center gap-2 hover:bg-gray-50 ${
                          analysisType === 'visualization' ? 'border-blue-500 bg-blue-50' : ''
                        }`}
                      >
                        <BarChart2 size={24} />
                        <span className="text-sm">Visualize</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {analysisType === 'summary' && (
                <div className="mt-6">
                  <div className="border rounded-lg shadow-sm bg-white">
                    <div className="border-b p-4">
                      <h3 className="text-lg font-medium">Summary Statistics</h3>
                    </div>
                    <div className="p-4">
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div className="p-4 bg-gray-50 rounded-lg">
                          <div className="text-sm text-gray-600">Total Records</div>
                          <div className="text-xl font-bold mt-1">{queryResult.summary.totalRecords}</div>
                        </div>
                        <div className="p-4 bg-gray-50 rounded-lg">
                          <div className="text-sm text-gray-600">Time Range</div>
                          <div className="text-xl font-bold mt-1">{queryResult.summary.timeRange}</div>
                        </div>
                        <div className="p-4 bg-gray-50 rounded-lg">
                          <div className="text-sm text-gray-600">Average Sales</div>
                          <div className="text-xl font-bold mt-1">{queryResult.summary.avgSales}</div>
                        </div>
                        <div className="p-4 bg-gray-50 rounded-lg">
                          <div className="text-sm text-gray-600">Average Revenue</div>
                          <div className="text-xl font-bold mt-1">{queryResult.summary.avgRevenue}</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {analysisType === 'visualization' && (
                <div className="mt-6">
                  <div className="border rounded-lg shadow-sm bg-white">
                    <div className="border-b p-4">
                      <div className="flex justify-between items-center">
                        <h3 className="text-lg font-medium">Data Visualization</h3>
                        <div className="flex gap-2">
                          <button
                            onClick={() => setVisualizationType('line')}
                            className={`p-2 rounded ${visualizationType === 'line' ? 'bg-blue-100' : 'bg-gray-100'}`}
                          >
                            <LineChart size={20} />
                          </button>
                          <button
                            onClick={() => setVisualizationType('bar')}
                            className={`p-2 rounded ${visualizationType === 'bar' ? 'bg-blue-100' : 'bg-gray-100'}`}
                          >
                            <BarChart2 size={20} />
                          </button>
                        </div>
                      </div>
                    </div>
                    <div className="p-4">
                      <div className="h-80">
                        <ResponsiveContainer width="100%" height="100%">
                          {visualizationType === 'line' ? (
                            <RechartsLineChart data={queryResult.data}>
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="month" />
                              <YAxis />
                              <Tooltip />
                              <Legend />
                              <Line type="monotone" dataKey="sales" stroke="#8884d8" />
                              <Line type="monotone" dataKey="revenue" stroke="#82ca9d" />
                            </RechartsLineChart>
                          ) : (
                            <BarChart data={queryResult.data}>
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="month" />
                              <YAxis />
                              <Tooltip />
                              <Legend />
                              <Bar dataKey="sales" fill="#8884d8" />
                              <Bar dataKey="revenue" fill="#82ca9d" />
                            </BarChart>
                          )}
                        </ResponsiveContainer>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default QueryEditor;