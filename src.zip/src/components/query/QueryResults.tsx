import React from 'react';
import { Card } from '../common/Card';
import { Loader } from 'lucide-react';

interface QueryResult {
  id: string;
  query: string;
  timestamp: string;
  status: 'success' | 'error' | 'running';
  data: Record<string, any>[];
  columns: string[];
  error?: string;
}

interface QueryResultsProps {
  results: QueryResult | null;
  loading: boolean;
}

const QueryResults: React.FC<QueryResultsProps> = ({ results, loading }) => {
  if (loading) {
    return (
      <Card className="p-6">
        <div className="flex items-center justify-center space-x-2">
          <Loader className="w-5 h-5 animate-spin text-blue-600" />
          <span className="text-gray-600">Executing query...</span>
        </div>
      </Card>
    );
  }

  if (!results) {
    return (
      <Card className="p-6">
        <div className="text-center text-gray-500">
          No results to display. Try running a query.
        </div>
      </Card>
    );
  }

  if (results.error) {
    return (
      <Card className="p-6">
        <div className="text-red-600">
          <h3 className="font-medium mb-2">Error executing query:</h3>
          <pre className="bg-red-50 p-3 rounded text-sm">{results.error}</pre>
        </div>
      </Card>
    );
  }

  return (
    <Card className="overflow-hidden">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              {results.columns.map((column, index) => (
                <th
                  key={index}
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  {column}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {results.data.map((row, rowIndex) => (
              <tr key={rowIndex}>
                {results.columns.map((column, colIndex) => (
                  <td
                    key={`${rowIndex}-${colIndex}`}
                    className="px-6 py-4 whitespace-nowrap text-sm text-gray-900"
                  >
                    {formatCellValue(row[column])}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {results.data.length > 0 && (
        <div className="bg-gray-50 px-6 py-3 border-t">
          <p className="text-sm text-gray-500">
            Showing {results.data.length} results • Query executed at{' '}
            {new Date(results.timestamp).toLocaleString()}
          </p>
        </div>
      )}
    </Card>
  );
};

// Helper function to format cell values
const formatCellValue = (value: any): string => {
  if (value === null || value === undefined) {
    return 'NULL';
  }
  if (typeof value === 'object') {
    return JSON.stringify(value);
  }
  return String(value);
};

export default QueryResults;