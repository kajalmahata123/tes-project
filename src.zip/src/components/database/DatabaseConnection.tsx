import React, { useState } from 'react';
import { Database, Plus, Check, X, Settings } from 'lucide-react';

const DatabaseConnection = () => {
  const [connections, setConnections] = useState([
    { id: 1, name: 'Production MySQL', type: 'MySQL', status: 'connected' },
    { id: 2, name: 'Analytics PostgreSQL', type: 'PostgreSQL', status: 'connected' },
    { id: 3, name: 'MongoDB Atlas', type: 'MongoDB', status: 'disconnected' }
  ]);

  const [showNewConnection, setShowNewConnection] = useState(false);

  return (
    <div className="bg-white rounded-lg shadow-sm">
      <div className="p-4 border-b flex justify-between items-center">
        <div>
          <h3 className="text-lg font-medium text-gray-800">Database Connections</h3>
          <p className="text-sm text-gray-500">Manage your connected databases</p>
        </div>
        <button
          onClick={() => setShowNewConnection(true)}
          className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 flex items-center space-x-2"
        >
          <Plus size={16} />
          <span>New Connection</span>
        </button>
      </div>

      <div className="p-4">
        <div className="space-y-4">
          {connections.map((connection) => (
            <div
              key={connection.id}
              className="p-4 border rounded-lg hover:border-blue-500 transition-colors"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Database size={20} className="text-gray-500" />
                  <div>
                    <h4 className="font-medium text-gray-800">{connection.name}</h4>
                    <p className="text-sm text-gray-500">{connection.type}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  {connection.status === 'connected' ? (
                    <span className="flex items-center text-green-600 text-sm">
                      <Check size={16} className="mr-1" />
                      Connected
                    </span>
                  ) : (
                    <span className="flex items-center text-red-600 text-sm">
                      <X size={16} className="mr-1" />
                      Disconnected
                    </span>
                  )}
                  <button className="p-2 text-gray-500 hover:text-gray-700 rounded">
                    <Settings size={16} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {showNewConnection && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-medium mb-4">Add New Database Connection</h3>
            <form className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Connection Name</label>
                <input
                  type="text"
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  placeholder="My Database"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Database Type</label>
                <select className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                  <option>MySQL</option>
                  <option>PostgreSQL</option>
                  <option>MongoDB</option>
                  <option>Oracle</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Host</label>
                <input
                  type="text"
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  placeholder="localhost"
                />
              </div>
              <div className="flex space-x-3">
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
                >
                  Connect
                </button>
                <button
                  type="button"
                  onClick={() => setShowNewConnection(false)}
                  className="flex-1 bg-gray-100 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-200"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default DatabaseConnection;
