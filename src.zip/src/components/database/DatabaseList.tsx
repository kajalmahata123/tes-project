import React, { useState } from 'react';
import { 
  Database, 
  MoreVertical, 
  Edit2, 
  Trash2, 
  Play, 
  Pause,
  CheckCircle2,
  XCircle,
  AlertCircle
} from 'lucide-react';
import { Button } from '../common/Button';

interface DatabaseType {
  id: string;
  name: string;
  type: 'MySQL' | 'PostgreSQL' | 'MongoDB' | 'Oracle';
  host: string;
  port: number;
  status: 'connected' | 'disconnected' | 'error';
  lastSync: string;
  size: string;
  tables: number;
}

const sampleDatabases: DatabaseType[] = [
  {
    id: '1',
    name: 'Production DB',
    type: 'PostgreSQL',
    host: 'prod-db.example.com',
    port: 5432,
    status: 'connected',
    lastSync: '2024-03-10T15:30:00Z',
    size: '1.2 TB',
    tables: 142
  },
  {
    id: '2',
    name: 'Analytics DB',
    type: 'MySQL',
    host: 'analytics.example.com',
    port: 3306,
    status: 'connected',
    lastSync: '2024-03-10T15:28:00Z',
    size: '850 GB',
    tables: 87
  },
  {
    id: '3',
    name: 'Document Store',
    type: 'MongoDB',
    host: 'mongo.example.com',
    port: 27017,
    status: 'error',
    lastSync: '2024-03-10T14:45:00Z',
    size: '500 GB',
    tables: 35
  },
  {
    id: '4',
    name: 'Legacy System',
    type: 'Oracle',
    host: 'oracle.example.com',
    port: 1521,
    status: 'disconnected',
    lastSync: '2024-03-10T12:00:00Z',
    size: '2.1 TB',
    tables: 256
  }
];

interface DatabaseCardProps {
  database: DatabaseType;
  onEdit: (db: DatabaseType) => void;
  onDelete: (id: string) => void;
  onToggleConnection: (id: string, currentStatus: string) => void;
}

const DatabaseCard: React.FC<DatabaseCardProps> = ({
  database,
  onEdit,
  onDelete,
  onToggleConnection
}) => {
  const [showActions, setShowActions] = useState(false);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'connected':
        return 'text-green-600';
      case 'disconnected':
        return 'text-gray-600';
      case 'error':
        return 'text-red-600';
      default:
        return 'text-gray-600';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'connected':
        return <CheckCircle2 className="w-5 h-5 text-green-600" />;
      case 'disconnected':
        return <XCircle className="w-5 h-5 text-gray-600" />;
      case 'error':
        return <AlertCircle className="w-5 h-5 text-red-600" />;
      default:
        return null;
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow">
      <div className="p-6">
        <div className="flex justify-between items-start">
          <div className="flex items-start space-x-4">
            <div className="p-2 bg-blue-50 rounded-lg">
              <Database className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <h3 className="text-lg font-medium text-gray-900">{database.name}</h3>
              <p className="text-sm text-gray-500">{database.type}</p>
            </div>
          </div>
          <div className="relative">
            <button
              onClick={() => setShowActions(!showActions)}
              className="p-2 hover:bg-gray-100 rounded-lg"
            >
              <MoreVertical className="w-5 h-5 text-gray-500" />
            </button>
            
            {showActions && (
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200 py-1 z-10">
                <button
                  onClick={() => onEdit(database)}
                  className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                >
                  <Edit2 className="w-4 h-4 mr-2" />
                  Edit
                </button>
                <button
                  onClick={() => onToggleConnection(database.id, database.status)}
                  className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                >
                  {database.status === 'connected' ? (
                    <>
                      <Pause className="w-4 h-4 mr-2" />
                      Disconnect
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4 mr-2" />
                      Connect
                    </>
                  )}
                </button>
                <button
                  onClick={() => onDelete(database.id)}
                  className="flex items-center w-full px-4 py-2 text-sm text-red-600 hover:bg-red-50"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete
                </button>
              </div>
            )}
          </div>
        </div>

        <div className="mt-4 grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-gray-500">Host</p>
            <p className="text-sm font-medium">{database.host}:{database.port}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Status</p>
            <div className="flex items-center space-x-1">
              {getStatusIcon(database.status)}
              <span className={`text-sm font-medium ${getStatusColor(database.status)}`}>
                {database.status.charAt(0).toUpperCase() + database.status.slice(1)}
              </span>
            </div>
          </div>
          <div>
            <p className="text-sm text-gray-500">Size</p>
            <p className="text-sm font-medium">{database.size}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Tables</p>
            <p className="text-sm font-medium">{database.tables}</p>
          </div>
        </div>

        <div className="mt-4 pt-4 border-t">
          <p className="text-xs text-gray-500">
            Last synchronized: {formatDate(database.lastSync)}
          </p>
        </div>
      </div>
    </div>
  );
};

const DatabaseList: React.FC = () => {
  const [databases, setDatabases] = useState<DatabaseType[]>(sampleDatabases);
  const [isAddingNew, setIsAddingNew] = useState(false);

  const handleEdit = (database: DatabaseType) => {
    console.log('Editing database:', database);
    // Implement edit logic
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this database?')) {
      setDatabases(databases.filter(db => db.id !== id));
    }
  };

  const handleToggleConnection = (id: string, currentStatus: string) => {
    setDatabases(databases.map(db => {
      if (db.id === id) {
        return {
          ...db,
          status: currentStatus === 'connected' ? 'disconnected' : 'connected'
        };
      }
      return db;
    }));
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-semibold text-gray-900">Connected Databases</h2>
          <p className="text-sm text-gray-500">Manage your database connections and settings</p>
        </div>
        <Button
          variant="primary"
          leftIcon={<Database size={16} />}
          onClick={() => setIsAddingNew(true)}
        >
          Add Database
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {databases.map(database => (
          <DatabaseCard
            key={database.id}
            database={database}
            onEdit={handleEdit}
            onDelete={handleDelete}
            onToggleConnection={handleToggleConnection}
          />
        ))}
      </div>

      {databases.length === 0 && (
        <div className="text-center py-12">
          <Database className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900">No databases connected</h3>
          <p className="text-sm text-gray-500">Get started by adding your first database connection</p>
        </div>
      )}
    </div>
  );
};

export default DatabaseList;