import React, { useState } from 'react';
import { 
  LineChart, 
  Line, 
  BarChart, 
  Bar, 
  PieChart, 
  Pie, 
  AreaChart, 
  Area,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  Cell
} from 'recharts';
import { Settings, Download, Maximize2 } from 'lucide-react';

// Color palette for charts
const COLORS = [
  '#2563eb', '#3b82f6', '#60a5fa', '#93c5fd', 
  '#10b981', '#34d399', '#6ee7b7', '#a7f3d0',
  '#f59e0b', '#fbbf24', '#fcd34d', '#fde68a'
];

// TypeScript interfaces
interface SeriesConfig {
  key?: string;
  dataKey: string;
  color?: string;
  stack?: boolean;
}

interface ChartConfig {
  xAxis?: string;
  description?: string;
  series?: SeriesConfig[];
  innerRadius?: number;
  outerRadius?: number;
  paddingAngle?: number;
  dataKey?: string;
}

interface ChartViewProps {
  data: Array<Record<string, any>>;
  type?: 'line' | 'bar' | 'pie' | 'area';
  title: string;
  config?: ChartConfig;
  className?: string;
}

const ChartView: React.FC<ChartViewProps> = ({ 
  data, 
  type = 'line', 
  title, 
  config = {}, 
  className = '' 
}) => {
  const [showSettings, setShowSettings] = useState(false);

  const renderChart = () => {
    switch (type.toLowerCase()) {
      case 'line':
        return (
          <ResponsiveContainer width="100%" height={400}>
            <LineChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 10 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey={config.xAxis || 'name'} />
              <YAxis />
              <Tooltip />
              <Legend />
              {config.series?.map((series, index) => (
                <Line
                  key={series.key || index}
                  type="monotone"
                  dataKey={series.dataKey}
                  stroke={series.color || COLORS[index % COLORS.length]}
                  dot={{ r: 4 }}
                  activeDot={{ r: 8 }}
                  strokeWidth={2}
                />
              ))}
            </LineChart>
          </ResponsiveContainer>
        );

      case 'bar':
        return (
          <ResponsiveContainer width="100%" height={400}>
            <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 10 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey={config.xAxis || 'name'} />
              <YAxis />
              <Tooltip />
              <Legend />
              {config.series?.map((series, index) => (
                <Bar
                  key={series.key || index}
                  dataKey={series.dataKey}
                  fill={series.color || COLORS[index % COLORS.length]}
                  radius={[4, 4, 0, 0]}
                />
              ))}
            </BarChart>
          </ResponsiveContainer>
        );

      case 'pie':
        return (
          <ResponsiveContainer width="100%" height={400}>
            <PieChart margin={{ top: 20, right: 30, left: 20, bottom: 10 }}>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                innerRadius={config.innerRadius || 60}
                outerRadius={config.outerRadius || 140}
                paddingAngle={config.paddingAngle || 5}
                dataKey={config.dataKey || 'value'}
              >
                {data.map((entry, index) => (
                  <Cell 
                    key={`cell-${index}`} 
                    fill={COLORS[index % COLORS.length]} 
                  />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        );

      case 'area':
        return (
          <ResponsiveContainer width="100%" height={400}>
            <AreaChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 10 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey={config.xAxis || 'name'} />
              <YAxis />
              <Tooltip />
              <Legend />
              {config.series?.map((series, index) => (
                <Area
                  key={series.key || index}
                  type="monotone"
                  dataKey={series.dataKey}
                  stackId={series.stack ? "1" : undefined}
                  fill={series.color || COLORS[index % COLORS.length]}
                  stroke={series.color || COLORS[index % COLORS.length]}
                  fillOpacity={0.6}
                />
              ))}
            </AreaChart>
          </ResponsiveContainer>
        );

      default:
        return (
          <div className="flex items-center justify-center h-64 text-gray-500">
            Unsupported chart type: {type}
          </div>
        );
    }
  };

  // Chart settings panel interface
  const renderSettings = () => {
    if (!showSettings) return null;

    return (
      <div className="px-6 py-4 border-t bg-gray-50">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Chart Type</label>
            <select
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
              value={type}
              // Add onChange handler when needed
            >
              <option value="line">Line Chart</option>
              <option value="bar">Bar Chart</option>
              <option value="pie">Pie Chart</option>
              <option value="area">Area Chart</option>
            </select>
          </div>
          {/* Add more settings as needed */}
        </div>
      </div>
    );
  };

  return (
    <div className={`bg-white rounded-lg shadow-sm ${className}`}>
      {/* Chart Header */}
      <div className="px-6 py-4 border-b flex justify-between items-center">
        <div>
          <h3 className="text-lg font-medium text-gray-900">{title}</h3>
          {config.description && (
            <p className="mt-1 text-sm text-gray-500">{config.description}</p>
          )}
        </div>
        <div className="flex items-center space-x-2">
          <button 
            onClick={() => setShowSettings(!showSettings)}
            className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100"
            title="Chart Settings"
          >
            <Settings size={18} />
          </button>
          <button 
            className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100"
            title="Download Chart"
            onClick={() => {/* Implement download functionality */}}
          >
            <Download size={18} />
          </button>
          <button 
            className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100"
            title="Fullscreen"
            onClick={() => {/* Implement fullscreen functionality */}}
          >
            <Maximize2 size={18} />
          </button>
        </div>
      </div>

      {/* Chart Content */}
      <div className="p-6">
        {renderChart()}
      </div>

      {/* Settings Panel */}
      {renderSettings()}
    </div>
  );
};

export default ChartView;