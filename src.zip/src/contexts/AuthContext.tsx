import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { authService } from '../services/authService';

interface AuthContextType {
  isAuthenticated: boolean;
  user: any | null;
  token: string | null;
  login: (token: string, user: any) => void;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    return !!(localStorage.getItem('token') || sessionStorage.getItem('token'));
  });
  const [user, setUser] = useState<any | null>(null);
  const [token, setToken] = useState<string | null>(() => {
    return localStorage.getItem('token') || sessionStorage.getItem('token');
  });

  const login = useCallback((token: string, user: any) => {
    setIsAuthenticated(true);
    setUser(user);
    setToken(token);
  }, []);

  const logout = useCallback(async () => {
    try {
      await authService.logout();
    } finally {
      setIsAuthenticated(false);
      setUser(null);
      setToken(null);
      localStorage.removeItem('token');
      sessionStorage.removeItem('token');
    }
  }, []);

  // Auto refresh token
  useEffect(() => {
    if (isAuthenticated) {
      const refreshToken = async () => {
        try {
          const response = await authService.refreshToken();
          login(response.token, response.user);
        } catch (error) {
          logout();
        }
      };

      const intervalId = setInterval(refreshToken, 14 * 60 * 1000); // Refresh every 14 minutes
      return () => clearInterval(intervalId);
    }
  }, [isAuthenticated, login, logout]);

  return (
    <AuthContext.Provider value={{ isAuthenticated, user, token, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};