import React from 'react';
import { lazy } from 'react';
import type { LucideProps } from 'lucide-react';
import { Home, Database, BarChart2, LogIn } from 'lucide-react';
const Dashboard = lazy(() => import('./pages/Dashboard'));
const Databases = lazy(() => import('./pages/Databases'));
const Visualizations = lazy(() => import('./pages/Visualizations'));
const Login = lazy(() => import('./pages/LoginPage'));
const SignUp = lazy(() => import('./pages/SignUpPage'));
const ForgotPassword = lazy(() => import('./pages/ForgotPasswordPage'));
export interface Route {
  path: string;
  component: React.LazyExoticComponent<React.ComponentType>;
  label: string;
  icon?: JSX.Element;
  isAuth?: boolean;
}

const iconProps: LucideProps = {
  size: 20,
  strokeWidth: 2
};

export const routes: Route[] = [
  {
    path: '/dashboard',
    component: Dashboard,
    label: 'Dashboard',
    icon: React.createElement(Home, iconProps)
  },
  {
    path: '/databases',
    component: Databases,
    label: 'Databases',
    icon: React.createElement(Database, iconProps)
  },
  {
    path: '/visualizations',
    component: Visualizations,
    label: 'Visualizations',
    icon: React.createElement(BarChart2, iconProps)
  },
  {
    path: '/signup',
    component: SignUp,
    label: 'Sign Up',
    icon: React.createElement(LogIn, iconProps),
    isAuth: true
  }
];

export default routes;
//export default { routes };