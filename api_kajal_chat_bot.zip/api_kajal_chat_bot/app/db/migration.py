# db/migration.py
# Migration script to add app_id column to sessions table

import sqlite3
import os
import logging

logger = logging.getLogger(__name__)

# Path to the SQLite database
DB_PATH = './app/data/sessions.db'

def check_column_exists(cursor, table, column):
    """Check if a column exists in a table."""
    cursor.execute(f"PRAGMA table_info({table})")
    columns = cursor.fetchall()
    return any(col[1] == column for col in columns)

def add_app_id_column():
    """Add app_id column to sessions table if it doesn't exist."""
    # Ensure the data directory exists
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    
    # Check if the database file exists
    if not os.path.exists(DB_PATH):
        logger.warning(f"Database file {DB_PATH} does not exist. No migration needed.")
        return
    
    try:
        # Connect to the database
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        # Check if app_id column already exists
        if not check_column_exists(cursor, 'sessions', 'app_id'):
            # Add the app_id column
            cursor.execute("ALTER TABLE sessions ADD COLUMN app_id TEXT")
            
            # Update existing rows with a default value if needed
            cursor.execute("UPDATE sessions SET app_id = 'default_app' WHERE app_id IS NULL")
            
            # Commit the changes
            conn.commit()
            logger.info("Successfully added app_id column to sessions table")
        else:
            logger.info("app_id column already exists in sessions table")
        
        # Close the connection
        conn.close()
        
    except sqlite3.Error as e:
        logger.error(f"SQLite error: {e}")
    except Exception as e:
        logger.error(f"Error during migration: {e}")

if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Run the migration
    add_app_id_column()
    print("Migration completed") 