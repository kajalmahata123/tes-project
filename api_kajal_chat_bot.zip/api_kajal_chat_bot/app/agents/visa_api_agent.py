import logging
from typing import List, Dict, Any, Optional
from langchain_anthropic import ChatAnthropic
from langchain.schema import BaseMessage, HumanMessage, AIMessage
from langchain.memory import ConversationBufferMemory
from app.agents.base_agent import BaseAgent
from app.config import get_settings
from app.llm.llm_service import create_llm_instance
from app.schemas.chat_schemas import ChatMessage
from app.schemas.agent_schemas import AgentConfig
from app.graphs.react_graph import create_react_graph
from app.tools.documentation_tool import DocumentationTool

logger = logging.getLogger(__name__)


class VisaApiAgent(BaseAgent):
    """
    Agent specialized for handling Visa API documentation queries.
    Implements the ReAct pattern for reasoning and tool usage.
    """

    def __init__(self, config: AgentConfig):
        """
        Initialize Visa API agent.

        Args:
            config: Agent configuration
        """
        super().__init__(config)
        self.llm = None
        self.memory = None
        self.doc_tool = None

    async def initialize(self) -> None:
        """Initialize agent resources."""
        # Initialize LLM
        self.llm = self.initialize_llm(temperature=0.2)

        # Initialize memory
        self.memory = ConversationBufferMemory(
            memory_key="chat_history",
            return_messages=True,
            input_key="input",
            output_key="output"
        )

        # Initialize tools
        self.doc_tool = DocumentationTool(
            knowledge_base=self.config.knowledge_base,
            top_k=5
        )

        # Set up tools list
        self.tools = [self.doc_tool]

        # Create the agent graph using LangGraph
        self.agent_graph = await create_react_graph(
            llm=self.llm,
            tools=self.tools,
            system_prompt=self._get_system_prompt()
        )

        logger.info(f"Initialized {self.__class__.__name__} with {len(self.tools)} tools")

    async def process_message(self, message: str, chat_history: List[ChatMessage]) -> str:
        """
        Process user message and return agent response.

        Args:
            message: User message text
            chat_history: List of previous chat messages

        Returns:
            Agent response text
        """
        logger.info(f"Processing message for {self.name}: {message[:50]}...")

        # Convert chat history to memory format if not already in memory
        if chat_history:
            self._update_memory_from_history(chat_history)

        # Get current memory messages to provide as context
        memory_messages = self.get_memory_messages()

        # Execute the ReAct agent graph
        try:
            result = await self.agent_graph.ainvoke({
                "input": message,
                "chat_history": memory_messages
            })

            response = result.get("output", "I'm sorry, I couldn't process your request.")

            # Update memory with this exchange
            self.memory.chat_memory.add_user_message(message)
            self.memory.chat_memory.add_ai_message(response)

            return response

        except Exception as e:
            logger.error(f"Error in agent processing: {e}", exc_info=True)
            return "I encountered an error while processing your request. Please try again."

    def get_memory_messages(self) -> List[BaseMessage]:
        """
        Get messages from memory.

        Returns:
            List of messages from memory
        """
        if not self.memory:
            return []
        return self.memory.chat_memory.messages

    def clear_memory(self) -> None:
        """Clear conversation memory."""
        if self.memory:
            self.memory.clear()

    def _update_memory_from_history(self, chat_history: List[ChatMessage]) -> None:
        """
        Update memory with chat history.

        Args:
            chat_history: List of chat messages
        """
        # Clear existing memory
        self.clear_memory()

        # Add messages to memory
        for msg in chat_history:
            if msg.role == "user":
                self.memory.chat_memory.add_user_message(msg.content)
            elif msg.role == "assistant":
                self.memory.chat_memory.add_ai_message(msg.content)

    def _get_system_prompt(self) -> str:
        """
        Get system prompt for the agent.

        Returns:
            System prompt string
        """
        return """You are a helpful AI assistant specializing in the Visa Flexible Credential API. 
Your purpose is to help developers understand and implement Visa API integrations.

When answering questions:
1. First, determine if you need to search the API documentation.
2. Use the documentation search tool to find relevant information.
3. Analyze the search results to formulate a complete and accurate answer.
4. Provide code examples when appropriate.
5. Be specific and reference relevant API endpoints, parameters, and schemas.
6. If you're unsure about something, acknowledge it and provide the best information you have.

Remember that you cannot make actual API calls - you can only provide guidance, documentation, and example code.
"""

    @property
    def capabilities(self) -> List[str]:
        """
        List agent capabilities.

        Returns:
            List of capability strings
        """
        return [
            "Answer questions about Visa API concepts, endpoints, and parameters",
            "Provide accurate information based on Visa API documentation",
            "Reference specific API endpoints and schemas",
            "Generate example code snippets"
        ]