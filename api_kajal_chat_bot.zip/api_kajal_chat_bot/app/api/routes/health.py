from fastapi import APIRouter
from typing import Dict
import logging
import time

router = APIRouter()
logger = logging.getLogger(__name__)

start_time = time.time()


@router.get("")
async def health_check() -> Dict[str, str]:
    """
    Simple health check endpoint.
    Returns status OK if the API is running.
    """
    return {"status": "OK"}


@router.get("/info")
async def health_info() -> Dict[str, str]:
    """
    Extended health check with system information.
    """
    uptime = time.time() - start_time

    return {
        "status": "OK",
        "uptime": f"{uptime:.2f} seconds"
    }