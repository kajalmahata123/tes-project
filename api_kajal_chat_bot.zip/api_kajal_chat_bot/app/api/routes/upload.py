from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, BackgroundTasks
from fastapi.responses import JSONResponse
import logging
import uuid
import os
import shutil
from pathlib import Path
import tempfile
from app.dependencies import get_agent_factory, verify_api_key, get_knowledge_base
from app.core.agent_factory import AgentFactory
from app.core.knowledge_base import KnowledgeBase
from app.tools.openapi_loader import OpenAPILoader

logger = logging.getLogger(__name__)

router = APIRouter()


@router.post("/openapi-spec")
async def upload_openapi_spec(
        background_tasks: BackgroundTasks,
        file: UploadFile = File(...),
        agent_factory: AgentFactory = Depends(get_agent_factory),
        knowledge_base: KnowledgeBase = Depends(get_knowledge_base)
):
    """
    Upload and process an OpenAPI specification file.
    The file will be loaded into the knowledge base for agent use.
    """
    logger.info(f"Received OpenAPI file upload: {file.filename}")

    try:
        # Validate file extension
        file_ext = os.path.splitext(file.filename)[1].lower()
        if file_ext not in ['.json', '.yaml', '.yml']:
            raise HTTPException(
                status_code=400,
                detail="Invalid file format. Only JSON and YAML OpenAPI files are supported."
            )

        # Create temp file
        temp_dir = Path(tempfile.gettempdir())
        temp_file = temp_dir / f"{uuid.uuid4()}{file_ext}"

        # Save uploaded file
        with open(temp_file, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)

        # Process file in background
        background_tasks.add_task(
            process_openapi_file,
            str(temp_file),
            file.filename,
            knowledge_base
        )

        return JSONResponse(
            status_code=202,
            content={
                "message": "OpenAPI specification accepted for processing",
                "filename": file.filename
            }
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error handling OpenAPI upload: {e}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail="Error processing OpenAPI file"
        )
    finally:
        file.file.close()


async def process_openapi_file(file_path: str, original_filename: str, knowledge_base: KnowledgeBase):
    """
    Process an OpenAPI file and load into knowledge base.
    """
    try:
        logger.info(f"Processing OpenAPI file: {original_filename}")

        # Ensure knowledge base is initialized
        if not knowledge_base.vectorstore:
            logger.info("Knowledge base not initialized in background task, initializing now")
            await knowledge_base.initialize()

        # Initialize OpenAPI loader
        loader = OpenAPILoader(knowledge_base)

        # Load and validate the spec
        spec = await loader.load_spec(file_path)

        # Process the spec and add to knowledge base
        await loader.process_spec(spec, original_filename)

        logger.info(f"Successfully processed OpenAPI file: {original_filename}")

    except Exception as e:
        logger.error(f"Error processing OpenAPI file {original_filename}: {e}", exc_info=True)
    finally:
        # Clean up temporary file
        try:
            if os.path.exists(file_path):
                os.unlink(file_path)
        except Exception as e:
            logger.error(f"Error removing temporary file {file_path}: {e}")