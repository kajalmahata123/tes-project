import uuid
from contextlib import asynccontextmanager
from fastapi import FastAPI, Depends, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.docs import get_redoc_html, get_swagger_ui_html
from fastapi.openapi.utils import get_openapi
#from fastapi.responses import JSONResponse
import logging
import time
from fastapi.staticfiles import StaticFiles
from app.config import get_settings
from app.api.routes import chat, health, upload, api_keys, bootstrap
from app.core.session_manager import SessionManager
from app.dependencies import verify_api_key, get_agent_factory
from app.llm.llm_service import get_llm_service
from utils.logging import get_logger
from fastapi.responses import HTMLResponse, JSONResponse

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = get_logger("fastapi")

# Get environment configuration
settings = get_settings()


# Define lifespan context manager
@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Starting up API service...")
    #
    get_llm_service()
    # Initialize database first
    from db.manager import DatabaseManager

    db_url = settings.DB_URL
    db_manager = DatabaseManager(db_url)
    await db_manager.initialize()
    logger.info("Database initialized")

    # Initialize session manager
    session_manager = SessionManager.get_instance()

    # Create agent factory instance at startup
    agent_factory = await get_agent_factory()
    logger.info(f"Loaded agent types: {', '.join(agent_factory.available_agents())}")

    try:
        yield
    finally:
        logger.info("Shutting down API service...")
        # Any cleanup code goes here


# Initialize FastAPI app
app = FastAPI(
    title=settings.PROJECT_NAME,
    openapi_url=f"{settings.API_PREFIX}/openapi.json",
    docs_url=f"{settings.API_PREFIX}/docs",
    redoc_url=f"{settings.API_PREFIX}/redoc",
    debug=settings.DEBUG,
    lifespan=lifespan
)

# Add static file mounts - only JS and CSS needed for production
#app.mount("/static/templates", StaticFiles(directory="static/templates"), name="static_html")
#app.mount("/static/js", StaticFiles(directory="static/js"), name="static_js")
#app.mount("/static/css", StaticFiles(directory="static/css"), name="static_css")

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS if hasattr(settings, 'CORS_ORIGINS') else ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Add production routes only
app.include_router(
    health.router,
    prefix=f"{settings.API_PREFIX}/health",
    tags=["health"]
)

app.include_router(
    chat.router,
    prefix=f"{settings.API_PREFIX}/chat",
    tags=["chat"],
    dependencies=[Depends(verify_api_key)]
)

app.include_router(
    upload.router,
    prefix=f"{settings.API_PREFIX}/upload",
    tags=["upload"],
    dependencies=[Depends(verify_api_key)]
)
app.include_router(
    api_keys.router,
    prefix="/api/admin",
    tags=["admin"],
    dependencies=[Depends(verify_api_key)]
)
app.include_router(
    bootstrap.router,
    prefix="/api/admin/bootstrap",
    tags=["bootstrap"]
)
@app.get("/test", response_class=HTMLResponse)
async def serve_test_html():
    """
    Serve test.html directly via a route
    This is accessible at http://yourserver.com/test
    """
    with open("static/test_chatgpt_widget.html", "r") as f:
        html_content = f.read()
    return HTMLResponse(content=html_content)
# Custom Swagger UI route
@app.get("/docs", include_in_schema=False)
async def custom_swagger_ui_html():
    return get_swagger_ui_html(
        openapi_url=app.openapi_url,
        title=f"{app.title} - Swagger UI",
        oauth2_redirect_url=app.swagger_ui_oauth2_redirect_url,
        swagger_js_url="https://cdn.jsdelivr.net/npm/swagger-ui-dist@5/swagger-ui-bundle.js",
        swagger_css_url="https://cdn.jsdelivr.net/npm/swagger-ui-dist@5/swagger-ui.css",
        swagger_favicon_url="/static/favicon.png",
    )


# OpenAPI schema with custom tags configuration
@app.get("/api/openapi.json", include_in_schema=False)
async def get_open_api_endpoint():
    # Generate OpenAPI schema
    openapi_schema = get_openapi(
        title=app.title,
        version=app.version,
        description=app.description,
        routes=app.routes,
    )

    # Customize the tags
    openapi_schema["tags"] = [
        {
            "name": "chat",
            "description": "Chat session operations including messages, session management, and agent selection.",
        },
        {
            "name": "admin",
            "description": "Administrative operations such as API key management.",
        },
        {
            "name": "system",
            "description": "System operations such as health checks.",
        },
        {
            "name": "bootstrap",
            "description": "Bootstrap operations for initial setup.",
        }
    ]
    # Add security schemes
    if "components" not in openapi_schema:
        openapi_schema["components"] = {}

    openapi_schema["components"]["securitySchemes"] = {
        "ApiKeyHeader": {
            "type": "apiKey",
            "in": "header",
            "name": "X-API-Key"
        },
        "AppIdHeader": {
            "type": "apiKey",
            "in": "header",
            "name": "X-App-ID"
        }
    }

    # Add security requirement to all paths except bootstrap
    for path, path_item in openapi_schema["paths"].items():
        if "/api/admin/bootstrap" not in path:
            for method in path_item:
                if "security" not in path_item[method]:
                    path_item[method]["security"] = [
                        {"ApiKeyHeader": [], "AppIdHeader": []}
                    ]
    return JSONResponse(openapi_schema)
# Custom ReDoc route
@app.get("/redoc", include_in_schema=False)
async def redoc_html():
    return get_redoc_html(
        openapi_url=app.openapi_url,
        title=f"{app.title} - ReDoc",
        redoc_js_url="https://cdn.jsdelivr.net/npm/redoc@next/bundles/redoc.standalone.js",
        redoc_favicon_url="/static/favicon.png",
    )


# Add a simple root endpoint
@app.get("/", tags=["system"], response_class=HTMLResponse)
async def root():
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Chat API</title>
        <style>
            body {
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
                max-width: 800px;
                margin: 0 auto;
                padding: 2rem;
                line-height: 1.5;
            }
            h1 {
                color: #333;
                border-bottom: 1px solid #eaeaea;
                padding-bottom: 0.5rem;
            }
            a {
                color: #0070f3;
                text-decoration: none;
            }
            a:hover {
                text-decoration: underline;
            }
            .doc-links {
                display: flex;
                gap: 2rem;
                margin: 2rem 0;
            }
            .doc-link {
                padding: 1rem;
                border: 1px solid #eaeaea;
                border-radius: 5px;
                transition: all 0.2s ease;
            }
            .doc-link:hover {
                border-color: #0070f3;
                box-shadow: 0 4px 14px 0 rgba(0, 118, 255, 0.1);
            }
            .version {
                color: #666;
                font-size: 0.9rem;
                margin-top: 2rem;
            }
        </style>
    </head>
    <body>
        <h1>Welcome to the Chat API</h1>
        <p>This API provides chat functionality with AI agents specialized for different tasks.</p>

        <div class="doc-links">
            <a href="/docs" class="doc-link">
                <h2>Swagger UI</h2>
                <p>Interactive API documentation for developers</p>
            </a>
            <a href="/redoc" class="doc-link">
                <h2>ReDoc</h2>
                <p>API reference documentation</p>
            </a>
        </div>

        <h2>Authentication</h2>
        <p>All API endpoints require authentication using <code>X-App-ID</code> and <code>X-API-Key</code> headers.</p>

        <h2>Features</h2>
        <ul>
            <li>Create and manage chat sessions with AI agents</li>
            <li>Support for multiple specialized agents</li>
            <li>Automatic agent selection based on message content</li>
            <li>API key management</li>
        </ul>

        <p class="version">API Version: 1.0.0</p>
    </body>
    </html>
    """
# Request timing middleware
@app.middleware("http")
async def log_requests(request: Request, call_next):
    """Middleware to log all requests and responses"""
    request_id = str(uuid.uuid4())
    start_time = time.time()

    # Log request details
    logger.info(f"Request [{request_id}]: {request.method} {request.url.path} received")

    try:
        # Process request
        response = await call_next(request)

        # Calculate processing time
        process_time = time.time() - start_time
        response.headers["X-Process-Time"] = str(process_time)
        # Log response details
        logger.info(f"Response [{request_id}]: {request.method} {request.url.path} "
                    f"completed with status {response.status_code} in {process_time:.3f}s")

        return response
    except Exception as e:
        # Automatically captures detailed error information
        logger.error(f"Request failed [{request_id}]: {request.method} {request.url.path} - {str(e)}")

        return JSONResponse(
            status_code=500,
            content={"detail": "Internal Server Error"}
        )


# Exception handlers
@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    logger.error(f"Unhandled exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={"detail": "An unexpected error occurred."}
    )


# Configure logging for uvicorn and other third-party libraries
def configure_third_party_loggers():
    """Configure logging for third-party libraries like uvicorn"""
    uvicorn_logger = get_logger("uvicorn")
    # Retrieve and configure other third-party loggers as needed

    # Configure the root logger for uncaught exceptions
    root_logger = get_logger("root")

    # This ensures that any uncaught exceptions will be logged with details
    def handle_exception(exc_type, exc_value, exc_traceback):
        if issubclass(exc_type, KeyboardInterrupt):
            # Don't log keyboard interrupt
            import sys
            sys.exit(0)
        root_logger.critical("Uncaught exception", exc_info=(exc_type, exc_value, exc_traceback))

    import sys
    sys.excepthook = handle_exception


# Call this at startup
configure_third_party_loggers()

if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.DEBUG
    )