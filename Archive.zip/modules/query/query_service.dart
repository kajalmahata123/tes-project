// Create this file at lib/modules/query/query_service.dart

import 'package:uuid/uuid.dart';
import 'query_models.dart';
import '../datasource/datasource_models.dart';
import '../datasource/datasource_service.dart';

class QueryService {
  // For demo purposes, we'll use in-memory storage
  static List<QueryIntent> _queryHistory = [];
  
  // Get query history
  static Future<List<QueryIntent>> getQueryHistory() async {
    // Simulate network delay
    await Future.delayed(const Duration(milliseconds: 800));
    return _queryHistory;
  }
  
  // Add a query to history
  static Future<QueryIntent> addQuery(QueryIntent query) async {
    // Simulate network delay
    await Future.delayed(const Duration(seconds: 1));
    _queryHistory.add(query);
    return query;
  }
  
  // Generate SQL from natural language
  static Future<QueryIntent> generateSQL(String sourceId, String naturalLanguage) async {
    // Simulate network delay and processing
    await Future.delayed(const Duration(seconds: 2));
    
    // Get the source to access the schema
    final source = await DatasourceService.getSource(sourceId);
    if (source == null) {
      throw Exception('Data source not found');
    }
    
    // Mock generation of SQL based on natural language input
    // In a real app, this would use a more sophisticated approach with NLP/ML
    
    // Sample tables to use in the query
    final availableTables = source.tables.map((t) => t.name).toList();
    final selectedTables = <String>[];
    
    // Select relevant tables based on keywords in the query
    final keywords = naturalLanguage.toLowerCase().split(' ');
    for (final table in availableTables) {
      if (keywords.contains(table.toLowerCase()) || 
          keywords.any((k) => k.contains(table.toLowerCase()))) {
        selectedTables.add(table);
      }
    }
    
    // If no tables were matched, use the first available table or tables with common names
    if (selectedTables.isEmpty && availableTables.isNotEmpty) {
      if (availableTables.contains('users')) selectedTables.add('users');
      if (availableTables.contains('orders')) selectedTables.add('orders');
      if (availableTables.contains('products')) selectedTables.add('products');
      if (selectedTables.isEmpty) selectedTables.add(availableTables.first);
    }
    
    // Generate sample SQL based on the query intent
    String generatedSQL = '';
    List<String> suggestedQueries = [];
    
    if (naturalLanguage.toLowerCase().contains('show') || 
        naturalLanguage.toLowerCase().contains('list') ||
        naturalLanguage.toLowerCase().contains('get') ||
        naturalLanguage.toLowerCase().contains('all')) {
      // Query to list all items
      if (selectedTables.length == 1) {
        generatedSQL = 'SELECT * FROM ${selectedTables[0]} LIMIT 100;';
      } else if (selectedTables.length > 1) {
        generatedSQL = 'SELECT * FROM ${selectedTables[0]} JOIN ${selectedTables[1]} ON ${selectedTables[0]}.id = ${selectedTables[1]}.${selectedTables[0].substring(0, selectedTables[0].length - 1)}_id LIMIT 100;';
      }
      
      suggestedQueries = [
        'SELECT * FROM ${selectedTables[0]} ORDER BY created_at DESC LIMIT 10;',
        'SELECT COUNT(*) FROM ${selectedTables[0]};',
      ];
    } else if (naturalLanguage.toLowerCase().contains('count') || 
              naturalLanguage.toLowerCase().contains('how many')) {
      // Count query
      generatedSQL = 'SELECT COUNT(*) FROM ${selectedTables[0]};';
      
      suggestedQueries = [
        'SELECT COUNT(*) FROM ${selectedTables[0]} GROUP BY status;',
        'SELECT DATE(created_at) as date, COUNT(*) FROM ${selectedTables[0]} GROUP BY date ORDER BY date DESC LIMIT 30;',
      ];
    } else {
      // Generic query
      if (selectedTables.isNotEmpty) {
        generatedSQL = 'SELECT * FROM ${selectedTables[0]} LIMIT 100;';
        
        suggestedQueries = [
          'SELECT * FROM ${selectedTables[0]} ORDER BY id DESC LIMIT 10;',
          'SELECT COUNT(*) FROM ${selectedTables[0]} GROUP BY created_at;',
        ];
      }
    }
    
    // Create the query intent
    final query = QueryIntent(
      id: const Uuid().v4(),
      naturalLanguage: naturalLanguage,
      generatedSQL: generatedSQL,
      tables: selectedTables,
      createdAt: DateTime.now(),
      suggestedQueries: suggestedQueries,
    );
    
    // Add to history
    await addQuery(query);
    
    return query;
  }
  
  // Analyze SQL and provide insights
  static Future<SQLInsight> analyzeSQL(String sourceId, String sql) async {
    // Simulate network delay and processing
    await Future.delayed(const Duration(seconds: 1));
    
    // Mock SQL parsing and analysis
    // In a real app, this would use a proper SQL parser and analyzer
    
    // Extract tables
    final tableRegex = RegExp(r'FROM\s+(\w+)|JOIN\s+(\w+)', caseSensitive: false);
    final tableMatches = tableRegex.allMatches(sql);
    final tables = tableMatches
        .map((m) => m.group(1) ?? m.group(2))
        .where((t) => t != null)
        .map((t) => t!)
        .toList();
    
    // Extract columns
    final columnRegex = RegExp(r'SELECT\s+(.*?)\s+FROM', caseSensitive: false);
    final columnMatch = columnRegex.firstMatch(sql);
    final columnsStr = columnMatch?.group(1) ?? '*';
    final columns = columnsStr == '*'
        ? ['*']
        : columnsStr
            .split(',')
            .map((c) => c.trim())
            .toList();
    
    // Extract conditions
    final whereRegex = RegExp(r'WHERE\s+(.*?)(?:ORDER BY|GROUP BY|LIMIT|;|$)', caseSensitive: false);
    final whereMatch = whereRegex.firstMatch(sql);
    final conditions = whereMatch != null
        ? [whereMatch.group(1)!.trim()]
        : <String>[];
    
    // Extract joins
    final joinRegex = RegExp(r'(INNER|LEFT|RIGHT|FULL)?\s*JOIN\s+([^\s]+)\s+ON\s+(.*?)(?:WHERE|ORDER BY|GROUP BY|LIMIT|;|$)', caseSensitive: false);
    final joinMatches = joinRegex.allMatches(sql);
    final joins = joinMatches
        .map((m) => '${m.group(1) ?? 'INNER'} JOIN ${m.group(2)} ON ${m.group(3)}')
        .toList();
    
    // Create performance data
    final performance = {
      'estimatedRows': 1000,
      'estimatedCost': 2.5,
      'indexUsage': tables.isNotEmpty ? {'${tables[0]}_pkey': 'Used'} : {},
      'scanType': 'Index Scan',
    };
    
    // Create improvement suggestions
    final improvements = <String>[];
    
    if (columns.contains('*')) {
      improvements.add('Select specific columns instead of "*" to improve performance');
    }
    
    if (!sql.toLowerCase().contains('where') && tables.isNotEmpty) {
      improvements.add('Consider adding a WHERE clause to limit results');
    }
    
    // Create the insight
    final insight = SQLInsight(
      sql: sql,
      tables: tables,
      columns: columns,
      conditions: conditions,
      joins: joins,
      performance: performance,
      improvements: improvements,
    );
    
    return insight;
  }
}