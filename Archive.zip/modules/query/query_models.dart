

class QueryIntent {
  final String id;
  final String naturalLanguage;
  final String generatedSQL;
  final List<String> tables;
  final DateTime createdAt;
  final List<String> suggestedQueries;
  
  QueryIntent({
    required this.id,
    required this.naturalLanguage,
    required this.generatedSQL,
    required this.tables,
    required this.createdAt,
    this.suggestedQueries = const [],
  });
  
  factory QueryIntent.fromJson(Map<String, dynamic> json) {
    return QueryIntent(
      id: json['id'],
      naturalLanguage: json['naturalLanguage'],
      generatedSQL: json['generatedSQL'],
      tables: List<String>.from(json['tables']),
      createdAt: DateTime.parse(json['createdAt']),
      suggestedQueries: List<String>.from(json['suggestedQueries'] ?? []),
    );
  }
  
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'naturalLanguage': naturalLanguage,
      'generatedSQL': generatedSQL,
      'tables': tables,
      'createdAt': createdAt.toIso8601String(),
      'suggestedQueries': suggestedQueries,
    };
  }
}

class SQLInsight {
  final String sql;
  final List<String> tables;
  final List<String> columns;
  final List<String> conditions;
  final List<String> joins;
  final Map<String, dynamic> performance;
  final List<String> improvements;
  
  SQLInsight({
    required this.sql,
    required this.tables,
    required this.columns,
    required this.conditions,
    required this.joins,
    required this.performance,
    required this.improvements,
  });
  
  factory SQLInsight.fromJson(Map<String, dynamic> json) {
    return SQLInsight(
      sql: json['sql'],
      tables: List<String>.from(json['tables']),
      columns: List<String>.from(json['columns']),
      conditions: List<String>.from(json['conditions']),
      joins: List<String>.from(json['joins']),
      performance: json['performance'],
      improvements: List<String>.from(json['improvements']),
    );
  }
  
  Map<String, dynamic> toJson() {
    return {
      'sql': sql,
      'tables': tables,
      'columns': columns,
      'conditions': conditions,
      'joins': joins,
      'performance': performance,
      'improvements': improvements,
    };
  }
}