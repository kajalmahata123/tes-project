//File: modules/query/query_intent_analysis.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:uuid/uuid.dart';
import '../datasource/datasource_models.dart';
import '../datasource/datasource_service.dart';
import 'query_models.dart';
import 'query_service.dart';
import 'sql_insight_page.dart';

class QueryIntentAnalysisPage extends StatefulWidget {
  final String sourceId;
  final DatabaseSource source;

  const QueryIntentAnalysisPage({
    Key? key,
    required this.sourceId,
    required this.source,
  }) : super(key: key);

  @override
  State<QueryIntentAnalysisPage> createState() => _QueryIntentAnalysisPageState();
}

class _QueryIntentAnalysisPageState extends State<QueryIntentAnalysisPage> {
  final TextEditingController _queryController = TextEditingController();
  final TextEditingController _sqlController = TextEditingController();
  
  bool _isAnalyzing = false;
  bool _isLoading = true;
  QueryIntent? _currentQuery;
  List<QueryIntent> _recentQueries = [];
  List<String> _suggestedPrompts = [];
  
  @override
  void initState() {
    super.initState();
    _loadInitialData();
  }
  
  @override
  void dispose() {
    _queryController.dispose();
    _sqlController.dispose();
    super.dispose();
  }
  
  Future<void> _loadInitialData() async {
    setState(() {
      _isLoading = true;
    });
    
    try {
      // Load recent queries
      _recentQueries = await QueryService.getQueryHistory();
      
      // Generate suggested prompts based on the database schema
      _generateSuggestedPrompts();
      
      setState(() {
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error loading data: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }
  
  void _generateSuggestedPrompts() {
    // Create sample prompts based on the database schema
    final prompts = <String>[];
    
    if (widget.source.tables.isNotEmpty) {
      for (final table in widget.source.tables) {
        prompts.add('Show all ${table.name}');
        prompts.add('Count the number of ${table.name}');
        
        // Find interesting columns to create more specific prompts
        final numericColumns = table.columns.where(
          (col) => col.type.contains('int') || 
                   col.type.contains('decimal') || 
                   col.type.contains('float') || 
                   col.type.contains('double')
        ).toList();
        
        final dateColumns = table.columns.where(
          (col) => col.type.contains('date') || 
                   col.type.contains('time')
        ).toList();
        
        final stringColumns = table.columns.where(
          (col) => col.type.contains('varchar') || 
                   col.type.contains('text') || 
                   col.type.contains('char')
        ).toList();
        
        // Add specific prompts based on column types
        if (numericColumns.isNotEmpty) {
          prompts.add('Find the average ${numericColumns[0].name} of all ${table.name}');
          prompts.add('What is the maximum ${numericColumns[0].name} in ${table.name}?');
        }
        
        if (dateColumns.isNotEmpty) {
          prompts.add('Show ${table.name} created in the last 30 days');
          prompts.add('How many ${table.name} were added each month?');
        }
        
        if (stringColumns.isNotEmpty) {
          final statusCol = stringColumns.firstWhere(
            (col) => col.name.contains('status') || col.name.contains('state'),
            orElse: () => stringColumns.first,
          );
          prompts.add('Find all ${table.name} with ${statusCol.name} equal to "active"');
          prompts.add('Group ${table.name} by ${statusCol.name} and count them');
        }
      }
      
      // Add relationship-based prompts if we have multiple tables
      if (widget.source.tables.length >= 2) {
        final table1 = widget.source.tables[0].name;
        final table2 = widget.source.tables[1].name;
        prompts.add('Show all ${table1} with their related ${table2}');
        prompts.add('Find ${table1} that have no ${table2}');
      }
    }
    
    // Add some generic prompts
    prompts.add('List the top 10 most recent records');
    prompts.add('Show me data grouped by month');
    prompts.add('Find records with the highest value');
    
    // Shuffle and select a subset to display
    prompts.shuffle();
    _suggestedPrompts = prompts.take(5).toList();
  }
  
  Future<void> _analyzeQuery() async {
    final query = _queryController.text.trim();
    if (query.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please enter a query'),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }
    
    setState(() {
      _isAnalyzing = true;
      _currentQuery = null;
    });
    
    try {
      final result = await QueryService.generateSQL(widget.sourceId, query);
      
      setState(() {
        _isAnalyzing = false;
        _currentQuery = result;
        _sqlController.text = result.generatedSQL;
        
        // Refresh recent queries
        if (!_recentQueries.any((q) => q.id == result.id)) {
          _recentQueries.insert(0, result);
        }
      });
    } catch (e) {
      setState(() {
        _isAnalyzing = false;
      });
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error analyzing query: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }
  
  Future<void> _runQuery() async {
    if (_currentQuery == null || _sqlController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('No SQL query available to run'),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }
    
    // Navigate to SQL Insights page to run the query
    if (!mounted) return;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => SQLInsightPage(
          sourceId: widget.sourceId,
          source: widget.source,
          initialSQL: _sqlController.text,
        ),
      ),
    );
  }
  
  void _useSuggestedPrompt(String prompt) {
    setState(() {
      _queryController.text = prompt;
    });
    _analyzeQuery();
  }
  
  void _useSuggestedQuery(String sql) {
    setState(() {
      _sqlController.text = sql;
      
      // Create a new query intent for this suggested query
      if (_currentQuery != null) {
        _currentQuery = QueryIntent(
          id: const Uuid().v4(),
          naturalLanguage: _currentQuery!.naturalLanguage,
          generatedSQL: sql,
          tables: _currentQuery!.tables,
          createdAt: DateTime.now(),
          suggestedQueries: [],
        );
      }
    });
  }
  
  void _useHistoryQuery(QueryIntent query) {
    setState(() {
      _queryController.text = query.naturalLanguage;
      _sqlController.text = query.generatedSQL;
      _currentQuery = query;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Query Intent Analysis'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'Refresh',
            onPressed: _loadInitialData,
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Main content area
                  Expanded(
                    flex: 3,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Natural language query input
                        Card(
                          child: Padding(
                            padding: const EdgeInsets.all(16.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Icon(
                                      Icons.psychology,
                                      color: Theme.of(context).primaryColor,
                                    ),
                                    const SizedBox(width: 8),
                                    const Text(
                                      'Enter your query in natural language',
                                      style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 12),
                                TextField(
                                  controller: _queryController,
                                  decoration: const InputDecoration(
                                    hintText: 'e.g., "Show all customers who made a purchase last month"',
                                    border: OutlineInputBorder(),
                                    filled: true,
                                  ),
                                  maxLines: 3,
                                  enabled: !_isAnalyzing,
                                ),
                                const SizedBox(height: 16),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    ElevatedButton.icon(
                                      onPressed: _isAnalyzing ? null : _analyzeQuery,
                                      icon: const Icon(Icons.auto_awesome),
                                      label: const Text('Analyze'),
                                    ),
                                    if (_isAnalyzing)
                                      const Row(
                                        children: [
                                          SizedBox(
                                            width: 20,
                                            height: 20,
                                            child: CircularProgressIndicator(
                                              strokeWidth: 2,
                                            ),
                                          ),
                                          SizedBox(width: 8),
                                          Text('Analyzing...'),
                                        ],
                                      ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                        
                        const SizedBox(height: 16),
                        
                        // Suggested prompts
                        if (_suggestedPrompts.isNotEmpty)
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Suggested Prompts:',
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Wrap(
                                spacing: 8,
                                runSpacing: 8,
                                children: _suggestedPrompts.map((prompt) {
                                  return ActionChip(
                                    avatar: const Icon(Icons.lightbulb_outline, size: 16),
                                    label: Text(prompt),
                                    onPressed: () => _useSuggestedPrompt(prompt),
                                  );
                                }).toList(),
                              ),
                            ],
                          ),
                        
                        const SizedBox(height: 16),
                        
                        // Generated SQL
                        Expanded(
                          child: Card(
                            child: Padding(
                              padding: const EdgeInsets.all(16.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        children: [
                                          Icon(
                                            Icons.code,
                                            color: Theme.of(context).primaryColor,
                                          ),
                                          const SizedBox(width: 8),
                                          const Text(
                                            'Generated SQL',
                                            style: TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ],
                                      ),
                                      Row(
                                        children: [
                                          IconButton(
                                            icon: const Icon(Icons.content_copy, size: 20),
                                            tooltip: 'Copy SQL',
                                            onPressed: _sqlController.text.isEmpty
                                                ? null
                                                : () {
                                                    Clipboard.setData(
                                                      ClipboardData(text: _sqlController.text),
                                                    );
                                                    ScaffoldMessenger.of(context).showSnackBar(
                                                      const SnackBar(
                                                        content: Text('SQL copied to clipboard'),
                                                        duration: Duration(seconds: 1),
                                                      ),
                                                    );
                                                  },
                                          ),
                                          const SizedBox(width: 8),
                                          OutlinedButton.icon(
                                            icon: const Icon(Icons.play_arrow),
                                            label: const Text('Run Query'),
                                            onPressed: _sqlController.text.isEmpty ? null : _runQuery,
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 12),
                                  Expanded(
                                    child: TextField(
                                      controller: _sqlController,
                                      decoration: const InputDecoration(
                                        border: OutlineInputBorder(),
                                        filled: true,
                                        hintText: 'SQL will appear here after analysis',
                                      ),
                                      maxLines: null,
                                      expands: true,
                                      style: const TextStyle(
                                        fontFamily: 'monospace',
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        
                        // Suggested queries
                        if (_currentQuery != null && _currentQuery!.suggestedQueries.isNotEmpty)
                          Padding(
                            padding: const EdgeInsets.only(top: 16.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  'Suggested Queries:',
                                  style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Container(
                                  height: 120,
                                  decoration: BoxDecoration(
                                    color: Colors.grey.shade100,
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: ListView.separated(
                                    padding: const EdgeInsets.all(8),
                                    itemCount: _currentQuery!.suggestedQueries.length,
                                    separatorBuilder: (context, index) => const Divider(),
                                    itemBuilder: (context, index) {
                                      final query = _currentQuery!.suggestedQueries[index];
                                      return ListTile(
                                        dense: true,
                                        title: Text(
                                          query,
                                          style: const TextStyle(
                                            fontFamily: 'monospace',
                                            fontSize: 12,
                                          ),
                                        ),
                                        trailing: IconButton(
                                          icon: const Icon(Icons.add, size: 18),
                                          tooltip: 'Use this query',
                                          onPressed: () => _useSuggestedQuery(query),
                                        ),
                                      );
                                    },
                                  ),
                                ),
                              ],
                            ),
                          ),
                      ],
                    ),
                  ),
                  
                  const SizedBox(width: 16),
                  
                  // Sidebar - Query history
                  Expanded(
                    flex: 1,
                    child: Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Icon(
                                  Icons.history,
                                  color: Theme.of(context).primaryColor,
                                ),
                                const SizedBox(width: 8),
                                const Text(
                                  'Recent Queries',
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 16),
                            Expanded(
                              child: _recentQueries.isEmpty
                                  ? Center(
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Icon(
                                            Icons.history_toggle_off,
                                            size: 48,
                                            color: Colors.grey.shade400,
                                          ),
                                          const SizedBox(height: 16),
                                          const Text(
                                            'No query history yet',
                                            textAlign: TextAlign.center,
                                            style: TextStyle(color: Colors.grey),
                                          ),
                                        ],
                                      ),
                                    )
                                  : ListView.builder(
                                      itemCount: _recentQueries.length,
                                      itemBuilder: (context, index) {
                                        final query = _recentQueries[index];
                                        return ListTile(
                                          title: Text(
                                            query.naturalLanguage,
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                            style: const TextStyle(fontSize: 14),
                                          ),
                                          subtitle: Text(
                                            _formatDate(query.createdAt),
                                            style: TextStyle(
                                              fontSize: 12,
                                              color: Colors.grey.shade600,
                                            ),
                                          ),
                                          onTap: () => _useHistoryQuery(query),
                                          dense: true,
                                        );
                                      },
                                    ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }
  
  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);
    
    if (difference.inDays > 0) {
      return '${difference.inDays}d ago';
    } else if (difference.inHours > 0) {
      return '${difference.inHours}h ago';
    } else if (difference.inMinutes > 0) {
      return '${difference.inMinutes}m ago';
    } else {
      return 'Just now';
    }
  }
}

//File: modules/query/sql_insight_page.dart
