import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../datasource/datasource_models.dart';
import 'query_models.dart';
import 'query_service.dart';

class SQLInsightPage extends StatefulWidget {
  final String sourceId;
  final DatabaseSource source;
  final String initialSQL;
  
  const SQLInsightPage({
    Key? key,
    required this.sourceId,
    required this.source,
    required this.initialSQL,
  }) : super(key: key);
  
  @override
  State<SQLInsightPage> createState() => _SQLInsightPageState();
}

class _SQLInsightPageState extends State<SQLInsightPage> {
  late final TextEditingController _sqlController;
  bool _isAnalyzing = false;
  bool _isExecuting = false;
  SQLInsight? _sqlInsight;
  List<Map<String, dynamic>>? _queryResults;
  String? _errorMessage;
  
  @override
  void initState() {
    super.initState();
    _sqlController = TextEditingController(text: widget.initialSQL);
    _analyzeSQL();
  }
  
  @override
  void dispose() {
    _sqlController.dispose();
    super.dispose();
  }
  
  Future<void> _analyzeSQL() async {
    final sql = _sqlController.text.trim();
    if (sql.isEmpty) {
      setState(() {
        _errorMessage = 'Please enter a SQL query';
      });
      return;
    }
    
    setState(() {
      _isAnalyzing = true;
      _sqlInsight = null;
      _errorMessage = null;
    });
    
    try {
      // This would be a real service call in a production app
      // For demo, we'll create a mock insight
      await Future.delayed(const Duration(seconds: 1));
      
      // Extract tables
      final tableRegex = RegExp(r'FROM\s+([^\s,;]+)|JOIN\s+([^\s,;]+)', caseSensitive: false);
      final tableMatches = tableRegex.allMatches(sql);
      final tables = tableMatches
          .map((m) => m.group(1) ?? m.group(2))
          .where((t) => t != null)
          .map((t) => t!)
          .toList();
      
      // Extract columns
      final columnRegex = RegExp(r'SELECT\s+(.*?)\s+FROM', caseSensitive: false);
      final columnMatch = columnRegex.firstMatch(sql);
      final columnsStr = columnMatch?.group(1) ?? '*';
      final columns = columnsStr == '*'
          ? ['*']
          : columnsStr
              .split(',')
              .map((c) => c.trim())
              .toList();
      
      // Extract conditions
      final whereRegex = RegExp(r'WHERE\s+(.*?)(?:ORDER BY|GROUP BY|LIMIT|;|$)', caseSensitive: false);
      final whereMatch = whereRegex.firstMatch(sql);
      final conditions = whereMatch != null
          ? [whereMatch.group(1)!.trim()]
          : <String>[];
      
      // Extract joins
      final joinRegex = RegExp(r'(INNER|LEFT|RIGHT|FULL)?\s*JOIN\s+([^\s]+)\s+ON\s+(.*?)(?:WHERE|ORDER BY|GROUP BY|LIMIT|;|$)', caseSensitive: false);
      final joinMatches = joinRegex.allMatches(sql);
      final joins = joinMatches
          .map((m) => '${m.group(1) ?? 'INNER'} JOIN ${m.group(2)} ON ${m.group(3)}')
          .toList();
      
      // Create performance data
      final performance = {
        'estimatedRows': 1000,
        'estimatedCost': 2.5,
        'indexUsage': tables.isNotEmpty ? {'${tables[0]}_pkey': 'Used'} : {},
        'scanType': 'Index Scan',
      };
      
      // Create improvement suggestions
      final improvements = <String>[];
      
      if (columns.contains('*')) {
        improvements.add('Select specific columns instead of "*" to improve performance');
      }
      
      if (!sql.toLowerCase().contains('where') && tables.isNotEmpty) {
        improvements.add('Consider adding a WHERE clause to limit results');
      }
      
      if (!sql.toLowerCase().contains('limit') && !sql.toLowerCase().contains('top')) {
        improvements.add('Add a LIMIT clause to restrict the number of rows returned');
      }
      
      if (conditions.isNotEmpty && !sql.toLowerCase().contains('index')) {
        improvements.add('Ensure columns in WHERE clause are indexed');
      }
      
      // Create the insight
      final insight = SQLInsight(
        sql: sql,
        tables: tables,
        columns: columns,
        conditions: conditions,
        joins: joins,
        performance: performance,
        improvements: improvements,
      );
      
      setState(() {
        _sqlInsight = insight;
        _isAnalyzing = false;
      });
      
      // Execute the query
      _executeQuery();
    } catch (e) {
      setState(() {
        _isAnalyzing = false;
        _errorMessage = 'Error analyzing SQL: ${e.toString()}';
      });
    }
  }
  
  Future<void> _executeQuery() async {
    final sql = _sqlController.text.trim();
    if (sql.isEmpty) return;
    
    setState(() {
      _isExecuting = true;
      _queryResults = null;
      _errorMessage = null;
    });
    
    try {
      // In a real app, this would execute the query against the database
      // For demo purposes, we'll return mock results
      await Future.delayed(const Duration(seconds: 1));
      
      // Generate mock results based on SQL
      final results = <Map<String, dynamic>>[];
      
      // Check if this is a SELECT query
      if (sql.trim().toUpperCase().startsWith('SELECT')) {
        // Parse SQL to extract table and maybe conditions
        final tableName = _extractTableName(sql);
        
        if (tableName != null) {
          // Try to find table in schema
          final tableSchema = widget.source.tables.firstWhere(
            (t) => t.name.toLowerCase() == tableName.toLowerCase(),
            orElse: () => widget.source.tables.isNotEmpty 
                ? widget.source.tables.first 
                : DatabaseTable(name: 'unknown', columns: []),
          );
          
          // Generate mock data based on columns
          final columnNames = tableSchema.columns.map((c) => c.name).toList();
          
          // Add sample rows
          final rowCount = sql.toUpperCase().contains('LIMIT')
              ? int.tryParse(sql.toUpperCase().split('LIMIT')[1].trim().split(' ').first) ?? 10
              : 10;
          
          for (var i = 0; i < rowCount; i++) {
            final row = <String, dynamic>{};
            
            for (final column in tableSchema.columns) {
              row[column.name] = _generateMockValue(column, i);
            }
            
            results.add(row);
          }
        } else {
          // Fallback for complex queries
          results.add({'result': 'Query executed successfully'});
        }
      } else if (sql.trim().toUpperCase().startsWith('INSERT') ||
                 sql.trim().toUpperCase().startsWith('UPDATE') ||
                 sql.trim().toUpperCase().startsWith('DELETE')) {
        // For DML queries, return affected rows
        results.add({'affected_rows': 5});
      } else {
        // For other queries (like DDL), return a generic message
        results.add({'result': 'Query executed successfully'});
      }
      
      setState(() {
        _queryResults = results;
        _isExecuting = false;
      });
    } catch (e) {
      setState(() {
        _isExecuting = false;
        _errorMessage = 'Error executing query: ${e.toString()}';
      });
    }
  }
  
  String? _extractTableName(String sql) {
    // Simple regex to extract table name from basic SELECT queries
    final regex = RegExp(r'FROM\s+([^\s,;]+)', caseSensitive: false);
    final match = regex.firstMatch(sql);
    return match?.group(1);
  }
  
  dynamic _generateMockValue(DatabaseColumn column, int rowIndex) {
    if (column.isPrimaryKey) {
      return rowIndex + 1;
    }
    
    if (column.name.contains('id')) {
      return rowIndex + 100;
    }
    
    if (column.type.contains('int')) {
      return (rowIndex + 1) * 10;
    }
    
    if (column.type.contains('decimal') || column.type.contains('float')) {
      return (rowIndex + 1) * 10.5;
    }
    
    if (column.type.contains('date') || column.type.contains('time')) {
      final now = DateTime.now();
      return now.subtract(Duration(days: rowIndex)).toString().substring(0, 10);
    }
    
    if (column.name.contains('name')) {
      return 'Name ${rowIndex + 1}';
    }
    
    if (column.name.contains('email')) {
      return 'user${rowIndex + 1}@example.com';
    }
    
    if (column.name.contains('status')) {
      final statuses = ['active', 'inactive', 'pending'];
      return statuses[rowIndex % statuses.length];
    }
    
    return 'Value ${rowIndex + 1}';
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('SQL Insights'),
        actions: [
          IconButton(
            icon: const Icon(Icons.analytics),
            tooltip: 'Analyze SQL',
            onPressed: _isAnalyzing ? null : _analyzeSQL,
          ),
          IconButton(
            icon: const Icon(Icons.play_arrow),
            tooltip: 'Execute Query',
            onPressed: _isExecuting ? null : _executeQuery,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // SQL Editor
            SizedBox(
              height: 150,
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Icon(
                                Icons.code,
                                color: Theme.of(context).primaryColor,
                              ),
                              const SizedBox(width: 8),
                              const Text(
                                'SQL Query',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),//File: modules/query/sql_insight_page.dart (Continued)

                              ),
                            ],
                          ),
                          IconButton(
                            icon: const Icon(Icons.content_copy, size: 20),
                            tooltip: 'Copy SQL',
                            onPressed: () {
                              Clipboard.setData(
                                ClipboardData(text: _sqlController.text),
                              );
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('SQL copied to clipboard'),
                                  duration: Duration(seconds: 1),
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Expanded(
                        child: TextField(
                          controller: _sqlController,
                          decoration: const InputDecoration(
                            border: OutlineInputBorder(),
                            filled: true,
                            hintText: 'Enter your SQL query here',
                          ),
                          maxLines: null,
                          expands: true,
                          style: const TextStyle(
                            fontFamily: 'monospace',
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            
            const SizedBox(height: 16),
            
            // Analysis and Results Tabs
            Expanded(
              child: DefaultTabController(
                length: 2,
                child: Column(
                  children: [
                    const TabBar(
                      tabs: [
                        Tab(text: 'Results'),
                        Tab(text: 'SQL Insights'),
                      ],
                      indicatorColor: Colors.blue,
                      labelColor: Colors.blue,
                      unselectedLabelColor: Colors.grey,
                    ),
                    Expanded(
                      child: TabBarView(
                        children: [
                          // Query Results Tab
                          _buildResultsTab(),
                          
                          // SQL Insights Tab
                          _buildInsightsTab(),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _isExecuting || _isAnalyzing ? null : () {
          _analyzeSQL();
          _executeQuery();
        },
        tooltip: 'Run and Analyze',
        child: const Icon(Icons.bolt),
        backgroundColor: _isExecuting || _isAnalyzing 
            ? Colors.grey 
            : Theme.of(context).primaryColor,
      ),
    );
  }
  
  Widget _buildResultsTab() {
    if (_isExecuting) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 16),
            Text('Executing query...'),
          ],
        ),
      );
    }
    
    if (_errorMessage != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline, size: 48, color: Colors.red.shade300),
            const SizedBox(height: 16),
            Text(
              _errorMessage!,
              style: TextStyle(color: Colors.red.shade700),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _executeQuery,
              child: const Text('Try Again'),
            ),
          ],
        ),
      );
    }
    
    if (_queryResults == null) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.table_chart, size: 48, color: Colors.grey),
            SizedBox(height: 16),
            Text(
              'No results yet',
              style: TextStyle(color: Colors.grey),
            ),
            SizedBox(height: 8),
            Text(
              'Run a query to see results',
              style: TextStyle(color: Colors.grey),
            ),
          ],
        ),
      );
    }
    
    if (_queryResults!.isEmpty) {
      return const Center(
        child: Text('Query returned no results'),
      );
    }
    
    // Check if this is a result set or a status message
    if (_queryResults!.first.containsKey('affected_rows') || 
        _queryResults!.first.containsKey('result')) {
      // Show status message
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.check_circle, size: 48, color: Colors.green),
            const SizedBox(height: 16),
            if (_queryResults!.first.containsKey('affected_rows'))
              Text(
                'Query executed successfully\n${_queryResults!.first['affected_rows']} rows affected',
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 16),
              )
            else
              Text(
                _queryResults!.first['result'],
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 16),
              ),
          ],
        ),
      );
    }
    
    // Show result set in a table
    final columns = _queryResults!.first.keys.toList();
    
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Results (${_queryResults!.length} rows)',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.download, size: 20),
                  tooltip: 'Export Results',
                  onPressed: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Export feature would be implemented here'),
                      ),
                    );
                  },
                ),
              ],
            ),
            const SizedBox(height: 16),
            Expanded(
              child: SingleChildScrollView(
                scrollDirection: Axis.vertical,
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: DataTable(
                    columns: columns.map<DataColumn>((column) {
                      return DataColumn(
                        label: Text(
                          column,
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                      );
                    }).toList(),
                    rows: _queryResults!.map<DataRow>((row) {
                      return DataRow(
                        cells: columns.map<DataCell>((column) {
                          return DataCell(
                            Text(row[column]?.toString() ?? 'NULL'),
                          );
                        }).toList(),
                      );
                    }).toList(),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildInsightsTab() {
    if (_isAnalyzing) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 16),
            Text('Analyzing query...'),
          ],
        ),
      );
    }
    
    if (_errorMessage != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline, size: 48, color: Colors.red.shade300),
            const SizedBox(height: 16),
            Text(
              _errorMessage!,
              style: TextStyle(color: Colors.red.shade700),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _analyzeSQL,
              child: const Text('Try Again'),
            ),
          ],
        ),
      );
    }
    
    if (_sqlInsight == null) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.insights, size: 48, color: Colors.grey),
            SizedBox(height: 16),
            Text(
              'No SQL analysis yet',
              style: TextStyle(color: Colors.grey),
            ),
            SizedBox(height: 8),
            Text(
              'Analyze a query to see insights',
              style: TextStyle(color: Colors.grey),
            ),
          ],
        ),
      );
    }
    
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Query Overview Card
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Query Overview',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 16),
                  
                  // Tables Used
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(
                        width: 120,
                        child: Text(
                          'Tables:',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ),
                      Expanded(
                        child: _sqlInsight!.tables.isEmpty
                            ? const Text('No tables detected')
                            : Wrap(
                                spacing: 8.0,
                                runSpacing: 4.0,
                                children: _sqlInsight!.tables.map((table) {
                                  return Chip(
                                    label: Text(table),
                                    backgroundColor: Colors.blue.shade50,
                                    labelStyle: TextStyle(color: Colors.blue.shade700),
                                  );
                                }).toList(),
                              ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  
                  // Columns Used
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(
                        width: 120,
                        child: Text(
                          'Columns:',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ),
                      Expanded(
                        child: _sqlInsight!.columns.isEmpty
                            ? const Text('No columns detected')
                            : Wrap(
                                spacing: 8.0,
                                runSpacing: 4.0,
                                children: _sqlInsight!.columns.map((column) {
                                  return Chip(
                                    label: Text(column),
                                    backgroundColor: Colors.green.shade50,
                                    labelStyle: TextStyle(color: Colors.green.shade700),
                                  );
                                }).toList(),
                              ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  
                  // Conditions
                  if (_sqlInsight!.conditions.isNotEmpty) ...[
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(
                          width: 120,
                          child: Text(
                            'Conditions:',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: _sqlInsight!.conditions.map((condition) {
                              return Padding(
                                padding: const EdgeInsets.only(bottom: 4.0),
                                child: Text(condition),
                              );
                            }).toList(),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                  ],
                  
                  // Joins
                  if (_sqlInsight!.joins.isNotEmpty) ...[
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(
                          width: 120,
                          child: Text(
                            'Joins:',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: _sqlInsight!.joins.map((join) {
                              return Padding(
                                padding: const EdgeInsets.only(bottom: 4.0),
                                child: Text(join),
                              );
                            }).toList(),
                          ),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
            ),
          ),
          
          const SizedBox(height: 16),
          
          // Performance Insights Card
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Performance Insights',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 16),
                  
                  // Performance metrics
                  Table(
                    columnWidths: const {
                      0: FlexColumnWidth(1.5),
                      1: FlexColumnWidth(2),
                    },
                    children: [
                      TableRow(
                        children: [
                          const Padding(
                            padding: EdgeInsets.symmetric(vertical: 4.0),
                            child: Text(
                              'Estimated Rows:',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(vertical: 4.0),
                            child: Text(
                              _sqlInsight!.performance['estimatedRows'].toString(),
                            ),
                          ),
                        ],
                      ),
                      TableRow(
                        children: [
                          const Padding(
                            padding: EdgeInsets.symmetric(vertical: 4.0),
                            child: Text(
                              'Estimated Cost:',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(vertical: 4.0),
                            child: Text(
                              _sqlInsight!.performance['estimatedCost'].toString(),
                            ),
                          ),
                        ],
                      ),
                      TableRow(
                        children: [
                          const Padding(
                            padding: EdgeInsets.symmetric(vertical: 4.0),
                            child: Text(
                              'Scan Type:',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(vertical: 4.0),
                            child: Text(
                              _sqlInsight!.performance['scanType'].toString(),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  
                  const SizedBox(height: 16),
                  
                  // Index Usage
                  const Text(
                    'Index Usage:',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: (_sqlInsight!.performance['indexUsage'] as Map<String, dynamic>)
                        .entries
                        .map((entry) {
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 4.0),
                        child: Row(
                          children: [
                            Text(entry.key),
                            const SizedBox(width: 8),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                              decoration: BoxDecoration(
                                color: Colors.green.shade50,
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: Text(
                                entry.value,
                                style: TextStyle(
                                  color: Colors.green.shade700,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    }).toList(),
                  ),
                ],
              ),
            ),
          ),
          
          const SizedBox(height: 16),
          
          // Improvement Suggestions Card
          if (_sqlInsight!.improvements.isNotEmpty)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(
                          Icons.lightbulb,
                          color: Colors.amber.shade700,
                        ),
                        const SizedBox(width: 8),
                        const Text(
                          'Improvement Suggestions',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    
                    // Suggestions list
                    ListView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: _sqlInsight!.improvements.length,
                      itemBuilder: (context, index) {
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 8.0),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Icon(
                                Icons.arrow_right,
                                color: Colors.amber.shade700,
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(_sqlInsight!.improvements[index]),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}