import 'package:flutter/material.dart';
import 'datasource_models.dart';
import 'datasource_service.dart';
import 'datasource_detail_page.dart';

class DatasourceListPage extends StatefulWidget {
  const DatasourceListPage({Key? key}) : super(key: key);

  @override
  State<DatasourceListPage> createState() => _DatasourceListPageState();
}

class _DatasourceListPageState extends State<DatasourceListPage> {
  bool _isLoading = true;
  List<DatabaseSource> _sources = [];
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _loadDatasources();
  }

  Future<void> _loadDatasources() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final sources = await DatasourceService.getSources();
      setState(() {
        _sources = sources;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = 'Failed to load data sources: ${e.toString()}';
        _isLoading = false;
      });
    }
  }

  void _navigateToAddDatasource() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const DatasourceDetailPage(isNew: true),
      ),
    ).then((_) => _loadDatasources());
  }

  void _navigateToEditDatasource(DatabaseSource source) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => DatasourceDetailPage(
          isNew: false,
          source: source,
        ),
      ),
    ).then((_) => _loadDatasources());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Data Sources'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'Refresh',
            onPressed: _loadDatasources,
          ),
        ],
      ),
      body: _buildBody(),
      floatingActionButton: FloatingActionButton(
        onPressed: _navigateToAddDatasource,
        tooltip: 'Add Data Source',
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_errorMessage != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline, size: 48, color: Colors.red.shade300),
            const SizedBox(height: 16),
            Text(
              _errorMessage!,
              style: TextStyle(color: Colors.red.shade700),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _loadDatasources,
              child: const Text('Try Again'),
            ),
          ],
        ),
      );
    }

    if (_sources.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.dataset, size: 64, color: Colors.grey),
            const SizedBox(height: 16),
            const Text(
              'No data sources found',
              style: TextStyle(fontSize: 18, color: Colors.grey),
            ),
            const SizedBox(height: 8),
            const Text(
              'Add a data source to get started',
              style: TextStyle(color: Colors.grey),
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: _navigateToAddDatasource,
              icon: const Icon(Icons.add),
              label: const Text('Add Data Source'),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _sources.length,
      itemBuilder: (context, index) {
        final source = _sources[index];
        return Card(
          margin: const EdgeInsets.only(bottom: 16),
          child: InkWell(
            onTap: () => _navigateToEditDatasource(source),
            borderRadius: BorderRadius.circular(8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ListTile(
                  leading: CircleAvatar(
                    backgroundColor: source.type.color.withOpacity(0.2),
                    child: Icon(source.type.icon, color: source.type.color),
                  ),
                  title: Text(source.name),
                  subtitle: Text(source.type.name),
                  trailing: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: source.connectionStatus == 'Connected'
                          ? Colors.green.withOpacity(0.2)
                          : Colors.grey.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      source.connectionStatus ?? 'Unknown',
                      style: TextStyle(
                        color: source.connectionStatus == 'Connected'
                            ? Colors.green.shade700
                            : Colors.grey.shade700,
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        source.displayConnectionString,
                        style: TextStyle(
                          fontFamily: 'monospace',
                          fontSize: 12,
                          color: Colors.grey.shade700,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Icon(Icons.table_chart, size: 16, color: Colors.grey.shade600),
                          const SizedBox(width: 4),
                          Text(
                            '${source.tables.length} tables',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.grey.shade600,
                            ),
                          ),
                          const SizedBox(width: 16),
                          if (source.lastConnected != null) ...[
                            Icon(Icons.access_time, size: 16, color: Colors.grey.shade600),
                            const SizedBox(width: 4),
                            Text(
                              'Last connected: ${_formatDate(source.lastConnected!)}',
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.grey.shade600,
                              ),
                            ),
                          ],
                        ],
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      TextButton.icon(
                        icon: const Icon(Icons.link, size: 16),
                        label: const Text('Test Connection'),
                        onPressed: () => _testConnection(source),
                      ),
                      TextButton.icon(
                        icon: const Icon(Icons.schema, size: 16),
                        label: const Text('Import Schema'),
                        onPressed: () => _importSchema(source),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);

    if (difference.inDays > 0) {
      return '${difference.inDays}d ago';
    } else if (difference.inHours > 0) {
      return '${difference.inHours}h ago';
    } else if (difference.inMinutes > 0) {
      return '${difference.inMinutes}m ago';
    } else {
      return 'Just now';
    }
  }

  Future<void> _testConnection(DatabaseSource source) async {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => const AlertDialog(
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 16),
            Text('Testing connection...'),
          ],
        ),
      ),
    );

    try {
      final success = await DatasourceService.testConnection(source);
      
      if (!mounted) return;
      Navigator.of(context).pop();
      
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text(success ? 'Connection Successful' : 'Connection Failed'),
          content: Text(
            success
                ? 'Successfully connected to ${source.name}'
                : 'Could not connect to ${source.name}. Please check your connection details.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('OK'),
            ),
          ],
        ),
      );
      
      if (success) {
        source.connectionStatus = 'Connected';
        source.lastConnected = DateTime.now();
        await DatasourceService.updateSource(source);
        _loadDatasources();
      }
    } catch (e) {
      if (!mounted) return;
      Navigator.of(context).pop();
      
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Error'),
          content: Text('An error occurred: ${e.toString()}'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('OK'),
            ),
          ],
        ),
      );
    }
  }

  Future<void> _importSchema(DatabaseSource source) async {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => const AlertDialog(
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 16),
            Text('Importing schema...'),
          ],
        ),
      ),
    );

    try {
      final tables = await DatasourceService.importSchema(source.id);
      
      if (!mounted) return;
      Navigator.of(context).pop();
      
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Schema Imported'),
          content: Text('Successfully imported ${tables.length} tables from ${source.name}'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('OK'),
            ),
          ],
        ),
      );
      
      _loadDatasources();
    } catch (e) {
      if (!mounted) return;
      Navigator.of(context).pop();
      
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Error'),
          content: Text('An error occurred: ${e.toString()}'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('OK'),
            ),
          ],
        ),
      );
    }
  }
}

