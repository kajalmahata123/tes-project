
import 'package:flutter/material.dart';

enum DatabaseType {
  mysql,
  postgresql,
  sqlserver,
  oracle,
  sqlite,
}

extension DatabaseTypeExtension on DatabaseType {
  String get name {
    switch (this) {
      case DatabaseType.mysql:
        return 'MySQL';
      case DatabaseType.postgresql:
        return 'PostgreSQL';
      case DatabaseType.sqlserver:
        return 'SQL Server';
      case DatabaseType.oracle:
        return 'Oracle';
      case DatabaseType.sqlite:
        return 'SQLite';
    }
  }
  
  IconData get icon {
    switch (this) {
      case DatabaseType.mysql:
        return Icons.storage;
      case DatabaseType.postgresql:
        return Icons.storage;
      case DatabaseType.sqlserver:
        return Icons.storage;
      case DatabaseType.oracle:
        return Icons.storage;
      case DatabaseType.sqlite:
        return Icons.phone_android;
    }
  }
  
  Color get color {
    switch (this) {
      case DatabaseType.mysql:
        return Colors.orange;
      case DatabaseType.postgresql:
        return Colors.blue;
      case DatabaseType.sqlserver:
        return Colors.red;
      case DatabaseType.oracle:
        return Colors.red.shade800;
      case DatabaseType.sqlite:
        return Colors.teal;
    }
  }
}

class DatabaseSource {
  final String id;
  final String name;
  final DatabaseType type;
  final String host;
  final int port;
  final String username;
  final String password;
  final String database;
  String? connectionStatus;
  final DateTime createdAt;
  DateTime? lastConnected;
  List<DatabaseTable> tables;
  
  DatabaseSource({
    required this.id,
    required this.name,
    required this.type,
    required this.host,
    required this.port,
    required this.username,
    required this.password,
    required this.database,
    this.connectionStatus,
    required this.createdAt,
    this.lastConnected,
    this.tables = const [],
  });
  
  factory DatabaseSource.fromJson(Map<String, dynamic> json) {
    return DatabaseSource(
      id: json['id'],
      name: json['name'],
      type: DatabaseType.values.firstWhere(
        (e) => e.name == json['type'],
        orElse: () => DatabaseType.mysql,
      ),
      host: json['host'],
      port: json['port'],
      username: json['username'],
      password: json['password'],
      database: json['database'],
      connectionStatus: json['connectionStatus'],
      createdAt: DateTime.parse(json['createdAt']),
      lastConnected: json['lastConnected'] != null
          ? DateTime.parse(json['lastConnected'])
          : null,
      tables: (json['tables'] as List?)
              ?.map((table) => DatabaseTable.fromJson(table))
              .toList() ??
          [],
    );
  }
  
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'type': type.name,
      'host': host,
      'port': port,
      'username': username,
      'password': password,
      'database': database,
      'connectionStatus': connectionStatus,
      'createdAt': createdAt.toIso8601String(),
      'lastConnected': lastConnected?.toIso8601String(),
      'tables': tables.map((table) => table.toJson()).toList(),
    };
  }
  
  String get displayConnectionString {
    switch (type) {
      case DatabaseType.mysql:
        return 'jdbc:mysql://$host:$port/$database';
      case DatabaseType.postgresql:
        return 'jdbc:postgresql://$host:$port/$database';
      case DatabaseType.sqlserver:
        return 'jdbc:sqlserver://$host:$port;databaseName=$database';
      case DatabaseType.oracle:
        return 'jdbc:oracle:thin:@$host:$port/$database';
      case DatabaseType.sqlite:
        return 'jdbc:sqlite:$database';
    }
  }
}

class DatabaseTable {
  final String name;
  final List<DatabaseColumn> columns;
  
  DatabaseTable({
    required this.name,
    required this.columns,
  });
  
  factory DatabaseTable.fromJson(Map<String, dynamic> json) {
    return DatabaseTable(
      name: json['name'],
      columns: (json['columns'] as List)
          .map((column) => DatabaseColumn.fromJson(column))
          .toList(),
    );
  }
  
  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'columns': columns.map((column) => column.toJson()).toList(),
    };
  }
}

class DatabaseColumn {
  final String name;
  final String type;
  final bool isPrimaryKey;
  final bool isNullable;
  final String? defaultValue;
  
  DatabaseColumn({
    required this.name,
    required this.type,
    this.isPrimaryKey = false,
    this.isNullable = true,
    this.defaultValue,
  });
  
  factory DatabaseColumn.fromJson(Map<String, dynamic> json) {
    return DatabaseColumn(
      name: json['name'],
      type: json['type'],
      isPrimaryKey: json['isPrimaryKey'] ?? false,
      isNullable: json['isNullable'] ?? true,
      defaultValue: json['defaultValue'],
    );
  }
  
  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'type': type,
      'isPrimaryKey': isPrimaryKey,
      'isNullable': isNullable,
      'defaultValue': defaultValue,
    };
  }
}