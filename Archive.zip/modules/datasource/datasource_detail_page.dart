//File: modules/datasource/datasource_detail_page.dart
import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import 'datasource_models.dart';
import 'datasource_service.dart';

class DatasourceDetailPage extends StatefulWidget {
  final bool isNew;
  final DatabaseSource? source;

  const DatasourceDetailPage({
    Key? key,
    required this.isNew,
    this.source,
  }) : super(key: key);

  @override
  State<DatasourceDetailPage> createState() => _DatasourceDetailPageState();
}

class _DatasourceDetailPageState extends State<DatasourceDetailPage> {
  final _formKey = GlobalKey<FormState>();
  
  late final TextEditingController _nameController;
  late DatabaseType _selectedType;
  late final TextEditingController _hostController;
  late final TextEditingController _portController;
  late final TextEditingController _usernameController;
  late final TextEditingController _passwordController;
  late final TextEditingController _databaseController;
  
  bool _isLoading = false;
  bool _isPasswordVisible = false;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    
    // Initialize controllers with existing values or defaults
    _nameController = TextEditingController(text: widget.source?.name ?? '');
    _selectedType = widget.source?.type ?? DatabaseType.mysql;
    _hostController = TextEditingController(text: widget.source?.host ?? 'localhost');
    _portController = TextEditingController(
      text: widget.source?.port.toString() ?? _getDefaultPort(_selectedType).toString(),
    );
    _usernameController = TextEditingController(text: widget.source?.username ?? '');
    _passwordController = TextEditingController(text: widget.source?.password ?? '');
    _databaseController = TextEditingController(text: widget.source?.database ?? '');
  }

  @override
  void dispose() {
    _nameController.dispose();
    _hostController.dispose();
    _portController.dispose();
    _usernameController.dispose();
    _passwordController.dispose();
    _databaseController.dispose();
    super.dispose();
  }

  int _getDefaultPort(DatabaseType type) {
    switch (type) {
      case DatabaseType.mysql:
        return 3306;
      case DatabaseType.postgresql:
        return 5432;
      case DatabaseType.sqlserver:
        return 1433;
      case DatabaseType.oracle:
        return 1521;
      case DatabaseType.sqlite:
        return 0; // Not applicable for SQLite
    }
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }
    
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });
    
    try {
      final int port = int.tryParse(_portController.text) ?? _getDefaultPort(_selectedType);
      
      final source = DatabaseSource(
        id: widget.source?.id ?? const Uuid().v4(),
        name: _nameController.text.trim(),
        type: _selectedType,
        host: _hostController.text.trim(),
        port: port,
        username: _usernameController.text.trim(),
        password: _passwordController.text,
        database: _databaseController.text.trim(),
        connectionStatus: widget.source?.connectionStatus,
        createdAt: widget.source?.createdAt ?? DateTime.now(),
        lastConnected: widget.source?.lastConnected,
        tables: widget.source?.tables ?? [],
      );
      
      if (widget.isNew) {
        await DatasourceService.addSource(source);
      } else {
        await DatasourceService.updateSource(source);
      }
      
      if (!mounted) return;
      Navigator.of(context).pop();
    } catch (e) {
      setState(() {
        _errorMessage = 'Failed to save data source: ${e.toString()}';
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.isNew ? 'Add Data Source' : 'Edit Data Source'),
        actions: [
          if (!widget.isNew)
            IconButton(
              icon: const Icon(Icons.delete),
              tooltip: 'Delete',
              onPressed: _confirmDelete,
            ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (_errorMessage != null)
                Container(
                  padding: const EdgeInsets.all(12),
                  margin: const EdgeInsets.only(bottom: 16),
                  decoration: BoxDecoration(
                    color: Colors.red.shade50,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.red.shade200),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.error_outline, color: Colors.red.shade700),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          _errorMessage!,
                          style: TextStyle(color: Colors.red.shade700),
                        ),
                      ),
                    ],
                  ),
                ),
              
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Name field
                      TextFormField(
                        controller: _nameController,
                        decoration: const InputDecoration(
                          labelText: 'Name',
                          hintText: 'Enter a name for this data source',
                          border: OutlineInputBorder(),
                        ),
                        validator: (value) {
                          if (value == null || value.trim().isEmpty) {
                            return 'Name is required';
                          }
                          return null;
                        },
                        enabled: !_isLoading,
                      ),
                      
                      const SizedBox(height: 16),
                      
                      // Database type
                      DropdownButtonFormField<DatabaseType>(
                        value: _selectedType,
                        decoration: const InputDecoration(
                          labelText: 'Database Type',
                          border: OutlineInputBorder(),
                        ),
                        items: DatabaseType.values.map((type) {
                          return DropdownMenuItem<DatabaseType>(
                            value: type,
                            child: Row(
                              children: [
                                Icon(type.icon, color: type.color, size: 20),
                                const SizedBox(width: 10),
                                Text(type.name),
                              ],
                            ),
                          );
                        }).toList(),
                        onChanged: _isLoading
                            ? null
                            : (value) {
                                if (value != null) {
                                  setState(() {
                                    _selectedType = value;
                                    _portController.text = _getDefaultPort(value).toString();
                                  });
                                }
                              },
                      ),
                      
                      const SizedBox(height: 16),
                      
                      if (_selectedType != DatabaseType.sqlite) ...[
                        // Host field
                        TextFormField(
                          controller: _hostController,
                          decoration: const InputDecoration(
                            labelText: 'Host',
                            hintText: 'Enter the database host',
                            border: OutlineInputBorder(),
                          ),
                          validator: (value) {
                            if (value == null || value.trim().isEmpty) {
                              return 'Host is required';
                            }
                            return null;
                          },
                          enabled: !_isLoading,
                        ),
                        
                        const SizedBox(height: 16),
                        
                        // Port field
                        TextFormField(
                          controller: _portController,
                          decoration: InputDecoration(
                            labelText: 'Port',
                            hintText: 'Enter the database port',
                            border: const OutlineInputBorder(),
                            helperText: 'Default: ${_getDefaultPort(_selectedType)}',
                          ),
                          keyboardType: TextInputType.number,
                          validator: (value) {
                            if (value == null || value.trim().isEmpty) {
                              return 'Port is required';
                            }
                            if (int.tryParse(value) == null) {
                              return 'Port must be a number';
                            }
                            return null;
                          },
                          enabled: !_isLoading,
                        ),
                        
                        const SizedBox(height: 16),
                      ],
                      
                      // Database name field
                      TextFormField(
                        controller: _databaseController,
                        decoration: InputDecoration(
                          labelText: _selectedType == DatabaseType.sqlite
                              ? 'File Path'
                              : 'Database Name',
                          hintText: _selectedType == DatabaseType.sqlite
                              ? 'Enter the path to the SQLite file'
                              : 'Enter the database name',
                          border: const OutlineInputBorder(),
                        ),
                        validator: (value) {
                          if (value == null || value.trim().isEmpty) {
                            return _selectedType == DatabaseType.sqlite
                                ? 'File path is required'
                                : 'Database name is required';
                          }
                          return null;
                        },
                        enabled: !_isLoading,
                      ),
                      
                      const SizedBox(height: 16),
                      
                      if (_selectedType != DatabaseType.sqlite) ...[
                        // Username field
                        TextFormField(
                          controller: _usernameController,
                          decoration: const InputDecoration(
                            labelText: 'Username',
                            hintText: 'Enter the database username',
                            border: OutlineInputBorder(),
                          ),
                          validator: (value) {
                            if (value == null || value.trim().isEmpty) {
                              return 'Username is required';
                            }
                            return null;
                          },
                          enabled: !_isLoading,
                        ),
                        
                        const SizedBox(height: 16),
                        
                        // Password field
                        TextFormField(
                          controller: _passwordController,
                          obscureText: !_isPasswordVisible,
                          decoration: InputDecoration(
                            labelText: 'Password',
                            hintText: 'Enter the database password',
                            border: const OutlineInputBorder(),
                            suffixIcon: IconButton(
                              icon: Icon(
                                _isPasswordVisible
                                    ? Icons.visibility_off
                                    : Icons.visibility,
                              ),
                              onPressed: () {
                                setState(() {
                                  _isPasswordVisible = !_isPasswordVisible;
                                });
                              },
                            ),
                          ),
                          enabled: !_isLoading,
                        ),
                        
                        const SizedBox(height: 16),
                      ],
                    ],
                  ),
                ),
              ),
              
              const SizedBox(height: 16),
              
              // Save button
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _save,
                  child: _isLoading
                      ? const CircularProgressIndicator()
                      : Text(widget.isNew ? 'Add Data Source' : 'Save Changes'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _confirmDelete() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Confirm Delete'),
        content: Text('Are you sure you want to delete "${widget.source?.name}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              _deleteSource();
            },
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  Future<void> _deleteSource() async {
    if (widget.source == null) return;
    
    setState(() {
      _isLoading = true;
    });
    
    try {
      await DatasourceService.deleteSource(widget.source!.id);
      
      if (!mounted) return;
      Navigator.of(context).pop();
    } catch (e) {
      setState(() {
        _errorMessage = 'Failed to delete data source: ${e.toString()}';
        _isLoading = false;
      });
    }
  }
}
