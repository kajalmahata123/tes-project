import 'datasource_models.dart';

class DatasourceService {
  // This would connect to your actual backend in a real app
  // For demo purposes, we'll use an in-memory list
  
  static List<DatabaseSource> _sources = [];
  
  // Add some sample data sources
  static void _initializeSampleData() {
    if (_sources.isEmpty) {
      _sources = [
        DatabaseSource(
          id: '1',
          name: 'Production MySQL',
          type: DatabaseType.mysql,
          host: 'db.example.com',
          port: 3306,
          username: 'admin',
          password: '********',
          database: 'production_db',
          connectionStatus: 'Connected',
          createdAt: DateTime.now().subtract(const Duration(days: 30)),
          lastConnected: DateTime.now().subtract(const Duration(hours: 2)),
          tables: [
            DatabaseTable(
              name: 'users',
              columns: [
                DatabaseColumn(
                  name: 'id',
                  type: 'int',
                  isPrimaryKey: true,
                  isNullable: false,
                ),
                DatabaseColumn(
                  name: 'username',
                  type: 'varchar(50)',
                  isNullable: false,
                ),
                DatabaseColumn(
                  name: 'email',
                  type: 'varchar(100)',
                  isNullable: false,
                ),
                DatabaseColumn(
                  name: 'created_at',
                  type: 'timestamp',
                  defaultValue: 'CURRENT_TIMESTAMP',
                ),
              ],
            ),
            DatabaseTable(
              name: 'orders',
              columns: [
                DatabaseColumn(
                  name: 'id',
                  type: 'int',
                  isPrimaryKey: true,
                  isNullable: false,
                ),
                DatabaseColumn(
                  name: 'user_id',
                  type: 'int',
                  isNullable: false,
                ),
                DatabaseColumn(
                  name: 'total_amount',
                  type: 'decimal(10,2)',
                  isNullable: false,
                ),
                DatabaseColumn(
                  name: 'status',
                  type: 'varchar(20)',
                  isNullable: false,
                  defaultValue: 'pending',
                ),
                DatabaseColumn(
                  name: 'created_at',
                  type: 'timestamp',
                  defaultValue: 'CURRENT_TIMESTAMP',
                ),
              ],
            ),
          ],
        ),
        DatabaseSource(
          id: '2',
          name: 'Analytics PostgreSQL',
          type: DatabaseType.postgresql,
          host: 'analytics.example.com',
          port: 5432,
          username: 'reporter',
          password: '********',
          database: 'analytics',
          connectionStatus: 'Connected',
          createdAt: DateTime.now().subtract(const Duration(days: 15)),
          lastConnected: DateTime.now().subtract(const Duration(minutes: 30)),
          tables: [
            DatabaseTable(
              name: 'page_views',
              columns: [
                DatabaseColumn(
                  name: 'id',
                  type: 'serial',
                  isPrimaryKey: true,
                  isNullable: false,
                ),
                DatabaseColumn(
                  name: 'page_url',
                  type: 'text',
                  isNullable: false,
                ),
                DatabaseColumn(
                  name: 'user_id',
                  type: 'integer',
                ),
                DatabaseColumn(
                  name: 'view_timestamp',
                  type: 'timestamp',
                  isNullable: false,
                ),
              ],
            ),
          ],
        ),
      ];
    }
  }
  
  // Get all data sources
  static Future<List<DatabaseSource>> getSources() async {
    _initializeSampleData();
    // Simulate network delay
    await Future.delayed(const Duration(milliseconds: 800));
    return _sources;
  }
  
  // Get a data source by ID
  static Future<DatabaseSource?> getSource(String id) async {
    _initializeSampleData();
    await Future.delayed(const Duration(milliseconds: 500));
    try {
      return _sources.firstWhere((source) => source.id == id);
    } catch (e) {
      return null;
    }
  }
  
  // Add a new data source
  static Future<DatabaseSource> addSource(DatabaseSource source) async {
    _initializeSampleData();
    await Future.delayed(const Duration(seconds: 1));
    _sources.add(source);
    return source;
  }
  
  // Update a data source
  static Future<DatabaseSource> updateSource(DatabaseSource source) async {
    _initializeSampleData();
    await Future.delayed(const Duration(seconds: 1));
    final index = _sources.indexWhere((s) => s.id == source.id);
    if (index >= 0) {
      _sources[index] = source;
      return source;
    } else {
      throw Exception('Source not found');
    }
  }
  
  // Delete a data source
  static Future<void> deleteSource(String id) async {
    _initializeSampleData();
    await Future.delayed(const Duration(seconds: 1));
    _sources.removeWhere((source) => source.id == id);
  }
  
  // Test a connection to a data source
  static Future<bool> testConnection(DatabaseSource source) async {
    // Simulate network delay and connection test
    await Future.delayed(const Duration(seconds: 2));
    
    // For demo purposes, let's say most connections succeed
    final random = DateTime.now().millisecondsSinceEpoch % 10;
    return random < 8; // 80% success rate
  }
  
  // Import schema from a data source
  static Future<List<DatabaseTable>> importSchema(String sourceId) async {
    // Simulate network delay and schema import
    await Future.delayed(const Duration(seconds: 3));
    
    // For demo purposes, return existing schema or generate a new one
    final source = await getSource(sourceId);
    if (source != null && source.tables.isNotEmpty) {
      return source.tables;
    }
    
    // Generate some sample tables
    final tables = [
      DatabaseTable(
        name: 'customers',
        columns: [
          DatabaseColumn(
            name: 'customer_id',
            type: 'int',
            isPrimaryKey: true,
            isNullable: false,
          ),
          DatabaseColumn(name: 'name', type: 'varchar(100)', isNullable: false),
          DatabaseColumn(name: 'email', type: 'varchar(100)', isNullable: false),
          DatabaseColumn(name: 'phone', type: 'varchar(20)'),
          DatabaseColumn(
            name: 'created_at',
            type: 'timestamp',
            defaultValue: 'CURRENT_TIMESTAMP',
          ),
        ],
      ),
      DatabaseTable(
        name: 'products',
        columns: [
          DatabaseColumn(
            name: 'product_id',
            type: 'int',
            isPrimaryKey: true,
            isNullable: false,
          ),
          DatabaseColumn(name: 'name', type: 'varchar(100)', isNullable: false),
          DatabaseColumn(name: 'description', type: 'text'),
          DatabaseColumn(
            name: 'price',
            type: 'decimal(10,2)',
            isNullable: false,
          ),
          DatabaseColumn(name: 'stock', type: 'int', defaultValue: '0'),
        ],
      ),
      DatabaseTable(
        name: 'orders',
        columns: [
          DatabaseColumn(
            name: 'order_id',
            type: 'int',
            isPrimaryKey: true,
            isNullable: false,
          ),
          DatabaseColumn(
            name: 'customer_id',
            type: 'int',
            isNullable: false,
          ),
          DatabaseColumn(
            name: 'order_date',
            type: 'timestamp',
            isNullable: false,
            defaultValue: 'CURRENT_TIMESTAMP',
          ),
          DatabaseColumn(
            name: 'total_amount',
            type: 'decimal(10,2)',
            isNullable: false,
          ),
          DatabaseColumn(
            name: 'status',
            type: 'varchar(20)',
            isNullable: false,
            defaultValue: "'pending'",
          ),
        ],
      ),
    ];
    
    // Update the source with the new schema
    if (source != null) {
      source.tables.addAll(tables);
      await updateSource(source);
    }
    
    return tables;
  }
}
