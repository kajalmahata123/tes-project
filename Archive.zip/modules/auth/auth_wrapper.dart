import 'package:flutter/material.dart';
import 'login_page.dart';
import '../home/home_page.dart';

class AuthWrapper extends StatefulWidget {
  const AuthWrapper({Key? key}) : super(key: key);

  @override
  State<AuthWrapper> createState() => _AuthWrapperState();
}

class _AuthWrapperState extends State<AuthWrapper> {
  bool _isLoading = true;
  bool _isAuthenticated = false;
  
  @override
  void initState() {
    super.initState();
    _checkAuthentication();
  }
  
  Future<void> _checkAuthentication() async {
    // Simulate checking for stored credentials
    await Future.delayed(const Duration(seconds: 1));
    
    setState(() {
      _isAuthenticated = false;  // Always start with login screen
      _isLoading = false;
    });
  }
  
  void _onAuthenticated() {
    setState(() {
      _isAuthenticated = true;
    });
  }
  
  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }
    
    if (_isAuthenticated) {
      return const HomePage();
    } else {
      return LoginPage(onAuthenticated: _onAuthenticated);
    }
  }
}