//File: modules/home/home_page.dart
import 'package:flutter/material.dart';
import '../datasource/datasource_list_page.dart';
import '../datasource/datasource_models.dart';
import '../datasource/datasource_service.dart';
import '../query/query_intent_analysis.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool _isLoading = true;
  List<DatabaseSource> _recentSources = [];
  String? _errorMessage;
  int _selectedIndex = 0;

  @override
  void initState() {
    super.initState();
    _loadRecentSources();
  }

  Future<void> _loadRecentSources() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final sources = await DatasourceService.getSources();
      setState(() {
        _recentSources = sources;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = 'Failed to load data sources: ${e.toString()}';
        _isLoading = false;
      });
    }
  }

  void _onNavItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('SmartQL'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'Refresh',
            onPressed: _loadRecentSources,
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Logout',
            onPressed: () => _logout(context),
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _getBody(),
      bottomNavigationBar: BottomNavigationBar(
  items: const [
    BottomNavigationBarItem(
      icon: Icon(Icons.home),
      label: 'Home',
    ),
    BottomNavigationBarItem(
      icon: Icon(Icons.storage),
      label: 'Data Sources',
    ),
  ],
  currentIndex: _selectedIndex,
  onTap: _onNavItemTapped,
),
    );
  }

  Widget _getBody() {
    switch (_selectedIndex) {
      case 0:
        return _buildHomeTab();
      case 1:
        return const DatasourceListPage();
      default:
        return _buildHomeTab();
    }
  }

  Widget _buildHomeTab() {
    if (_errorMessage != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline, size: 48, color: Colors.red.shade300),
            const SizedBox(height: 16),
            Text(
              _errorMessage!,
              style: TextStyle(color: Colors.red.shade700),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _loadRecentSources,
              child: const Text('Try Again'),
            ),
          ],
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Welcome section
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Welcome to SmartQL',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Intelligent SQL generation and optimization',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.grey,
                    ),
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'SmartQL helps you work with databases more efficiently by:'
                  ),
                  const SizedBox(height: 8),
                  const _FeatureItem(
                    icon: Icons.psychology, 
                    text: 'Converting natural language to SQL queries',
                  ),
                  const _FeatureItem(
                    icon: Icons.insights, 
                    text: 'Providing insights on query performance',
                  ),
                  const _FeatureItem(
                    icon: Icons.auto_awesome, 
                    text: 'Suggesting improvements to optimize queries',
                  ),
                  const _FeatureItem(
                    icon: Icons.storage, 
                    text: 'Managing database connections and schemas',
                  ),
                ],
              ),
            ),
          ),
          
          const SizedBox(height: 24),
          
          // Recent data sources section
          const Text(
            'Your Data Sources',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          
          Expanded(
            child: _recentSources.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.storage,
                          size: 64,
                          color: Colors.grey.shade400,
                        ),
                        const SizedBox(height: 16),
                        const Text(
                          'No data sources found',
                          style: TextStyle(
                            fontSize: 18,
                            color: Colors.grey,
                          ),
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          'Add a data source to get started',
                          style: TextStyle(color: Colors.grey),
                        ),
                        const SizedBox(height: 24),
                        ElevatedButton.icon(
                          onPressed: () {
                            setState(() {
                              _selectedIndex = 1;
                            });
                          },
                          icon: const Icon(Icons.add),
                          label: const Text('Add Data Source'),
                        ),
                      ],
                    ),
                  )
                : GridView.builder(
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      childAspectRatio: 3 / 2,
                      crossAxisSpacing: 16,
                      mainAxisSpacing: 16,
                    ),
                    itemCount: _recentSources.length,
                    itemBuilder: (context, index) {
                      final source = _recentSources[index];
                      return _DataSourceCard(
                        source: source,
                        onTap: () => _navigateToQueryAnalysis(source),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  void _navigateToQueryAnalysis(DatabaseSource source) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => QueryIntentAnalysisPage(
          sourceId: source.id,
          source: source,
        ),
      ),
    );
  }

  Future<void> _logout(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Confirm Logout'),
        content: const Text('Are you sure you want to log out?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Logout'),
          ),
        ],
      ),
    );
    
    if (confirmed == true) {
      // In a real app, we would clear authentication state here
      if (!mounted) return;
      
      // Restart app to show login screen
      Navigator.of(context).pushNamedAndRemoveUntil('/', (route) => false);
    }
  }
}

class _FeatureItem extends StatelessWidget {
  final IconData icon;
  final String text;
  
  const _FeatureItem({
    required this.icon,
    required this.text,
  });
  
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child: Row(
        children: [
          Icon(icon, size: 20, color: Theme.of(context).primaryColor),
          const SizedBox(width: 8),
          Expanded(child: Text(text)),
        ],
      ),
    );
  }
}

class _DataSourceCard extends StatelessWidget {
  final DatabaseSource source;
  final VoidCallback onTap;
  
  const _DataSourceCard({
    required this.source,
    required this.onTap,
  });
  
  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header with database type
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              color: source.type.color.withOpacity(0.1),
              child: Row(
                children: [
                  Icon(source.type.icon, color: source.type.color),
                  const SizedBox(width: 8),
                  Text(
                    source.name,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: source.connectionStatus == 'Connected'
                          ? Colors.green.withOpacity(0.2)
                          : Colors.grey.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      source.connectionStatus ?? 'Unknown',
                      style: TextStyle(
                        color: source.connectionStatus == 'Connected'
                            ? Colors.green.shade700
                            : Colors.grey.shade700,
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            
            // Database details
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    source.type.name,
                    style: TextStyle(
                      color: Colors.grey.shade600,
                      fontSize: 14,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Icon(Icons.table_chart, size: 16, color: Colors.grey.shade600),
                      const SizedBox(width: 4),
                      Text(
                        '${source.tables.length} tables',
                        style: TextStyle(
                          //File: modules/home/home_page.dart (Continued)
                          fontSize: 14,
                          color: Colors.grey.shade600,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            
            // Action buttons
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  TextButton.icon(
                    icon: const Icon(Icons.psychology, size: 16),
                    label: const Text('Query'),
                    onPressed: onTap,
                  ),
                  TextButton.icon(
                    icon: const Icon(Icons.schema, size: 16),
                    label: const Text('Schema'),
                    onPressed: () {
                      // In a real app, this would navigate to a schema viewer
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Schema viewer would open here'),
                          duration: Duration(seconds: 1),
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Package Dependency Addition
// For UUID generation used in the application, you need to add this to pubspec.yaml:
// dependencies:
//   uuid: ^3.0.6

// File: pubspec.yaml
// A section of the pubspec.yaml you'll need to ensure is included:
/*
name: smartql_app
description: An intelligent SQL query analysis application.

environment:
  sdk: ">=2.17.0 <3.0.0"

dependencies:
  flutter:
    sdk: flutter
  cupertino_icons: ^1.0.5
  uuid: ^3.0.6

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^2.0.1
*/

// Main Navigation Routes Integration
// File: main.dart
// Update your main.dart to include routes:
/*
import 'package:flutter/material.dart';
import 'modules/auth/auth_wrapper.dart';
import 'modules/datasource/datasource_models.dart';

void main() {
  runApp(const SmartQLApp());
}

class SmartQLApp extends StatelessWidget {
  const SmartQLApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SmartQL',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        brightness: Brightness.light,
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.blue,
          brightness: Brightness.light,
        ),
        useMaterial3: true,
        fontFamily: 'Roboto',
      ),
      darkTheme: ThemeData(
        brightness: Brightness.dark,
        primarySwatch: Colors.blue,
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.blue,
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
        fontFamily: 'Roboto',
      ),
      themeMode: ThemeMode.system,
      initialRoute: '/',
      routes: {
        '/': (context) => const AuthWrapper(),
        // Other routes can be added here if needed
      },
    );
  }
}
*/

// Add this additional helper class for the BottomNavigationBar
// This was missing in the original implementation and would cause compiler errors:

extension BottomNavigationBarExt on BottomNavigationBar {
  static BottomNavigationBarItem item({
    required Icon icon,
    Icon? activeIcon,
    required String label,
  }) {
    return BottomNavigationBarItem(
      icon: icon,
      activeIcon: activeIcon,
      label: label,
    );
  }
}

// Implementation Notes for Assembly:
// 1. Create the directory structure first:
//    - lib/
//      - modules/
//        - auth/
//        - datasource/
//        - home/
//        - query/
//    - assets/
//
// 2. Add the uuid package to your pubspec.yaml
//
// 3. Place all files in their respective module directories
//
// 4. Run 'flutter pub get' to install dependencies
//
// 5. Ensure the BottomNavigationBarExt extension is included to fix
//    the BottomNavigationBar.item reference in the HomePage
//
// 6. Run the app with 'flutter run'
//
// Default login credentials:
// Username: admin
// Password: password