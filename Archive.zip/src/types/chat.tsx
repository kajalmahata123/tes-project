// src/types/chat.ts
export type MessageRole = 'user' | 'assistant' | 'system';

export interface Message {
  role: MessageRole;
  content: string;
  timestamp?: string;
}

export interface ChatRequest {
  messages: Message[];
  session_id?: string;
  context?: Record<string, any>;
}

export interface ChatResponse {
  response: string;
  session_id: string;
  created_at: string;
  sources?: Source[];
}

export interface Source {
  id: string;
  metadata: {
    document_id: string;
    document_name: string;
    [key: string]: any;
  };
}

export interface ChatSession {
  session_id: string;
  messages: Message[];
  created_at: string;
  last_accessed: string;
}



