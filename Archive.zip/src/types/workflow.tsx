// src/types/workflow.ts
export interface WorkflowStep {
  step_number: number;
  api_method: string;
  api_path: string;
  description: string;
  parameters: string[];
  next_steps: string;
}

export interface Workflow {
  workflow_id: string;
  title: string;
  description: string;
  steps: WorkflowStep[];
  visualization?: string;
  created_at: string;
  metadata?: Record<string, any>;
}

export interface CodeGeneration {
  code_id: string;
  language: string;
  code: string;
  workflow_id?: string;
  description?: string;
  created_at: string;
  metadata?: Record<string, any>;
}