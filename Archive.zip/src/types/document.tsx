// src/types/document.ts
export interface Document {
  document_id: string;
  document_name: string;
  document_type: 'pdf' | 'openapi';
  upload_success: boolean;
  vector_db_added: boolean;
  created_at: string;
  chunks_count?: number;
  metadata?: Record<string, any>;
}

export interface DocumentUploadRequest {
  file: File;
  document_type: 'pdf' | 'openapi';
  document_description?: string;
  add_to_vector_db?: boolean;
}

export interface DocumentUploadResponse {
  document_id: string;
  document_name: string;
  document_type: string;
  upload_success: boolean;
  vector_db_added: boolean;
  created_at: string;
  chunks_count?: number;
  metadata?: Record<string, any>;
}
