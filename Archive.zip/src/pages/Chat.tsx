// src/pages/Chat.tsx
import React, { useState } from 'react';
import MainLayout from '../components/layout/MainLayout';
import ChatContainer from '../components/chat/ChatContainer';

const Chat: React.FC = () => {
  const [sessionId, setSessionId] = useState<string | undefined>(undefined);

  return (
    <MainLayout>
      <div className="max-w-6xl mx-auto h-[calc(100vh-9rem)]">
        <ChatContainer
          className="h-[calc(100vh-12rem)]"
          sessionId={sessionId}
          onSessionIdChange={setSessionId}
        />
      </div>
    </MainLayout>
  );
};

export default Chat;

