// src/pages/Home.tsx
import React from 'react';
import { Link } from 'react-router-dom';
import MainLayout from '../components/layout/MainLayout';
import Button from '../components/common/Button';

const Home: React.FC = () => {
  return (
    <MainLayout>
      <div className="max-w-7xl mx-auto">
        {/* Hero Section */}
        <div className="bg-gradient-to-r from-primary-600 to-primary-800 rounded-lg shadow-xl overflow-hidden mb-10">
          <div className="px-6 py-12 md:px-12 md:py-20 lg:py-24 max-w-3xl">
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white">
              Agent-Based API Chatbot
            </h1>
            <p className="mt-4 text-lg text-primary-100">
              A powerful assistant that helps you understand APIs, generate workflows, and create code.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Link to="/chat">
                <Button size="lg">
                  Start Chatting
                  <svg
                    className="ml-2 h-5 w-5"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M17 8l4 4m0 0l-4 4m4-4H3"
                    />
                  </svg>
                </Button>
              </Link>
              <Link to="/documents">
                <Button size="lg" variant="outline" className="bg-white bg-opacity-10 hover:bg-opacity-20 border-white text-white">
                  Upload Documents
                </Button>
              </Link>
            </div>
          </div>
        </div>

        {/* Features Section */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-secondary-900 mb-8">Features</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Feature 1 */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center justify-center h-12 w-12 rounded-md bg-primary-500 text-white mb-4">
                <svg
                  className="h-6 w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"
                  />
                </svg>
              </div>
              <h3 className="text-lg font-medium text-secondary-900 mb-2">
                Document Processing
              </h3>
              <p className="text-secondary-600">
                Upload PDF documents and OpenAPI specifications to train the system about your API details.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center justify-center h-12 w-12 rounded-md bg-primary-500 text-white mb-4">
                <svg
                  className="h-6 w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M8 9l3 3-3 3m5 0h3M5 20h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                  />
                </svg>
              </div>
              <h3 className="text-lg font-medium text-secondary-900 mb-2">
                Workflow Generation
              </h3>
              <p className="text-secondary-600">
                Generate API workflows with step-by-step sequences and visual diagrams based on your requirements.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center justify-center h-12 w-12 rounded-md bg-primary-500 text-white mb-4">
                <svg
                  className="h-6 w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4"
                  />
                </svg>
              </div>
              <h3 className="text-lg font-medium text-secondary-900 mb-2">
                Code Generation
              </h3>
              <p className="text-secondary-600">
                Convert workflows into working code in multiple programming languages like Python, JavaScript, and more.
              </p>
            </div>
          </div>
        </div>

        {/* Getting Started Section */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-2xl font-bold text-secondary-900 mb-4">Getting Started</h2>
          <ol className="list-decimal pl-5 space-y-3 text-secondary-700">
            <li>
              <span className="font-medium text-secondary-900">Upload Documents</span> - Start by
              uploading PDF documents containing API descriptions or OpenAPI specification files.
            </li>
            <li>
              <span className="font-medium text-secondary-900">Start a Chat</span> - Ask questions
              about your APIs or request workflows for specific scenarios.
            </li>
            <li>
              <span className="font-medium text-secondary-900">Generate Code</span> - Ask the agent
              to generate code based on workflows or API specifications.
            </li>
            <li>
              <span className="font-medium text-secondary-900">Save Results</span> - Copy the
              generated workflows, diagrams, and code for your projects.
            </li>
          </ol>
        </div>

        {/* Example Prompts */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-2xl font-bold text-secondary-900 mb-4">Example Prompts</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="border border-secondary-200 rounded-md p-4 bg-secondary-50">
              <p className="text-primary-700 font-medium">Generate a workflow for user authentication</p>
            </div>
            <div className="border border-secondary-200 rounded-md p-4 bg-secondary-50">
              <p className="text-primary-700 font-medium">Create Python code to implement the user registration workflow</p>
            </div>
            <div className="border border-secondary-200 rounded-md p-4 bg-secondary-50">
              <p className="text-primary-700 font-medium">What APIs are available for order management?</p>
            </div>
            <div className="border border-secondary-200 rounded-md p-4 bg-secondary-50">
              <p className="text-primary-700 font-medium">Generate a workflow for payment processing and corresponding JavaScript code</p>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default Home;