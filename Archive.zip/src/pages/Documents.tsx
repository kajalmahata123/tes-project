// src/pages/Documents.tsx
import React, { useState, useEffect } from 'react';
import MainLayout from '../components/layout/MainLayout';
import DocumentUpload from '../components/documents/DocumentUpload';
import DocumentList from '../components/documents/DocumentList';
import { Document } from '../types/document';
import { documentService } from '../services/documentService';

const Documents: React.FC = () => {
  const [documents, setDocuments] = useState<Document[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // This is a placeholder since we don't have a real endpoint to list documents
  // In a real application, you would call an API endpoint to get the list
  const fetchDocuments = async () => {
    try {
      setIsLoading(true);
      setError(null);

      // Simulate API call with timeout
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Mock data
      const mockDocuments: Document[] = [
        {
          document_id: '1',
          document_name: 'API Specification.pdf',
          document_type: 'pdf',
          upload_success: true,
          vector_db_added: true,
          created_at: new Date().toISOString(),
          chunks_count: 23,
          metadata: {
            title: 'API Specification',
            page_count: 12
          }
        },
        {
          document_id: '2',
          document_name: 'openapi.yaml',
          document_type: 'openapi',
          upload_success: true,
          vector_db_added: true,
          created_at: new Date().toISOString(),
          chunks_count: 15,
          metadata: {
            title: 'User API',
            version: '1.0.0'
          }
        }
      ];

      setDocuments(mockDocuments);

    } catch (err: any) {
      console.error('Error fetching documents:', err);
      setError('Failed to load documents');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDocumentUpload = () => {
    // Refresh the document list after successful upload
    fetchDocuments();
  };

  const handleDocumentDelete = async (documentId: string) => {
    try {
      // In a real application, call the API to delete the document
      // await documentService.deleteDocument(documentId);

      // Update the local state
      setDocuments(documents.filter(doc => doc.document_id !== documentId));

    } catch (err: any) {
      console.error('Error deleting document:', err);
      setError('Failed to delete document');
    }
  };

  useEffect(() => {
    fetchDocuments();
  }, []);

  return (
    <MainLayout>
      <div className="max-w-7xl mx-auto">
        <div className="bg-white rounded-lg shadow-md p-4 mb-6">
          <h1 className="text-2xl font-bold text-secondary-900">Document Management</h1>
          <p className="text-secondary-600 mt-1">
            Upload PDF documents and OpenAPI specifications to use in the chat system.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1">
            <DocumentUpload onUploadSuccess={handleDocumentUpload} />
          </div>

          <div className="lg:col-span-2">
            <DocumentList
              documents={documents}
              isLoading={isLoading}
              error={error}
              onDelete={handleDocumentDelete}
            />
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default Documents;