// src/services/chatService.ts
import api from './api';
import { ChatRequest, ChatResponse } from '../types/chat';

export const chatService = {
  /**
   * Send a chat message to the API
   * @param chatRequest Chat request object containing messages and context
   * @returns Promise with chat response
   */
  sendMessage: async (chatRequest: ChatRequest): Promise<ChatResponse> => {
    const response = await api.post<ChatResponse>('/chat', chatRequest);
    return response.data;
  },

  /**
   * Delete a chat session
   * @param sessionId ID of the session to delete
   * @returns Promise resolving to void on success
   */
  deleteSession: async (sessionId: string): Promise<void> => {
    await api.delete(`/chat/${sessionId}`);
  },
};