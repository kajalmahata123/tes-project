// src/components/chat/ChatInput.tsx
import React, { useState, FormEvent, useRef, useEffect } from 'react';
import Button from '../common/Button';

interface ChatInputProps {
  onSendMessage: (message: string) => void;
  isLoading?: boolean;
  placeholder?: string;
  onFileUpload?: (file: File) => void;
  suggestedPrompts?: string[];
}

const ChatInput: React.FC<ChatInputProps> = ({
  onSendMessage,
  isLoading = false,
  placeholder = 'Type your message...',
  onFileUpload,
  suggestedPrompts = [],
}) => {
  const [message, setMessage] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();

    if (message.trim() && !isLoading) {
      onSendMessage(message.trim());
      setMessage('');

      // Reset textarea height
      if (textareaRef.current) {
        textareaRef.current.style.height = 'auto';
      }
    }
  };

  // Auto-resize textarea based on content
  const handleTextareaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const textarea = e.target;
    setMessage(textarea.value);

    // Reset height to calculate the right height
    textarea.style.height = 'auto';
    // Set the height based on scrollHeight (content height)
    textarea.style.height = `${Math.min(textarea.scrollHeight, 200)}px`;

    // Show suggestions when textarea is empty and being focused
    setShowSuggestions(textarea.value === '');
  };

  // Handle CTRL+Enter or CMD+Enter to submit
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      handleSubmit(e);
    }

    // Hide suggestions on typing
    if (e.key !== 'Tab' && e.key !== 'Shift') {
      setShowSuggestions(false);
    }
  };

  // Handle file upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0 && onFileUpload) {
      onFileUpload(e.target.files[0]);
    }
  };

  // Handle clicking on suggested prompt
  const handleSuggestedPrompt = (prompt: string) => {
    setMessage(prompt);
    setShowSuggestions(false);
    if (textareaRef.current) {
      textareaRef.current.focus();
      // Trigger height adjustment
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`;
    }
  };

  // Focus textarea on mount
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.focus();
    }
  }, []);

  return (
    <div className="sticky bottom-0 z-10">
      {/* Suggested prompts */}
      {showSuggestions && suggestedPrompts.length > 0 && (
        <div className="bg-white border-t border-secondary-200 px-4 py-3 flex flex-wrap gap-2 max-w-4xl mx-auto">
          {suggestedPrompts.map((prompt, index) => (
            <button
              key={index}
              type="button"
              onClick={() => handleSuggestedPrompt(prompt)}
              className="px-3 py-1.5 text-sm bg-secondary-50 text-secondary-700 hover:bg-secondary-100 rounded-full border border-secondary-200 transition-colors whitespace-nowrap"
            >
              {prompt}
            </button>
          ))}
        </div>
      )}

      <form
        onSubmit={handleSubmit}
        className="border-t border-secondary-200 bg-white p-4 shadow-md"
      >
        <div className="flex items-end gap-3 max-w-4xl mx-auto">
          {/* File upload button (only show if onFileUpload is provided) */}
          {onFileUpload && (
            <>
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileUpload}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="p-2.5 rounded-full text-secondary-500 hover:bg-secondary-100 hover:text-secondary-700 transition-colors"
                aria-label="Upload file"
                title="Upload a file"
                disabled={isLoading}
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M14 3v4a1 1 0 0 0 1 1h4" />
                  <path d="M17 21H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7l5 5v11a2 2 0 0 1-2 2z" />
                  <path d="M12 11v6" />
                  <path d="m9 14 3-3 3 3" />
                </svg>
              </button>
            </>
          )}

          <div className="flex-grow relative">
            <textarea
              ref={textareaRef}
              value={message}
              onChange={handleTextareaChange}
              onKeyDown={handleKeyDown}
              onClick={() => message === '' && setShowSuggestions(true)}
              onFocus={() => message === '' && setShowSuggestions(true)}
              onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
              placeholder={placeholder}
              disabled={isLoading}
              className="w-full px-4 py-3 border border-secondary-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 resize-none min-h-[52px] max-h-36 overflow-auto transition-all duration-200"
              rows={1}
            />
            <div className="absolute right-3 bottom-3 text-xs text-secondary-500 bg-white px-1 rounded">
              <kbd className="px-1.5 py-0.5 bg-secondary-100 border border-secondary-300 rounded text-secondary-600 font-sans">Ctrl+Enter</kbd>
            </div>
          </div>

          <Button
            type="submit"
            disabled={isLoading || !message.trim()}
            isLoading={isLoading}
            className="px-6 h-[52px] rounded-lg font-medium flex items-center gap-2 transition-all duration-200 hover:shadow-sm disabled:opacity-50"
          >
            {!isLoading && (
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="m3 3 3 9-3 9 19-9Z" />
                <path d="M6 12h16" />
              </svg>
            )}
            {isLoading ? "Sending..." : "Send"}
          </Button>
        </div>
      </form>
    </div>
  );
};

export default ChatInput;