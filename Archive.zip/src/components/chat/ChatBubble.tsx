import React from 'react';
import { Message } from '../../types/chat';
import { WorkflowViewer } from '../workflow/WorkflowViewer';
import { CodeBlock } from '../workflow/CodeBlock';
import { MermaidDiagram } from '../workflow/MermaidDiagram';
import ReactMarkdown from 'react-markdown';

interface ChatBubbleProps {
  message: Message;
}

const ChatBubble: React.FC<ChatBubbleProps> = ({ message }) => {
  const isUser = message.role === 'user';
  
  // Function to parse and render content with special handling for workflow and code
  const renderContent = () => {
    const content = message.content;
    
    // Simple detection of workflow in the content
    const hasWorkflow = content.includes('# Workflow:');
    // Simple detection of code blocks in the content
    const hasCode = content.includes('```');
    // Simple detection of mermaid diagrams
    const hasMermaid = content.includes('```mermaid');
    
    if (hasWorkflow || hasCode || hasMermaid) {
      return (
        <div className="prose prose-sm max-w-none">
          <ReactMarkdown
            components={{
              // For code blocks - updated parameter destructuring for v10
              code({node, className, children}) {
                const inline = (node as any)?.inline;
                const match = /language-(\w+)/.exec(className || '');
                const language = match ? match[1] : '';
                const value = String(children).replace(/\n$/, '');
                
                if (language === 'mermaid') {
                  return <MermaidDiagram chart={value} />;
                }
                
                if (!inline && language) {
                  return <CodeBlock code={value} language={language} />;
                }
                
                return <code className={className}>{children}</code>;
              },
              
              // For headings - updated parameter destructuring for v10
              h1({children}) {
                if (String(children).includes('Workflow:')) {
                  return <h1 className="text-xl font-bold text-primary-600 mt-4 mb-2">{children}</h1>;
                }
                return <h1 className="text-xl font-bold mt-4 mb-2">{children}</h1>;
              },
              
              h2({children}) {
                if (String(children).includes('Step')) {
                  return <h2 className="text-lg font-semibold text-secondary-700 mt-3 mb-1">{children}</h2>;
                }
                return <h2 className="text-lg font-semibold mt-3 mb-1">{children}</h2>;
              }
            }}
          >
            {content}
          </ReactMarkdown>
        </div>
      );
    }
    
    // For simple text messages
    return <p className="whitespace-pre-wrap">{content}</p>;
  };
  
  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'} mb-4`}>
      <div
        className={`rounded-lg px-4 py-2 max-w-[80%] ${
          isUser
            ? 'bg-primary-600 text-white rounded-br-none'
            : 'bg-secondary-100 text-secondary-900 rounded-bl-none'
        }`}
      >
        {renderContent()}
        
        {/* Timestamp */}
        {message.timestamp && (
          <div className={`text-xs mt-1 ${isUser ? 'text-primary-200' : 'text-secondary-500'}`}>
            {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </div>
        )}
      </div>
    </div>
  );
};

export default ChatBubble;