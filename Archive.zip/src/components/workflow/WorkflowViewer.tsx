// src/components/workflow/WorkflowViewer.tsx
import React from 'react';
import { Workflow } from '../../types/workflow';
import { WorkflowStep } from './WorkflowStep';
import { MermaidDiagram } from './MermaidDiagram';

interface WorkflowViewerProps {
  workflow: Workflow;
  className?: string;
}

export const WorkflowViewer: React.FC<WorkflowViewerProps> = ({ workflow, className = '' }) => {
  return (
    <div className={`bg-white rounded-lg shadow-md overflow-hidden ${className}`}>
      {/* Header */}
      <div className="bg-primary-600 text-white p-4">
        <h2 className="text-xl font-bold">{workflow.title}</h2>
        <p className="mt-1 text-primary-100">{workflow.description}</p>
      </div>

      {/* Steps */}
      <div className="p-4">
        <h3 className="text-lg font-semibold text-secondary-700 mb-4">Workflow Steps</h3>
        <div className="space-y-4">
          {workflow.steps.map((step) => (
            <WorkflowStep key={step.step_number} step={step} />
          ))}
        </div>
      </div>

      {/* Visualization */}
      {workflow.visualization && (
        <div className="border-t border-secondary-200 p-4">
          <h3 className="text-lg font-semibold text-secondary-700 mb-4">Workflow Diagram</h3>
          <MermaidDiagram chart={workflow.visualization} />
        </div>
      )}

      {/* Metadata */}
      <div className="bg-secondary-50 px-4 py-3 text-xs text-secondary-500 border-t border-secondary-200">
        <p>Created: {new Date(workflow.created_at).toLocaleString()}</p>
        <p>Workflow ID: {workflow.workflow_id}</p>
      </div>
    </div>
  );
};

