// src/components/workflow/MermaidDiagram.tsx
import React, { useEffect, useState } from 'react';
import mermaid from 'mermaid';

interface MermaidDiagramProps {
  chart: string;
  className?: string;
}

export const MermaidDiagram: React.FC<MermaidDiagramProps> = ({ chart, className = '' }) => {
  const [svg, setSvg] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const renderDiagram = async () => {
      try {
        // Initialize mermaid with each render and ensure good contrast
        mermaid.initialize({
          startOnLoad: false,
          theme: 'default',
          securityLevel: 'loose',
          flowchart: {
            htmlLabels: true,
            curve: 'basis',
          },
          // Explicitly set darker colors for better visibility
          themeVariables: {
            primaryColor: '#0284c7',        // dark blue
            primaryTextColor: '#ffffff',    // white text
            primaryBorderColor: '#075985',  // darker blue border
            lineColor: '#334155',           // dark slate for lines
            secondaryColor: '#94a3b8',      // medium slate
            tertiaryColor: '#f1f5f9',       // light slate background
            // Make sure text and nodes have good contrast
            nodeBorder: '#334155',          // dark border
            clusterBkg: '#e2e8f0',
            clusterBorder: '#64748b',
            edgeLabelBackground: '#f8fafc',
            // Ensure text labels are dark
            labelColor: '#0f172a',          // very dark for text
          },
        });

        // Clean the chart text
        const cleanChart = chart.trim();

        // Fix common issues with mermaid diagrams
        // Replace 'title' node with 'workflow' to avoid conflicts
        const fixedChart = cleanChart.replace(/\btitle\b(?=\s*\[)/g, 'workflow');

        // Generate a unique ID
        const id = `mermaid-${Date.now().toString()}`;

        // Use mermaid.render with promises
        const { svg: renderedSvg } = await mermaid.render(id, fixedChart);

        // Post-process the SVG to ensure visibility
        // Add a stroke to all paths and text elements if needed
        const enhancedSvg = renderedSvg
          // Make sure all paths (lines) have sufficient opacity and stroke width
          .replace(/<path([^>]*)>/g, '<path$1 stroke-opacity="0.8" stroke-width="1.5">')
          // Ensure text elements have a dark fill
          .replace(/<text([^>]*)>/g, '<text$1 fill="#0f172a">');

        setSvg(enhancedSvg);
        setError(null);
      } catch (err) {
        console.error('Mermaid rendering error:', err);
        setError('Failed to render diagram. There might be a syntax error in the diagram definition.');
        setSvg('');
      }
    };

    renderDiagram();
  }, [chart]);

  if (error) {
    return (
      <div className={`my-4 ${className}`}>
        <div className="p-4 bg-red-50 text-red-700 rounded-md border border-red-300">
          <p className="font-medium">Error rendering diagram</p>
          <p className="text-sm">{error}</p>
          <pre className="mt-2 p-2 bg-gray-100 rounded text-xs overflow-auto">{chart}</pre>
        </div>
      </div>
    );
  }

  return (
    <div className={`my-4 ${className}`}>
      <div className="overflow-auto rounded-md border border-gray-200 bg-white p-4">
        {svg ? (
          <div dangerouslySetInnerHTML={{ __html: svg }} className="flex justify-center" />
        ) : (
          <div className="flex justify-center items-center h-20">
            <p className="text-gray-500">Loading diagram...</p>
          </div>
        )}
      </div>
    </div>
  );
};