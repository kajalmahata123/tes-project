// src/components/workflow/WorkflowStep.tsx
import React, { useState } from 'react';
import { WorkflowStep as WorkflowStepType } from '../../types/workflow';

interface WorkflowStepProps {
  step: WorkflowStepType;
  className?: string;
}

export const WorkflowStep: React.FC<WorkflowStepProps> = ({ step, className = '' }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <div className={`border border-secondary-200 rounded-lg overflow-hidden ${className}`}>
      {/* Step Header */}
      <div
        className="bg-secondary-50 p-3 flex justify-between items-center cursor-pointer hover:bg-secondary-100"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center">
          <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-primary-100 text-primary-800 text-sm font-medium mr-3">
            {step.step_number}
          </span>
          <div>
            <h4 className="font-medium text-secondary-900">
              {step.api_method} {step.api_path}
            </h4>
          </div>
        </div>
        <button
          className="text-secondary-500 hover:text-secondary-700"
          aria-expanded={isExpanded}
        >
          <svg
            className={`h-5 w-5 transform transition-transform ${isExpanded ? 'rotate-180' : ''}`}
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 20 20"
            fill="currentColor"
            aria-hidden="true"
          >
            <path
              fillRule="evenodd"
              d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
              clipRule="evenodd"
            />
          </svg>
        </button>
      </div>

      {/* Step Details */}
      {isExpanded && (
        <div className="p-4 border-t border-secondary-200">
          <p className="text-secondary-700 mb-3">{step.description}</p>

          {/* Parameters */}
          {step.parameters && step.parameters.length > 0 && (
            <div className="mb-3">
              <h5 className="text-sm font-semibold text-secondary-900 mb-1">Parameters:</h5>
              <ul className="list-disc list-inside text-sm text-secondary-700 pl-2">
                {step.parameters.map((param, index) => (
                  <li key={index}>{param}</li>
                ))}
              </ul>
            </div>
          )}

          {/* Next Steps */}
          {step.next_steps && (
            <div>
              <h5 className="text-sm font-semibold text-secondary-900 mb-1">Next Steps:</h5>
              <p className="text-sm text-secondary-700">{step.next_steps}</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};