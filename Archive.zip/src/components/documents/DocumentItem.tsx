
// src/components/documents/DocumentItem.tsx
import React, { useState } from 'react';
import { Document } from '../../types/document';
import Button from '../common/Button';

interface DocumentItemProps {
  document: Document;
  onDelete: () => void;
}

const DocumentItem: React.FC<DocumentItemProps> = ({ document, onDelete }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const handleDelete = async () => {
    try {
      setIsDeleting(true);
      onDelete();
    } catch (error) {
      console.error('Error deleting document:', error);
    } finally {
      setIsDeleting(false);
    }
  };

  // Get document type icon
  const getDocumentIcon = () => {
    switch (document.document_type) {
      case 'pdf':
        return (
          <svg
            className="h-10 w-10 text-error-500"
            fill="currentColor"
            viewBox="0 0 20 20"
          >
            <path
              fillRule="evenodd"
              d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 6a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm1 3a1 1 0 100 2h6a1 1 0 100-2H7z"
              clipRule="evenodd"
            />
          </svg>
        );
      case 'openapi':
        return (
          <svg
            className="h-10 w-10 text-primary-500"
            fill="currentColor"
            viewBox="0 0 20 20"
          >
            <path
              fillRule="evenodd"
              d="M2 5a2 2 0 012-2h12a2 2 0 012 2v10a2 2 0 01-2 2H4a2 2 0 01-2-2V5zm3.293 1.293a1 1 0 011.414 0l3 3a1 1 0 010 1.414l-3 3a1 1 0 01-1.414-1.414L7.586 10 5.293 7.707a1 1 0 010-1.414zM11 12a1 1 0 100 2h3a1 1 0 100-2h-3z"
              clipRule="evenodd"
            />
          </svg>
        );
      default:
        return (
          <svg
            className="h-10 w-10 text-secondary-400"
            fill="currentColor"
            viewBox="0 0 20 20"
          >
            <path
              fillRule="evenodd"
              d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4z"
              clipRule="evenodd"
            />
          </svg>
        );
    }
  };

  // Format date
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  return (
    <div className="py-4">
      <div className="flex items-start">
        <div className="flex-shrink-0">{getDocumentIcon()}</div>
        <div className="ml-4 flex-1">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-medium text-secondary-900">{document.document_name}</h3>
            <div className="flex space-x-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsExpanded(!isExpanded)}
                aria-expanded={isExpanded}
                aria-label={isExpanded ? "Hide details" : "Show details"}
              >
                <svg
                  className={`h-5 w-5 text-secondary-500 transform transition-transform ${
                    isExpanded ? 'rotate-180' : ''
                  }`}
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M19 9l-7 7-7-7"
                  />
                </svg>
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleDelete}
                isLoading={isDeleting}
                disabled={isDeleting}
              >
                <svg
                  className="h-5 w-5 text-error-500"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                  />
                </svg>
              </Button>
            </div>
          </div>

          <div className="mt-1 flex items-center text-sm text-secondary-500">
            <span className="capitalize">{document.document_type}</span>
            <span className="mx-2">•</span>
            <span>{formatDate(document.created_at)}</span>
            {document.vector_db_added && (
              <>
                <span className="mx-2">•</span>
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-success-100 text-success-800">
                  Indexed
                </span>
              </>
            )}
          </div>

          {/* Expanded content */}
          {isExpanded && (
            <div className="mt-3 border-t border-secondary-200 pt-3">
              <dl className="grid grid-cols-1 gap-x-4 gap-y-3 sm:grid-cols-2">
                <div className="sm:col-span-1">
                  <dt className="text-sm font-medium text-secondary-500">Document ID</dt>
                  <dd className="mt-1 text-sm text-secondary-900">{document.document_id}</dd>
                </div>

                {document.chunks_count !== undefined && (
                  <div className="sm:col-span-1">
                    <dt className="text-sm font-medium text-secondary-500">Chunks</dt>
                    <dd className="mt-1 text-sm text-secondary-900">{document.chunks_count}</dd>
                  </div>
                )}

                {document.metadata && Object.keys(document.metadata).length > 0 && (
                  <div className="sm:col-span-2">
                    <dt className="text-sm font-medium text-secondary-500">Metadata</dt>
                    <dd className="mt-1 text-sm text-secondary-900">
                      <pre className="bg-secondary-50 p-2 rounded overflow-auto max-h-32">
                        {JSON.stringify(document.metadata, null, 2)}
                      </pre>
                    </dd>
                  </div>
                )}
              </dl>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DocumentItem;