// src/components/documents/DocumentList.tsx
import React from 'react';
import { Document } from '../../types/document';
import DocumentItem from './DocumentItem';
import Loader from '../common/Loader';

interface DocumentListProps {
  documents: Document[];
  isLoading: boolean;
  error: string | null;
  onDelete: (documentId: string) => void;
  className?: string;
}

const DocumentList: React.FC<DocumentListProps> = ({
  documents,
  isLoading,
  error,
  onDelete,
  className = '',
}) => {
  if (isLoading) {
    return (
      <div className={`bg-white rounded-lg shadow-md p-6 flex justify-center ${className}`}>
        <Loader />
      </div>
    );
  }

  if (error) {
    return (
      <div className={`bg-white rounded-lg shadow-md p-6 ${className}`}>
        <div className="p-4 bg-error-50 text-error-700 rounded-md border border-error-200">
          <h3 className="font-medium">Error loading documents</h3>
          <p>{error}</p>
        </div>
      </div>
    );
  }

  if (documents.length === 0) {
    return (
      <div className={`bg-white rounded-lg shadow-md p-6 text-center ${className}`}>
        <svg
          className="mx-auto h-12 w-12 text-secondary-400"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
          aria-hidden="true"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
          />
        </svg>
        <h3 className="mt-2 text-sm font-medium text-secondary-900">No documents</h3>
        <p className="mt-1 text-sm text-secondary-500">
          Upload a document to get started.
        </p>
      </div>
    );
  }

  return (
    <div className={`bg-white rounded-lg shadow-md p-6 ${className}`}>
      <h2 className="text-xl font-semibold mb-4">Your Documents</h2>
      <div className="divide-y divide-secondary-200">
        {documents.map((document) => (
          <DocumentItem
            key={document.document_id}
            document={document}
            onDelete={() => onDelete(document.document_id)}
          />
        ))}
      </div>
    </div>
  );
};

export default DocumentList;
