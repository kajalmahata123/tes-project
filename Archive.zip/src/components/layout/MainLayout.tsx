import React, { ReactNode } from 'react';
import Navbar from '../common/Navbar';

interface MainLayoutProps {
  children: ReactNode;
  sidebar?: ReactNode;
}

const MainLayout: React.FC<MainLayoutProps> = ({ children, sidebar }) => {
  return (
    <div className="min-h-screen flex flex-col bg-secondary-100">
      <Navbar />
      <div className="flex-grow flex">
        {sidebar && (
          <aside className="w-64 bg-white shadow-md hidden md:block overflow-y-auto">
            {sidebar}
          </aside>
        )}
        <main className={`flex-1 p-4 md:p-6 overflow-y-auto ${sidebar ? 'md:ml-0' : ''}`}>
          {children}
        </main>
      </div>
    </div>
  );
};

export default MainLayout;