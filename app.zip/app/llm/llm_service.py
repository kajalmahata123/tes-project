import os
from typing import Annotated, Optional
from fastapi import Depends, HTTPException, status
from langchain_anthropic import ChatAnthropic
from app.config import get_settings

# Singleton pattern for service instances
_chroma_service = None
_embedding_service = None
_llm_service = None
_chat_memory_service = None


def get_llm_service() -> ChatAnthropic:
    """Return singleton instance of Anthropic Claude LLM service"""
    global _llm_service
    if _llm_service is None:
        if not get_settings().CLAUDE_API_KEY:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Anthropic API key not configured",
            )

        _llm_service = ChatAnthropic(
            model=get_settings().ANTHROPIC_MODEL,
            anthropic_api_key=get_settings().CLAUDE_API_KEY,
            temperature=0.2,
            max_tokens=4096,
        )

    return _llm_service


def create_llm_instance(model: Optional[str] = None, temperature: Optional[float] = None, 
                       max_tokens: Optional[int] = None) -> ChatAnthropic:
    """
    Create a new instance of the LLM with custom parameters.
    If any parameter is None, the default from settings will be used.
    
    Args:
        model: Model name override
        temperature: Temperature override
        max_tokens: Max tokens override
        
    Returns:
        New ChatAnthropic instance
    """
    settings = get_settings()
    
    if not settings.CLAUDE_API_KEY:
        raise ValueError("Anthropic API key not configured")
    
    return ChatAnthropic(
        model=model or settings.ANTHROPIC_MODEL,
        anthropic_api_key=settings.CLAUDE_API_KEY,
        temperature=temperature if temperature is not None else 0.2,
        max_tokens=max_tokens or 4096,
    )


LLM = Annotated[ChatAnthropic, Depends(get_llm_service)]

