import importlib
import logging
from typing import Dict, Type, Optional, List
from app.agents.base_agent import BaseAgent
from app.schemas.agent_schemas import AgentConfig
from app.core.agent_registry import AgentRegistry
from app.core.knowledge_base import KnowledgeBase
from app.config import get_settings

logger = logging.getLogger(__name__)


class AgentFactory:
    """
    Factory class for creating and managing agent instances.
    Allows dynamic loading and instantiation of agent classes.
    """

    def __init__(self, registry: AgentRegistry, knowledge_base: KnowledgeBase):
        """
        Initialize the agent factory.

        Args:
            registry: Registry of available agent types
            knowledge_base: Knowledge base for agents to use
        """
        self.registry = registry
        self.knowledge_base = knowledge_base
        self._agent_instances: Dict[str, BaseAgent] = {}
        logger.info(f"Agent factory initialized with {len(registry.get_registered_agents())} registered agent types")

    async def get_agent(self, agent_type: str, agent_id: Optional[str] = None) -> BaseAgent:
        """
        Get or create an agent instance by type and optional ID.

        Args:
            agent_type: Type of agent to create
            agent_id: Optional unique ID for the agent instance

        Returns:
            Agent instance

        Raises:
            ValueError: If agent type is not registered
        """
        # Use agent_id if provided, otherwise use agent_type as the instance key
        instance_key = agent_id or agent_type

        # Return existing instance if available
        if instance_key in self._agent_instances:
            return self._agent_instances[instance_key]

        # Get agent class from registry
        agent_class = self.registry.get_agent_class(agent_type)
        if not agent_class:
            raise ValueError(f"Agent type '{agent_type}' is not registered")

        # Get settings
        settings = get_settings()

        # Create agent configuration with API keys
        config = AgentConfig(
            name=instance_key,
            knowledge_base=self.knowledge_base,
            api_keys={
                "anthropic": settings.CLAUDE_API_KEY,
                "openai": settings.OPENAI_API_KEY
            },
            temperature=0.2,
            max_iterations=5
        )

        # Log configuration details for debugging
        logger.info(f"Creating agent with config: name={config.name}, has_kb={config.knowledge_base is not None}")
        logger.info(
            f"API keys configured: anthropic={bool(config.api_keys.get('anthropic'))}, openai={bool(config.api_keys.get('openai'))}")

        # Instantiate the agent
        try:
            agent = agent_class(config)
            await agent.initialize()

            # Store instance
            self._agent_instances[instance_key] = agent
            logger.info(f"Created new agent instance: {agent}")

            return agent
        except Exception as e:
            logger.error(f"Error creating agent instance: {e}", exc_info=True)
            raise

    def available_agents(self) -> List[str]:
        """
        Get list of available agent types.

        Returns:
            List of registered agent type names
        """
        return self.registry.get_registered_agents()

    def register_agent_class(self, agent_type: str, agent_class: Type[BaseAgent]) -> None:
        """
        Register a new agent class.

        Args:
            agent_type: Type name for the agent
            agent_class: Agent class to register

        Raises:
            ValueError: If agent_type is already registered
        """
        self.registry.register_agent(agent_type, agent_class)
        logger.info(f"Registered new agent type: {agent_type}")

    async def load_dynamic_agent(self, module_path: str, class_name: str, agent_type: str) -> None:
        """
        Dynamically load and register an agent class from a module.

        Args:
            module_path: Python module path
            class_name: Agent class name in the module
            agent_type: Type name to register the agent under

        Raises:
            ImportError: If module or class cannot be loaded
            TypeError: If loaded class is not a BaseAgent subclass
        """
        try:
            module = importlib.import_module(module_path)
            agent_class = getattr(module, class_name)

            if not issubclass(agent_class, BaseAgent):
                raise TypeError(f"Class {class_name} is not a subclass of BaseAgent")

            self.register_agent_class(agent_type, agent_class)
            logger.info(f"Dynamically loaded agent type '{agent_type}' from {module_path}.{class_name}")

        except (ImportError, AttributeError) as e:
            logger.error(f"Failed to load agent module {module_path}.{class_name}: {e}")
            raise ImportError(f"Could not load agent class: {e}")