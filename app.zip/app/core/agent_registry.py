from typing import Dict, Type, List, Optional
import logging

from app.agents.base_agent import BaseAgent

logger = logging.getLogger(__name__)


class AgentRegistry:
    """
    Registry for agent classes that can be instantiated by the factory.
    Enables dynamic registration and discovery of agent implementations.
    """

    def __init__(self):
        """Initialize an empty agent registry."""
        self._agents: Dict[str, Type[BaseAgent]] = {}
        logger.info("Agent registry initialized")

    def register_agent(self, agent_type: str, agent_class: Type[BaseAgent]) -> None:
        """
        Register an agent class with a type name.

        Args:
            agent_type: Unique name for this agent type
            agent_class: Class to instantiate for this agent type

        Raises:
            ValueError: If agent_type is already registered
        """
        if agent_type in self._agents:
            raise ValueError(f"Agent type '{agent_type}' is already registered")

        if not issubclass(agent_class, BaseAgent):
            raise TypeError(f"Agent class must be a subclass of BaseAgent")

        self._agents[agent_type] = agent_class
        logger.debug(f"Registered agent type '{agent_type}' with class {agent_class.__name__}")

    def unregister_agent(self, agent_type: str) -> None:
        """
        Remove an agent type from the registry.

        Args:
            agent_type: Agent type to remove

        Raises:
            KeyError: If agent_type is not registered
        """
        if agent_type not in self._agents:
            raise KeyError(f"Agent type '{agent_type}' is not registered")

        del self._agents[agent_type]
        logger.debug(f"Unregistered agent type '{agent_type}'")

    def get_agent_class(self, agent_type: str) -> Optional[Type[BaseAgent]]:
        """
        Get agent class by type name.

        Args:
            agent_type: Registered type name

        Returns:
            Agent class if found, None otherwise
        """
        return self._agents.get(agent_type)

    def get_registered_agents(self) -> List[str]:
        """
        Get a list of all registered agent types.

        Returns:
            List of registered agent type names
        """
        return list(self._agents.keys())

    def has_agent(self, agent_type: str) -> bool:
        """
        Check if an agent type is registered.

        Args:
            agent_type: Agent type to check

        Returns:
            True if agent type is registered, False otherwise
        """
        return agent_type in self._agents