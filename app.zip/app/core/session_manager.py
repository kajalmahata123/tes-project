# app/core/session_manager.py
import time
import logging
import json
from typing import Dict, List, Optional, Any
import asyncio
from datetime import datetime, timedelta
import uuid

from app.api.models.chat import SessionInfo, ChatMessage
from app.core.agent_factory import AgentFactory
from app.config import get_settings

# Import database manager - only if it exists
try:
    from db.manager import DatabaseManager

    HAS_DB = True
except ImportError:
    HAS_DB = False

logger = logging.getLogger(__name__)


class ChatSession:
    """
    Represents a chat session with an agent.
    Manages chat history and provides interface to the agent.
    """

    def __init__(self, session_id: str, agent_type: str, agent, app_id: str, messages: List[ChatMessage] = None):
        """
        Initialize chat session.

        Args:
            session_id: Unique session identifier
            agent_type: Type of agent used
            agent: Agent instance
            app_id: Identifier of the application owning this session
            messages: Optional list of existing messages
        """
        self.session_id = session_id
        self.agent_type = agent_type
        self.agent = agent
        self.app_id = app_id
        self.created_at = datetime.now()
        self.last_activity = self.created_at
        self.messages = messages or []
        logger.info(f"Created chat session {session_id} for app {app_id} with agent type {agent_type}")

    async def process_message(self, message: str) -> str:
        """
        Process a user message and generate a response.

        Args:
            message: User message text

        Returns:
            Agent response text
        """
        # Update activity timestamp
        self.last_activity = datetime.now()

        # Add user message to history
        user_msg = ChatMessage(
            role="user",
            content=message,
            timestamp=self.last_activity.isoformat()
        )
        self.messages.append(user_msg)

        # Get response from agent - pass a fresh state for each new message
        # This ensures the agent considers it a new request even in the same session
        response = await self.agent.process_message(message, self.messages)

        # Add agent response to history
        assistant_msg = ChatMessage(
            role="assistant",
            content=response,
            timestamp=datetime.now().isoformat()
        )
        self.messages.append(assistant_msg)

        # Save messages to database after each interaction
        try:
            session_manager = SessionManager.get_instance()
            await session_manager.save_session_state(self.session_id)
        except Exception as e:
            logger.error(f"Failed to save session state: {e}", exc_info=True)

        return response

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert session to dictionary for serialization.

        Returns:
            Dictionary representation of session
        """
        return {
            "session_id": self.session_id,
            "agent_type": self.agent_type,
            "app_id": self.app_id,
            "created_at": self.created_at.isoformat(),
            "last_activity": self.last_activity.isoformat(),
            "messages": [msg.model_dump() for msg in self.messages]
        }

    @property
    def is_expired(self) -> bool:
        """
        Check if session is expired based on last activity.

        Returns:
            True if session is expired, False otherwise
        """
        settings = get_settings()
        expiry_time = self.last_activity + timedelta(minutes=settings.SESSION_EXPIRY_MINUTES)
        return datetime.now() > expiry_time

    def clear_history(self) -> None:
        """Clear chat history but keep session."""
        self.messages = []
        # Also clear agent memory if possible
        if hasattr(self.agent, 'clear_memory'):
            self.agent.clear_memory()

        # Update the database to reflect cleared history
        try:
            session_manager = SessionManager.get_instance()
            asyncio.create_task(session_manager.clear_session_messages(self.session_id))
        except Exception as e:
            logger.error(f"Failed to clear session messages in database: {e}", exc_info=True)


class SessionManager:
    """
    Manages chat sessions for the application.
    Singleton class that stores active sessions and handles cleanup.
    """

    _instance = None
    SESSION_RETENTION_DAYS = 30  # Keep sessions for 30 days

    @classmethod
    def get_instance(cls):
        """
        Get singleton instance.

        Returns:
            SessionManager instance
        """
        if cls._instance is None:
            cls._instance = SessionManager()
        return cls._instance

    def __init__(self):
        """Initialize session manager."""
        if SessionManager._instance is not None:
            raise RuntimeError("SessionManager is a singleton. Use get_instance() instead.")

        self.sessions: Dict[str, ChatSession] = {}
        self.cleanup_task = None
        self.settings = get_settings()

        # Initialize database if available
        self.db = None
        self.use_db = getattr(self.settings, "USE_DATABASE", False) and HAS_DB

        if self.use_db:
            db_url = getattr(self.settings, "DB_URL", "sqlite+aiosqlite:///./data/sessions.db")
            self.db = DatabaseManager(db_url)
            logger.info(f"Session manager initialized with database: {db_url}")
        else:
            logger.info("Session manager initialized with in-memory storage only")

    async def initialize(self):
        """Initialize the session manager."""
        if self.use_db and self.db:
            await self.db.initialize()
            logger.info("Database initialized")

    async def start_cleanup_task(self):
        """Start periodic cleanup of expired sessions."""
        if self.cleanup_task is None:
            self.cleanup_task = asyncio.create_task(self._cleanup_loop())
            logger.info("Started session cleanup task")

    async def _cleanup_loop(self):
        """Periodically clean up expired sessions."""
        try:
            while True:
                await asyncio.sleep(60 * 5)  # Run every 5 minutes
                await self.cleanup_expired_sessions()
                await self.cleanup_old_sessions()
        except asyncio.CancelledError:
            logger.info("Session cleanup task cancelled")
        except Exception as e:
            logger.error(f"Error in session cleanup: {e}", exc_info=True)

    async def cleanup_expired_sessions(self):
        """Remove expired sessions based on inactivity."""
        expired_sessions = []

        for session_id, session in self.sessions.items():
            if session.is_expired:
                expired_sessions.append(session_id)

        for session_id in expired_sessions:
            await self.delete_session(session_id)

        if expired_sessions:
            logger.info(f"Cleaned up {len(expired_sessions)} expired sessions")

    async def cleanup_old_sessions(self):
        """Remove sessions older than SESSION_RETENTION_DAYS."""
        if not self.use_db or not self.db:
            return

        try:
            # Calculate cutoff date
            cutoff_date = datetime.now() - timedelta(days=self.SESSION_RETENTION_DAYS)
            cutoff_date_str = cutoff_date.isoformat()

            # Find sessions older than cutoff date
            old_sessions = await self.db.get_sessions_before_date(cutoff_date_str)

            # Delete old sessions
            deleted_count = 0
            for session in old_sessions:
                session_id = session["session_id"]

                # Remove from memory if present
                if session_id in self.sessions:
                    del self.sessions[session_id]

                # Remove from database
                deleted = await self.db.delete_session(session_id)
                if deleted:
                    deleted_count += 1

            if deleted_count > 0:
                logger.info(f"Cleaned up {deleted_count} sessions older than {self.SESSION_RETENTION_DAYS} days")
        except Exception as e:
            logger.error(f"Error cleaning up old sessions: {e}", exc_info=True)

    async def get_session(
            self, session_id: str, agent_type: str, agent_factory: AgentFactory, app_id: str
    ) -> ChatSession:
        """
        Get or create a chat session.

        Args:
            session_id: Session identifier
            agent_type: Type of agent to use
            agent_factory: Factory for creating agents
            app_id: Identifier of the application requesting the session

        Returns:
            Chat session

        Raises:
            ValueError: If agent type is not available or session belongs to a different app
        """
        # Check if session exists in memory
        if session_id in self.sessions:
            session = self.sessions[session_id]

            # Security check: ensure the app_id matches
            if session.app_id != app_id:
                logger.warning(
                    f"App {app_id} attempted to access session {session_id} belonging to app {session.app_id}")
                raise ValueError(f"Session {session_id} does not belong to app {app_id}")

            # If agent type doesn't match, recreate session
            if session.agent_type != agent_type:
                logger.info(f"Changing agent type for session {session_id} from {session.agent_type} to {agent_type}")
                await self.delete_session(session_id)
                return await self._create_session(session_id, agent_type, agent_factory, app_id)

            # Update last activity
            session.last_activity = datetime.now()
            return session

        # Check database if enabled
        if self.use_db and self.db:
            try:
                db_session = await self.db.get_session(session_id)
                if db_session:
                    # Security check: ensure the app_id matches
                    db_app_id = db_session.get("app_id")
                    if db_app_id and db_app_id != app_id:
                        logger.warning(
                            f"App {app_id} attempted to access session {session_id} belonging to app {db_app_id}")
                        raise ValueError(f"Session {session_id} does not belong to app {app_id}")

                    # Get messages from database
                    messages = await self.db.get_messages(session_id)

                    # If agent type doesn't match, recreate session
                    if db_session["agent_type"] != agent_type:
                        logger.info(
                            f"Changing agent type for session {session_id} from {db_session['agent_type']} to {agent_type}")
                        await self.delete_session(session_id)
                        return await self._create_session(session_id, agent_type, agent_factory, app_id)

                    # Create agent
                    agent = await agent_factory.get_agent(agent_type, session_id)

                    # Create session with loaded messages
                    created_at = datetime.fromisoformat(db_session["created_at"])
                    last_activity = datetime.now()  # Update last activity to now

                    session = ChatSession(session_id, agent_type, agent, app_id, messages)
                    session.created_at = created_at
                    session.last_activity = last_activity

                    # Update last activity in database
                    await self.db.update_session(
                        session_id=session_id,
                        last_activity=last_activity.isoformat(),
                        app_id=app_id,  # Make sure app_id is updated
                        state_data=None
                    )

                    # Store in memory
                    self.sessions[session_id] = session
                    logger.info(
                        f"Loaded session {session_id} for app {app_id} from database with {len(messages)} messages")
                    return session
            except Exception as e:
                logger.error(f"Error loading session from database: {e}", exc_info=True)

        # Create new session
        return await self._create_session(session_id, agent_type, agent_factory, app_id)

    async def _create_session(
            self, session_id: str, agent_type: str, agent_factory: AgentFactory, app_id: str
    ) -> ChatSession:
        """
        Create a new chat session.

        Args:
            session_id: Session identifier
            agent_type: Type of agent to use
            agent_factory: Factory for creating agents
            app_id: Identifier of the application owning this session

        Returns:
            New chat session

        Raises:
            ValueError: If agent type is not available
        """
        # Get agent
        agent = await agent_factory.get_agent(agent_type, session_id)

        # Create session
        session = ChatSession(session_id, agent_type, agent, app_id)
        self.sessions[session_id] = session

        # Save to database if enabled
        if self.use_db and self.db:
            try:
                now = datetime.now().isoformat()
                await self.db.create_session(
                    session_id=session_id,
                    agent_type=agent_type,
                    app_id=app_id,
                    created_at=now,
                    last_activity=now
                )
            except Exception as e:
                logger.error(f"Error saving session to database: {e}", exc_info=True)

        # Ensure cleanup task is running
        await self.start_cleanup_task()

        return session

    async def delete_session(self, session_id: str, app_id: str = None) -> bool:
        """
        Delete a chat session.

        Args:
            session_id: Session identifier
            app_id: Optional app identifier for security check

        Returns:
            True if session was deleted, False if not found or access denied
        """
        # Security check if app_id is provided
        if app_id and session_id in self.sessions:
            session = self.sessions[session_id]
            if session.app_id != app_id:
                logger.warning(
                    f"App {app_id} attempted to delete session {session_id} belonging to app {session.app_id}")
                return False

        # Remove from memory
        memory_deleted = False
        if session_id in self.sessions:
            del self.sessions[session_id]
            memory_deleted = True

        # Remove from database if enabled
        db_deleted = False
        if self.use_db and self.db:
            try:
                # If app_id is provided, check ownership before deleting
                if app_id:
                    db_session = await self.db.get_session(session_id)
                    if db_session and db_session.get("app_id") != app_id:
                        logger.warning(f"App {app_id} attempted to delete session {session_id} from database")
                        return False

                db_deleted = await self.db.delete_session(session_id)
            except Exception as e:
                logger.error(f"Error deleting session from database: {e}", exc_info=True)

        if memory_deleted or db_deleted:
            logger.info(f"Deleted session {session_id}")
            return True

        return False

    async def list_app_sessions(self, app_id: str, limit: int = 10, offset: int = 0) -> List[SessionInfo]:
        """
        List sessions for a specific application.

        Args:
            app_id: Application identifier
            limit: Maximum number of sessions to return
            offset: Number of sessions to skip

        Returns:
            List of session info objects
        """
        # If database is enabled, get sessions from database
        if self.use_db and self.db:
            try:
                db_sessions = await self.db.get_app_sessions(
                    app_id=app_id,
                    limit=limit,
                    offset=offset,
                    sort_by="last_activity",
                    ascending=False
                )

                return [
                    SessionInfo(
                        session_id=s["session_id"],
                        agent_type=s["agent_type"],
                        app_id=s["app_id"],
                        created_at=s["created_at"],
                        last_activity=s["last_activity"],
                        message_count=await self.db.get_message_count(s["session_id"])
                    )
                    for s in db_sessions
                ]
            except Exception as e:
                logger.error(f"Error listing app sessions from database: {e}", exc_info=True)

        # Fallback to memory if database is not available or failed
        # Get sessions for this app from memory
        app_sessions = [
            s for s in self.sessions.values()
            if s.app_id == app_id
        ]

        # Sort sessions by last activity (newest first)
        sorted_sessions = sorted(
            app_sessions,
            key=lambda s: s.last_activity,
            reverse=True
        )

        # Apply pagination
        paginated = sorted_sessions[offset:offset + limit]

        # Convert to info objects
        return [
            SessionInfo(
                session_id=s.session_id,
                agent_type=s.agent_type,
                app_id=s.app_id,
                created_at=s.created_at.isoformat(),
                last_activity=s.last_activity.isoformat(),
                message_count=len(s.messages)
            )
            for s in paginated
        ]

    async def get_session_info(self, session_id: str, app_id: str = None) -> Optional[SessionInfo]:
        """
        Get information about a session.

        Args:
            session_id: Session identifier
            app_id: Optional app identifier for security check

        Returns:
            Session info or None if not found or access denied
        """
        # Try memory first
        session = self.sessions.get(session_id)
        if session:
            # Security check if app_id is provided
            if app_id and session.app_id != app_id:
                logger.warning(
                    f"App {app_id} attempted to access session info for {session_id} belonging to app {session.app_id}")
                return None

            return SessionInfo(
                session_id=session.session_id,
                agent_type=session.agent_type,
                app_id=session.app_id,
                created_at=session.created_at.isoformat(),
                last_activity=session.last_activity.isoformat(),
                message_count=len(session.messages),
                messages=session.messages
            )

        # Try database if available
        if self.use_db and self.db:
            try:
                db_session = await self.db.get_session(session_id)
                if db_session:
                    # Security check if app_id is provided
                    db_app_id = db_session.get("app_id")
                    if app_id and db_app_id and db_app_id != app_id:
                        logger.warning(
                            f"App {app_id} attempted to access session info for {session_id} belonging to app {db_app_id}")
                        return None

                    messages = await self.db.get_messages(session_id)
                    return SessionInfo(
                        session_id=db_session["session_id"],
                        agent_type=db_session["agent_type"],
                        app_id=db_session.get("app_id", "unknown"),
                        created_at=db_session["created_at"],
                        last_activity=db_session["last_activity"],
                        message_count=len(messages),
                        messages=messages
                    )
            except Exception as e:
                logger.error(f"Error getting session info from database: {e}", exc_info=True)

        return None

    async def save_session_state(self, session_id: str) -> bool:
        """
        Save session state to persistent storage.

        Args:
            session_id: Session identifier

        Returns:
            True if saved successfully, False otherwise
        """
        # Get session from memory
        session = self.sessions.get(session_id)
        if not session:
            return False

        # Save to database if enabled
        if self.use_db and self.db:
            try:
                # Update session
                await self.db.update_session(
                    session_id=session_id,
                    last_activity=session.last_activity.isoformat(),
                    app_id=session.app_id,  # Make sure app_id is stored
                    state_data=None  # We don't currently store agent state
                )

                # Save messages - only save messages that don't already exist in the database
                for msg in session.messages:
                    message_id = f"{session_id}_{msg.timestamp}"

                    # Check if this message already exists in DB to avoid duplicates
                    exists = await self.db.message_exists(message_id)
                    if not exists:
                        await self.db.add_message(
                            message_id=message_id,
                            session_id=session_id,
                            role=msg.role,
                            content=msg.content,
                            timestamp=msg.timestamp
                        )

                logger.debug(
                    f"Saved session {session_id} for app {session.app_id} to database with {len(session.messages)} messages")
                return True
            except Exception as e:
                logger.error(f"Error saving session to database: {e}", exc_info=True)
                return False

        # For non-DB mode, just log
        logger.debug(f"Saved state for session {session_id} (in-memory only)")
        return True

    async def clear_session_messages(self, session_id: str, app_id: str = None) -> bool:
        """
        Clear messages for a specific session in the database.

        Args:
            session_id: Session identifier
            app_id: Optional app identifier for security check

        Returns:
            True if cleared successfully, False otherwise
        """
        if not self.use_db or not self.db:
            return False

        try:
            # Security check if app_id is provided
            if app_id:
                session = self.sessions.get(session_id)
                if session and session.app_id != app_id:
                    logger.warning(
                        f"App {app_id} attempted to clear messages for session {session_id} belonging to app {session.app_id}")
                    return False

                db_session = await self.db.get_session(session_id)
                if db_session and db_session.get("app_id") != app_id:
                    logger.warning(f"App {app_id} attempted to clear messages for session {session_id} from database")
                    return False

            await self.db.delete_session_messages(session_id)
            logger.info(f"Cleared messages for session {session_id} from database")
            return True
        except Exception as e:
            logger.error(f"Error clearing messages from database: {e}", exc_info=True)
            return False