export interface Agent {
  id: string;
  type: 'visa_api_agent' | 'code_generator' | 'workflow_creator' | 'system';
  label: string;
  status: 'active' | 'inactive' | 'error';
  data?: Record<string, any>;
}

export interface AgentEdge {
  id: string;
  source: string;
  target: string;
  label?: string;
  type?: string;
}

export interface AgentGraphData {
  nodes: Agent[];
  edges: AgentEdge[];
}

export interface AgentGraphProps {
  apiKey: string;
  appId?: string;
  onError?: (error: Error) => void;
}

export interface AgentNodeProps {
  data: Agent;
  selected?: boolean;
  onClick?: () => void;
} 