import React from 'react';
import { Handle, Position } from 'reactflow';
import { Box, Typography, Paper } from '@mui/material';
import { AgentNodeProps } from '../../types/agent';

const AgentNode: React.FC<AgentNodeProps> = ({ data, selected }) => {
  const statusColor = {
    active: '#4caf50',
    inactive: '#9e9e9e',
    error: '#f44336'
  }[data.status] || '#9e9e9e';

  return (
    <Paper
      elevation={selected ? 8 : 3}
      sx={{
        padding: 2,
        minWidth: 200,
        backgroundColor: '#ffffff',
        border: `2px solid ${statusColor}`,
        borderRadius: 2
      }}
    >
      <Handle type="target" position={Position.Top} />
      
      <Box>
        <Typography variant="subtitle1" fontWeight="bold">
          {data.label || 'Unnamed Agent'}
        </Typography>
        <Typography variant="body2" color="textSecondary">
          Type: {data.type}
        </Typography>
        <Typography variant="body2" color="textSecondary">
          Status: {data.status}
        </Typography>
      </Box>

      <Handle type="source" position={Position.Bottom} />
    </Paper>
  );
};

export default AgentNode; 