import React, { useEffect, useState, useCallback } from 'react';
import ReactFlow, {
  Background,
  Controls,
  Node,
  Edge,
  useNodesState,
  useEdgesState,
  ConnectionMode
} from 'reactflow';
import 'reactflow/dist/style.css';
import { Box, CircularProgress, Alert } from '@mui/material';
import { Agent, AgentEdge, AgentGraphProps } from '../types/agent';
import AgentNode from './nodes/AgentNode';

const nodeTypes = {
  agent: AgentNode
};

const AgentGraph: React.FC<AgentGraphProps> = ({ apiKey, appId, onError }) => {
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchAgentGraph = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);

      const response = await fetch('/api/v1/graphs/agents/graph', {
        headers: {
          'Accept': 'application/json',
          'api_key': apiKey,
          ...(appId && { 'app_id': appId })
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch agent graph: ${response.statusText}`);
      }

      const data = await response.json();
      
      // Transform nodes for React Flow
      const graphNodes: Node[] = (data.nodes || []).map((agent: Agent) => ({
        id: agent.id,
        type: 'agent',
        position: agent.data?.position || { x: 0, y: 0 },
        data: agent
      }));

      // Transform edges for React Flow
      const graphEdges: Edge[] = (data.edges || []).map((edge: AgentEdge) => ({
        id: edge.id,
        source: edge.source,
        target: edge.target,
        label: edge.label,
        type: edge.type
      }));

      setNodes(graphNodes);
      setEdges(graphEdges);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to fetch agent graph';
      setError(errorMessage);
      onError?.(err instanceof Error ? err : new Error(errorMessage));
    } finally {
      setLoading(false);
    }
  }, [apiKey, appId, onError]);

  useEffect(() => {
    fetchAgentGraph();

    // Set up WebSocket connection for live updates
    const ws = new WebSocket(
      `ws://${window.location.host}/api/v1/ws/graph-updates?api_key=${apiKey}${appId ? `&app_id=${appId}` : ''}`
    );

    ws.onmessage = (event) => {
      const update = JSON.parse(event.data);
      if (update.type === 'graph_update') {
        fetchAgentGraph();
      }
    };

    return () => {
      ws.close();
    };
  }, [apiKey, appId, fetchAgentGraph]);

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" height="100%">
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box p={2}>
        <Alert severity="error" onClose={() => setError(null)}>
          {error}
        </Alert>
      </Box>
    );
  }

  return (
    <Box sx={{ width: '100%', height: '100%', minHeight: 600 }}>
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        nodeTypes={nodeTypes}
        connectionMode={ConnectionMode.STRICT}
        fitView
      >
        <Background />
        <Controls />
      </ReactFlow>
    </Box>
  );
};

export default AgentGraph; 