/**
 * AgentNode.jsx
 * Base component for rendering agent nodes in the agent graph
 */

const AgentNode = ({ data }) => {
  const { Typography, Box } = MaterialUI;
  
  // Default node styling classes
  const nodeClasses = `agent-node ${data.nodeType ? data.nodeType + '-node' : ''}`;
  
  return (
    <div className={nodeClasses}>
      <div className="node-title">
        {data.label}
      </div>
      
      {data.description && (
        <div className="node-description">
          {data.description}
        </div>
      )}
      
      {data.metrics && (
        <div className="metrics-card">
          {Object.entries(data.metrics).map(([key, value]) => (
            <div key={key} className="metrics-row">
              <Typography variant="caption">{formatMetricKey(key)}:</Typography>
              <Typography variant="caption" style={{ fontWeight: 'bold' }}>{value}</Typography>
            </div>
          ))}
        </div>
      )}
      
      {data.status && (
        <Box display="flex" alignItems="center" justifyContent="center" mt={1}>
          <div style={{ 
            width: 10, 
            height: 10, 
            borderRadius: '50%', 
            backgroundColor: data.status === 'active' ? '#4caf50' : '#f44336',
            marginRight: 5
          }} />
          <Typography variant="caption">
            {data.status === 'active' ? 'Active' : 'Inactive'}
          </Typography>
        </Box>
      )}
    </div>
  );
};

// Helper function to format metric keys for display
const formatMetricKey = (key) => {
  // Convert camelCase to Title Case with Spaces
  return key
    .replace(/([A-Z])/g, ' $1')
    .replace(/^./, (str) => str.toUpperCase());
}; 