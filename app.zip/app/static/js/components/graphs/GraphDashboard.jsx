/**
 * GraphDashboard.jsx
 * Dashboard component that combines the agent and tool graph visualizations
 */

const GraphDashboard = () => {
  const { useState, useRef } = React;
  const { 
    AppBar, Tabs, Tab, Typography, Box, Container, Paper
  } = MaterialUI;
  
  // Tab state
  const [currentTab, setCurrentTab] = useState(0);
  
  // References to child components for updating
  const agentGraphRef = useRef(null);
  const toolGraphRef = useRef(null);
  
  // Handle tab change
  const handleTabChange = (event, newValue) => {
    setCurrentTab(newValue);
  };
  
  // Tab panel component
  const TabPanel = ({ children, value, index }) => {
    return (
      <div role="tabpanel" hidden={value !== index} id={`graph-tabpanel-${index}`}>
        {value === index && (
          <Box p={3}>
            {children}
          </Box>
        )}
      </div>
    );
  };
  
  // Handlers for WebSocket updates
  const handleAgentGraphUpdate = (graphData) => {
    if (agentGraphRef.current && agentGraphRef.current.updateGraphData) {
      agentGraphRef.current.updateGraphData(graphData);
    }
  };
  
  const handleToolGraphUpdate = (graphData) => {
    if (toolGraphRef.current && toolGraphRef.current.updateGraphData) {
      toolGraphRef.current.updateGraphData(graphData);
    }
  };
  
  return (
    <div className="graph-dashboard">
      {/* LiveGraphUpdates component for WebSocket connection */}
      <LiveGraphUpdates 
        onAgentGraphUpdate={handleAgentGraphUpdate}
        onToolGraphUpdate={handleToolGraphUpdate}
      />
      
      <Typography variant="h5" gutterBottom>
        System Visualization Dashboard
      </Typography>
      
      <Typography variant="body1" paragraph>
        Explore the agent workflows and tool relationships within the Content-Craft Visa API Agent system. 
        These visualizations help understand how different components interact and provide insights into system performance.
      </Typography>
      
      <Paper>
        <AppBar position="static" color="default" elevation={0}>
          <Tabs
            value={currentTab}
            onChange={handleTabChange}
            indicatorColor="primary"
            textColor="primary"
            variant="fullWidth"
          >
            <Tab label="Agent Workflow" />
            <Tab label="Tool Ecosystem" />
            <Tab label="Combined View" />
          </Tabs>
        </AppBar>
        
        <TabPanel value={currentTab} index={0}>
          <Typography variant="subtitle1" gutterBottom>
            Agent Workflow Graph
          </Typography>
          <Typography variant="body2" paragraph>
            This graph shows how agents interact with each other and system components. 
            Click on nodes to view detailed metrics.
          </Typography>
          <div className="graph-container">
            <AgentGraph ref={agentGraphRef} />
          </div>
        </TabPanel>
        
        <TabPanel value={currentTab} index={1}>
          <Typography variant="subtitle1" gutterBottom>
            Tool Ecosystem Graph
          </Typography>
          <Typography variant="body2" paragraph>
            This visualization shows the relationships between different tools used by agents.
            Tool size indicates usage frequency, and connections show related tools.
            Click on a tool to see detailed metrics and information.
          </Typography>
          <div className="graph-container">
            <ToolGraph ref={toolGraphRef} />
          </div>
        </TabPanel>
        
        <TabPanel value={currentTab} index={2}>
          <Typography variant="subtitle1" gutterBottom>
            Combined System View
          </Typography>
          <Typography variant="body2" paragraph>
            This view shows both agent workflows and tool relationships side by side,
            providing a comprehensive overview of the entire system.
          </Typography>
          
          <Box display="flex" flexDirection={{ xs: 'column', md: 'row' }} gap={2}>
            <Box flex={1} height={{ xs: 400, md: 600 }} mb={{ xs: 2, md: 0 }}>
              <Typography variant="subtitle2" align="center" gutterBottom>
                Agent Workflow
              </Typography>
              <div style={{ width: '100%', height: '100%', position: 'relative' }}>
                <AgentGraph ref={agentGraphRef} />
              </div>
            </Box>
            
            <Box flex={1} height={{ xs: 400, md: 600 }}>
              <Typography variant="subtitle2" align="center" gutterBottom>
                Tool Ecosystem
              </Typography>
              <div style={{ width: '100%', height: '100%', position: 'relative' }}>
                <ToolGraph ref={toolGraphRef} />
              </div>
            </Box>
          </Box>
        </TabPanel>
      </Paper>
      
      <Box mt={2} display="flex" justifyContent="flex-end">
        <Typography variant="caption" color="textSecondary">
          Data updates automatically via WebSocket
        </Typography>
      </Box>
    </div>
  );
}; 