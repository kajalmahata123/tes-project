/**
 * ToolGraph.jsx
 * Component for displaying the tool graph visualization using D3 force-directed graph
 */

const ToolGraph = React.forwardRef((props, ref) => {
  const { 
    useState, useEffect, useRef, useCallback, useImperativeHandle
  } = React;
  
  const { 
    CircularProgress, Typography, Button, Box, Paper, Chip
  } = MaterialUI;
  
  // State for tool graph data
  const [graphData, setGraphData] = useState({ nodes: [], links: [] });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedTool, setSelectedTool] = useState(null);
  
  // Refs for D3 elements
  const containerRef = useRef(null);
  const svgRef = useRef(null);
  const simulationRef = useRef(null);
  
  // API Configuration
  const API_URL = '/api/v1/graphs/tools/graph';
  const API_KEY = localStorage.getItem('api_key') || ''; // Should be stored securely
  const APP_ID = window.VISA_API_BOT_APP_ID;
  
  // Tool category colors
  const categoryColors = {
    'Documentation': '#3782F7',
    'Code': '#F77A37',
    'Search': '#37F7BA',
    'Data Processing': '#A337F7',
    'Visualization': '#F7D037',
    'Knowledge': '#37C0F7',
    'Default': '#777777'
  };
  
  // Expose methods via ref
  useImperativeHandle(ref, () => ({
    updateGraphData: (data) => {
      if (!data || !data.nodes || !data.links) return;
      setGraphData(data);
      // Force re-render of the D3 visualization
      if (simulationRef.current) {
        simulationRef.current.stop();
      }
      renderGraph(data);
    }
  }));
  
  // Function to render the D3 graph
  const renderGraph = useCallback((data) => {
    if (loading || !data.nodes.length || !containerRef.current) return;
    
    const width = containerRef.current.clientWidth;
    const height = containerRef.current.clientHeight;
    
    // Clear any existing SVG
    d3.select(svgRef.current).selectAll("*").remove();
    
    // Create SVG
    const svg = d3.select(svgRef.current)
      .attr("width", width)
      .attr("height", height)
      .attr("viewBox", [0, 0, width, height])
      .attr("style", "max-width: 100%; height: auto;");
    
    // Define forces
    const simulation = d3.forceSimulation(data.nodes)
      .force("link", d3.forceLink(data.links).id(d => d.id).distance(d => 100 / (d.value || 1)))
      .force("charge", d3.forceManyBody().strength(-300))
      .force("center", d3.forceCenter(width / 2, height / 2))
      .force("collide", d3.forceCollide().radius(d => 30 + (d.value / 3 || 10)));
    
    // Create links
    const link = svg.append("g")
      .attr("stroke", "#999")
      .attr("stroke-opacity", 0.6)
      .selectAll("line")
      .data(data.links)
      .join("line")
      .attr("stroke-width", d => Math.sqrt(d.value));
    
    // Create nodes
    const node = svg.append("g")
      .selectAll("g")
      .data(data.nodes)
      .join("g")
      .call(drag(simulation))
      .on("click", (event, d) => {
        setSelectedTool(d);
        event.stopPropagation();
      });
    
    // Add circles to nodes
    node.append("circle")
      .attr("r", d => 10 + (d.value / 5 || 5))
      .attr("fill", d => categoryColors[d.category] || categoryColors.Default)
      .attr("stroke", "#fff")
      .attr("stroke-width", 1.5);
    
    // Add labels to nodes
    node.append("text")
      .attr("x", 0)
      .attr("y", d => -10 - (d.value / 5 || 5))
      .attr("text-anchor", "middle")
      .attr("font-size", "10px")
      .text(d => d.name)
      .attr("pointer-events", "none")
      .attr("stroke", "#fff")
      .attr("stroke-width", 0.5)
      .attr("paint-order", "stroke");
    
    // Add tool category labels
    node.append("text")
      .attr("x", 0)
      .attr("y", d => 15 + (d.value / 5 || 5))
      .attr("font-size", "8px")
      .attr("text-anchor", "middle")
      .attr("fill", "#666")
      .text(d => d.category)
      .attr("pointer-events", "none");
    
    // Define tick function
    simulation.on("tick", () => {
      link
        .attr("x1", d => d.source.x)
        .attr("y1", d => d.source.y)
        .attr("x2", d => d.target.x)
        .attr("y2", d => d.target.y);
      
      node.attr("transform", d => `translate(${d.x},${d.y})`);
    });
    
    // Click on background to deselect
    svg.on("click", () => {
      setSelectedTool(null);
    });
    
    // Save simulation to ref for cleanup
    simulationRef.current = simulation;
    
  }, [loading, containerRef, categoryColors, setSelectedTool]);
  
  // Fetch tool graph data from the API
  const fetchToolGraph = useCallback(async () => {
    setLoading(true);
    try {
      const response = await fetch(API_URL, {
        headers: {
          'X-API-Key': API_KEY,
          'X-App-ID': APP_ID
        }
      });
      
      if (!response.ok) {
        throw new Error(`Error fetching tool graph: ${response.statusText}`);
      }
      
      const data = await response.json();
      setGraphData(data);
      setError(null);
    } catch (err) {
      console.error('Error fetching tool graph:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [API_URL, API_KEY, APP_ID]);
  
  // Load data on component mount
  useEffect(() => {
    fetchToolGraph();
    
    // Initial load only, updates will come through WebSocket
  }, [fetchToolGraph]);
  
  // Create and update the force-directed graph using D3
  useEffect(() => {
    renderGraph(graphData);
    
    // Cleanup function
    return () => {
      if (simulationRef.current) {
        simulationRef.current.stop();
      }
    };
  }, [graphData, renderGraph]);
  
  // Drag function for nodes
  function drag(simulation) {
    function dragstarted(event) {
      if (!event.active) simulation.alphaTarget(0.3).restart();
      event.subject.fx = event.subject.x;
      event.subject.fy = event.subject.y;
    }
    
    function dragged(event) {
      event.subject.fx = event.x;
      event.subject.fy = event.y;
    }
    
    function dragended(event) {
      if (!event.active) simulation.alphaTarget(0);
      event.subject.fx = null;
      event.subject.fy = null;
    }
    
    return d3.drag()
      .on("start", dragstarted)
      .on("drag", dragged)
      .on("end", dragended);
  }
  
  // If loading, show a loading indicator
  if (loading && graphData.nodes.length === 0) {
    return (
      <Box className="loading-container">
        <CircularProgress />
        <Typography variant="body1" style={{ marginLeft: 20 }}>
          Loading tool graph...
        </Typography>
      </Box>
    );
  }
  
  // If error, show error message
  if (error && graphData.nodes.length === 0) {
    return (
      <div className="error-message">
        <Typography variant="h6">Error Loading Tool Graph</Typography>
        <Typography variant="body1">{error}</Typography>
        <Button 
          variant="contained" 
          color="primary" 
          onClick={fetchToolGraph}
          style={{ marginTop: 16 }}
        >
          Retry
        </Button>
      </div>
    );
  }
  
  // Render the graph
  return (
    <div className="graph-view" ref={containerRef}>
      <svg ref={svgRef} width="100%" height="100%"></svg>
      
      {/* Graph Legend */}
      <div className="graph-legend">
        <Typography variant="subtitle2" gutterBottom>Tool Categories</Typography>
        {Object.entries(categoryColors).filter(([key]) => key !== 'Default').map(([category, color]) => (
          <div className="legend-item" key={category}>
            <span className="legend-color" style={{ backgroundColor: color }}></span>
            <span>{category}</span>
          </div>
        ))}
      </div>
      
      {/* Selected Tool Details Panel */}
      {selectedTool && (
        <Paper className="tool-details">
          <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
            <Typography variant="h6">{selectedTool.name}</Typography>
            <Button size="small" onClick={() => setSelectedTool(null)}>Close</Button>
          </Box>
          
          <Chip 
            label={selectedTool.category} 
            style={{ 
              backgroundColor: categoryColors[selectedTool.category] || categoryColors.Default,
              color: 'white',
              marginBottom: 16
            }} 
            size="small" 
          />
          
          {selectedTool.description && (
            <Typography variant="body2" paragraph>{selectedTool.description}</Typography>
          )}
          
          {selectedTool.stats && (
            <React.Fragment>
              <Typography variant="subtitle2">Usage Statistics</Typography>
              <Box mb={2}>
                {Object.entries(selectedTool.stats).map(([key, value]) => (
                  <Box key={key} display="flex" justifyContent="space-between" mb={0.5}>
                    <Typography variant="body2">{formatToolMetricKey(key)}:</Typography>
                    <Typography variant="body2" fontWeight="bold">{value}</Typography>
                  </Box>
                ))}
              </Box>
            </React.Fragment>
          )}
        </Paper>
      )}
    </div>
  );
});

// Helper function to format tool metric keys for display
const formatToolMetricKey = (key) => {
  // Convert camelCase to Title Case with Spaces
  return key
    .replace(/([A-Z])/g, ' $1')
    .replace(/^./, (str) => str.toUpperCase());
}; 