/**
 * WorkflowAgentNode.jsx
 * Component for rendering Workflow Agent nodes with specific styling
 */

const WorkflowAgentNode = ({ data }) => {
  const { Icon } = MaterialUI;
  
  // Add nodeType for specific styling
  const nodeData = {
    ...data,
    nodeType: 'workflow'
  };
  
  return (
    <div style={{ position: 'relative' }}>
      <div style={{ 
        position: 'absolute',
        top: -10,
        left: '50%',
        transform: 'translateX(-50%)',
        backgroundColor: '#37F7BA',
        color: 'white',
        padding: '2px 8px',
        borderRadius: 12,
        fontSize: 10,
        fontWeight: 'bold',
        zIndex: 10
      }}>
        WORKFLOW
      </div>
      <AgentNode data={nodeData} />
    </div>
  );
}; 