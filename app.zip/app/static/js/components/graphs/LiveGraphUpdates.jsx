/**
 * LiveGraphUpdates.jsx
 * Component for receiving real-time graph updates via WebSocket
 */

const LiveGraphUpdates = ({ onAgentGraphUpdate, onToolGraphUpdate }) => {
  const { useState, useEffect, useCallback } = React;
  const { Snackbar, Paper, Typography } = MaterialUI;
  
  // State for connection status
  const [connected, setConnected] = useState(false);
  const [error, setError] = useState(null);
  const [showNotification, setShowNotification] = useState(false);
  const [notificationMessage, setNotificationMessage] = useState('');
  const [lastUpdate, setLastUpdate] = useState(null);
  
  // Retrieve API key from localStorage
  const apiKey = localStorage.getItem('api_key') || '';
  
  const connectWebSocket = useCallback(() => {
    if (!apiKey) {
      console.error('API key is required for WebSocket connection');
      return;
    }

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const host = window.location.host;
    const clientId = `client_${Math.random().toString(36).substr(2, 8)}`;
    const appId = window.VISA_API_BOT_APP_ID;

    // Debug logging for WebSocket connection
    console.log('Initializing WebSocket connection:', {
      protocol,
      host,
      clientId,
      appId,
      apiKey: apiKey ? 'Present' : 'Missing'
    });

    const wsUrl = `${protocol}//${host}/api/v1/ws/graph-updates?api_key=${apiKey}&client_id=${clientId}&app_id=${appId}`;
    
    const ws = new WebSocket(wsUrl);
    
    ws.onopen = () => {
      console.log('WebSocket connected');
      setConnected(true);
      setError(null);
    };
    
    ws.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data);
        console.log('WebSocket message received:', message);
        
        // Handle different message types
        if (message.type === 'agent_graph_update' && onAgentGraphUpdate) {
          onAgentGraphUpdate(message.data);
          setNotificationMessage('Agent graph data updated');
          setShowNotification(true);
          setLastUpdate(new Date());
        } else if (message.type === 'tool_graph_update' && onToolGraphUpdate) {
          onToolGraphUpdate(message.data);
          setNotificationMessage('Tool graph data updated');
          setShowNotification(true);
          setLastUpdate(new Date());
        } else if (message.type === 'metric_update') {
          setNotificationMessage(`${message.metric_type} metrics updated`);
          setShowNotification(true);
          setLastUpdate(new Date());
        } else if (message.type === 'connection_status') {
          console.log('Connection status:', message);
        }
      } catch (err) {
        console.error('Error processing WebSocket message:', err);
      }
    };
    
    ws.onerror = (error) => {
      console.error('WebSocket error:', error);
      setError('WebSocket connection error');
      setConnected(false);
    };
    
    ws.onclose = (event) => {
      console.log('WebSocket closed:', event.code, event.reason);
      setConnected(false);
      
      // If connection was closed due to an error or unexpected disconnect
      if (event.code !== 1000) {
        setError(`WebSocket disconnected: ${event.reason || 'Unknown reason'}`);
        
        // Attempt to reconnect after a delay
        setTimeout(connectWebSocket, 5000);
      }
    };
  }, [apiKey, onAgentGraphUpdate, onToolGraphUpdate]);
  
  useEffect(() => {
    // Only connect if API key is available
    if (apiKey) {
      connectWebSocket();
    } else {
      setError('No API key available. Please set an API key.');
    }
    
    // Clean up function
    return () => {
      // No need to clean up WebSocket connection manually in modern browsers
    };
  }, [apiKey, connectWebSocket]);
  
  const handleCloseNotification = () => {
    setShowNotification(false);
  };
  
  const formatTime = (date) => {
    if (!date) return '';
    return date.toLocaleTimeString();
  };
  
  // Only render notification elements
  return (
    <>
      {/* Status indicator (only shown when there's an error) */}
      {error && (
        <Paper 
          style={{ 
            padding: '8px 16px', 
            marginBottom: '16px',
            backgroundColor: '#ffebee', 
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between'
          }}
        >
          <Typography variant="body2" style={{ color: '#d32f2f' }}>
            {error}
          </Typography>
        </Paper>
      )}
      
      {/* Update notification */}
      <Snackbar
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'right',
        }}
        open={showNotification}
        autoHideDuration={3000}
        onClose={handleCloseNotification}
      >
        <Paper 
          style={{ 
            padding: '8px 16px', 
            backgroundColor: '#e3f2fd',
            display: 'flex',
            flexDirection: 'column'
          }}
        >
          <Typography variant="body2" style={{ fontWeight: 'bold' }}>
            {notificationMessage}
          </Typography>
          {lastUpdate && (
            <Typography variant="caption" style={{ marginTop: 4 }}>
              {formatTime(lastUpdate)}
            </Typography>
          )}
        </Paper>
      </Snackbar>
    </>
  );
};

// Export for use in other components
window.LiveGraphUpdates = LiveGraphUpdates; 