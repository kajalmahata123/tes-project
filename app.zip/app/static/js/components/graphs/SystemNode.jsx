/**
 * SystemNode.jsx
 * Component for rendering system nodes (LLM, Knowledge Base) with specific styling
 */

const SystemNode = ({ data }) => {
  const { Typography, Box, Icon } = MaterialUI;
  
  // Determine node type and styling
  let nodeType, iconName, color;
  
  if (data.type === 'llm') {
    nodeType = 'llm';
    iconName = 'psychology';
    color = '#A337F7';
  } else if (data.type === 'knowledgeBase') {
    nodeType = 'knowledge-base';
    iconName = 'storage';
    color = '#F7D037';
  } else {
    nodeType = 'system';
    iconName = 'settings';
    color = '#37C0F7';
  }
  
  const nodeClasses = `agent-node ${nodeType}-node`;
  
  return (
    <div className={nodeClasses}>
      <Box display="flex" alignItems="center" justifyContent="center" mb={1}>
        <Icon style={{ color, marginRight: 5 }}>{iconName}</Icon>
        <div className="node-title">
          {data.label}
        </div>
      </Box>
      
      {data.description && (
        <div className="node-description">
          {data.description}
        </div>
      )}
      
      {data.metrics && (
        <div className="metrics-card">
          {Object.entries(data.metrics).map(([key, value]) => (
            <div key={key} className="metrics-row">
              <Typography variant="caption">{formatSystemMetricKey(key)}:</Typography>
              <Typography variant="caption" style={{ fontWeight: 'bold' }}>{value}</Typography>
            </div>
          ))}
        </div>
      )}
      
      {data.status && (
        <Box display="flex" alignItems="center" justifyContent="center" mt={1}>
          <div style={{ 
            width: 10, 
            height: 10, 
            borderRadius: '50%', 
            backgroundColor: data.status === 'active' ? '#4caf50' : '#f44336',
            marginRight: 5
          }} />
          <Typography variant="caption">
            {data.status === 'active' ? 'Active' : 'Inactive'}
          </Typography>
        </Box>
      )}
    </div>
  );
};

// Helper function to format system metric keys for display
const formatSystemMetricKey = (key) => {
  // Convert camelCase to Title Case with Spaces
  return key
    .replace(/([A-Z])/g, ' $1')
    .replace(/^./, (str) => str.toUpperCase());
}; 