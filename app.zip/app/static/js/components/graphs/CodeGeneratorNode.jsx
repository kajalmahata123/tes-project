/**
 * CodeGeneratorNode.jsx
 * Component for rendering Code Generator Agent nodes with specific styling
 */

const CodeGeneratorNode = ({ data }) => {
  const { Icon } = MaterialUI;
  
  // Add nodeType for specific styling
  const nodeData = {
    ...data,
    nodeType: 'code-generator'
  };
  
  return (
    <div style={{ position: 'relative' }}>
      <div style={{ 
        position: 'absolute',
        top: -10,
        left: '50%',
        transform: 'translateX(-50%)',
        backgroundColor: '#F77A37',
        color: 'white',
        padding: '2px 8px',
        borderRadius: 12,
        fontSize: 10,
        fontWeight: 'bold',
        zIndex: 10
      }}>
        CODE GEN
      </div>
      <AgentNode data={nodeData} />
    </div>
  );
}; 