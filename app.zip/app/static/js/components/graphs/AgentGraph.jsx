/**
 * AgentGraph.jsx
 * Simple agent relationship visualization using MaterialUI components
 */

const AgentGraph = React.forwardRef((props, ref) => {
  const { Box, Typography, Paper, List, ListItem, ListItemText, Divider, CircularProgress } = MaterialUI;
  const [agents, setAgents] = React.useState([]);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState(null);

  const fetchAgents = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/v1/graphs/agents/graph', {
        headers: {
          'Accept': 'application/json',
          'api_key': localStorage.getItem('api_key') || ''
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch agent data');
      }

      const data = await response.json();
      setAgents(data.nodes || []);
      setError(null);
    } catch (err) {
      console.error('Error fetching agent data:', err);
      setError('Unable to load agent data. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    fetchAgents();
  }, []);

  // Expose refresh method through ref
  React.useImperativeHandle(ref, () => ({
    updateGraph: fetchAgents
  }));

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ p: 3 }}>
        <Typography color="error" gutterBottom>{error}</Typography>
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h6" gutterBottom>
        Active Agents
      </Typography>
      <Paper elevation={2}>
        <List>
          {agents.length === 0 ? (
            <ListItem>
              <ListItemText primary="No agents currently active" />
            </ListItem>
          ) : (
            agents.map((agent, index) => (
              <React.Fragment key={agent.id || index}>
                <ListItem>
                  <ListItemText
                    primary={agent.label || 'Unnamed Agent'}
                    secondary={`Type: ${agent.type || 'Unknown'} | Status: ${agent.status || 'Unknown'}`}
                  />
                </ListItem>
                {index < agents.length - 1 && <Divider />}
              </React.Fragment>
            ))
          )}
        </List>
      </Paper>
    </Box>
  );
});

// Add display name for debugging
AgentGraph.displayName = 'AgentGraph';

// Export the component
export default AgentGraph; 