/**
 * VisaAPIAgentNode.jsx
 * Component for rendering Visa API Agent nodes with specific styling
 */

const VisaAPIAgentNode = ({ data }) => {
  const { Icon } = MaterialUI;
  
  // Add nodeType for specific styling
  const nodeData = {
    ...data,
    nodeType: 'visa-api'
  };
  
  return (
    <div style={{ position: 'relative' }}>
      <div style={{ 
        position: 'absolute',
        top: -10,
        left: '50%',
        transform: 'translateX(-50%)',
        backgroundColor: '#3782F7',
        color: 'white',
        padding: '2px 8px',
        borderRadius: 12,
        fontSize: 10,
        fontWeight: 'bold',
        zIndex: 10
      }}>
        VISA API
      </div>
      <AgentNode data={nodeData} />
    </div>
  );
}; 