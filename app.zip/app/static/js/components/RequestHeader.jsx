/**
 * RequestHeader.jsx
 * Component for displaying Visa API Bot request information
 */

const RequestHeader = () => {
  const { useState, useEffect } = React;
  const { 
    Paper, 
    Typography, 
    Box, 
    Chip,
    Divider,
    IconButton,
    Collapse,
    Alert
  } = MaterialUI;

  // State for request information
  const [requestInfo, setRequestInfo] = useState({
    status: 'idle',
    lastRequest: null,
    requestCount: 0,
    activeRequests: [],
    errors: []
  });

  const [expanded, setExpanded] = useState(true);

  // Fetch request information
  const fetchRequestInfo = async () => {
    try {
      const response = await fetch('/api/v1/status/requests', {
        headers: {
          'X-API-Key': localStorage.getItem('api_key'),
          'X-App-ID': 'Visa_api_Bot'
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch request information');
      }

      const data = await response.json();
      setRequestInfo(data);
    } catch (error) {
      console.error('Error fetching request info:', error);
    }
  };

  // Update request info periodically
  useEffect(() => {
    fetchRequestInfo();
    const interval = setInterval(fetchRequestInfo, 5000); // Update every 5 seconds
    
    return () => clearInterval(interval);
  }, []);

  // Format timestamp
  const formatTime = (timestamp) => {
    if (!timestamp) return 'N/A';
    return new Date(timestamp).toLocaleTimeString();
  };

  // Get status color
  const getStatusColor = (status) => {
    const colors = {
      idle: '#757575',
      processing: '#2196f3',
      success: '#4caf50',
      error: '#f44336'
    };
    return colors[status] || colors.idle;
  };

  return (
    <Paper 
      elevation={2} 
      sx={{ 
        mb: 2, 
        p: 2,
        backgroundColor: '#f8f9fa'
      }}
    >
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          <Typography variant="h6" component="div" sx={{ mr: 2 }}>
            Visa API Bot Status
          </Typography>
          <Chip
            label="Visa_api_Bot"
            size="small"
            color="primary"
            variant="outlined"
          />
        </Box>
        <IconButton 
          onClick={() => setExpanded(!expanded)}
          size="small"
        >
          <i className={`fas fa-chevron-${expanded ? 'up' : 'down'}`}></i>
        </IconButton>
      </Box>

      <Collapse in={expanded}>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
          <Chip
            label={(requestInfo.status || 'idle').toUpperCase()}
            sx={{
              backgroundColor: getStatusColor(requestInfo.status),
              color: 'white',
              mr: 2
            }}
          />
          <Typography variant="body2">
            Last Updated: {formatTime(requestInfo.lastRequest)}
          </Typography>
        </Box>

        <Divider sx={{ my: 1 }} />

        <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 2 }}>
          <Paper variant="outlined" sx={{ p: 1 }}>
            <Typography variant="subtitle2">Total Requests</Typography>
            <Typography variant="h6">{requestInfo.requestCount}</Typography>
          </Paper>
          
          <Paper variant="outlined" sx={{ p: 1 }}>
            <Typography variant="subtitle2">Active Requests</Typography>
            <Typography variant="h6">{requestInfo.activeRequests.length}</Typography>
          </Paper>
        </Box>

        {requestInfo.activeRequests.length > 0 && (
          <Box sx={{ mt: 2 }}>
            <Typography variant="subtitle2" gutterBottom>
              Active Requests
            </Typography>
            {requestInfo.activeRequests.map((request, index) => (
              <Alert 
                key={index} 
                severity="info" 
                sx={{ mb: 1 }}
              >
                {request.type} - Started at {formatTime(request.startTime)}
              </Alert>
            ))}
          </Box>
        )}

        {requestInfo.errors.length > 0 && (
          <Box sx={{ mt: 2 }}>
            <Typography variant="subtitle2" gutterBottom>
              Recent Errors
            </Typography>
            {requestInfo.errors.map((error, index) => (
              <Alert 
                key={index} 
                severity="error" 
                sx={{ mb: 1 }}
              >
                {error.message} - {formatTime(error.timestamp)}
              </Alert>
            ))}
          </Box>
        )}
      </Collapse>
    </Paper>
  );
};

// Export for use in other components
window.RequestHeader = RequestHeader; 