// chatgpt-style-widget.js - Part 1: Core Class and Initialization
class ChatGPTStyleWidget {
  constructor(options = {}) {
    this.apiUrl = options.apiUrl || 'http://localhost:8000/api/v1';
    this.apiKey = options.apiKey || '';
    this.containerId = options.containerId || 'chatgpt-widget-container';
    this.userId = options.userId || null;
    this.sessionId = options.sessionId || null;
    this.theme = options.theme || 'light';
    this.position = options.position || 'bottom-right';

    this.messages = [];
    this.initialized = false;
    this.loading = false;
    this.eventListeners = {};

    this.init();
  }

  async init() {
    // Prevent multiple initializations
    if (this.loading) return;
    this.loading = true;

    // Create container immediately
    this.createContainer();
    this.createStyles();

    try {
      // Load libraries in sequence
      await this.loadLibraries();

      // Render widget after libraries are loaded
      this.renderWidget();
      this.attachEventListeners();
      this.initialized = true;

      // Resume existing session or show welcome screen
      if (this.sessionId) {
        await this.loadSessionHistory();
      } else {
        this.showWelcomeScreen();
      }
    } catch (error) {
      console.error('Error initializing widget:', error);
    } finally {
      this.loading = false;
    }
  }

  async loadLibraries() {
    // Load all required libraries in sequence
    await this.loadStylesheets();
    await this.loadTailwind();
    await this.loadFontAwesome();
    await this.loadPrism();
    await this.loadMermaid();
  }

  loadStylesheet(url) {
    return new Promise((resolve) => {
      const link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = url;
      link.onload = () => resolve();
      link.onerror = () => {
        console.warn(`Failed to load stylesheet: ${url}`);
        resolve(); // Resolve anyway to prevent blocking
      };
      document.head.appendChild(link);
    });
  }

  async loadStylesheets() {
    await this.loadStylesheet('https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css');

    // Load Prism themes
    await this.loadStylesheet('https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/themes/prism.min.css');
    const darkTheme = await this.loadStylesheet('https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/themes/prism-tomorrow.min.css');

    // Set dark theme ID for later toggling
    const darkThemeLink = document.querySelector('link[href*="prism-tomorrow.min.css"]');
    if (darkThemeLink) {
      darkThemeLink.id = 'prism-dark-theme';
      darkThemeLink.disabled = this.theme !== 'dark';
    }
  }

  loadScript(url) {
    return new Promise((resolve) => {
      const script = document.createElement('script');
      script.src = url;
      script.onload = () => resolve();
      script.onerror = () => {
        console.warn(`Failed to load script: ${url}`);
        resolve(); // Resolve anyway to prevent blocking
      };
      document.head.appendChild(script);
    });
  }

  async loadTailwind() {
    await this.loadScript('https://cdn.tailwindcss.com');

    // Configure Tailwind
    if (window.tailwind) {
      const configScript = document.createElement('script');
      configScript.textContent = `
        tailwind.config = {
          darkMode: 'class',
          theme: {
            extend: {
              colors: {
                primary: '#10a37f',
                secondary: '#1a5f7a',
                dark: {
                  100: '#202123',
                  200: '#343541',
                  300: '#444654',
                  400: '#565869'
                },
                light: {
                  100: '#ffffff',
                  200: '#f7f7f8',
                  300: '#ececf1',
                  400: '#d9d9e3'
                }
              },
              boxShadow: {
                'chat': '0 0 15px rgba(0, 0, 0, 0.1)',
                'message': '0 2px 6px rgba(0, 0, 0, 0.05)'
              },
              keyframes: {
                typing: {
                  '0%, 60%, 100%': { transform: 'translateY(0)' },
                  '30%': { transform: 'translateY(-5px)' }
                }
              },
              animation: {
                typing: 'typing 1.4s infinite'
              }
            }
          }
        }
      `;
      document.head.appendChild(configScript);
    }
  }

  async loadFontAwesome() {
    await this.loadStylesheet('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css');
  }

  async loadPrism() {
    // Load Prism core first
    await this.loadScript('https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/components/prism-core.min.js');

    // Load autoloader which will handle language components on demand
    await this.loadScript('https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/plugins/autoloader/prism-autoloader.min.js');
  }

  async loadMermaid() {
    if (!window.mermaid) {
      await this.loadScript('https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js');

      if (window.mermaid) {
        window.mermaid.initialize({
          startOnLoad: true,
          theme: this.theme === 'dark' ? 'dark' : 'default'
        });
      }
    }
  }

  createContainer() {
    // Check if container exists
    let container = document.getElementById(this.containerId);
    if (!container) {
      // Create container element
      container = document.createElement('div');
      container.id = this.containerId;
      document.body.appendChild(container);
    }

    this.container = container;

    // Add base classes
    this.container.className = 'fixed inset-0 w-full h-full z-50 flex';
  }

  createStyles() {
    // Add custom styles that aren't covered by Tailwind
    const style = document.createElement('style');
    style.textContent = `
      /* Custom scrollbar styles */
      .chatgpt-messages::-webkit-scrollbar {
        width: 6px;
      }

      .chatgpt-messages::-webkit-scrollbar-track {
        background: transparent;
      }

      .chatgpt-messages::-webkit-scrollbar-thumb {
        background-color: rgba(0, 0, 0, 0.2);
        border-radius: 20px;
      }

      .dark .chatgpt-messages::-webkit-scrollbar-thumb {
        background-color: rgba(255, 255, 255, 0.2);
      }

      /* Code highlighting enhancements */
      .chatgpt-code pre[class*="language-"] {
        margin: 0;
        border-radius: 0;
      }

      /* Auto-resize input */
      .chatgpt-input {
        overflow-y: auto;
        max-height: 200px;
      }

      /* Animation delay for typing indicator */
      .chatgpt-typing-dot:nth-child(1) { animation-delay: 0s; }
      .chatgpt-typing-dot:nth-child(2) { animation-delay: 0.2s; }
      .chatgpt-typing-dot:nth-child(3) { animation-delay: 0.4s; }
    `;
    document.head.appendChild(style);
  }

  // chatgpt-style-widget.js - Part 2: Rendering UI
// Add these methods to the ChatGPTStyleWidget class

renderWidget() {
  const darkClass = this.theme === 'dark' ? 'dark' : '';

  this.container.innerHTML = `
    <div class="flex h-full w-full ${darkClass}">
      <div class="chatgpt-layout w-full h-full flex">
        <!-- Sidebar -->
        <div class="chatgpt-sidebar flex-shrink-0 w-64 bg-light-200 dark:bg-dark-100 border-r border-light-400 dark:border-dark-400 flex flex-col transition-all duration-300 md:translate-x-0 -translate-x-full">
          <!-- New Chat Button -->
          <div class="p-4">
            <button class="chatgpt-new-chat-btn w-full flex items-center justify-center gap-2 bg-light-100 dark:bg-dark-200 hover:bg-light-300 dark:hover:bg-dark-300 text-dark-100 dark:text-light-100 py-3 px-4 rounded-md border border-light-400 dark:border-dark-400 transition-colors duration-200">
              <i class="fa-solid fa-plus text-sm"></i>
              <span>New chat</span>
            </button>
          </div>

          <!-- Conversations List -->
          <div class="chatgpt-conversations flex-1 overflow-y-auto px-2 pb-4">
            <div class="chatgpt-conversation active flex items-center gap-2 py-2 px-3 rounded-md cursor-pointer text-dark-100 dark:text-light-100 hover:bg-light-300 dark:hover:bg-dark-300 transition-colors duration-200 mb-1">
              <i class="fa-regular fa-message text-sm opacity-70"></i>
              <span class="truncate">Current Chat</span>
            </div>
          </div>
        </div>

        <!-- Main Content -->
        <div class="chatgpt-main flex-1 flex flex-col h-full overflow-hidden relative">
          <!-- Header -->
          <div class="chatgpt-header h-14 flex items-center justify-between px-4 border-b border-light-400 dark:border-dark-400">
            <div class="chatgpt-title flex items-center gap-2 font-medium">
              <div class="w-6 h-6 rounded-full bg-primary flex items-center justify-center text-white">
                <i class="fa-solid fa-robot text-xs"></i>
              </div>
              <span>API Assistant</span>
            </div>

            <div class="chatgpt-controls flex items-center">
              <button class="chatgpt-control-button chatgpt-mobile-menu w-8 h-8 flex items-center justify-center text-light-400 dark:text-dark-300 hover:bg-light-300 dark:hover:bg-dark-300 rounded-md transition-colors duration-200 mr-1 md:hidden">
                <i class="fa-solid fa-bars"></i>
              </button>
              <button class="chatgpt-control-button chatgpt-theme-toggle w-8 h-8 flex items-center justify-center text-light-400 dark:text-dark-300 hover:bg-light-300 dark:hover:bg-dark-300 rounded-md transition-colors duration-200">
                <i class="fa-solid ${this.theme === 'dark' ? 'fa-sun' : 'fa-moon'}"></i>
              </button>
            </div>
          </div>

          <!-- Messages Area -->
          <div id="chatgpt-messages" class="chatgpt-messages flex-1 overflow-y-auto">
            <!-- Welcome Screen -->
            <div id="chatgpt-welcome" class="chatgpt-welcome flex flex-col items-center justify-center h-full text-center p-6 animate__animated animate__fadeIn">
              <h1 class="text-3xl font-semibold mb-4 text-dark-100 dark:text-light-100">How can I help you today?</h1>

              <div class="chatgpt-examples grid grid-cols-1 md:grid-cols-2 gap-3 max-w-2xl mt-6">
                <div class="chatgpt-example bg-light-200 dark:bg-dark-300 p-3 rounded-lg border border-light-400 dark:border-dark-400 text-left cursor-pointer hover:bg-light-300 dark:hover:bg-dark-400 transition-colors duration-200 shadow-sm">
                  <span class="text-sm">Generate client code for authentication API</span>
                </div>
                <div class="chatgpt-example bg-light-200 dark:bg-dark-300 p-3 rounded-lg border border-light-400 dark:border-dark-400 text-left cursor-pointer hover:bg-light-300 dark:hover:bg-dark-400 transition-colors duration-200 shadow-sm">
                  <span class="text-sm">Explain how to use the payment processing endpoint</span>
                </div>
                <div class="chatgpt-example bg-light-200 dark:bg-dark-300 p-3 rounded-lg border border-light-400 dark:border-dark-400 text-left cursor-pointer hover:bg-light-300 dark:hover:bg-dark-400 transition-colors duration-200 shadow-sm">
                  <span class="text-sm">Debug my API connection issue</span>
                </div>
                <div class="chatgpt-example bg-light-200 dark:bg-dark-300 p-3 rounded-lg border border-light-400 dark:border-dark-400 text-left cursor-pointer hover:bg-light-300 dark:hover:bg-dark-400 transition-colors duration-200 shadow-sm">
                  <span class="text-sm">What are best practices for API security?</span>
                </div>
              </div>
            </div>
          </div>

          <!-- Input Area -->
          <div class="chatgpt-input-container absolute bottom-0 left-0 right-0 px-4 pb-4 pt-6 bg-gradient-to-b from-transparent via-light-100/80 to-light-100 dark:via-dark-200/80 dark:to-dark-200">
            <div class="chatgpt-input-box max-w-3xl mx-auto relative">
              <textarea class="chatgpt-input w-full resize-none border border-light-400 dark:border-dark-400 bg-light-100 dark:bg-dark-300 rounded-lg py-3 pl-4 pr-10 text-dark-100 dark:text-light-100 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary shadow-chat"
                placeholder="Message API Assistant..." rows="1"></textarea>
              <button class="chatgpt-send absolute right-3 bottom-3 text-primary disabled:text-light-400 dark:disabled:text-dark-400 disabled:cursor-not-allowed transition-colors duration-200" disabled>
                <i class="fa-solid fa-paper-plane"></i>
              </button>
            </div>

            <div class="chatgpt-footer text-center text-xs text-light-400 dark:text-dark-300 mt-2">
              API Assistant can make mistakes. Consider verifying important information.
            </div>
          </div>
        </div>
      </div>
    </div>
  `;

  // Store references to DOM elements
  this.messagesContainer = this.container.querySelector('#chatgpt-messages');
  this.welcomeScreen = this.container.querySelector('#chatgpt-welcome');
  this.chatInput = this.container.querySelector('.chatgpt-input');
  this.sendButton = this.container.querySelector('.chatgpt-send');
  this.newChatButton = this.container.querySelector('.chatgpt-new-chat-btn');
  this.themeToggleButton = this.container.querySelector('.chatgpt-theme-toggle');
  this.mobileMenuButton = this.container.querySelector('.chatgpt-mobile-menu');
  this.sidebar = this.container.querySelector('.chatgpt-sidebar');

  // Auto-resize input
  this.chatInput.addEventListener('input', () => {
    this.chatInput.style.height = 'auto';
    this.chatInput.style.height = Math.min(this.chatInput.scrollHeight, 200) + 'px';

    // Enable/disable send button based on input
    this.sendButton.disabled = this.chatInput.value.trim() === '';
  });
}

// chatgpt-style-widget.js - Part 3: Event Handling and User Interactions
// Add these methods to the ChatGPTStyleWidget class

attachEventListeners() {
  // Send message when clicking the send button
  this.sendButton.addEventListener('click', () => {
    if (!this.sendButton.disabled) {
      this.sendMessage();
    }
  });

  // Send message on Enter (but allow Shift+Enter for new line)
  this.chatInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (!this.sendButton.disabled) {
        this.sendMessage();
      }
    }
  });

  // Handle new chat button
  this.newChatButton.addEventListener('click', () => {
    this.clearChat();
    this.showWelcomeScreen();

    // Update sidebar
    const conversations = this.container.querySelectorAll('.chatgpt-conversation');
    conversations.forEach(conv => conv.classList.remove('active'));

    // Add new conversation to sidebar
    const newConversation = document.createElement('div');
    newConversation.classList.add('chatgpt-conversation', 'active', 'flex', 'items-center', 'gap-2', 'py-2', 'px-3', 'rounded-md', 'cursor-pointer', 'text-dark-100', 'dark:text-light-100', 'hover:bg-light-300', 'dark:hover:bg-dark-300', 'transition-colors', 'duration-200', 'mb-1');
    newConversation.innerHTML = `
      <i class="fa-regular fa-message text-sm opacity-70"></i>
      <span class="truncate">New Chat</span>
    `;

    // Add click event to the new conversation
    newConversation.addEventListener('click', () => {
      conversations.forEach(conv => conv.classList.remove('active'));
      newConversation.classList.add('active');
    });

    // Insert at the top of the list
    const conversationsContainer = this.container.querySelector('.chatgpt-conversations');
    if (conversationsContainer.firstChild) {
      conversationsContainer.insertBefore(newConversation, conversationsContainer.firstChild);
    } else {
      conversationsContainer.appendChild(newConversation);
    }

    // On mobile, close the sidebar
    if (window.innerWidth <= 768) {
      this.sidebar.classList.remove('translate-x-0');
      this.sidebar.classList.add('-translate-x-full');
    }
  });

  // Theme toggle
  this.themeToggleButton.addEventListener('click', () => {
    this.toggleTheme();
  });

  // Mobile menu toggle
  this.mobileMenuButton.addEventListener('click', () => {
    if (this.sidebar.classList.contains('-translate-x-full')) {
      this.sidebar.classList.remove('-translate-x-full');
      this.sidebar.classList.add('translate-x-0');
    } else {
      this.sidebar.classList.remove('translate-x-0');
      this.sidebar.classList.add('-translate-x-full');
    }
  });

  // Click outside sidebar to close on mobile
  document.addEventListener('click', (e) => {
    if (window.innerWidth <= 768 &&
        !this.sidebar.classList.contains('-translate-x-full') &&
        !this.sidebar.contains(e.target) &&
        !this.mobileMenuButton.contains(e.target)) {
      this.sidebar.classList.remove('translate-x-0');
      this.sidebar.classList.add('-translate-x-full');
    }
  });

  // Example questions
  const examples = this.container.querySelectorAll('.chatgpt-example');
  examples.forEach(example => {
    example.addEventListener('click', () => {
      const text = example.textContent.trim();
      this.chatInput.value = text;
      this.chatInput.dispatchEvent(new Event('input'));
      this.sendMessage();
    });
  });

  // Handle existing conversation clicks
  const conversations = this.container.querySelectorAll('.chatgpt-conversation');
  conversations.forEach(conversation => {
    conversation.addEventListener('click', () => {
      conversations.forEach(c => c.classList.remove('active'));
      conversation.classList.add('active');

      // In a real implementation, you would load the selected conversation here
      // For now, we'll just clear the chat
      this.clearChat();

      // On mobile, close the sidebar after selection
      if (window.innerWidth <= 768) {
        this.sidebar.classList.remove('translate-x-0');
        this.sidebar.classList.add('-translate-x-full');
      }
    });
  });

  // Window resize handler for responsive adjustments
  this.resizeHandler = () => {
    // Close sidebar on mobile when resizing
    if (window.innerWidth <= 768) {
      this.sidebar.classList.remove('translate-x-0');
      this.sidebar.classList.add('-translate-x-full');
    } else {
      this.sidebar.classList.remove('-translate-x-full');
      this.sidebar.classList.add('translate-x-0');
    }
  };

  window.addEventListener('resize', this.resizeHandler);

  // Initial check for mobile
  this.resizeHandler();

  // Keyboard shortcuts
  document.addEventListener('keydown', (e) => {
    // Ctrl+/ or Cmd+/ to focus chat input
    if ((e.ctrlKey || e.metaKey) && e.key === '/') {
      e.preventDefault();
      this.chatInput.focus();
    }

    // Escape to close mobile sidebar
    if (e.key === 'Escape' && window.innerWidth <= 768 && !this.sidebar.classList.contains('-translate-x-full')) {
      this.sidebar.classList.remove('translate-x-0');
      this.sidebar.classList.add('-translate-x-full');
    }
  });
}

// Send a message
async sendMessage() {
  const message = this.chatInput.value.trim();
  if (!message) return;

  // Hide welcome screen
  this.hideWelcomeScreen();

  // Reset input
  this.chatInput.value = '';
  this.chatInput.style.height = 'auto';
  this.sendButton.disabled = true;

  // Add user message to UI
  this.addMessage('user', message);

  // Show typing indicator
  this.showTypingIndicator();

  try {
    // Make API request
    const response = await this.makeAPIRequest(message);

    // Hide typing indicator
    this.hideTypingIndicator();

    // Add response to UI
    if (response && response.response) {
      this.addMessage('assistant', response.response);

      // Update session ID if new
      if (response.session_id && !this.sessionId) {
        this.sessionId = response.session_id;
        this.triggerEvent('sessionChange', { sessionId: this.sessionId });
      }
    } else {
      this.addMessage('assistant', 'Sorry, I encountered an error. Please try again.');
    }
  } catch (error) {
    console.error('Error sending message:', error);
    this.hideTypingIndicator();
    this.addMessage('assistant', 'Sorry, I encountered an error. Please try again.');
  }

  // Focus back on input
  this.chatInput.focus();
}

// Toggle theme between light and dark
toggleTheme() {
  this.theme = this.theme === 'light' ? 'dark' : 'light';

  // Update container classes
  const layoutDiv = this.container.querySelector('.chatgpt-layout');
  if (layoutDiv) {
    if (this.theme === 'dark') {
      layoutDiv.classList.add('dark');
    } else {
      layoutDiv.classList.remove('dark');
    }
  }

  // Update Prism theme if loaded
  const prismDarkTheme = document.getElementById('prism-dark-theme');
  if (prismDarkTheme) {
    prismDarkTheme.disabled = this.theme !== 'dark';
  }

  // Update mermaid theme if loaded
  if (window.mermaid) {
    window.mermaid.initialize({
      theme: this.theme === 'dark' ? 'dark' : 'default'
    });
  }

  // Update theme toggle button icon
  const themeIcon = this.themeToggleButton.querySelector('i');
  if (themeIcon) {
    if (this.theme === 'dark') {
      themeIcon.classList.remove('fa-moon');
      themeIcon.classList.add('fa-sun');
    } else {
      themeIcon.classList.remove('fa-sun');
      themeIcon.classList.add('fa-moon');
    }
  }

  // Trigger theme change event
  this.triggerEvent('themeChange', { theme: this.theme });
}

// Show/hide welcome screen
showWelcomeScreen() {
  if (this.welcomeScreen) {
    this.welcomeScreen.style.display = 'flex';
  }
}

hideWelcomeScreen() {
  if (this.welcomeScreen) {
    this.welcomeScreen.style.display = 'none';
  }
}

// Clear chat
clearChat() {
  this.messages = [];

  if (this.messagesContainer) {
    // Keep only the welcome screen, remove all messages
    const messages = this.messagesContainer.querySelectorAll('.chatgpt-message, .chatgpt-typing');
    messages.forEach(msg => msg.remove());
  }

  this.showWelcomeScreen();

  // Trigger clear event
  this.triggerEvent('clear', {});
}
// chatgpt-style-widget.js - Part 4: Message Handling and Content Processing
// Add these methods to the ChatGPTStyleWidget class

// Add a message to the chat
addMessage(role, content, scroll = true) {
  // Hide welcome screen when adding messages
  this.hideWelcomeScreen();

  // Store message in history
  this.messages.push({ role, content });

  // Create message element
  const messageEl = document.createElement('div');
  messageEl.classList.add('chatgpt-message', role, 'animate__animated', 'animate__fadeIn', 'py-6', 'px-4', 'border-b', 'border-light-300', 'dark:border-dark-300');
  messageEl.classList.add(role === 'assistant' ? 'bg-light-200 dark:bg-dark-300' : 'bg-light-100 dark:bg-dark-200');

  // Create message container with max width
  const containerEl = document.createElement('div');
  containerEl.classList.add('max-w-3xl', 'mx-auto', 'flex');

  // Create avatar
  const avatarEl = document.createElement('div');
  avatarEl.classList.add('flex-shrink-0', 'w-7', 'h-7', 'rounded-full', 'flex', 'items-center', 'justify-center', 'mr-4', 'mt-1');

  if (role === 'user') {
    avatarEl.classList.add('bg-purple-600', 'text-white', 'font-semibold');
    avatarEl.innerHTML = `<span class="text-xs">U</span>`;
  } else {
    avatarEl.classList.add('bg-primary', 'text-white');
    avatarEl.innerHTML = `<i class="fa-solid fa-robot text-xs"></i>`;
  }

  // Create message content container
  const contentEl = document.createElement('div');
  contentEl.classList.add('flex-1', 'prose', 'dark:prose-invert', 'prose-p:my-2', 'prose-pre:my-2');

  // Process content (format code blocks, links, etc.)
  const formattedContent = this.processMessageContent(content);
  contentEl.innerHTML = formattedContent;

  // Assemble message
  containerEl.appendChild(avatarEl);
  containerEl.appendChild(contentEl);
  messageEl.appendChild(containerEl);

  // Add to messages container
  this.messagesContainer.appendChild(messageEl);

  // Add enhanced code block functionality
  this.addCodeBlockFunctionality(messageEl);

  // Scroll to bottom if needed
  if (scroll) {
    this.scrollToBottom();
  }

  // Update sidebar conversation name if first message
  if (this.messages.length === 2 && role === 'assistant') {
    this.updateConversationName();
  }

  // Trigger message event
  this.triggerEvent('newMessage', { role, content });
}

// Process message content to format code, links, etc.
processMessageContent(content) {
  try {
    // Format code blocks with syntax highlighting and download button
    content = content.replace(/```(\w+)?\n([\s\S]*?)```/g, (match, language, code) => {
      const lang = language || 'text';
      const fileExt = this.getFileExtension(lang);

      // Escape the code content for data attribute
      const escapedCode = this.escapeHtml(code)
        .replace(/"/g, '&quot;'); // Double quotes need special handling for attributes

      return `
        <div class="chatgpt-code not-prose rounded-lg overflow-hidden border border-light-400 dark:border-dark-400 my-4 shadow-sm">
          <div class="chatgpt-code-header flex justify-between items-center py-2 px-4 bg-light-300 dark:bg-dark-400 text-sm">
            <span class="font-medium">${this.escapeHtml(lang)}</span>
            <div class="chatgpt-code-actions flex gap-2">
              <button class="chatgpt-code-copy p-1 hover:bg-light-400 dark:hover:bg-dark-300 rounded transition-colors" title="Copy code">
                <i class="fa-regular fa-copy"></i>
                // chatgpt-style-widget.js - Part 4: Message Handling and Content Processing (continued)

                <i class="fa-regular fa-copy"></i>
              </button>
              <button class="chatgpt-code-download p-1 hover:bg-light-400 dark:hover:bg-dark-300 rounded transition-colors" title="Download as ${lang} file" data-lang="${lang}" data-ext="${fileExt}">
                <i class="fa-solid fa-download"></i>
              </button>
            </div>
          </div>
          <div class="chatgpt-code-content">
            <pre class="!m-0 !rounded-none"><code class="language-${lang}">${this.escapeHtml(code)}</code></pre>
          </div>
        </div>
      `;
    });

    // Format inline code
    content = content.replace(/`([^`]+)`/g, '<code class="bg-light-300 dark:bg-dark-400 px-1.5 py-0.5 rounded text-sm">$1</code>');

    // Format mermaid diagrams
    content = content.replace(/```mermaid\n([\s\S]*?)```/g, (match, diagram) => {
      return `<div class="chatgpt-mermaid bg-white p-4 rounded-lg my-4 overflow-x-auto shadow-sm">${diagram}</div>`;
    });

    // Convert URLs to clickable links
    content = content.replace(/(https?:\/\/[^\s]+)/g, '<a href="$1" target="_blank" rel="noopener noreferrer" class="text-primary hover:underline">$1</a>');

    // Process markdown formatting
    // Bold
    content = content.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');

    // Italic
    content = content.replace(/\*(.*?)\*/g, '<em>$1</em>');

    // Headers
    content = content.replace(/^### (.*?)$/gm, '<h3 class="text-lg font-semibold mt-6 mb-2">$1</h3>');
    content = content.replace(/^## (.*?)$/gm, '<h2 class="text-xl font-semibold mt-6 mb-2">$1</h2>');
    content = content.replace(/^# (.*?)$/gm, '<h1 class="text-2xl font-semibold mt-6 mb-3">$1</h1>');

    // Lists
    content = content.replace(/^\s*- (.*?)$/gm, '<li class="ml-4">$1</li>');
    content = content.replace(/(<li.*?<\/li>)\s*\n\s*(<li)/g, '$1$2');
    content = content.replace(/(<li.*?<\/li>)+/g, '<ul class="list-disc my-2">$&</ul>');

    // Numbered lists
    content = content.replace(/^\s*\d+\.\s+(.*?)$/gm, '<li class="ml-4">$1</li>');
    content = content.replace(/(?:<li.*?<\/li>)\s*\n\s*(?:<li>)/g, '$&');
    content = content.replace(/(?:<li class="ml-4">.*?<\/li>)+/g, (match) => {
      if (!/^<ul>/.test(match)) return '<ol class="list-decimal my-2">' + match + '</ol>';
      return match;
    });

    // Blockquotes
    content = content.replace(/^\s*>\s+(.*?)$/gm, '<blockquote class="border-l-4 border-light-400 dark:border-dark-400 pl-4 py-1 my-2 text-light-400 dark:text-dark-300">$1</blockquote>');

    // Convert line breaks to paragraphs for better readability
    const paragraphs = content.split('\n\n');
    content = paragraphs.map(p => {
      if (p.trim() &&
          !p.includes('<h1') &&
          !p.includes('<h2') &&
          !p.includes('<h3') &&
          !p.includes('<ul') &&
          !p.includes('<ol') &&
          !p.includes('<blockquote') &&
          !p.includes('<div') &&
          !p.includes('<pre')) {
        return `<p>${p.replace(/\n/g, '<br>')}</p>`;
      }
      return p;
    }).join('\n\n');

    return content;
  } catch (error) {
    console.error('Error processing message content:', error);
    return `<p>Error formatting content: ${error.message}</p><p>${content}</p>`;
  }
}

// Add code block functionality (copy and download)
addCodeBlockFunctionality(messageEl) {
  try {
    // Add copy buttons functionality
    const copyButtons = messageEl.querySelectorAll('.chatgpt-code-copy');
    copyButtons.forEach(button => {
      button.addEventListener('click', () => {
        const codeBlock = button.closest('.chatgpt-code');
        const code = codeBlock.querySelector('code').textContent;

        navigator.clipboard.writeText(code).then(() => {
          // Show copied confirmation
          const originalHTML = button.innerHTML;
          button.innerHTML = `<i class="fa-solid fa-check"></i>`;

          setTimeout(() => {
            button.innerHTML = originalHTML;
          }, 2000);
        });
      });
    });

    // Add download functionality
    const downloadButtons = messageEl.querySelectorAll('.chatgpt-code-download');
    downloadButtons.forEach(button => {
      button.addEventListener('click', () => {
        try {
          const lang = button.getAttribute('data-lang') || 'text';
          const fileExt = button.getAttribute('data-ext') || 'txt';

          const codeBlock = button.closest('.chatgpt-code');
          const code = codeBlock.querySelector('code').textContent;

          // Create a blob
          const blob = new Blob([code], { type: 'text/plain' });

          // Create a download link
          const link = document.createElement('a');
          link.href = URL.createObjectURL(blob);
          link.download = `code.${fileExt}`;

          // Trigger download
          document.body.appendChild(link);
          link.click();

          // Clean up
          document.body.removeChild(link);
          URL.revokeObjectURL(link.href);
        } catch (error) {
          console.error('Error downloading code:', error);
        }
      });
    });

    // Apply syntax highlighting after a short delay to ensure Prism is loaded
    setTimeout(() => {
      try {
        if (window.Prism) {
          Prism.highlightAllUnder(messageEl);
        }
      } catch (error) {
        console.warn('Error applying syntax highlighting:', error);
      }
    }, 100);
  } catch (error) {
    console.error('Error adding code block functionality:', error);
  }
}

// Helper method to get file extension for a language
getFileExtension(language) {
  const fileExtensions = {
    'javascript': 'js',
    'typescript': 'ts',
    'python': 'py',
    'java': 'java',
    'csharp': 'cs',
    'cpp': 'cpp',
    'c': 'c',
    'php': 'php',
    'ruby': 'rb',
    'go': 'go',
    'rust': 'rs',
    'swift': 'swift',
    'kotlin': 'kt',
    'scala': 'scala',
    'r': 'r',
    'bash': 'sh',
    'shell': 'sh',
    'sql': 'sql',
    'html': 'html',
    'css': 'css',
    'xml': 'xml',
    'json': 'json',
    'yaml': 'yaml',
    'markdown': 'md',
    'text': 'txt'
  };

  return fileExtensions[language.toLowerCase()] || 'txt';
}

// Helper function to escape HTML
escapeHtml(unsafe) {
  if (typeof unsafe !== 'string') return '';

  return unsafe
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

// Update conversation name in sidebar based on first user message
updateConversationName() {
  try {
    if (this.messages.length >= 1) {
      const activeConversation = this.container.querySelector('.chatgpt-conversation.active');
      if (activeConversation) {
        // Extract first ~20 chars of first user message
        const firstUserMessage = this.messages[0].content;
        const shortName = firstUserMessage.substring(0, 20) + (firstUserMessage.length > 20 ? '...' : '');
        const nameSpan = activeConversation.querySelector('span');
        if (nameSpan) {
          nameSpan.textContent = shortName;
        }
      }
    }
  } catch (error) {
    console.error('Error updating conversation name:', error);
  }
}
// chatgpt-style-widget.js - Part 5: UI Indicators and API Communication

// Show typing indicator
showTypingIndicator() {
  try {
    const typingEl = document.createElement('div');
    typingEl.classList.add(
      'chatgpt-typing',
      'py-6', 'px-4',
      'border-b', 'border-light-300', 'dark:border-dark-300',
      'bg-light-200', 'dark:bg-dark-300'
    );
    typingEl.id = 'chatgpt-typing-indicator';

    const containerEl = document.createElement('div');
    containerEl.classList.add('max-w-3xl', 'mx-auto', 'flex');

    const avatarEl = document.createElement('div');
    avatarEl.classList.add(
      'flex-shrink-0', 'w-7', 'h-7',
      'rounded-full', 'bg-primary',
      'flex', 'items-center', 'justify-center',
      'text-white', 'mr-4'
    );
    avatarEl.innerHTML = `<i class="fa-solid fa-robot text-xs"></i>`;

    const indicatorEl = document.createElement('div');
    indicatorEl.classList.add('flex', 'items-end', 'h-7');

    const dotsContainer = document.createElement('div');
    dotsContainer.classList.add('flex', 'gap-1');

    for (let i = 0; i < 3; i++) {
      const dot = document.createElement('div');
      dot.classList.add(
        'w-2', 'h-2',
        'bg-light-400', 'dark:bg-dark-400',
        'rounded-full'
      );
      // Use CSS for animation to avoid issues with Tailwind
      dot.style.animation = 'typing 1.4s infinite';
      dot.style.animationDelay = `${i * 0.2}s`;
      dotsContainer.appendChild(dot);
    }

    indicatorEl.appendChild(dotsContainer);
    containerEl.appendChild(avatarEl);
    containerEl.appendChild(indicatorEl);
    typingEl.appendChild(containerEl);

    this.messagesContainer.appendChild(typingEl);
    this.scrollToBottom();
  } catch (error) {
    console.error('Error showing typing indicator:', error);
  }
}

// Hide typing indicator
hideTypingIndicator() {
  try {
    const indicator = document.getElementById('chatgpt-typing-indicator');
    if (indicator) {
      indicator.remove();
    }
  } catch (error) {
    console.error('Error hiding typing indicator:', error);
  }
}

// Scroll messages to bottom
scrollToBottom() {
  try {
    if (this.messagesContainer) {
      this.messagesContainer.scrollTop = this.messagesContainer.scrollHeight;
    }
  } catch (error) {
    console.error('Error scrolling to bottom:', error);
  }
}

// Make API request
async makeAPIRequest(message) {
  try {
    const endpoint = `${this.apiUrl}/chat/message`;

    const payload = {
      message: message
    };

    // Add session ID if available
    if (this.sessionId) {
      payload.session_id = this.sessionId;
    }

    const response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-API-Key': this.apiKey
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }

    const data = await response.json();

    // Store session ID if returned
    if (data.session_id && !this.sessionId) {
      this.sessionId = data.session_id;
      this.triggerEvent('sessionChange', { sessionId: this.sessionId });
    }

    return data;
  } catch (error) {
    console.error('API request failed:', error);
    throw error;
  }
}

// Load session history
async loadSessionHistory() {
  try {
    if (!this.sessionId) return;

    const endpoint = `${this.apiUrl}/chat/session/${this.sessionId}`;
    const response = await fetch(endpoint, {
      headers: {
        'X-API-Key': this.apiKey
      }
    });

    if (response.ok) {
      const sessionData = await response.json();
      if (sessionData.messages && sessionData.messages.length > 0) {
        // Clear current messages
        this.messages = [];

        // Remove existing messages from UI
        const messages = this.messagesContainer.querySelectorAll('.chatgpt-message');
        messages.forEach(msg => msg.remove());

        // Hide welcome screen
        this.hideWelcomeScreen();

        // Add historical messages
        sessionData.messages.forEach(msg => {
          if (msg.role && msg.content) {
            this.addMessage(msg.role, msg.content, false);
          }
        });

        // Scroll to bottom
        this.scrollToBottom();
      }
    }
  } catch (error) {
    console.error('Error loading session history:', error);
  }
}

// Add a conversation to the sidebar
addConversation(title) {
  try {
    const conversationsContainer = this.container.querySelector('.chatgpt-conversations');

    if (conversationsContainer) {
      const conversationEl = document.createElement('div');
      conversationEl.classList.add(
        'chatgpt-conversation',
        'flex', 'items-center', 'gap-2',
        'py-2', 'px-3',
        'rounded-md', 'cursor-pointer',
        'text-dark-100', 'dark:text-light-100',
        'hover:bg-light-300', 'dark:hover:bg-dark-300',
        'transition-colors', 'duration-200', 'mb-1'
      );

      conversationEl.innerHTML = `
        <i class="fa-regular fa-message text-sm opacity-70"></i>
        <span class="truncate">${this.escapeHtml(title || 'New Conversation')}</span>
      `;

      // Add event listener
      conversationEl.addEventListener('click', () => {
        // Remove active class from all conversations
        const conversations = this.container.querySelectorAll('.chatgpt-conversation');
        conversations.forEach(conv => conv.classList.remove('active'));

        // Add active class to this conversation
        conversationEl.classList.add('active');

        // Load conversation (in a real implementation)
        // Here you would load the selected conversation's messages

        // On mobile, close sidebar after selection
        if (window.innerWidth <= 768) {
          this.sidebar.classList.remove('translate-x-0');
          this.sidebar.classList.add('-translate-x-full');
        }
      });

      // Add to conversations container
      conversationsContainer.prepend(conversationEl);

      return conversationEl;
    }
  } catch (error) {
    console.error('Error adding conversation:', error);
  }

  return null;
}
// chatgpt-style-widget.js - Part 6: Event System and Public API

// Event system - register event listener
on(eventName, callback) {
  if (!this.eventListeners) {
    this.eventListeners = {};
  }

  if (!this.eventListeners[eventName]) {
    this.eventListeners[eventName] = [];
  }

  this.eventListeners[eventName].push(callback);

  return this; // Allow chaining
}

// Event system - trigger event
triggerEvent(eventName, data) {
  if (!this.eventListeners || !this.eventListeners[eventName]) {
    return;
  }

  this.eventListeners[eventName].forEach(callback => {
    try {
      callback(data);
    } catch (error) {
      console.error(`Error in ${eventName} event handler:`, error);
    }
  });
}

// Get current session ID
getSessionId() {
  return this.sessionId;
}

// Set session ID and load history
setSessionId(sessionId) {
  this.sessionId = sessionId;
  if (this.sessionId) {
    this.loadSessionHistory();
  }
}

// Get all messages
getMessages() {
  return [...this.messages];
}

// Add a message programmatically
addUserMessage(content) {
  this.addMessage('user', content);
  return this; // Allow chaining
}

addAssistantMessage(content) {
  this.addMessage('assistant', content);
  return this; // Allow chaining
}

// Download conversation as JSON
downloadConversation() {
  try {
    if (this.messages.length === 0) return;

    const conversationData = {
      session_id: this.sessionId || 'unsaved-session',
      timestamp: new Date().toISOString(),
      messages: this.messages
    };

    const blob = new Blob([JSON.stringify(conversationData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');

    link.href = url;
    link.download = `conversation-${new Date().toISOString().slice(0,10)}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    return true;
  } catch (error) {
    console.error('Error downloading conversation:', error);
    return false;
  }
}

// Import conversation from JSON
importConversation(jsonFile) {
  return new Promise((resolve, reject) => {
    try {
      const reader = new FileReader();

      reader.onload = (event) => {
        try {
          const data = JSON.parse(event.target.result);

          if (data && Array.isArray(data.messages)) {
            // Clear current messages
            this.clearChat();

            // Set session ID if available
            if (data.session_id) {
              this.sessionId = data.session_id;
            }

            // Add messages
            data.messages.forEach(msg => {
              if (msg.role && msg.content) {
                this.addMessage(msg.role, msg.content, false);
              }
            });

            // Scroll to bottom
            this.scrollToBottom();

            resolve(true);
          } else {
            reject(new Error('Invalid conversation format'));
          }
        } catch (error) {
          reject(error);
        }
      };

      reader.onerror = () => reject(new Error('Failed to read file'));
      reader.readAsText(jsonFile);
    } catch (error) {
      reject(error);
    }
  });
}

// Destroy widget and clean up
destroy() {
  try {
    // Remove event listeners
    window.removeEventListener('resize', this.resizeHandler);

    // Remove widget from DOM
    if (this.container) {
      this.container.remove();
    }

    // Clear any references
    this.messagesContainer = null;
    this.welcomeScreen = null;
    this.chatInput = null;
    this.sendButton = null;
    this.newChatButton = null;
    this.themeToggleButton = null;
    this.mobileMenuButton = null;
    this.sidebar = null;
    this.container = null;

    return true;
  } catch (error) {
    console.error('Error destroying widget:', error);
    return false;
  }
}




}