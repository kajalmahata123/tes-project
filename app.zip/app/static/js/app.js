document.addEventListener('DOMContentLoaded', function() {
    const API_URL = 'http://localhost:8000/api/v1';
    const API_KEY = 'visa_api_dev_3f29a8c7b6d5e4f3';

    // Check if API is available
    fetch(`${API_URL}/health`)
        .then(response => {
            if (!response.ok) {
                console.error('API health check failed:', response.status);
                alert('Warning: API server might not be available. Please ensure the server is running.');
            }
        })
        .catch(error => {
            console.error('API health check error:', error);
            alert('Warning: Could not connect to API server. Please ensure the server is running on http://localhost:8000');
        });

    // Add click handlers to both buttons
    document.getElementById('main-launch-btn').addEventListener('click', function() {
        ChatGPTStyleWidget.openInNewWindow({
            apiUrl: API_URL,
            apiKey: API_KEY,
            theme: 'light',
            title: 'API Assistant'
        });
    });

    document.getElementById('floating-launch-btn').addEventListener('click', function() {
        ChatGPTStyleWidget.openInNewWindow({
            apiUrl: API_URL,
            apiKey: API_KEY,
            theme: 'light',
            title: 'API Assistant'
        });
    });
}); 