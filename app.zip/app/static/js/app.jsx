/**
 * Main Application Component
 * Entry point for the Content-Craft Visa API Agent Dashboard
 */

const App = () => {
  const { useState, useEffect } = React;
  const { 
    ThemeProvider, 
    createTheme, 
    CssBaseline, 
    AppBar, 
    Toolbar, 
    Typography, 
    TextField, 
    Button,
    Box,
    Container,
    Paper,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    Snackbar,
    Alert,
    Chip
  } = MaterialUI;
  
  // State for API key and App ID
  const [apiKey, setApiKey] = useState(localStorage.getItem('api_key') || 'sk_fbf08b13c3aa05360539bde6f3ba9d799540624494ee4f69');
  const [showApiKeyDialog, setShowApiKeyDialog] = useState(!localStorage.getItem('api_key'));
  const [notification, setNotification] = useState({show: false, message: '', severity: 'info'});
  const APP_ID = 'Visa_api_Bot';
  
  // Create theme
  const theme = createTheme({
    palette: {
      primary: {
        main: '#1976d2',
      },
      secondary: {
        main: '#f50057',
      },
    },
  });
  
  // Save API key to localStorage
  useEffect(() => {
    if (apiKey) {
      localStorage.setItem('api_key', apiKey);
    }
  }, [apiKey]);
  
  // Handle API key submission
  const handleApiKeySubmit = () => {
    if (apiKey.trim()) {
      localStorage.setItem('api_key', apiKey);
      setShowApiKeyDialog(false);
      setNotification({
        show: true,
        message: 'API Key saved successfully',
        severity: 'success'
      });
      
      // Reload the page to reconnect websocket with the new API key
      window.location.reload();
    } else {
      setNotification({
        show: true,
        message: 'Please enter a valid API Key',
        severity: 'error'
      });
    }
  };
  
  // Handle API key dialog open
  const handleOpenApiKeyDialog = () => {
    setShowApiKeyDialog(true);
  };
  
  // Close notification
  const handleCloseNotification = () => {
    setNotification({...notification, show: false});
  };
  
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      
      {/* Application Header */}
      <AppBar position="static">
        <Toolbar>
          <Box display="flex" alignItems="center" style={{ flexGrow: 1 }}>
            <Typography variant="h6" style={{ marginRight: '16px' }}>
              Visa API Agent Dashboard
            </Typography>
            <Chip
              label={`App ID: ${APP_ID}`}
              size="small"
              color="secondary"
              style={{ backgroundColor: 'rgba(255, 255, 255, 0.15)' }}
            />
          </Box>
          <Button color="inherit" onClick={handleOpenApiKeyDialog}>
            Change API Key
          </Button>
        </Toolbar>
      </AppBar>
      
      {/* Main Content */}
      <Container maxWidth="xl" style={{ marginTop: 20, marginBottom: 20 }}>
        {/* Request Header */}
        <RequestHeader />
        
        {/* Graph Dashboard */}
        <GraphDashboard appId={APP_ID} />
      </Container>
      
      {/* Footer */}
      <Box
        component="footer"
        sx={{
          py: 3,
          px: 2,
          mt: 'auto',
          backgroundColor: theme.palette.grey[100]
        }}
      >
        <Container maxWidth="xl">
          <Typography variant="body2" color="text.secondary" align="center">
            Content-Craft Visa API Agent Dashboard © {new Date().getFullYear()}
          </Typography>
        </Container>
      </Box>
      
      {/* API Key Dialog */}
      <Dialog open={showApiKeyDialog} onClose={() => setShowApiKeyDialog(false)}>
        <DialogTitle>Enter API Key</DialogTitle>
        <DialogContent>
          <Box mb={2}>
            <Typography variant="body2" color="textSecondary">
              App ID: {APP_ID}
            </Typography>
          </Box>
          <TextField
            autoFocus
            margin="dense"
            label="API Key"
            type="text"
            fullWidth
            variant="outlined"
            value={apiKey}
            onChange={(e) => setApiKey(e.target.value)}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setShowApiKeyDialog(false)}>Cancel</Button>
          <Button onClick={handleApiKeySubmit} variant="contained" color="primary">
            Save
          </Button>
        </DialogActions>
      </Dialog>
      
      {/* Notifications */}
      <Snackbar 
        open={notification.show} 
        autoHideDuration={6000} 
        onClose={handleCloseNotification}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
      >
        <Alert onClose={handleCloseNotification} severity={notification.severity}>
          {notification.message}
        </Alert>
      </Snackbar>
    </ThemeProvider>
  );
};

// Make APP_ID available globally
window.VISA_API_BOT_APP_ID = 'Visa_api_Bot';

// Render the application
ReactDOM.render(
  <App />,
  document.getElementById('root')
); 