static openInNewWindow(options = {}) {
        const newWindow = window.open('', '_blank', 'width=1200,height=800');
        if (!newWindow) {
            alert('Pop-up blocker prevented opening the chat. Please allow pop-ups for this site.');
            return null;
        }

        const widgetHtml = `
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>${options.title || 'API Assistant'}</title>
                <link rel="preconnect" href="https://cdn.tailwindcss.com">
                <link rel="preconnect" href="https://cdnjs.cloudflare.com">
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.8.0/styles/atom-one-dark.min.css">
                <script src="https://cdn.tailwindcss.com"></script>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.8.0/highlight.min.js"></script>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.8.0/languages/python.min.js"></script>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.8.0/languages/javascript.min.js"></script>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.8.0/languages/typescript.min.js"></script>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.8.0/languages/bash.min.js"></script>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.8.0/languages/json.min.js"></script>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.8.0/languages/java.min.js"></script>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.8.0/languages/csharp.min.js"></script>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.8.0/languages/php.min.js"></script>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.8.0/languages/ruby.min.js"></script>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.8.0/languages/go.min.js"></script>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.8.0/languages/yaml.min.js"></script>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.8.0/languages/sql.min.js"></script>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.8.0/languages/xml.min.js"></script>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.8.0/languages/css.min.js"></script>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.8.0/languages/rust.min.js"></script>
                <script src="https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js"></script>
                <style>
                    body, html {
                        margin: 0;
                        padding: 0;
                        height: 100%;
                        overflow: hidden;
                        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
                    }
                    #chatgpt-widget-container {
                        width: 100%;
                        height: 100%;
                    }
                    .loading-container {
                        position: fixed;
                        top: 0;
                        left: 0;
                        width: 100%;
                        height: 100%;
                        display: flex;
                        flex-direction: column;
                        justify-content: center;
                        align-items: center;
                        background-color: #f7f7f8;
                        z-index: 9999;
                        transition: opacity 0.5s ease-out;
                    }
                    .loading-spinner {
                        width: 40px;
                        height: 40px;
                        border: 4px solid rgba(0, 0, 0, 0.1);
                        border-radius: 50%;
                        border-top-color: #10a37f;
                        animation: spin 1s ease-in-out infinite;
                        margin-bottom: 20px;
                    }
                    .loading-text {
                        font-size: 18px;
                        color: #333;
                    }
                    @keyframes spin {
                        to { transform: rotate(360deg); }
                    }
                    .loading-container.fade-out {
                        opacity: 0;
                        pointer-events: none;
                    }
                    .code-block {
                        position: relative;
                        margin: 1em 0;
                    }
                    .mermaid {
                        background: white;
                        padding: 1em;
                        border-radius: 8px;
                        margin: 1em 0;
                    }
                    pre code.hljs {
                        padding: 1em;
                        border-radius: 8px;
                        margin: 0.5em 0;
                        font-family: 'Fira Code', 'Roboto Mono', Monaco, Menlo, 'Ubuntu Mono', Consolas, monospace;
                        line-height: 1.5;
                    }
                    .chat-sidebar-toggle {
                        cursor: pointer;
                        display: none;
                    }
                    @media (max-width: 768px) {
                        .chat-sidebar {
                            position: absolute;
                            top: 0;
                            left: -280px;
                            height: 100%;
                            transition: left 0.3s ease;
                            z-index: 50;
                        }
                        .chat-sidebar.open {
                            left: 0;
                        }
                        .chat-sidebar-toggle {
                            display: block;
                        }
                        .chat-sidebar-overlay {
                            position: fixed;
                            top: 0;
                            left: 0;
                            width: 100%;
                            height: 100%;
                            background-color: rgba(0, 0, 0, 0.5);
                            z-index: 40;
                            display: none;
                        }
                        .chat-sidebar-overlay.active {
                            display: block;
                        }
                    }
                    .custom-scrollbar::-webkit-scrollbar {
                        width: 6px;
                        height: 6px;
                    }
                    .custom-scrollbar::-webkit-scrollbar-track {
                        background: transparent;
                    }
                    .custom-scrollbar::-webkit-scrollbar-thumb {
                        background-color: #d1d5db;
                        border-radius: 3px;
                    }
                    .dark .custom-scrollbar::-webkit-scrollbar-thumb {
                        background-color: #4b5563;
                    }
                    .custom-scrollbar::-webkit-scrollbar-thumb:hover {
                        background-color: #9ca3af;
                    }
                    .dark .custom-scrollbar::-webkit-scrollbar-thumb:hover {
                        background-color: #6b7280;
                    }
                    .animate-pulse-slow {
                        animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
                    }

                    @keyframes chat-message-in {
                        0% {
                            opacity: 0;
                            transform: translateY(10px);
                        }
                        100% {
                            opacity: 1;
                            transform: translateY(0);
                        }
                    }
                    .chat-message-animation {
                        animation: chat-message-in 0.3s ease forwards;
                    }

                    /* Markdown styles */
                    .markdown-content h1 {
                        font-size: 1.75rem;
                        font-weight: 700;
                        margin-top: 1.5rem;
                        margin-bottom: 1rem;
                    }
                    .markdown-content h2 {
                        font-size: 1.5rem;
                        font-weight: 700;
                        margin-top: 1.5rem;
                        margin-bottom: 0.75rem;
                    }
                    .markdown-content h3 {
                        font-size: 1.25rem;
                        font-weight: 600;
                        margin-top: 1.25rem;
                        margin-bottom: 0.75rem;
                    }
                    .markdown-content p {
                        margin-top: 0.75rem;
                        margin-bottom: 0.75rem;
                        line-height: 1.6;
                    }
                    .markdown-content ul, .markdown-content ol {
                        margin-top: 0.5rem;
                        margin-bottom: 0.5rem;
                        padding-left: 1.5rem;
                    }
                    .markdown-content ul {
                        list-style-type: disc;
                    }
                    .markdown-content ol {
                        list-style-type: decimal;
                    }
                    .markdown-content li {
                        margin-top: 0.25rem;
                        margin-bottom: 0.25rem;
                    }
                    .markdown-content a {
                        color: #2563eb;
                        text-decoration: underline;
                    }
                    .dark .markdown-content a {
                        color: #3b82f6;
                    }
                    .markdown-content blockquote {
                        border-left: 4px solid #e5e7eb;
                        padding-left: 1rem;
                        margin-left: 0;
                        margin-right: 0;
                        font-style: italic;
                    }
                    .dark .markdown-content blockquote {
                        border-left-color: #4b5563;
                    }
                    .markdown-content table {
                        border-collapse: collapse;
                        width: 100%;
                        margin-top: 1rem;
                        margin-bottom: 1rem;
                    }
                    .markdown-content th, .markdown-content td {
                        border: 1px solid #e5e7eb;
                        padding: 0.5rem;
                    }
                    .dark .markdown-content th, .dark .markdown-content td {
                        border-color: #4b5563;
                    }
                    .markdown-content th {
                        background-color: #f3f4f6;
                        font-weight: 600;
                    }
                    .dark .markdown-content th {
                        background-color: #374151;
                    }

                    /* Keyboard shortcut styling */
                    .keyboard-shortcut {
                        display: inline-flex;
                        align-items: center;
                        justify-content: center;
                        min-width: 24px;
                        height: 24px;
                        padding: 0 4px;
                        border-radius: 4px;
                        background-color: #f3f4f6;
                        border: 1px solid #e5e7eb;
                        font-size: 12px;
                        font-weight: 500;
                        color: #4b5563;
                    }
                    .dark .keyboard-shortcut {
                        background-color: #374151;
                        border-color: #4b5563;
                        color: #d1d5db;
                    }
                </style>
                <script>
                    // Configure tailwind
                    tailwind.config = {
                        darkMode: 'class',
                        theme: {
                            extend: {
                                colors: {
                                    primary: '${options.primaryColor || '#10a37f'}',
                                    'primary-light': '${options.primaryLightColor || '#34d399'}',
                                    'primary-dark': '${options.primaryDarkColor || '#059669'}'
                                }
                            }
                        }
                    };

                    // Configure Mermaid
                    mermaid.initialize({
                        startOnLoad: true,
                        theme: 'neutral',
                        flowchart: {
                            useMaxWidth: false,
                            htmlLabels: true,
                            curve: 'basis'
                        },
                        securityLevel: 'loose'
                    });

                    // Store options for later use
                    window.widgetOptions = ${JSON.stringify(options)};

                    // Function to load the widget script
                    function loadWidgetCode() {
                        // Define ChatGPTStyleWidget class directly in the new window
                        ${ChatGPTStyleWidget.toString()}

                        // Initialize the widget
                        window.widget = new ChatGPTStyleWidget({
                            ...window.widgetOptions,
                            containerId: 'chatgpt-widget-container',
                            position: 'fullscreen'
                        });

                        // Remove loading overlay
                        setTimeout(() => {
                            const overlay = document.getElementById('loading-overlay');
                            if (overlay) {
                                overlay.classList.add('fade-out');
                                setTimeout(() => {
                                    overlay.remove();
                                }, 500);
                            }
                        }, 500);
                    }

                    // Wait for DOM to be fully loaded
                    if (document.readyState === 'loading') {
                        document.addEventListener('DOMContentLoaded', loadWidgetCode);
                    } else {
                        loadWidgetCode();
                    }
                </script>
            </head>
            <body class="${options.theme === 'dark' ? 'dark' : ''}">
                <div class="loading-container" id="loading-overlay">
                    <div class="loading-spinner"></div>
                    <div class="loading-text">Loading API Assistant...</div>
                </div>
                <div id="chatgpt-widget-container"></div>
            </body>
            </html>
        `;

        newWindow.document.write(widgetHtml);
        newWindow.document.close();

        return newWindow;
    }

    async init() {
        // Load chat history from localStorage if enabled
        if (this.storageEnabled) {
            this.loadChatHistory();
        }

        this.setupUI();
        this.setupEventListeners();
        this.setupKeyboardShortcuts();

        // Create a new chat if no history exists
        if (this.chatHistory.length === 0) {
            this.createNewChat();
        } else {
            // Load the most recent chat
            this.loadChat(this.chatHistory[0].id);
        }
    }

    setupUI() {
        const container = document.getElementById(this.containerId);
        if (!container) return;

        // Apply theme to container
        if (this.theme === 'dark') {
            container.classList.add('dark');
        }

        // Set primary color CSS variable
        document.documentElement.style.setProperty('--primary-color', this.primaryColor);

        container.innerHTML = `
            <div class="flex h-full w-full ${this.theme === 'dark' ? 'dark' : ''} bg-white dark:bg-gray-800">
                <!-- Sidebar -->
                <div id="chat-sidebar" class="chat-sidebar w-64 h-full flex-shrink-0 border-r border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 flex flex-col">
                    <!-- Sidebar Header -->
                    <div class="p-4 border-b border-gray-200 dark:border-gray-700">
                        <button id="new-chat-btn" class="w-full py-2 px-4 bg-primary hover:bg-primary-dark text-white font-medium rounded-lg flex items-center justify-center transition-colors">
                            <i class="fa-solid fa-plus mr-2"></i>
                            New Chat
                        </button>
                    </div>

                    <!-- Chat History -->
                    <div id="chat-history-list" class="flex-grow overflow-y-auto custom-scrollbar p-2 space-y-1">
                        <!-- Chat history items will be inserted here dynamically -->
                        <div class="chat-history-placeholder text-center text-gray-400 dark:text-gray-500 py-8">
                            No chat history yet
                        </div>
                    </div>

                    <!-- Sidebar Footer -->
                    <div class="p-3 border-t border-gray-200 dark:border-gray-700 text-xs text-gray-500 dark:text-gray-400">
                        <div class="flex items-center justify-between">
                            <div class="flex items-center">
                                <button id="theme-toggle" class="p-2 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-500 dark:text-gray-400">
                                    <i class="fa-solid ${this.theme === 'dark' ? 'fa-sun' : 'fa-moon'}"></i>
                                </button>
                                <button id="settings-btn" class="p-2 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-500 dark:text-gray-400">
                                    <i class="fa-solid fa-gear"></i>
                                </button>
                            </div>
                            <div class="text-xs text-gray-400 dark:text-gray-500">
                                v1.0.0
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Chat Sidebar Overlay for Mobile -->
                <div id="chat-sidebar-overlay" class="chat-sidebar-overlay"></div>

                <!-- Main Chat Area -->
                <div class="flex-grow flex flex-col h-full">
                    <!-- Chat Header -->
                    <div class="h-14 flex items-center justify-between px-4 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 z-10">
                        <div class="flex items-center gap-2">
                            <!-- Mobile sidebar toggle -->
                            <button id="sidebar-toggle" class="chat-sidebar-toggle p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-500 dark:text-gray-400 mr-1">
                                <i class="fa-solid fa-bars"></i>
                            </button>

                            <div class="w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-white">
                                <i class="fa-solid ${this.widgetIcon} text-lg"></i>
                            </div>
                            <span id="chat-title" class="font-semibold text-gray-800 dark:text-white">${this.widgetTitle}</span>
                        </div>
                        <div class="flex items-center gap-2">
                            <button id="chat-options-btn" class="w-8 h-8 flex items-center justify-center text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700">
                                <i class="fa-solid fa-ellipsis"></i>
                            </button>
                        </div>
                    </div>

                    <!-- Messages Area -->
                    <div id="chatgpt-messages" class="flex-1 overflow-y-auto bg-white dark:bg-gray-800 scroll-smooth custom-scrollbar">
                        <!-- Welcome Screen -->
                        <div id="chatgpt-welcome" class="flex flex-col items-center justify-center min-h-full text-center p-8 bg-white dark:bg-gray-800">
                            <div class="w-16 h-16 rounded-full bg-primary flex items-center justify-center text-white mb-6">
                                <i class="fa-solid ${this.widgetIcon} text-3xl"></i>
                            </div>
                            <h1 class="text-4xl font-bold mb-4 text-gray-900 dark:text-white">Welcome to ${this.widgetTitle}</h1>
                            <p class="text-lg text-gray-600 dark:text-gray-300 mb-8 max-w-xl">
                                I'm here to help you with API integration, documentation, and troubleshooting.
                            </p>

                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-2xl w-full">
                                <button class="example-btn bg-white dark:bg-gray-700 p-4 rounded-xl border border-gray-200 dark:border-gray-600 text-left hover:bg-gray-50 dark:hover:bg-gray-600 transition-all duration-200 group">
                                    <div class="flex items-start gap-4">
                                        <div class="p-2 rounded-lg bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-300">
                                            <i class="fa-solid fa-code text-lg"></i>
                                        </div>
                                        <div>
                                            <h3 class="font-medium text-gray-900 dark:text-white mb-1 group-hover:text-primary">Generate client code</h3>
                                            <p class="text-sm text-gray-500 dark:text-gray-400">Get example code for API integration</p>
                                        </div>
                                    </div>
                                </button>
                                <button class="example-btn bg-white dark:bg-gray-700 p-4 rounded-xl border border-gray-200 dark:border-gray-600 text-left hover:bg-gray-50 dark:hover:bg-gray-600 transition-all duration-200 group">
                                    <div class="flex items-start gap-4">
                                        <div class="p-2 rounded-lg bg-green-100 dark:bg-green-900 text-green-600 dark:text-green-300">
                                            <i class="fa-solid fa-book text-lg"></i>
                                        </div>
                                        <div>
                                            <h3 class="font-medium text-gray-900 dark:text-white mb-1 group-hover:text-primary">API Documentation</h3>
                                            <p class="text-sm text-gray-500 dark:text-gray-400">Learn about available endpoints</p>
                                        </div>
                                    </div>
                                </button>
                                <button class="example-btn bg-white dark:bg-gray-700 p-4 rounded-xl border border-gray-200 dark:border-gray-600 text-left hover:bg-gray-50 dark:hover:bg-gray-600 transition-all duration-200 group">
                                    <div class="flex items-start gap-4">
                                        <div class="p-2 rounded-lg bg-purple-100 dark:bg-purple-900 text-purple-600 dark:text-purple-300">
                                            <i class="fa-solid fa-bug text-lg"></i>
                                        </div>
                                        <div>
                                            <h3 class="font-medium text-gray-900 dark:text-white mb-1 group-hover:text-primary">Debug Issues</h3>
                                            <p class="text-sm text-gray-500 dark:text-gray-400">Get help with API problems</p>
                                        </div>
                                    </div>
                                </button>
                                <button class="example-btn bg-white dark:bg-gray-700 p-4 rounded-xl border border-gray-200 dark:border-gray-600 text-left hover:bg-gray-50 dark:hover:bg-gray-600 transition-all duration-200 group">
                                    <div class="flex items-start gap-4">
                                        <div class="p-2 rounded-lg bg-orange-100 dark:bg-orange-900 text-orange-600 dark:text-orange-300">
                                            <i class="fa-solid fa-shield-halved text-lg"></i>
                                        </div>
                                        <div>
                                            <h3 class="font-medium text-gray-900 dark:text-white mb-1 group-hover:text-primary">Security Best Practices</h3>
                                            <p class="text-sm text-gray-500 dark:text-gray-400">Learn about API security</p>
                                        </div>
                                    </div>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Input Area -->
                    <div class="border-t border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 p-4">
                        <div class="max-w-3xl mx-auto relative">
                            <textarea
                                id="chat-input"
                                class="w-full resize-none rounded-lg pl-4 pr-12 py-3 bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 focus:border-primary focus:ring-1 focus:ring-primary dark:text-white text-gray-900 placeholder-gray-400 dark:placeholder-gray-500"
                                placeholder="Message API Assistant..."
                                rows="1"
                                style="min-height: 44px; max-height: 200px;"
                            ></textarea>
                            <button
                                id="send-message-btn"
                                class="absolute right-3 bottom-[10px] text-primary dark:text-primary-light disabled:text-gray-300 dark:disabled:text-gray-600 disabled:cursor-not-allowed p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-600"
                                disabled
                            >
                                <i class="fa-solid fa-paper-plane text-lg"></i>
                            </button>
                        </div>
                        <div class="flex items-center justify-between text-xs mt-2">
                            <div class="text-gray-400 dark:text-gray-500">
                                <span class="mr-2">
                                    <span class="keyboard-shortcut">${this.shortcuts.newChat}</span> New chat
                                </span>
                                <span>
                                    <span class="keyboard-shortcut">${this.shortcuts.focusInput}</span> Focus input
                                </span>
                            </div>
                            <div class="text-gray-400 dark:text-gray-500">
                                API Assistant can make mistakes. Consider checking important information.
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Chat Options Menu (hidden by default) -->
                <div id="chat-options-menu" class="hidden absolute top-14 right-4 w-48 bg-white dark:bg-gray-700 shadow-lg rounded-lg border border-gray-200 dark:border-gray-600 z-50">
                    <ul class="py-1">
                        <li>
                            <button id="rename-chat-btn" class="w-full text-left px-4 py-2 text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-600">
                                <i class="fa-solid fa-pen-to-square mr-2"></i> Rename chat
                            </button>
                        </li>
                        <li>
                            <button id="clear-chat-btn" class="w-full text-left px-4 py-2 text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-600">
                                <i class="fa-solid fa-trash-can mr-2"></i> Clear conversation
                            </button>
                        </li>
                        <li>
                            <button id="export-chat-btn" class="w-full text-left px-4 py-2 text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-600">
                                <i class="fa-solid fa-download mr-2"></i> Export chat
                            </button>
                        </li>
                    </ul>
                </div>
            </div>
        `;
    }

    setupEventListeners() {
        const container = document.getElementById(this.containerId);
        if (!container) return;

        // Chat input and send button
        const textarea = container.querySelector('#chat-input');
        const sendButton = container.querySelector('#send-message-btn');

        if (textarea && sendButton) {
            // Handle input changes
            textarea.addEventListener('input', () => {
                textarea.style.height = 'auto';
                textarea.style.height = Math.min(textarea.scrollHeight, 200) + 'px';
                sendButton.disabled = textarea.value.trim() === '';
            });

            // Handle send button click
            sendButton.addEventListener('click', () => {
                this.handleSendMessage(textarea.value);
                textarea.value = '';
                textarea.style.height = 'auto';
                sendButton.disabled = true;
                textarea.focus();
            });

            // Handle Enter key
            textarea.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    if (!sendButton.disabled && !this.isGenerating) {
                        this.handleSendMessage(textarea.value);
                        textarea.value = '';
                        textarea.style.height = 'auto';
                        sendButton.disabled = true;
                    }
                }
            });

            // Example buttons
            const exampleButtons = container.querySelectorAll('.example-btn');
            exampleButtons.forEach(button => {
                button.addEventListener('click', () => {
                    const headingEl = button.querySelector('h3');
                    if (headingEl) {
                        const text = headingEl.textContent.trim();
                        textarea.value = text;
                        textarea.dispatchEvent(new Event('input'));
                        this.handleSendMessage(text);
                        textarea.value = '';
                        sendButton.disabled = true;
                    }
                });
            });
        }

        // New chat button
        const newChatBtn = container.querySelector('#new-chat-btn');
        if (newChatBtn) {
            newChatBtn.addEventListener('click', () => {
                this.createNewChat();
            });
        }

        // Theme toggle
        const themeToggle = container.querySelector('#theme-toggle');
        if (themeToggle) {
            themeToggle.addEventListener('click', () => {
                this.toggleTheme();
            });
        }

        // Chat options menu
        const chatOptionsBtn = container.querySelector('#chat-options-btn');
        const chatOptionsMenu = container.querySelector('#chat-options-menu');
        if (chatOptionsBtn && chatOptionsMenu) {
            chatOptionsBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                chatOptionsMenu.classList.toggle('hidden');
            });

            document.addEventListener('click', (e) => {
                if (!chatOptionsMenu.contains(e.target) && !chatOptionsBtn.contains(e.target)) {
                    chatOptionsMenu.classList.add('hidden');
                }
            });

            // Chat options menu buttons
            const renameChatBtn = container.querySelector('#rename-chat-btn');
            const clearChatBtn = container.querySelector('#clear-chat-btn');
            const exportChatBtn = container.querySelector('#export-chat-btn');

            if (renameChatBtn) {
                renameChatBtn.addEventListener('click', () => {
                    this.renameCurrentChat();
                    chatOptionsMenu.classList.add('hidden');
                });
            }

            if (clearChatBtn) {
                clearChatBtn.addEventListener('click', () => {
                    this.clearCurrentChat();
                    chatOptionsMenu.classList.add('hidden');
                });
            }

            if (exportChatBtn) {
                exportChatBtn.addEventListener('click', () => {
                    this.exportCurrentChat();
                    chatOptionsMenu.classList.add('hidden');
                });
            }
        }

        // Mobile sidebar toggle
        const sidebarToggle = container.querySelector('#sidebar-toggle');
        const sidebar = container.querySelector('#chat-sidebar');
        const sidebarOverlay = container.querySelector('#chat-sidebar-overlay');

        if (sidebarToggle && sidebar && sidebarOverlay) {
            sidebarToggle.addEventListener('click', () => {
                sidebar.classList.toggle('open');
                sidebarOverlay.classList.toggle('active');
            });

            sidebarOverlay.addEventListener('click', () => {
                sidebar.classList.remove('open');
                sidebarOverlay.classList.remove('active');
            });
        }
    }

    setupKeyboardShortcuts() {
        document.addEventListener('keydown', (e) => {
            // New chat: Ctrl/Cmd + N
            if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === this.shortcuts.newChat.toLowerCase()) {
                e.preventDefault();
                this.createNewChat();
            }

            // Focus input: /
            if (e.key === this.shortcuts.focusInput && document.activeElement.tagName !== 'TEXTAREA') {
                e.preventDefault();
                const textarea = document.querySelector('#chat-input');
                if (textarea) {
                    textarea.focus();
                }
            }

            // Toggle sidebar: Escape
            if (e.key === 'Escape') {
                const sidebar = document.querySelector('#chat-sidebar');
                const sidebarOverlay = document.querySelector('#chat-sidebar-overlay');
                if (sidebar && sidebar.classList.contains('open')) {
                    sidebar.classList.remove('open');
                    if (sidebarOverlay) {
                        sidebarOverlay.classList.remove('active');
                    }
                }
            }
        });
    }

    async handleSendMessage(message) {
        const messagesContainer = document.getElementById('chatgpt-messages');
        const welcomeScreen = document.getElementById('chatgpt-welcome');

        if (!message.trim() || this.isGenerating) return;

        this.isGenerating = true;

        // Hide welcome screen if visible
        if (welcomeScreen && welcomeScreen.style.display !== 'none') {
            welcomeScreen.style.display = 'none';
        }

        // If this is the first message in a new chat, update the chat title
        if (this.messageHistory.length === 0) {
            const chatTitle = message.length > 30 ? message.substring(0, 30) + '...' : message;
            this.updateChatTitle(chatTitle);
        }

        // Add user message to history and display
        this.messageHistory.push({ role: 'user', content: message });
        this.addMessage('user', message);

        // Show typing indicator
        const typingIndicator = this.showTypingIndicator();

        try {
            // Make API call
            const response = await this.makeApiCall(message);

            // Remove typing indicator
            typingIndicator.remove();
            this.isGenerating = false;

            if (response) {
                // Add assistant's response to history and display
                this.messageHistory.push({ role: 'assistant', content: response });
                this.addMessage('assistant', response, true);

                // Save chat to history
                this.saveChatToHistory();
            } else {
                // Handle error case
                this.addMessage('assistant', 'I apologize, but I encountered an error processing your request. Please try again.', true);
            }
        } catch (error) {
            // Remove typing indicator and show error
            typingIndicator.remove();
            this.isGenerating = false;
            this.addMessage('assistant', `Error: ${error.message}. Please try again or contact support if the issue persists.`, true);
        }
    }

    async makeApiCall(message) {
        try {
            console.log('Making API call to:', `${this.apiUrl}/chat/message`);
            
            const requestPayload = {
                message: message,
                session_id: this.sessionId // Will be null for first message in thread
            };

            console.log('Request payload:', requestPayload);

            const response = await fetch(`${this.apiUrl}/chat/message`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-API-Key': this.apiKey,
                    'Accept': 'application/json'
                },
                mode: 'cors',
                credentials: 'include',
                body: JSON.stringify(requestPayload)
            });

            console.log('Response status:', response.status);
            console.log('Response headers:', Object.fromEntries(response.headers.entries()));

            if (!response.ok) {
                const errorText = await response.text();
                console.error('Error response:', errorText);
                throw new Error(`API call failed with status: ${response.status}. Details: ${errorText}`);
            }

            const data = await response.json();
            console.log('Response data:', data);
            
            // Store the session ID for subsequent messages in the thread
            if (data.session_id) {
                this.sessionId = data.session_id;
            }

            if (!data.response) {
                throw new Error('Invalid response format: missing response field');
            }

            // Add metadata to the response if available
            let formattedResponse = data.response;
            if (data.agent_type === 'code_generator') {
                formattedResponse = `[Generated by ${data.agent_type}]\n\n${data.response}`;
            }

            return formattedResponse;

        } catch (error) {
            console.error('API call error:', error);
            if (error instanceof TypeError && error.message.includes('Failed to fetch')) {
                throw new Error('Could not connect to the API. Please check if the server is running and accessible.');
            }
            throw error;
        }
    }

    addMessage(role, content, isHtml = false) {
        const messagesContainer = document.getElementById('chatgpt-messages');
        const messageDiv = document.createElement('div');
        messageDiv.className = 'message-container px-4 py-6 border-b border-gray-200 dark:border-gray-700 ' +
            (role === 'user' ? 'bg-white dark:bg-gray-800' : 'bg-gray-50 dark:bg-gray-700');

        // Set initial state for animation
        messageDiv.style.opacity = '0';
        messageDiv.style.transform = 'translateY(10px)';

        // Process content if it's HTML
        let processedContent = content;
        if (isHtml) {
            // Process markdown (simple implementation)
            processedContent = this.processMarkdown(content);

            // Process code blocks with enhanced display
            processedContent = processedContent.replace(/```(\w+)?\n([\s\S]*?)```/g, (match, language, code) => {
                const lang = language || 'plaintext';
                const uniqueId = 'code-' + Math.random().toString(36).substr(2, 9);

                return `<div class="code-block relative my-4 rounded-lg overflow-hidden shadow-lg">
                    <div class="flex justify-between items-center py-2 px-4 bg-gray-800 dark:bg-gray-900 text-gray-200">
                        <div class="flex items-center">
                            <span class="text-xs font-medium mr-3">${lang}</span>
                            <div class="flex space-x-1.5">
                                <span class="w-3 h-3 rounded-full bg-red-500"></span>
                                <span class="w-3 h-3 rounded-full bg-yellow-500"></span>
                                <span class="w-3 h-3 rounded-full bg-green-500"></span>
                            </div>
                        </div>
                        <div class="flex gap-2">
                            <button class="code-copy-button p-1.5 text-xs text-gray-400 hover:text-white transition-colors rounded hover:bg-gray-700"
                                    data-code-id="${uniqueId}" aria-label="Copy code">
                                <i class="fa-regular fa-copy mr-1"></i> Copy
                            </button>
                            <button class="code-download-button p-1.5 text-xs text-gray-400 hover:text-white transition-colors rounded hover:bg-gray-700"
                                    data-code-id="${uniqueId}" data-language="${lang}" aria-label="Download code">
                                <i class="fa-solid fa-download mr-1"></i> Download
                            </button>
                        </div>
                    </div>
                    <div class="relative group">
                        <pre class="m-0 p-4 bg-gray-900 dark:bg-gray-950 overflow-x-auto scrollbar-thin scrollbar-thumb-gray-700 scrollbar-track-gray-900" style="max-height: 400px;">
                            <code id="${uniqueId}" class="language-${lang} text-sm">${this.escapeHtml(code.trim())}</code>
                        </pre>
                        <div class="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                            <button class="code-fullscreen-button p-1.5 text-xs bg-gray-800 text-gray-400 hover:text-white rounded hover:bg-gray-700"
                                    data-code-id="${uniqueId}" aria-label="View in fullscreen">
                                <i class="fa-solid fa-expand"></i>
                            </button>
                        </div>
                    </div>
                </div>`;
            });

            // Process Mermaid diagrams
            processedContent = processedContent.replace(/```mermaid\n([\s\S]*?)```/g, (match, diagram) => {
                const diagramId = 'mermaid-' + Math.random().toString(36).substr(2, 9);
                return `<div class="mermaid-container bg-white dark:bg-gray-900 rounded-lg p-4 my-4 shadow-lg">
                    <div class="mermaid" id="${diagramId}">${diagram.trim()}</div>
                </div>`;
            });
        }

        messageDiv.innerHTML = `
            <div class="max-w-3xl mx-auto flex gap-6">
                <div class="flex-shrink-0">
                    ${role === 'user'
                        ? `<div class="w-8 h-8 rounded-lg bg-purple-500 flex items-center justify-center text-white font-medium">${this.avatarText}</div>`
                        : `<div class="w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-white">
                            <i class="fa-solid ${this.widgetIcon} text-lg"></i>
                           </div>`
                    }
                </div>
                <div class="flex-1 overflow-hidden">
                    <div class="${isHtml ? 'markdown-content' : 'prose'} dark:prose-invert max-w-none">
                        ${isHtml ? processedContent : `<p>${this.escapeHtml(content)}</p>`}
                    </div>
                </div>
            </div>
        `;

        messagesContainer.appendChild(messageDiv);

        // Trigger animation
        requestAnimationFrame(() => {
            messageDiv.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
            messageDiv.style.opacity = '1';
            messageDiv.style.transform = 'translateY(0)';
        });

        // Auto-scroll to the bottom
        messagesContainer.scrollTop = messagesContainer.scrollHeight;

        // Initialize syntax highlighting and Mermaid diagrams
        if (isHtml) {
            messageDiv.querySelectorAll('pre code').forEach((block) => {
                hljs.highlightElement(block);
            });

            messageDiv.querySelectorAll('.mermaid').forEach((diagram) => {
                try {
                    mermaid.init(undefined, diagram);
                } catch (error) {
                    console.error('Mermaid initialization error:', error);
                }
            });

            // Add click event for copy buttons
            messageDiv.querySelectorAll('.code-copy-button').forEach((button) => {
                button.addEventListener('click', () => {
                    const codeId = button.getAttribute('data-code-id');
                    const codeBlock = document.getElementById(codeId);
                    if (codeBlock) {
                        navigator.clipboard.writeText(codeBlock.textContent);

                        // Show "Copied!" text temporarily
                        const originalText = button.innerHTML;
                        button.innerHTML = '<i class="fa-solid fa-check mr-1"></i> Copied!';
                        button.classList.add('bg-green-700', 'text-white');
                        setTimeout(() => {
                            button.innerHTML = originalText;
                            button.classList.remove('bg-green-700', 'text-white');
                        }, 2000);
                    }
                });
            });

            // Add click event for download buttons
            messageDiv.querySelectorAll('.code-download-button').forEach((button) => {
                button.addEventListener('click', () => {
                    const codeId = button.getAttribute('data-code-id');
                    const language = button.getAttribute('data-language');
                    const codeBlock = document.getElementById(codeId);

                    if (codeBlock) {
                        // Create file extension based on language
                        let fileExtension = '.txt';
                        switch (language) {
                            case 'javascript':
                            case 'js':
                                fileExtension = '.js';
                                break;
                            case 'typescript':
                            case 'ts':
                                fileExtension = '.ts';
                                break;
                            case 'python':
                            case 'py':
                                fileExtension = '.py';
                                break;
                            case 'html':
                                fileExtension = '.html';
                                break;
                            case 'css':
                                fileExtension = '.css';
                                break;
                            case 'java':
                                fileExtension = '.java';
                                break;
                            case 'c':
                                fileExtension = '.c';
                                break;
                            case 'cpp':
                                fileExtension = '.cpp';
                                break;
                            case 'json':
                                fileExtension = '.json';
                                break;
                            case 'markdown':
                            case 'md':
                                fileExtension = '.md';
                                break;
                            case 'sql':
                                fileExtension = '.sql';
                                break;
                            case 'xml':
                                fileExtension = '.xml';
                                break;
                            case 'yaml':
                            case 'yml':
                                fileExtension = '.yaml';
                                break;
                            case 'rust':
                            case 'rs':
                                fileExtension = '.rs';
                                break;
                            case 'go':
                                fileExtension = '.go';
                                break;
                            case 'ruby':
                            case 'rb':
                                fileExtension = '.rb';
                                break;
                            case 'php':
                                fileExtension = '.php';
                                break;
                            // Add more languages as needed
                        }

                        // Create filename
                        const filename = `code_snippet${fileExtension}`;

                        // Create file
                        const blob = new Blob([codeBlock.textContent], { type: 'text/plain' });
                        const url = URL.createObjectURL(blob);

                        // Create download link
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = filename;
                        document.body.appendChild(a);
                        a.click();

                        // Clean up
                        document.body.removeChild(a);
                        URL.revokeObjectURL(url);

                        // Show feedback
                        const originalText = button.innerHTML;
                        button.innerHTML = '<i class="fa-solid fa-check mr-1"></i> Downloaded!';
                        button.classList.add('bg-green-700', 'text-white');
                        setTimeout(() => {
                            button.innerHTML = originalText;
                            button.classList.remove('bg-green-700', 'text-white');
                        }, 2000);
                    }
                });
            });

            // Add click event for fullscreen buttons
            messageDiv.querySelectorAll('.code-fullscreen-button').forEach((button) => {
                button.addEventListener('click', () => {
                    const codeId = button.getAttribute('data-code-id');
                    const codeBlock = document.getElementById(codeId);

                    if (codeBlock) {
                        // Create fullscreen modal
                        const modal = document.createElement('div');
                        modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
                        modal.style.backdropFilter = 'blur(4px)';

                        // Get language for proper display
                        const language = codeBlock.className.replace('language-', '');

                        modal.innerHTML = `
                            <div class="bg-gray-900 dark:bg-gray-950 rounded-lg w-11/12 max-w-4xl max-h-[90vh] flex flex-col">
                                <div class="flex justify-between items-center py-2 px-4 bg-gray-800 dark:bg-gray-900 rounded-t-lg">
                                    <div class="flex items-center">
                                        <span class="text-sm font-medium text-gray-200 mr-3">${language}</span>
                                        <div class="flex space-x-1.5">
                                            <span class="w-3 h-3 rounded-full bg-red-500"></span>
                                            <span class="w-3 h-3 rounded-full bg-yellow-500"></span>
                                            <span class="w-3 h-3 rounded-full bg-green-500"></span>
                                        </div>
                                    </div>
                                    <div class="flex gap-2">
                                        <button class="fullscreen-copy-button p-1.5 text-xs text-gray-400 hover:text-white transition-colors rounded hover:bg-gray-700">
                                            <i class="fa-regular fa-copy mr-1"></i> Copy
                                        </button>
                                        <button class="fullscreen-download-button p-1.5 text-xs text-gray-400 hover:text-white transition-colors rounded hover:bg-gray-700"
                                                data-language="${language}">
                                            <i class="fa-solid fa-download mr-1"></i> Download
                                        </button>
                                        <button class="fullscreen-close-button p-1.5 text-xs text-gray-400 hover:text-white transition-colors rounded hover:bg-gray-700">
                                            <i class="fa-solid fa-times mr-1"></i> Close
                                        </button>
                                    </div>
                                </div>
                                <div class="overflow-auto flex-1 p-4">
                                    <pre class="m-0 h-full"><code class="language-${language} text-sm">${codeBlock.innerHTML}</code></pre>
                                </div>
                            </div>
                        `;

                        document.body.appendChild(modal);

                        // Re-apply syntax highlighting
                        const fullscreenCode = modal.querySelector('code');
                        hljs.highlightElement(fullscreenCode);

                        // Handle close button
                        const closeButton = modal.querySelector('.fullscreen-close-button');
                        closeButton.addEventListener('click', () => {
                            document.body.removeChild(modal);
                        });

                        // Close on escape key
                        const handleEscape = (e) => {
                            if (e.key === 'Escape') {
                                document.body.removeChild(modal);
                                document.removeEventListener('keydown', handleEscape);
                            }
                        };
                        document.addEventListener('keydown', handleEscape);

                        // Handle click outside to close
                        modal.addEventListener('click', (e) => {
                            if (e.target === modal) {
                                document.body.removeChild(modal);
                            }
                        });

                        // Handle copy in fullscreen
                        const fullscreenCopyButton = modal.querySelector('.fullscreen-copy-button');
                        fullscreenCopyButton.addEventListener('click', () => {
                            navigator.clipboard.writeText(codeBlock.textContent);

                            fullscreenCopyButton.innerHTML = '<i class="fa-solid fa-check mr-1"></i> Copied!';
                            fullscreenCopyButton.classList.add('bg-green-700', 'text-white');
                            setTimeout(() => {
                                fullscreenCopyButton.innerHTML = '<i class="fa-regular fa-copy mr-1"></i> Copy';
                                fullscreenCopyButton.classList.remove('bg-green-700', 'text-white');
                            }, 2000);
                        });

                        // Handle download in fullscreen
                        const fullscreenDownloadButton = modal.querySelector('.fullscreen-download-button');
                        fullscreenDownloadButton.addEventListener('click', () => {
                            const language = fullscreenDownloadButton.getAttribute('data-language');

                            // Create file extension based on language (same logic as above)
                            let fileExtension = '.txt';
                            // Determine file extension based on language...

                            // Create filename
                            const filename = `code_snippet${fileExtension}`;

                            // Create file and download
                            const blob = new Blob([codeBlock.textContent], { type: 'text/plain' });
                            const url = URL.createObjectURL(blob);

                            const a = document.createElement('a');
                            a.href = url;
                            a.download = filename;
                            document.body.appendChild(a);
                            a.click();

                            document.body.removeChild(a);
                            URL.revokeObjectURL(url);

                            fullscreenDownloadButton.innerHTML = '<i class="fa-solid fa-check mr-1"></i> Downloaded!';
                            fullscreenDownloadButton.classList.add('bg-green-700', 'text-white');
                            setTimeout(() => {
                                fullscreenDownloadButton.innerHTML = '<i class="fa-solid fa-download mr-1"></i> Download';
                                fullscreenDownloadButton.classList.remove('bg-green-700', 'text-white');
                            }, 2000);
                        });
                    }
                });
            });
        }
    }

    showTypingIndicator() {
        const messagesContainer = document.getElementById('chatgpt-messages');
        const typingIndicator = document.createElement('div');
        typingIndicator.className = 'message-container px-4 py-6 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700';

        typingIndicator.innerHTML = `
            <div class="max-w-3xl mx-auto flex gap-6">
                <div class="flex-shrink-0">
                    <div class="w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-white">
                        <i class="fa-solid ${this.widgetIcon} text-lg"></i>
                    </div>
                </div>
                <div class="flex items-center">
                    <div class="flex gap-2">
                        <div class="w-2 h-2 bg-gray-400 dark:bg-gray-500 rounded-full animate-bounce" style="animation-delay: 0s;"></div>
                        <div class="w-2 h-2 bg-gray-400 dark:bg-gray-500 rounded-full animate-bounce" style="animation-delay: 0.2s;"></div>
                        <div class="w-2 h-2 bg-gray-400 dark:bg-gray-500 rounded-full animate-bounce" style="animation-delay: 0.4s;"></div>
                    </div>
                </div>
            </div>
        `;

        messagesContainer.appendChild(typingIndicator);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
        return typingIndicator;
    }

    // Process markdown (basic implementation)
    processMarkdown(text) {
        // This is a simplified markdown processing
        // For a production app, consider using a proper markdown library

        // Headers
        text = text.replace(/^### (.*$)/gm, '<h3>$1</h3>');
        text = text.replace(/^## (.*$)/gm, '<h2>$1</h2>');
        text = text.replace(/^# (.*$)/gm, '<h1>$1</h1>');

        // Bold
        text = text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');

        // Italic
        text = text.replace(/\*(.*?)\*/g, '<em>$1</em>');

        // Links
        text = text.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');

        // Lists (basic)
        text = text.replace(/^\s*\d+\.\s+(.*$)/gm, '<li>$1</li>');
        text = text.replace(/^\s*-\s+(.*$)/gm, '<li>$1</li>');

        // Fix lists
        text = text.replace(/<\/li>\s*<li>/g, '</li><li>');
        text = text.replace(/(\n<li>.*<\/li>)/g, '<ul>$1</ul>');

        // Paragraphs
        text = text.replace(/\n\s*\n/g, '\n\n');
        text = text.replace(/^(?!<[hou]|<li|<ul|<pre|<blockquote)(.+)$/gm, '<p>$1</p>');

        // Clean up extra paragraph tags
        text = text.replace(/<p><\/p>/g, '');

        return text;
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    toggleTheme() {
        const container = document.getElementById(this.containerId);
        if (container) {
            container.classList.toggle('dark');
            this.theme = container.classList.contains('dark') ? 'dark' : 'light';

            // Update theme toggle icon
            const themeIcon = container.querySelector('#theme-toggle i');
            if (themeIcon) {
                if (this.theme === 'dark') {
                    themeIcon.classList.remove('fa-moon');
                    themeIcon.classList.add('fa-sun');
                } else {
                    themeIcon.classList.remove('fa-sun');
                    themeIcon.classList.add('fa-moon');
                }
            }

            // Save theme preference
            if (this.storageEnabled) {
                localStorage.setItem('chatgpt-widget-theme', this.theme);
            }
        }
    }

    // Chat History Management
    createNewChat() {
        // Generate a unique ID for the chat
        const chatId = 'chat_' + Date.now();

        // Create a new chat object
        const newChat = {
            id: chatId,
            title: 'New Chat',
            created: new Date().toISOString(),
            messages: []
        };

        // Update current chat ID
        this.currentChatId = chatId;

        // Reset message history
        this.messageHistory = [];

        // Reset session ID
        this.sessionId = null;

        // Add to chat history
        this.chatHistory = [newChat, ...this.chatHistory];

        // Update UI
        this.updateChatHistoryUI();

        // Clear messages container
        const messagesContainer = document.getElementById('chatgpt-messages');
        const welcomeScreen = document.getElementById('chatgpt-welcome');

        if (messagesContainer) {
            messagesContainer.innerHTML = '';

            // Show welcome screen
            if (welcomeScreen) {
                welcomeScreen.style.display = 'flex';
            } else {
                // Create welcome screen if it doesn't exist
                messagesContainer.innerHTML = `
                    <div id="chatgpt-welcome" class="flex flex-col items-center justify-center min-h-full text-center p-8 bg-white dark:bg-gray-800">
                        <div class="w-16 h-16 rounded-full bg-primary flex items-center justify-center text-white mb-6">
                            <i class="fa-solid ${this.widgetIcon} text-3xl"></i>
                        </div>
                        <h1 class="text-4xl font-bold mb-4 text-gray-900 dark:text-white">Welcome to ${this.widgetTitle}</h1>
                        <p class="text-lg text-gray-600 dark:text-gray-300 mb-8 max-w-xl">
                            I'm here to help you with API integration, documentation, and troubleshooting.
                        </p>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-2xl w-full">
                            <!-- Example buttons (same as in setupUI) -->
                            <!-- ... -->
                        </div>
                    </div>
                `;
            }
        }

        // Reset chat title
        const chatTitle = document.getElementById('chat-title');
        if (chatTitle) {
            chatTitle.textContent = this.widgetTitle;
        }

        // Save to localStorage
        if (this.storageEnabled) {
            this.saveChatHistory();
        }

        // Focus input
        const textarea = document.getElementById('chat-input');
        if (textarea) {
            textarea.focus();
        }
    }

    loadChat(chatId) {
        const chat = this.chatHistory.find(c => c.id === chatId);
        if (!chat) return;

        // Update current chat ID
        this.currentChatId = chatId;

        // Load messages
        this.messageHistory = [...chat.messages];

        // Reset session ID - we'll get a new one when sending the first message
        this.sessionId = null;

        // Update UI
        this.updateChatHistoryUI();

        // Update messages container
        const messagesContainer = document.getElementById('chatgpt-messages');
        if (messagesContainer) {
            messagesContainer.innerHTML = '';

            if (chat.messages.length === 0) {
                // Show welcome screen for empty chats
                messagesContainer.innerHTML = `
                    <div id="chatgpt-welcome" class="flex flex-col items-center justify-center min-h-full text-center p-8 bg-white dark:bg-gray-800">
                        <!-- Welcome screen content -->
                    </div>
                `;
            } else {
                // Add all messages to the UI
                chat.messages.forEach(msg => {
                    this.addMessage(msg.role, msg.content, msg.role === 'assistant');
                });
            }
        }

        // Update chat title
        const chatTitle = document.getElementById('chat-title');
        if (chatTitle) {
            chatTitle.textContent = chat.title || this.widgetTitle;
        }

        // Close sidebar on mobile
        const sidebar = document.getElementById('chat-sidebar');
        const sidebarOverlay = document.getElementById('chat-sidebar-overlay');
        if (sidebar && window.innerWidth < 768) {
            sidebar.classList.remove('open');
            if (sidebarOverlay) {
                sidebarOverlay.classList.remove('active');
            }
        }
    }

    updateChatHistoryUI() {
        const historyList = document.getElementById('chat-history-list');
        if (!historyList) return;

        // Clear existing history items
        historyList.innerHTML = '';

        if (this.chatHistory.length === 0) {
            historyList.innerHTML = `
                <div class="chat-history-placeholder text-center text-gray-400 dark:text-gray-500 py-8">
                    No chat history yet
                </div>
            `;
            return;
        }

        // Add chat history items
        this.chatHistory.forEach(chat => {
            const item = document.createElement('div');
            item.className = `chat-history-item p-2 rounded-lg cursor-pointer flex items-center justify-between ${
                chat.id === this.currentChatId
                    ? 'bg-gray-200 dark:bg-gray-700'
                    : 'hover:bg-gray-100 dark:hover:bg-gray-800'
            }`;
            item.dataset.chatId = chat.id;

            // Format date
            const date = new Date(chat.created);
            const formattedDate = date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });

            item.innerHTML = `
                <div class="flex items-center overflow-hidden">
                    <div class="w-6 h-6 rounded-lg bg-gray-300 dark:bg-gray-600 flex items-center justify-center mr-2 text-gray-500 dark:text-gray-400">
                        <i class="fa-regular fa-comment text-xs"></i>
                    </div>
                    <span class="text-sm text-gray-800 dark:text-gray-200 truncate">${chat.title}</span>
                </div>
                <div class="flex items-center">
                    <span class="text-xs text-gray-400 dark:text-gray-500 mr-2">${formattedDate}</span>
                    ${chat.id === this.currentChatId ? '' : `
                    <button class="delete-chat-btn p-1 text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300">
                        <i class="fa-solid fa-xmark text-xs"></i>
                    </button>
                    `}
                </div>
            `;

            // Add click event to load chat
            item.addEventListener('click', (e) => {
                if (!e.target.closest('.delete-chat-btn')) {
                    this.loadChat(chat.id);
                }
            });

            // Add delete button event
            const deleteBtn = item.querySelector('.delete-chat-btn');
            if (deleteBtn) {
                deleteBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    this.deleteChat(chat.id);
                });
            }

            historyList.appendChild(item);
        });
    }

    saveChatToHistory() {
        if (!this.currentChatId) return;

        // Find current chat in history
        const chatIndex = this.chatHistory.findIndex(c => c.id === this.currentChatId);
        if (chatIndex === -1) return;

        // Update chat messages
        this.chatHistory[chatIndex].messages = [...this.messageHistory];

        // Update chat title if it's still the default
        if (this.chatHistory[chatIndex].title === 'New Chat' && this.messageHistory.length > 0) {
            const firstUserMessage = this.messageHistory.find(msg => msg.role === 'user');
            if (firstUserMessage) {
                const newTitle = firstUserMessage.content.length > 30
                    ? firstUserMessage.content.substring(0, 30) + '...'
                    : firstUserMessage.content;

                this.chatHistory[chatIndex].title = newTitle;
                this.updateChatTitle(newTitle);
            }
        }

        // Move current chat to top of history
        if (chatIndex > 0) {
            const [chat] = this.chatHistory.splice(chatIndex, 1);
            this.chatHistory.unshift(chat);
        }

        // Update UI
        this.updateChatHistoryUI();

        // Save to localStorage
        if (this.storageEnabled) {
            this.saveChatHistory();
        }
    }

    updateChatTitle(title) {
        if (!this.currentChatId) return;

        // Update chat title in history
        const chatIndex = this.chatHistory.findIndex(c => c.id === this.currentChatId);
        if (chatIndex === -1) return;

        this.chatHistory[chatIndex].title = title;

        // Update UI
        const chatTitle = document.getElementById('chat-title');
        if (chatTitle) {
            chatTitle.textContent = title;
        }

        // Update chat history UI
        this.updateChatHistoryUI();

        // Save to localStorage
        if (this.storageEnabled) {
            this.saveChatHistory();
        }
    }

    renameCurrentChat() {
        if (!this.currentChatId) return;

        // Find current chat
        const chat = this.chatHistory.find(c => c.id === this.currentChatId);
        if (!chat) return;

        // Prompt for new title
        const newTitle = prompt('Enter a new name for this chat:', chat.title);
        if (newTitle === null) return; // User cancelled

        // Update title
        this.updateChatTitle(newTitle || 'Untitled Chat');
    }

    clearCurrentChat() {
        if (!this.currentChatId) return;

        // Confirm clear
        if (!confirm('Are you sure you want to clear this conversation? This cannot be undone.')) {
            return;
        }

        // Reset message history
        this.messageHistory = [];

        // Reset session ID
        this.sessionId = null;

        // Update chat in history
        const chatIndex = this.chatHistory.findIndex(c => c.id === this.currentChatId);
        if (chatIndex !== -1) {
            this.chatHistory[chatIndex].messages = [];

            // Reset title if it was derived from first message
            if (this.chatHistory[chatIndex].title !== 'New Chat') {
                this.chatHistory[chatIndex].title = 'New Chat';
                this.updateChatTitle('New Chat');
            }
        }

        // Clear messages container
        const messagesContainer = document.getElementById('chatgpt-messages');
        if (messagesContainer) {
            messagesContainer.innerHTML = '';

            // Show welcome screen
            messagesContainer.innerHTML = `
                <div id="chatgpt-welcome" class="flex flex-col items-center justify-center min-h-full text-center p-8 bg-white dark:bg-gray-800">
                    <!-- Welcome screen content -->
                </div>
            `;
        }

        // Save to localStorage
        if (this.storageEnabled) {
            this.saveChatHistory();
        }
    }

    deleteChat(chatId) {
        // Confirm delete
        if (!confirm('Are you sure you want to delete this chat? This cannot be undone.')) {
            return;
        }

        // Find chat index
        const chatIndex = this.chatHistory.findIndex(c => c.id === chatId);
        if (chatIndex === -1) return;

        // Remove chat from history
        this.chatHistory.splice(chatIndex, 1);

        // If deleted the current chat, load another one or create a new one
        if (chatId === this.currentChatId) {
            if (this.chatHistory.length > 0) {
                this.loadChat(this.chatHistory[0].id);
            } else {
                this.createNewChat();
            }
        }

        // Update UI
        this.updateChatHistoryUI();

        // Save to localStorage
        if (this.storageEnabled) {
            this.saveChatHistory();
        }
    }

    exportCurrentChat() {
        if (!this.currentChatId) return;

        // Find current chat
        const chat = this.chatHistory.find(c => c.id === this.currentChatId);
        if (!chat || chat.messages.length === 0) {
            alert('No messages to export.');
            return;
        }

        // Format chat as JSON
        const chatData = {
            title: chat.title,
            created: chat.created,
            messages: chat.messages,
            exportDate: new Date().toISOString()
        };

        // Create file
        const blob = new Blob([JSON.stringify(chatData, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);

        // Create download link
        const a = document.createElement('a');
        a.href = url;
        a.download = `${chat.title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_${new Date().getTime()}.json`;
        document.body.appendChild(a);
        a.click();

        // Clean up
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }

    // LocalStorage Management
    loadChatHistory() {
        try {
            const savedHistory = localStorage.getItem('chatgpt-widget-history');
            if (savedHistory) {
                this.chatHistory = JSON.parse(savedHistory);
            }

            // Load theme preference
            const savedTheme = localStorage.getItem('chatgpt-widget-theme');
            if (savedTheme) {
                this.theme = savedTheme;
            }
        } catch (error) {
            console.error('Error loading chat history:', error);
            // Reset history in case of corruption
            this.chatHistory = [];
        }
    }

    saveChatHistory() {
        try {
            // Limit history size to prevent localStorage overflow
            const limitedHistory = this.chatHistory.slice(0, 50);

            localStorage.setItem('chatgpt-widget-history', JSON.stringify(limitedHistory));
        } catch (error) {
            console.error('Error saving chat history:', error);
        }
    }

    // Static method to determine if the browser supports localStorage
    static isStorageAvailable() {
        try {
            const storage = window.localStorage;
            const x = '__storage_test__';
            storage.setItem(x, x);
            storage.removeItem(x);
            return true;
        } catch (e) {
            return false;
        }
    }
}