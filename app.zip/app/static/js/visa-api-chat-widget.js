// visa-api-chat-widget.js
class VisaAPIChatWidget {
  constructor(options = {}) {
    this.apiUrl = options.apiUrl || 'http://localhost:8000/api/v1';
    this.apiKey = options.apiKey || '';
    this.containerId = options.containerId || 'visa-api-chat-container';
    this.userId = options.userId || null;
    this.sessionId = options.sessionId || null;
    this.theme = options.theme || 'light';
    this.position = options.position || 'bottom-right';

    this.messages = [];
    this.initialized = false;

    this.init();
  }

  async init() {
    this.createContainer();
    this.createStyles();
    this.renderWidget();
    this.attachEventListeners();
    this.initialized = true;

    // Resume existing session if provided
    if (this.sessionId) {
      await this.loadSessionHistory();
    }
  }

  createContainer() {
    // Check if container exists
    let container = document.getElementById(this.containerId);
    if (!container) {
      // Create container element
      container = document.createElement('div');
      container.id = this.containerId;
      document.body.appendChild(container);
    }

    this.container = container;
  }

  createStyles() {
    const style = document.createElement('style');
    style.textContent = `
      #${this.containerId} {
        position: fixed;
        ${this.position.includes('bottom') ? 'bottom: 20px;' : 'top: 20px;'}
        ${this.position.includes('right') ? 'right: 20px;' : 'left: 20px;'}
        width: 350px;
        height: 500px;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 5px 40px rgba(0, 0, 0, 0.16);
        background-color: ${this.theme === 'dark' ? '#1a1a1a' : '#ffffff'};
        color: ${this.theme === 'dark' ? '#ffffff' : '#333333'};
        display: flex;
        flex-direction: column;
        z-index: 9999;
        transition: all 0.3s ease;
      }

      .visa-chat-header {
        padding: 15px;
        background-color: #1a5f7a;
        color: white;
        font-weight: bold;
        display: flex;
        justify-content: space-between;
        align-items: center;
      }

      .visa-chat-body {
        flex: 1;
        overflow-y: auto;
        padding: 15px;
        display: flex;
        flex-direction: column;
      }

      .visa-chat-footer {
        padding: 10px;
        border-top: 1px solid #e6e6e6;
        display: flex;
      }

      .visa-chat-input {
        flex: 1;
        padding: 8px 12px;
        border: 1px solid #ccc;
        border-radius: 20px;
        outline: none;
      }

      .visa-chat-send {
        background-color: #1a5f7a;
        color: white;
        border: none;
        border-radius: 50%;
        width: 36px;
        height: 36px;
        margin-left: 8px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
      }

      .visa-chat-message {
        max-width: 80%;
        padding: 10px 15px;
        margin-bottom: 10px;
        border-radius: 18px;
        word-wrap: break-word;
      }

      .visa-chat-user {
        align-self: flex-end;
        background-color: #1a5f7a;
        color: white;
        border-bottom-right-radius: 5px;
      }

      .visa-chat-assistant {
        align-self: flex-start;
        background-color: ${this.theme === 'dark' ? '#2d2d2d' : '#f1f1f1'};
        color: ${this.theme === 'dark' ? '#ffffff' : '#333333'};
        border-bottom-left-radius: 5px;
      }

      .visa-chat-code {
        background-color: ${this.theme === 'dark' ? '#2d2d2d' : '#f5f5f5'};
        border-radius: 5px;
        padding: 10px;
        font-family: monospace;
        overflow-x: auto;
        margin: 5px 0;
      }

      .visa-chat-mermaid {
        width: 100%;
        overflow-x: auto;
        background-color: white;
        padding: 5px;
        border-radius: 5px;
        margin: 5px 0;
      }

      .visa-chat-minimize {
        background: none;
        border: none;
        color: white;
        cursor: pointer;
        font-size: 16px;
      }

      #${this.containerId}.minimized {
        height: 50px;
        width: 50px;
        border-radius: 50%;
        overflow: hidden;
      }

      #${this.containerId}.minimized .visa-chat-body,
      #${this.containerId}.minimized .visa-chat-footer {
        display: none;
      }

      .visa-chat-typing {
        align-self: flex-start;
        background-color: ${this.theme === 'dark' ? '#2d2d2d' : '#f1f1f1'};
        color: ${this.theme === 'dark' ? '#ffffff' : '#333333'};
        border-radius: 18px;
        padding: 10px 15px;
        margin-bottom: 10px;
      }

      .typing-dots span {
        animation: typingDot 1.4s infinite;
        display: inline-block;
        width: 5px;
        height: 5px;
        border-radius: 50%;
        background-color: ${this.theme === 'dark' ? '#ffffff' : '#333333'};
        margin-right: 3px;
      }

      .typing-dots span:nth-child(2) {
        animation-delay: 0.2s;
      }

      .typing-dots span:nth-child(3) {
        animation-delay: 0.4s;
      }

      @keyframes typingDot {
        0%, 60%, 100% { transform: translateY(0); }
        30% { transform: translateY(-5px); }
      }
    `;
    document.head.appendChild(style);
  }

  renderWidget() {
    this.container.innerHTML = `
      <div class="visa-chat-header">
        <span>Visa API Assistant</span>
        <button class="visa-chat-minimize">−</button>
      </div>
      <div class="visa-chat-body"></div>
      <div class="visa-chat-footer">
        <input type="text" class="visa-chat-input" placeholder="Ask about Visa API...">
        <button class="visa-chat-send">↑</button>
      </div>
    `;

    this.chatBody = this.container.querySelector('.visa-chat-body');
    this.chatInput = this.container.querySelector('.visa-chat-input');
    this.chatSend = this.container.querySelector('.visa-chat-send');
    this.minimizeBtn = this.container.querySelector('.visa-chat-minimize');
  }

  attachEventListeners() {
    this.chatSend.addEventListener('click', () => this.sendMessage());
    this.chatInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') this.sendMessage();
    });
    this.minimizeBtn.addEventListener('click', () => this.toggleMinimize());
  }

  toggleMinimize() {
    this.container.classList.toggle('minimized');
    this.minimizeBtn.textContent = this.container.classList.contains('minimized') ? '+' : '−';
  }

  async sendMessage() {
    const message = this.chatInput.value.trim();
    if (message === '') return;

    // Add user message to UI
    this.addMessage('user', message);
    this.chatInput.value = '';

    // Show typing indicator
    this.showTypingIndicator();

    try {
      const response = await this.makeAPIRequest(message);

      // Remove typing indicator
      this.hideTypingIndicator();

      // Add assistant response to UI
      if (response && response.response) {
        this.addMessage('assistant', response.response);

        // Update session ID if new
        if (response.session_id && !this.sessionId) {
          this.sessionId = response.session_id;
          // Trigger session ID change event
          this.triggerEvent('sessionChange', { sessionId: this.sessionId });
        }
      } else {
        this.addMessage('assistant', 'Sorry, I encountered an error. Please try again.');
      }
    } catch (error) {
      console.error('Error sending message:', error);
      this.hideTypingIndicator();
      this.addMessage('assistant', 'Sorry, I encountered an error. Please try again.');
    }
  }

  async makeAPIRequest(message) {
    const endpoint = `${this.apiUrl}/chat/message`;

    const payload = {
      message: message
    };

    // Add session ID if available
    if (this.sessionId) {
      payload.session_id = this.sessionId;
    }

    const response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-API-Key': this.apiKey
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }

    return await response.json();
  }

  async loadSessionHistory() {
    try {
      const endpoint = `${this.apiUrl}/chat/session/${this.sessionId}`;
      const response = await fetch(endpoint, {
        headers: {
          'X-API-Key': this.apiKey
        }
      });

      if (response.ok) {
        const sessionData = await response.json();
        if (sessionData.messages && sessionData.messages.length > 0) {
          // Clear current messages
          this.messages = [];
          this.chatBody.innerHTML = '';

          // Add historical messages
          sessionData.messages.forEach(msg => {
            this.addMessage(msg.role, msg.content, false);
          });

          // Scroll to bottom
          this.scrollToBottom();
        }
      }
    } catch (error) {
      console.error('Error loading session history:', error);
    }
  }

  addMessage(role, content, scroll = true) {
    // Store message
    this.messages.push({ role, content });

    // Create message element
    const messageEl = document.createElement('div');
    messageEl.classList.add('visa-chat-message', `visa-chat-${role}`);

    // Process content for code blocks and mermaid diagrams
    content = this.processMessageContent(content);

    messageEl.innerHTML = content;
    this.chatBody.appendChild(messageEl);

    // Scroll to bottom if needed
    if (scroll) {
      this.scrollToBottom();
    }

    // Initialize any Mermaid diagrams in the message
    if (content.includes('class="visa-chat-mermaid"') && window.mermaid) {
      window.mermaid.init(undefined, document.querySelectorAll('.visa-chat-mermaid'));
    }

    // Trigger message event
    this.triggerEvent('newMessage', { role, content });
  }

  processMessageContent(content) {
    // Process code blocks
    content = content.replace(/```(\w+)?\n([\s\S]*?)```/g, (match, language, code) => {
      return `<pre class="visa-chat-code" ${language ? `data-language="${language}"` : ''}>${this.escapeHtml(code)}</pre>`;
    });

    // Process mermaid diagrams
    content = content.replace(/```mermaid\n([\s\S]*?)```/g, (match, diagram) => {
      return `<div class="visa-chat-mermaid">${diagram}</div>`;
    });

    // Convert URLs to links
    content = content.replace(/https?:\/\/\S+/g, (url) => {
      return `<a href="${url}" target="_blank">${url}</a>`;
    });

    // Convert line breaks
    content = content.replace(/\n/g, '<br>');

    return content;
  }

  escapeHtml(unsafe) {
    return unsafe
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  showTypingIndicator() {
    const typingEl = document.createElement('div');
    typingEl.classList.add('visa-chat-typing');
    typingEl.innerHTML = `
      <div class="typing-dots">
        <span></span><span></span><span></span>
      </div>
    `;
    typingEl.id = 'typing-indicator';
    this.chatBody.appendChild(typingEl);
    this.scrollToBottom();
  }

  hideTypingIndicator() {
    const typingEl = document.getElementById('typing-indicator');
    if (typingEl) {
      typingEl.remove();
    }
  }

  scrollToBottom() {
    this.chatBody.scrollTop = this.chatBody.scrollHeight;
  }

  triggerEvent(name, data) {
    const event = new CustomEvent(`visa-chat-${name}`, { detail: data });
    this.container.dispatchEvent(event);
  }

  on(eventName, callback) {
    this.container.addEventListener(`visa-chat-${eventName}`, (event) => {
      callback(event.detail);
    });
  }

  // Public methods for external control
  getSessionId() {
    return this.sessionId;
  }

  setSessionId(sessionId) {
    this.sessionId = sessionId;
    this.loadSessionHistory();
  }

  clearChat() {
    this.messages = [];
    this.chatBody.innerHTML = '';
  }

  minimize() {
    this.container.classList.add('minimized');
    this.minimizeBtn.textContent = '+';
  }

  maximize() {
    this.container.classList.remove('minimized');
    this.minimizeBtn.textContent = '−';
  }
}

// Automatically load mermaid if not already loaded
if (!window.mermaid) {
  const script = document.createElement('script');
  script.src = 'https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js';
  script.onload = () => {
    window.mermaid.initialize({ startOnLoad: true });
  };
  document.head.appendChild(script);
}