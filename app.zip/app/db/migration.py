# db/migration.py
# Migration script to add app_id column to sessions table

import sqlite3
import os
import logging

logger = logging.getLogger(__name__)

# Path to the SQLite database
DB_PATH = './app/data/sessions.db'

def check_column_exists(cursor, table, column):
    """Check if a column exists in a table."""
    cursor.execute(f"PRAGMA table_info({table})")
    columns = cursor.fetchall()
    return any(col[1] == column for col in columns)

def add_app_id_column():
    """Add app_id column to sessions table if it doesn't exist."""
    # Ensure the data directory exists
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    
    # Check if the database file exists
    if not os.path.exists(DB_PATH):
        logger.warning(f"Database file {DB_PATH} does not exist. No migration needed.")
        return
    
    try:
        # Connect to the database
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        # Check if app_id column already exists
        if not check_column_exists(cursor, 'sessions', 'app_id'):
            # Add the app_id column
            cursor.execute("ALTER TABLE sessions ADD COLUMN app_id TEXT")
            
            # Update existing rows with a default value if needed
            cursor.execute("UPDATE sessions SET app_id = 'default_app' WHERE app_id IS NULL")
            
            # Commit the changes
            conn.commit()
            logger.info("Successfully added app_id column to sessions table")
        else:
            logger.info("app_id column already exists in sessions table")
        
        # Close the connection
        conn.close()
        
    except sqlite3.Error as e:
        logger.error(f"SQLite error: {e}")
    except Exception as e:
        logger.error(f"Error during migration: {e}")

def check_table_exists(cursor, table):
    """Check if a table exists in the database."""
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table,))
    return cursor.fetchone() is not None

def create_metrics_tables():
    """Create tables for metrics collection to support graph visualization."""
    # Ensure the data directory exists
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    
    try:
        # Connect to the database
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        # Create agent_metrics table if it doesn't exist
        if not check_table_exists(cursor, 'agent_metrics'):
            cursor.execute("""
            CREATE TABLE agent_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                agent_id TEXT NOT NULL,
                success INTEGER NOT NULL,
                response_time REAL NOT NULL,
                timestamp TEXT NOT NULL
            )
            """)
            logger.info("Created agent_metrics table")
            
            # Create indices for faster queries
            cursor.execute("CREATE INDEX idx_agent_metrics_agent_id ON agent_metrics(agent_id)")
            cursor.execute("CREATE INDEX idx_agent_metrics_timestamp ON agent_metrics(timestamp)")
        
        # Create tool_metrics table if it doesn't exist
        if not check_table_exists(cursor, 'tool_metrics'):
            cursor.execute("""
            CREATE TABLE tool_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tool_id TEXT NOT NULL,
                agent_id TEXT NOT NULL,
                success INTEGER NOT NULL,
                processing_time REAL NOT NULL,
                timestamp TEXT NOT NULL
            )
            """)
            logger.info("Created tool_metrics table")
            
            # Create indices for faster queries
            cursor.execute("CREATE INDEX idx_tool_metrics_tool_id ON tool_metrics(tool_id)")
            cursor.execute("CREATE INDEX idx_tool_metrics_agent_id ON tool_metrics(agent_id)")
            cursor.execute("CREATE INDEX idx_tool_metrics_timestamp ON tool_metrics(timestamp)")
        
        # Commit the changes
        conn.commit()
        conn.close()
        
    except sqlite3.Error as e:
        logger.error(f"SQLite error: {e}")
    except Exception as e:
        logger.error(f"Error creating metrics tables: {e}")

if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Run the migrations
    add_app_id_column()
    create_metrics_tables()
    print("Migration completed") 