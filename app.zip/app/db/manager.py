# db/manager.py
import hashlib
import os
import json
import logging
import secrets
import uuid
from typing import Dict, List, Any, Optional
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.ext.asyncio import async_sessionmaker
from sqlalchemy.future import select
from app.db.models import Base, SessionModel, MessageModel, AppApiKeyModel
from app.api.models.chat import ChatMessage
import datetime
logger = logging.getLogger(__name__)


class DatabaseManager:
    """Database manager for session and message persistence."""

    def __init__(self, db_url="sqlite+aiosqlite:///./app/data/sessions.db"):
        """
        Initialize the database manager.

        Args:
            db_url: SQLAlchemy database URL
        """
        self.db_url = db_url
        # Extract file path from SQLite URL for directory creation
        if db_url.startswith('sqlite'):
            db_path = db_url.split(':///')[-1]
            # Ensure directory exists
            os.makedirs(os.path.dirname(db_path), exist_ok=True)

        # Initialize engine and session factory
        self.engine = create_async_engine(db_url)
        self.async_session_factory = async_sessionmaker(
            self.engine, expire_on_commit=False, class_=AsyncSession
        )

    async def initialize(self):
        """Initialize the database."""
        async with self.engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        logger.info("Database initialized")

    async def create_session(self, session_id: str, agent_type: str,
                             created_at: str, last_activity: str,
                             app_id: str = None, meta_data: Optional[Dict] = None):
        """Create a new session in the database."""
        try:
            async with self.async_session_factory() as session:
                session_model = SessionModel(
                    session_id=session_id,
                    agent_type=agent_type,
                    app_id=app_id,  # Added app_id
                    created_at=created_at,
                    last_activity=last_activity,
                    meta_data=json.dumps(meta_data) if meta_data else None
                )
                session.add(session_model)
                await session.commit()
                logger.debug(f"Created session {session_id} for app {app_id} in database")
        except Exception as e:
            logger.error(f"Error creating session in database: {e}", exc_info=True)

    async def update_session(self, session_id: str, last_activity: str,
                             app_id: str = None, state_data: Optional[Dict] = None):
        """Update a session in the database."""
        try:
            async with self.async_session_factory() as session:
                result = await session.execute(
                    select(SessionModel).where(SessionModel.session_id == session_id)
                )
                session_model = result.scalar_one_or_none()
                if session_model:
                    session_model.last_activity = last_activity
                    if app_id is not None:  # Added app_id update
                        session_model.app_id = app_id
                    if state_data is not None:
                        session_model.state_data = json.dumps(state_data)
                    await session.commit()
                    logger.debug(f"Updated session {session_id} in database")
                else:
                    logger.warning(f"Session {session_id} not found for update")
        except Exception as e:
            logger.error(f"Error updating session: {e}", exc_info=True)

    async def add_message(self, message_id: str, session_id: str, role: str,
                          content: str, timestamp: str):
        """Add a message to the database."""
        try:
            async with self.async_session_factory() as session:
                # Check if message already exists
                result = await session.execute(
                    select(MessageModel).where(MessageModel.message_id == message_id)
                )
                if result.scalar_one_or_none():
                    logger.debug(f"Message {message_id} already exists, skipping")
                    return

                message = MessageModel(
                    message_id=message_id,
                    session_id=session_id,
                    role=role,
                    content=content,
                    timestamp=timestamp
                )
                session.add(message)
                await session.commit()
        except Exception as e:
            logger.error(f"Error adding message: {e}", exc_info=True)

    async def get_session(self, session_id: str) -> Optional[Dict]:
        """Get session from database."""
        try:
            async with self.async_session_factory() as session:
                result = await session.execute(
                    select(SessionModel).where(SessionModel.session_id == session_id)
                )
                session_model = result.scalar_one_or_none()
                if not session_model:
                    return None

                return {
                    "session_id": session_model.session_id,
                    "agent_type": session_model.agent_type,
                    "app_id": session_model.app_id,  # Added app_id to response
                    "created_at": session_model.created_at,
                    "last_activity": session_model.last_activity,
                    "state_data": json.loads(session_model.state_data) if session_model.state_data else None,
                    "meta_data": json.loads(session_model.meta_data) if session_model.meta_data else None
                }
        except Exception as e:
            logger.error(f"Error getting session: {e}", exc_info=True)
            return None

    async def get_messages(self, session_id: str) -> List[ChatMessage]:
        """Get messages for a session."""
        messages = []
        try:
            async with self.async_session_factory() as session:
                result = await session.execute(
                    select(MessageModel)
                    .where(MessageModel.session_id == session_id)
                    .order_by(MessageModel.timestamp)
                )
                for message_model in result.scalars():
                    messages.append(ChatMessage(
                        role=message_model.role,
                        content=message_model.content,
                        timestamp=message_model.timestamp
                    ))
        except Exception as e:
            logger.error(f"Error getting messages: {e}", exc_info=True)
        return messages

    async def delete_session(self, session_id: str) -> bool:
        """Delete a session and its messages."""
        try:
            async with self.async_session_factory() as session:
                # Delete messages first
                await session.execute(
                    select(MessageModel).where(MessageModel.session_id == session_id)
                )
                message_result = await session.execute(
                    select(MessageModel).where(MessageModel.session_id == session_id)
                )
                for message in message_result.scalars():
                    await session.delete(message)

                # Then delete session
                session_result = await session.execute(
                    select(SessionModel).where(SessionModel.session_id == session_id)
                )
                session_model = session_result.scalar_one_or_none()
                if session_model:
                    await session.delete(session_model)
                    await session.commit()
                    logger.info(f"Deleted session {session_id} from database")
                    return True
        except Exception as e:
            logger.error(f"Error deleting session: {e}", exc_info=True)
        return False

    async def get_sessions_before_date(self, date_str: str) -> List[Dict[str, Any]]:
        """
        Get all sessions created before a specific date.

        Args:
            date_str: ISO formatted date string

        Returns:
            List of session dictionaries
        """
        sessions = []
        try:
            async with self.async_session_factory() as session:
                result = await session.execute(
                    select(SessionModel)
                    .where(SessionModel.created_at < date_str)
                    .order_by(SessionModel.created_at)
                )
                for session_model in result.scalars():
                    sessions.append({
                        "session_id": session_model.session_id,
                        "agent_type": session_model.agent_type,
                        "app_id": session_model.app_id,  # Added app_id to response
                        "created_at": session_model.created_at,
                        "last_activity": session_model.last_activity,
                    })
        except Exception as e:
            logger.error(f"Error getting sessions before date {date_str}: {e}", exc_info=True)
        return sessions

    async def get_sessions(self, limit: int = 10, offset: int = 0,
                           sort_by: str = "last_activity", ascending: bool = False) -> List[Dict[str, Any]]:
        """
        Get sessions with pagination and sorting.

        Args:
            limit: Maximum number of sessions to return
            offset: Number of sessions to skip
            sort_by: Field to sort by
            ascending: Sort in ascending order if True, descending if False

        Returns:
            List of session dictionaries
        """
        sessions = []
        try:
            async with self.async_session_factory() as session:
                # Determine sort order
                if sort_by == "last_activity":
                    order_column = SessionModel.last_activity
                elif sort_by == "created_at":
                    order_column = SessionModel.created_at
                else:
                    order_column = SessionModel.last_activity

                # Apply sorting direction
                if ascending:
                    order_clause = order_column.asc()
                else:
                    order_clause = order_column.desc()

                # Execute query with pagination
                result = await session.execute(
                    select(SessionModel)
                    .order_by(order_clause)
                    .limit(limit)
                    .offset(offset)
                )

                for session_model in result.scalars():
                    sessions.append({
                        "session_id": session_model.session_id,
                        "agent_type": session_model.agent_type,
                        "app_id": session_model.app_id,  # Added app_id to response
                        "created_at": session_model.created_at,
                        "last_activity": session_model.last_activity,
                    })
        except Exception as e:
            logger.error(f"Error getting sessions: {e}", exc_info=True)
        return sessions

    async def get_app_sessions(self, app_id: str, limit: int = 10, offset: int = 0,
                               sort_by: str = "last_activity", ascending: bool = False) -> List[Dict[str, Any]]:
        """
        Get sessions for a specific application.

        Args:
            app_id: Application identifier
            limit: Maximum number of sessions to return
            offset: Number of sessions to skip
            sort_by: Field to sort by
            ascending: Sort in ascending order if True, descending if False

        Returns:
            List of session dictionaries
        """
        sessions = []
        try:
            async with self.async_session_factory() as session:
                # Determine sort order
                if sort_by == "last_activity":
                    order_column = SessionModel.last_activity
                elif sort_by == "created_at":
                    order_column = SessionModel.created_at
                else:
                    order_column = SessionModel.last_activity

                # Apply sorting direction
                if ascending:
                    order_clause = order_column.asc()
                else:
                    order_clause = order_column.desc()

                # Execute query with app_id filter and pagination
                result = await session.execute(
                    select(SessionModel)
                    .where(SessionModel.app_id == app_id)
                    .order_by(order_clause)
                    .limit(limit)
                    .offset(offset)
                )

                for session_model in result.scalars():
                    sessions.append({
                        "session_id": session_model.session_id,
                        "agent_type": session_model.agent_type,
                        "app_id": session_model.app_id,
                        "created_at": session_model.created_at,
                        "last_activity": session_model.last_activity,
                    })
        except Exception as e:
            logger.error(f"Error getting app sessions: {e}", exc_info=True)
        return sessions

    async def get_message_count(self, session_id: str) -> int:
        """
        Get count of messages for a specific session.

        Args:
            session_id: Session identifier

        Returns:
            Number of messages
        """
        try:
            async with self.async_session_factory() as session:
                from sqlalchemy import func
                result = await session.execute(
                    select(func.count())
                    .select_from(MessageModel)
                    .where(MessageModel.session_id == session_id)
                )
                return result.scalar_one() or 0
        except Exception as e:
            logger.error(f"Error getting message count: {e}", exc_info=True)
            return 0

    async def delete_session_messages(self, session_id: str) -> bool:
        """
        Delete all messages for a specific session.

        Args:
            session_id: Session identifier

        Returns:
            True if deletion was successful
        """
        try:
            async with self.async_session_factory() as session:
                from sqlalchemy import delete
                delete_stmt = delete(MessageModel).where(MessageModel.session_id == session_id)
                await session.execute(delete_stmt)
                await session.commit()
                logger.info(f"Deleted all messages for session {session_id}")
                return True
        except Exception as e:
            logger.error(f"Error deleting session messages: {e}", exc_info=True)
            return False

    async def message_exists(self, message_id: str) -> bool:
        """
        Check if a message exists in the database.

        Args:
            message_id: Message identifier

        Returns:
            True if message exists
        """
        try:
            async with self.async_session_factory() as session:
                result = await session.execute(
                    select(MessageModel).where(MessageModel.message_id == message_id)
                )
                return result.scalar_one_or_none() is not None
        except Exception as e:
            logger.error(f"Error checking if message exists: {e}", exc_info=True)
            return False

    async def create_api_key(self, app_id: str, app_name: str, description: str = None,
                             expires_in_days: int = None, rate_limit: int = 100) -> dict:
        """
        Create a new API key for an application.

        Args:
            app_id: Application identifier
            app_name: Human-readable application name
            description: Optional description
            expires_in_days: Optional expiration period in days
            rate_limit: Requests per minute allowed

        Returns:
            Dictionary containing the API key info (including clear-text key)
        """
        try:
            # Generate a random API key
            api_key = f"sk_{secrets.token_hex(24)}"
            # Hash the API key for storage
            hashed_key = hashlib.sha256(api_key.encode()).hexdigest()

            # Set expiration date if specified
            expires_at = None
            if expires_in_days:
                expires_at = datetime.datetime.utcnow() + datetime.timedelta(days=expires_in_days)

            # Create a UUID for the record
            key_id = str(uuid.uuid4())

            async with self.async_session_factory() as session:
                # Create API key record
                api_key_model = AppApiKeyModel(
                    id=key_id,
                    app_id=app_id,
                    api_key=hashed_key,
                    app_name=app_name,
                    description=description,
                    is_active=True,
                    created_at=datetime.datetime.utcnow(),
                    expires_at=expires_at,
                    rate_limit=rate_limit
                )

                session.add(api_key_model)
                await session.commit()

                # Return the record with the clear-text API key (only time it's available)
                return {
                    "id": key_id,
                    "app_id": app_id,
                    "api_key": api_key,  # Clear-text key, only returned once
                    "app_name": app_name,
                    "description": description,
                    "is_active": True,
                    "created_at": api_key_model.created_at.isoformat(),
                    "expires_at": api_key_model.expires_at.isoformat() if api_key_model.expires_at else None,
                    "rate_limit": rate_limit
                }
        except Exception as e:
            logger.error(f"Error creating API key: {e}", exc_info=True)
            raise

    async def validate_api_key(self, api_key: str) -> Optional[dict]:
        """
        Validate an API key and return the associated application info.

        Args:
            api_key: The API key to validate

        Returns:
            Application info if valid, None otherwise
        """
        try:
            # Hash the provided API key
            hashed_key = hashlib.sha256(api_key.encode()).hexdigest()

            async with self.async_session_factory() as session:
                # Find the API key record
                result = await session.execute(
                    select(AppApiKeyModel)
                    .where(AppApiKeyModel.api_key == hashed_key)
                    .where(AppApiKeyModel.is_active == True)
                )

                key_model = result.scalar_one_or_none()
                if not key_model:
                    return None

                # Check if key has expired
                if key_model.expires_at and key_model.expires_at < datetime.datetime.utcnow():
                    return None

                # Update last used timestamp
                key_model.last_used_at = datetime.datetime.utcnow()
                await session.commit()

                # Return application info
                return {
                    "app_id": key_model.app_id,
                    "app_name": key_model.app_name,
                    "rate_limit": key_model.rate_limit
                }
        except Exception as e:
            logger.error(f"Error validating API key: {e}", exc_info=True)
            return None

    async def deactivate_api_key(self, key_id: str) -> bool:
        """
        Deactivate an API key.

        Args:
            key_id: The ID of the API key record

        Returns:
            True if successful, False otherwise
        """
        try:
            async with self.async_session_factory() as session:
                result = await session.execute(
                    select(AppApiKeyModel).where(AppApiKeyModel.id == key_id)
                )

                key_model = result.scalar_one_or_none()
                if not key_model:
                    return False

                key_model.is_active = False
                await session.commit()
                return True
        except Exception as e:
            logger.error(f"Error deactivating API key: {e}", exc_info=True)
            return False

    async def get_app_api_keys(self, app_id: str) -> List[dict]:
        """
        Get all API keys for an application.

        Args:
            app_id: Application identifier

        Returns:
            List of API key records (without the hashed key)
        """
        keys = []
        try:
            async with self.async_session_factory() as session:
                result = await session.execute(
                    select(AppApiKeyModel)
                    .where(AppApiKeyModel.app_id == app_id)
                    .order_by(AppApiKeyModel.created_at.desc())
                )

                for key_model in result.scalars():
                    keys.append({
                        "id": key_model.id,
                        "app_id": key_model.app_id,
                        "app_name": key_model.app_name,
                        "description": key_model.description,
                        "is_active": key_model.is_active,
                        "created_at": key_model.created_at.isoformat(),
                        "last_used_at": key_model.last_used_at.isoformat() if key_model.last_used_at else None,
                        "expires_at": key_model.expires_at.isoformat() if key_model.expires_at else None,
                        "rate_limit": key_model.rate_limit
                    })

            return keys
        except Exception as e:
            logger.error(f"Error getting app API keys: {e}", exc_info=True)
            return []

    async def check_app_id_exists(self, app_id: str) -> bool:
        """
        Check if an application ID exists in the database.

        Args:
            app_id: Application identifier to check

        Returns:
            True if the application exists, False otherwise
        """
        try:
            async with self.async_session_factory() as session:
                # Query the app_api_keys table to see if there are any keys for this app_id
                from sqlalchemy import func
                result = await session.execute(
                    select(func.count())
                    .select_from(AppApiKeyModel)
                    .where(AppApiKeyModel.app_id == app_id)
                )
                count = result.scalar_one() or 0
                return count > 0
        except Exception as e:
            logger.error(f"Error checking if app_id exists: {e}", exc_info=True)
            return False