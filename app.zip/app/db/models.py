# db/models.py
# Update to SessionModel class to include app_id column

from sqlalchemy import  Integer
from sqlalchemy.orm import declarative_base, relationship
from sqlalchemy import Column, String, Text, ForeignKey, Index, Boolean, DateTime
import datetime
Base = declarative_base()


class SessionModel(Base):
    """Model for chat sessions."""
    __tablename__ = "sessions"

    session_id = Column(String, primary_key=True)
    agent_type = Column(String, nullable=False)
    app_id = Column(String, nullable=True)  # Added app_id column
    created_at = Column(String, nullable=False)
    last_activity = Column(String, nullable=False)
    state_data = Column(Text, nullable=True)
    meta_data = Column(Text, nullable=True)

    # Add index for app_id to improve query performance
    __table_args__ = (
        Index('idx_app_id', 'app_id'),
        Index('idx_last_activity', 'last_activity'),
    )

    # Relationship with messages
    messages = relationship("MessageModel", back_populates="session", cascade="all, delete-orphan")


class MessageModel(Base):
    """Model for chat messages."""
    __tablename__ = "messages"

    message_id = Column(String, primary_key=True)
    session_id = Column(String, ForeignKey("sessions.session_id", ondelete="CASCADE"), nullable=False)
    role = Column(String, nullable=False)
    content = Column(Text, nullable=False)
    timestamp = Column(String, nullable=False)

    # Add index for session_id and timestamp
    __table_args__ = (
        Index('idx_session_id', 'session_id'),
        Index('idx_timestamp', 'timestamp'),
    )

    # Relationship with session
    session = relationship("SessionModel", back_populates="messages")


class AppApiKeyModel(Base):
    """Model for application API keys."""
    __tablename__ = "app_api_keys"

    id = Column(String, primary_key=True)  # UUID for the key record
    app_id = Column(String, nullable=False, index=True)  # Application identifier
    api_key = Column(String, nullable=False, unique=True)  # Hashed API key
    app_name = Column(String, nullable=False)  # Human-readable application name
    description = Column(Text, nullable=True)  # Optional description
    is_active = Column(Boolean, default=True)  # Whether this key is active
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    last_used_at = Column(DateTime, nullable=True)  # Track last usage
    expires_at = Column(DateTime, nullable=True)  # Optional expiration date
    rate_limit = Column(Integer, default=100)  # Requests per minute allowed

    # Add indexes for performance
    __table_args__ = (
        Index('idx_app_id', 'app_id'),
        Index('idx_api_key', 'api_key'),
        Index('idx_is_active', 'is_active'),
    )