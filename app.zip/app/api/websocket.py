"""
WebSocket module for sending real-time updates about agent and tool graphs to the frontend.
"""

import asyncio
import json
import logging
from typing import Dict, List, Set, Any, Optional
from fastapi import WebSocket, WebSocketDisconnect
from app.utils.logging import get_logger

logger = get_logger(__name__)

class GraphUpdateManager:
    """
    Manages WebSocket connections and broadcasts updates about agent and tool graphs.
    Implements a simple pub/sub pattern.
    """
    
    def __init__(self):
        self.active_connections: Set[WebSocket] = set()
        self.connection_ids: Dict[WebSocket, str] = {}
        self._lock = asyncio.Lock()
    
    async def connect(self, websocket: WebSocket, client_id: str):
        """
        Connect a new WebSocket client
        """
        await websocket.accept()
        async with self._lock:
            self.active_connections.add(websocket)
            self.connection_ids[websocket] = client_id
            logger.info(f"WebSocket client connected: {client_id}. Total connections: {len(self.active_connections)}")
        
        # Send a welcome message
        await websocket.send_json({
            "type": "connection_status",
            "status": "connected",
            "message": f"Connected to graph update service. Client ID: {client_id}"
        })
    
    async def disconnect(self, websocket: WebSocket):
        """
        Disconnect a WebSocket client
        """
        async with self._lock:
            if websocket in self.active_connections:
                client_id = self.connection_ids.get(websocket, "unknown")
                self.active_connections.remove(websocket)
                if websocket in self.connection_ids:
                    del self.connection_ids[websocket]
                logger.info(f"WebSocket client disconnected: {client_id}. Remaining connections: {len(self.active_connections)}")
    
    async def broadcast_agent_graph_update(self, graph_data: Dict[str, Any]):
        """
        Broadcast agent graph updates to all connected clients
        """
        if not self.active_connections:
            logger.debug("No active connections, skipping agent graph broadcast")
            return
        
        message = {
            "type": "agent_graph_update",
            "timestamp": asyncio.get_event_loop().time(),
            "data": graph_data
        }
        
        await self._broadcast(message)
    
    async def broadcast_tool_graph_update(self, graph_data: Dict[str, Any]):
        """
        Broadcast tool graph updates to all connected clients
        """
        if not self.active_connections:
            logger.debug("No active connections, skipping tool graph broadcast")
            return
        
        message = {
            "type": "tool_graph_update",
            "timestamp": asyncio.get_event_loop().time(),
            "data": graph_data
        }
        
        await self._broadcast(message)
    
    async def broadcast_metric_update(self, metric_type: str, metric_data: Dict[str, Any]):
        """
        Broadcast metric updates to all connected clients
        """
        if not self.active_connections:
            logger.debug(f"No active connections, skipping {metric_type} metric broadcast")
            return
        
        message = {
            "type": "metric_update",
            "metric_type": metric_type,
            "timestamp": asyncio.get_event_loop().time(),
            "data": metric_data
        }
        
        await self._broadcast(message)
    
    async def _broadcast(self, message: Dict[str, Any]):
        """
        Internal method to broadcast a message to all connections
        """
        disconnected_clients = set()
        
        for websocket in self.active_connections:
            try:
                await websocket.send_json(message)
            except Exception as e:
                logger.error(f"Error sending WebSocket message: {str(e)}")
                disconnected_clients.add(websocket)
        
        # Clean up any disconnected clients
        if disconnected_clients:
            async with self._lock:
                for websocket in disconnected_clients:
                    await self.disconnect(websocket)

# Singleton instance
_graph_update_manager: Optional[GraphUpdateManager] = None

def get_graph_update_manager() -> GraphUpdateManager:
    """
    Get the singleton instance of the GraphUpdateManager
    """
    global _graph_update_manager
    if _graph_update_manager is None:
        _graph_update_manager = GraphUpdateManager()
    return _graph_update_manager 