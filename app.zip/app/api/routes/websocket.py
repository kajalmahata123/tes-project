"""
WebSocket routes for real-time updates.
"""

import uuid
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends, Query
from app.api.websocket import get_graph_update_manager
from app.dependencies import verify_api_key_ws
from app.utils.logging import get_logger
from typing import Dict, List, Any
import logging
import asyncio

logger = logging.getLogger(__name__)
router = APIRouter(tags=["websocket"])

# WebSocket connection manager
class ConnectionManager:
    def __init__(self):
        self.active_connections: Dict[str, List[WebSocket]] = {}

    async def connect(self, websocket: WebSocket, client_id: str):
        await websocket.accept()
        if client_id not in self.active_connections:
            self.active_connections[client_id] = []
        self.active_connections[client_id].append(websocket)
        logger.info(f"WebSocket client connected: {client_id}. Total connections: {self.total_connections()}")

    def disconnect(self, websocket: WebSocket, client_id: str):
        if client_id in self.active_connections:
            if websocket in self.active_connections[client_id]:
                self.active_connections[client_id].remove(websocket)
            if not self.active_connections[client_id]:
                del self.active_connections[client_id]
        logger.info(f"WebSocket client disconnected: {client_id}. Remaining connections: {self.total_connections()}")

    def total_connections(self) -> int:
        return sum(len(connections) for connections in self.active_connections.values())

    async def broadcast(self, message: Dict[str, Any]):
        for client_connections in self.active_connections.values():
            for connection in client_connections:
                try:
                    await connection.send_json(message)
                except Exception as e:
                    logger.error(f"Error sending message to WebSocket: {e}")

manager = ConnectionManager()

@router.websocket("/graph-updates")
async def websocket_graph_updates(
    websocket: WebSocket,
    client_id: str,
    auth: dict = Depends(verify_api_key_ws)
):
    """
    WebSocket endpoint for real-time graph updates.
    Requires API key and app_id for authentication.
    """
    await manager.connect(websocket, client_id)
    try:
        while True:
            # Keep connection alive
            await websocket.receive_text()
            
    except WebSocketDisconnect:
        manager.disconnect(websocket, client_id)
    except Exception as e:
        logger.error(f"Error in WebSocket connection: {e}", exc_info=True)
        manager.disconnect(websocket, client_id) 