from fastapi import APIRouter, Depends
from typing import Dict, List
import logging
import time
from app.dependencies import verify_api_key, get_agent_factory
from app.core.agent_factory import AgentFactory
from fastapi.responses import JSONResponse

router = APIRouter()
logger = logging.getLogger(__name__)

start_time = time.time()
request_stats = {
    "status": "idle",
    "lastRequest": None,
    "requestCount": 0,
    "activeRequests": [],
    "errors": []
}


@router.get("")
async def health_check() -> Dict[str, str]:
    """
    Simple health check endpoint.
    Returns status OK if the API is running.
    """
    return {"status": "OK"}


@router.get("/info")
async def health_info() -> Dict[str, str]:
    """
    Extended health check with system information.
    """
    uptime = time.time() - start_time

    return {
        "status": "OK",
        "uptime": f"{uptime:.2f} seconds"
    }


@router.get("/requests")
async def get_request_status(auth: Dict = Depends(verify_api_key)) -> Dict:
    """
    Get the current request status information.
    Requires API key authentication.
    """
    return request_stats


@router.get("/agents")
async def get_agent_status(
    auth: Dict = Depends(verify_api_key),
    agent_factory: AgentFactory = Depends(get_agent_factory)
) -> JSONResponse:
    """
    Get status information about all registered agents.
    Returns JSON data about available agents and their current status.
    """
    try:
        # Get list of available agents
        available_agents = agent_factory.available_agents()
        
        # Create response data
        agent_status = {
            "total_agents": len(available_agents),
            "agents": [
                {
                    "type": agent_type,
                    "status": "active",
                    "capabilities": ["chat", "task_execution"],
                } for agent_type in available_agents
            ],
            "timestamp": time.time()
        }
        
        return JSONResponse(content=agent_status)
        
    except Exception as e:
        logger.error(f"Error getting agent status: {e}", exc_info=True)
        return JSONResponse(
            content={
                "error": "Failed to get agent status",
                "detail": str(e)
            },
            status_code=500
        )