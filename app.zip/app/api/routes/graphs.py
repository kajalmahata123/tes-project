"""
API routes for graph visualization features.
These endpoints provide data for agent and tool graphs.
"""

from fastapi import APIRouter, Depends, HTTPException, WebSocket, WebSocketDisconnect
from typing import Dict, List, Any, Optional
import logging
import asyncio

from app.dependencies import verify_api_key
from app.services.graph_service import GraphService
from app.schemas.graph_schemas import (
    AgentGraphResponse, 
    ToolGraphResponse, 
    AgentDetailResponse, 
    ToolDetailResponse
)

logger = logging.getLogger(__name__)

router = APIRouter(tags=["graphs"])
graph_service = GraphService()


@router.get("/agents/graph", response_model=AgentGraphResponse)
async def get_agent_graph(api_key: str = Depends(verify_api_key)):
    """
    Returns a complete agent graph structure optimized for React visualization.
    This includes nodes, edges, and all metadata needed for the frontend.
    """
    try:
        return await graph_service.generate_agent_graph()
    except Exception as e:
        logger.error(f"Failed to generate agent graph: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to generate agent graph: {str(e)}")


@router.get("/tools/graph", response_model=ToolGraphResponse)
async def get_tool_graph(api_key: str = Depends(verify_api_key)):
    """
    Returns a complete tool ecosystem graph with relationships and metrics.
    """
    try:
        return await graph_service.generate_tool_graph()
    except Exception as e:
        logger.error(f"Failed to generate tool graph: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to generate tool graph: {str(e)}")


@router.get("/agents/{agent_id}", response_model=AgentDetailResponse)
async def get_agent_details(agent_id: str, api_key: str = Depends(verify_api_key)):
    """
    Returns detailed information about a specific agent.
    """
    agent = await graph_service.get_agent_details(agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail=f"Agent {agent_id} not found")
    return agent


@router.get("/tools/{tool_id}", response_model=ToolDetailResponse)
async def get_tool_details(tool_id: str, api_key: str = Depends(verify_api_key)):
    """
    Returns detailed information about a specific tool.
    """
    tool = await graph_service.get_tool_details(tool_id)
    if not tool:
        raise HTTPException(status_code=404, detail=f"Tool {tool_id} not found")
    return tool


# WebSocket connection manager for live updates
class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)
        logger.info(f"WebSocket client connected. Active connections: {len(self.active_connections)}")

    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)
        logger.info(f"WebSocket client disconnected. Remaining connections: {len(self.active_connections)}")

    async def broadcast(self, message: Dict[str, Any]):
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
            except Exception as e:
                logger.error(f"Error sending message to WebSocket: {e}")


manager = ConnectionManager()


@router.websocket("/ws/live-updates")
async def websocket_graph_updates(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        # Send initial data
        agent_graph = await graph_service.generate_agent_graph()
        await websocket.send_json({
            "type": "INITIAL_AGENT_GRAPH",
            "payload": agent_graph
        })
        
        tool_graph = await graph_service.generate_tool_graph()
        await websocket.send_json({
            "type": "INITIAL_TOOL_GRAPH",
            "payload": tool_graph
        })
        
        # Keep connection alive and send updates
        while True:
            await asyncio.sleep(10)
            # In a real implementation, you would send updates based on system events
            # This is just a placeholder for demonstration
            
    except WebSocketDisconnect:
        manager.disconnect(websocket)
    except Exception as e:
        logger.error(f"Error in WebSocket connection: {e}", exc_info=True)
        manager.disconnect(websocket) 