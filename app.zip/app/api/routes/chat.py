from fastapi import APIRouter, Depends, HTTPException, Query, BackgroundTasks
import logging
import uuid
from langchain_anthropic import ChatAnthropic
from app.dependencies import get_agent_factory, get_app_id, verify_api_key_and_app_id
from app.core.agent_factory import AgentFactory
from app.core.session_manager import SessionManager
from app.api.models.chat import (
    ChatRequest,
    ChatResponse,
    SessionInfo,
    SessionListResponse,
    AgentListResponse
)
from app.config import get_settings

logger = logging.getLogger(__name__)

router = APIRouter()


# Get session manager as a dependency
def get_session_manager():
    return SessionManager.get_instance()


async def select_agent_with_claude(message: str, api_key: str) -> str:
    """
    Use Claude to determine the most appropriate agent type based on message content.

    Args:
        message: User's message
        api_key: Claude API key

    Returns:
        Selected agent type
    """
    try:
        # Initialize Claude Sonnet
        claude = ChatAnthropic(
            anthropic_api_key=api_key,
            model="claude-3-5-sonnet-20240620",
            temperature=0  # Use deterministic responses for consistent selection
        )

        # Create the prompt
        prompt = f"""Analyze this user request and determine which specialized agent should handle it.
Choose exactly one option from: "visa_api_agent", "code_generator", or "workflow_creator".

User request: {message}

Guidelines:
- "code_generator" for requests about writing code, implementations, or programming examples in any language
- "workflow_creator" for requests about steps, processes, or implementation guides
- "visa_api_agent" for general API questions, concepts, or documentation

Return only the agent type, nothing else."""

        # Get Claude's response
        response = await claude.ainvoke([{"role": "user", "content": prompt}])
        agent_type = response.content.strip().lower()

        # Validate and sanitize the response
        valid_agents = ["visa_api_agent", "code_generator", "workflow_creator"]
        if agent_type in valid_agents:
            return agent_type
        else:
            # Try to extract a valid agent from the response
            for agent in valid_agents:
                if agent in agent_type:
                    logger.info(f"Extracted agent type '{agent}' from Claude response: '{agent_type}'")
                    return agent

            logger.warning(f"Claude returned invalid agent type: '{agent_type}', using default")
            return "visa_api_agent"

    except Exception as e:
        logger.error(f"Error selecting agent with Claude: {e}", exc_info=True)
        return "visa_api_agent"  # Default to general agent on error


@router.post("/message", response_model=ChatResponse)
async def chat_message(
        request: ChatRequest,
        background_tasks: BackgroundTasks,
        app_id: str = Depends(get_app_id),
        agent_factory: AgentFactory = Depends(get_agent_factory),
        session_manager: SessionManager = Depends(get_session_manager)
):
    """
    Process a chat message and return a response.
    """
    try:
        # Get or create session
        session_id = request.session_id or str(uuid.uuid4())

        # Auto-select agent type if not provided
        if request.agent_type is None:
            settings = get_settings()
            agent_type = await select_agent_with_claude(
                request.message,
                settings.CLAUDE_API_KEY
            )
            logger.info(f"Claude auto-selected agent type: {agent_type} for message: {request.message[:50]}...")
        else:
            agent_type = request.agent_type or get_settings().DEFAULT_AGENT

        # Get session (creates if not exists) with app_id
        session = await session_manager.get_session(
            session_id=session_id,
            agent_type=agent_type,
            agent_factory=agent_factory,
            app_id=app_id  # Pass the app_id
        )

        # Process message
        response = await session.process_message(request.message)

        # Add background task to save session state
        background_tasks.add_task(
            session_manager.save_session_state,
            session_id=session_id
        )

        return ChatResponse(
            message_id=str(uuid.uuid4()),
            session_id=session_id,
            response=response,
            agent_type=agent_type,
            app_id=app_id  # Include app_id in response
        )

    except ValueError as e:
        logger.error(f"Value error in chat: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error processing chat message: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="An error occurred processing your message")


@router.get("/sessions", response_model=SessionListResponse)
async def list_sessions(
        limit: int = Query(10, ge=1, le=100),
        offset: int = Query(0, ge=0),
        app_id: str = Depends(get_app_id),
        session_manager: SessionManager = Depends(get_session_manager)
):
    """
    List active chat sessions for the specified application.
    """
    try:
        # Use app-specific session listing
        sessions = await session_manager.list_app_sessions(
            app_id=app_id,
            limit=limit,
            offset=offset
        )
        return SessionListResponse(
            sessions=sessions,
            total=len(sessions),  # In production, would get actual total count
            limit=limit,
            offset=offset
        )
    except Exception as e:
        logger.error(f"Error listing sessions for app {app_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="An error occurred listing sessions")


@router.get("/session/{session_id}", response_model=SessionInfo)
async def get_session(
        session_id: str,
        app_id: str = Depends(get_app_id),
        session_manager: SessionManager = Depends(get_session_manager)
):
    """
    Get information about a specific chat session.
    """
    try:
        # Pass app_id for security check
        session = await session_manager.get_session_info(session_id, app_id)
        if not session:
            raise HTTPException(status_code=404, detail=f"Session {session_id} not found")
        return session
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting session {session_id} for app {app_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="An error occurred retrieving the session")


@router.delete("/session/{session_id}")
async def delete_session(
        session_id: str,
        app_id: str = Depends(get_app_id),
        session_manager: SessionManager = Depends(get_session_manager)
):
    """
    Delete a chat session.
    """
    try:
        # Pass app_id for security check
        success = await session_manager.delete_session(session_id, app_id)
        if not success:
            raise HTTPException(status_code=404, detail=f"Session {session_id} not found")
        return {"status": "success", "message": f"Session {session_id} deleted"}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting session {session_id} for app {app_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="An error occurred deleting the session")


@router.get("/agents", response_model=AgentListResponse)
async def list_agents(
        auth: dict = Depends(verify_api_key_and_app_id),
        agent_factory: AgentFactory = Depends(get_agent_factory)
):
    """
    List available agent types.
    """
    try:
        agents = agent_factory.available_agents()
        return AgentListResponse(
            agents=agents
        )
    except Exception as e:
        logger.error(f"Error listing agents: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="An error occurred listing agents")