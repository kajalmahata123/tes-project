import os
import json
import yaml
import logging
from typing import Dict, Any, List, Optional
from jsonschema import validate
from jsonschema.exceptions import ValidationError

logger = logging.getLogger(__name__)


class OpenAPIParser:
    """Service for parsing OpenAPI specifications"""

    def __init__(self):
        # OpenAPI 3.0 basic schema for validation
        self.openapi_schema = {
            "type": "object",
            "required": ["openapi", "info", "paths"],
            "properties": {
                "openapi": {"type": "string"},
                "info": {
                    "type": "object",
                    "required": ["title", "version"],
                },
                "paths": {"type": "object"}
            }
        }

    def parse_spec(self, file_path: str) -> Dict[str, Any]:
        """
        Parse OpenAPI specification file (JSON or YAML)

        Args:
            file_path: Path to OpenAPI specification file

        Returns:
            Parsed OpenAPI specification
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"OpenAPI spec file not found: {file_path}")

        try:
            # Determine file type based on extension
            file_ext = os.path.splitext(file_path)[1].lower()

            with open(file_path, 'r') as f:
                if file_ext in ['.yaml', '.yml']:
                    spec = yaml.safe_load(f)
                elif file_ext == '.json':
                    spec = json.load(f)
                else:
                    raise ValueError(f"Unsupported file extension: {file_ext}. Expected .json, .yaml, or .yml")

            # Validate against basic OpenAPI schema
            self._validate_spec(spec)

            # Add file metadata
            spec["_metadata"] = {
                "file_name": os.path.basename(file_path),
                "file_path": file_path,
                "type": "openapi"
            }

            return spec

        except Exception as e:
            logger.error(f"Error parsing OpenAPI spec {file_path}: {str(e)}")
            raise

    def _validate_spec(self, spec: Dict[str, Any]) -> None:
        """
        Validate OpenAPI specification against basic schema

        Args:
            spec: OpenAPI specification dictionary

        Raises:
            ValidationError: If specification doesn't match schema
        """
        try:
            validate(instance=spec, schema=self.openapi_schema)
        except ValidationError as e:
            logger.error(f"Invalid OpenAPI specification: {str(e)}")
            raise ValueError(f"Invalid OpenAPI specification: {str(e)}")

    def extract_endpoints(self, spec: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Extract endpoint information from OpenAPI specification

        Args:
            spec: OpenAPI specification dictionary

        Returns:
            List of endpoint information dictionaries
        """
        endpoints = []

        for path, path_item in spec.get("paths", {}).items():
            for method, operation in path_item.items():
                # Skip if not an HTTP method
                if method not in ["get", "post", "put", "delete", "patch", "options", "head"]:
                    continue

                endpoint = {
                    "path": path,
                    "method": method.upper(),
                    "summary": operation.get("summary", ""),
                    "description": operation.get("description", ""),
                    "operationId": operation.get("operationId", ""),
                    "parameters": self._extract_parameters(operation),
                    "requestBody": self._extract_request_body(operation),
                    "responses": self._extract_responses(operation),
                }

                endpoints.append(endpoint)

        return endpoints

    def _extract_parameters(self, operation: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Extract parameters from operation"""
        parameters = []

        for param in operation.get("parameters", []):
            parameters.append({
                "name": param.get("name", ""),
                "in": param.get("in", ""),
                "description": param.get("description", ""),
                "required": param.get("required", False),
                "schema": param.get("schema", {})
            })

        return parameters

    def _extract_request_body(self, operation: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Extract request body from operation"""
        if "requestBody" not in operation:
            return None

        request_body = operation["requestBody"]
        content = request_body.get("content", {})

        result = {
            "description": request_body.get("description", ""),
            "required": request_body.get("required", False),
            "content": {}
        }

        for media_type, media_info in content.items():
            result["content"][media_type] = {
                "schema": media_info.get("schema", {})
            }

        return result

    def _extract_responses(self, operation: Dict[str, Any]) -> Dict[str, Any]:
        """Extract responses from operation"""
        responses = {}

        for status_code, response in operation.get("responses", {}).items():
            responses[status_code] = {
                "description": response.get("description", ""),
                "content": {}
            }

            for media_type, media_info in response.get("content", {}).items():
                responses[status_code]["content"][media_type] = {
                    "schema": media_info.get("schema", {})
                }

        return responses

    def prepare_for_vector_db(self, spec: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Prepare OpenAPI spec for storage in vector database

        Args:
            spec: OpenAPI specification dictionary

        Returns:
            List of documents with text chunks and metadata
        """
        documents = []

        # Add basic info
        info = spec.get("info", {})
        basic_info = (
            f"API Title: {info.get('title', 'Unknown')}\n"
            f"Version: {info.get('version', 'Unknown')}\n"
            f"Description: {info.get('description', '')}"
        )

        documents.append({
            "text": basic_info,
            "metadata": {
                "type": "api_info",
                "title": info.get("title", "Unknown"),
                "version": info.get("version", "Unknown"),
                "file_name": spec.get("_metadata", {}).get("file_name", ""),
            }
        })

        # Add endpoints
        endpoints = self.extract_endpoints(spec)

        for endpoint in endpoints:
            # Create readable text for vector storage
            endpoint_text = (
                f"Path: {endpoint['path']}\n"
                f"Method: {endpoint['method']}\n"
                f"Summary: {endpoint['summary']}\n"
                f"Description: {endpoint['description']}\n\n"
            )

            # Add parameters
            if endpoint['parameters']:
                endpoint_text += "Parameters:\n"
                for param in endpoint['parameters']:
                    endpoint_text += (
                        f"- {param['name']} ({param['in']}): "
                        f"{param['description']}\n"
                        f"  Required: {param['required']}\n"
                    )

            # Add request body if present
            if endpoint['requestBody']:
                endpoint_text += "\nRequest Body:\n"
                endpoint_text += f"Description: {endpoint['requestBody']['description']}\n"
                endpoint_text += f"Required: {endpoint['requestBody']['required']}\n"

                for media_type, content in endpoint['requestBody']['content'].items():
                    endpoint_text += f"Media Type: {media_type}\n"

            # Add responses
            endpoint_text += "\nResponses:\n"
            for status_code, response in endpoint['responses'].items():
                endpoint_text += f"- {status_code}: {response['description']}\n"

            documents.append({
                "text": endpoint_text,
                "metadata": {
                    "type": "api_endpoint",
                    "path": endpoint['path'],
                    "method": endpoint['method'],
                    "operationId": endpoint['operationId'],
                    "file_name": spec.get("_metadata", {}).get("file_name", ""),
                }
            })

        return documents