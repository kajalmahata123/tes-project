import os
import re
import logging
from typing import List, Dict, Any, Optional, Tuple

import fitz  # PyMuPDF

logger = logging.getLogger(__name__)


class PDFParser:
    """Service for parsing PDF documents"""

    def __init__(self, chunk_size: int = 1000, chunk_overlap: int = 200):
        """
        Initialize PDF parser

        Args:
            chunk_size: Maximum character length of each text chunk
            chunk_overlap: Character overlap between chunks
        """
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap

    def parse_pdf(self, file_path: str) -> Dict[str, Any]:
        """
        Parse a PDF file and extract its content

        Args:
            file_path: Path to PDF file

        Returns:
            Dictionary containing document metadata and chunked content
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"PDF file not found: {file_path}")

        try:
            doc = fitz.open(file_path)

            # Extract metadata
            metadata = {
                "title": doc.metadata.get("title", os.path.basename(file_path)),
                "author": doc.metadata.get("author", "Unknown"),
                "subject": doc.metadata.get("subject", ""),
                "keywords": doc.metadata.get("keywords", ""),
                "page_count": len(doc),
                "file_name": os.path.basename(file_path),
                "file_path": file_path,
                "type": "pdf"
            }

            # Extract full text content
            full_text = ""
            toc = self._extract_toc(doc)

            for page_num, page in enumerate(doc):
                text = page.get_text()
                # Add page marker for better context
                full_text += f"\n--- Page {page_num + 1} ---\n{text}"

            # Chunk the text
            chunks = self._chunk_text(full_text)

            doc.close()

            return {
                "metadata": metadata,
                "toc": toc,
                "chunks": chunks
            }

        except Exception as e:
            logger.error(f"Error parsing PDF {file_path}: {str(e)}")
            raise

    def _extract_toc(self, doc: fitz.Document) -> List[Dict[str, Any]]:
        """Extract table of contents from PDF"""
        toc = doc.get_toc()
        formatted_toc = []

        for item in toc:
            level, title, page = item
            formatted_toc.append({
                "level": level,
                "title": title,
                "page": page
            })

        return formatted_toc

    def _chunk_text(self, text: str) -> List[Dict[str, Any]]:
        """
        Split the text into overlapping chunks

        Args:
            text: The full text to chunk

        Returns:
            List of chunk dictionaries with text and chunk index
        """
        if not text:
            return []

        chunks = []
        curr_idx = 0

        while curr_idx < len(text):
            # Get chunk with specified size
            chunk_end = min(curr_idx + self.chunk_size, len(text))

            # If we're not at the end, try to break at a paragraph or sentence
            if chunk_end < len(text):
                # Try to find paragraph break
                paragraph_break = text.rfind("\n\n", curr_idx, chunk_end)

                if paragraph_break != -1 and paragraph_break > curr_idx:
                    chunk_end = paragraph_break
                else:
                    # Try to find sentence break (period followed by space)
                    sentence_break = text.rfind(". ", curr_idx, chunk_end)
                    if sentence_break != -1 and sentence_break > curr_idx:
                        chunk_end = sentence_break + 1  # Include the period

            # Extract chunk text
            chunk_text = text[curr_idx:chunk_end].strip()

            if chunk_text:
                chunks.append({
                    "text": chunk_text,
                    "chunk_index": len(chunks)
                })

            # Move index for next chunk, accounting for overlap
            curr_idx = chunk_end - self.chunk_overlap if chunk_end < len(text) else len(text)

            # Avoid getting stuck in an infinite loop
            if curr_idx <= 0:
                curr_idx = chunk_end

        return chunks

    def extract_api_information(self, chunks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Extract API-related information from text chunks

        Args:
            chunks: List of text chunks

        Returns:
            List of API information dictionaries
        """
        api_info = []

        # Regular expressions for identifying API patterns
        endpoint_pattern = re.compile(r"(GET|POST|PUT|DELETE|PATCH)\s+(/[\w/{}]+)")
        param_pattern = re.compile(r"param(?:eter)?s?:?\s*([\w\s,{}]+)(?:\n|$)", re.IGNORECASE)

        for chunk in chunks:
            text = chunk["text"]

            # Look for API endpoints
            endpoints = endpoint_pattern.findall(text)
            if endpoints:
                for method, path in endpoints:
                    api_entry = {
                        "type": "api_endpoint",
                        "method": method,
                        "path": path,
                        "chunk_index": chunk["chunk_index"],
                        "parameters": [],
                        "description": ""
                    }

                    # Extract description (text before or after the endpoint)
                    endpoint_pos = text.find(f"{method} {path}")
                    before_text = text[:endpoint_pos].strip()
                    after_text = text[endpoint_pos + len(f"{method} {path}"):].strip()

                    # If there's text before the endpoint, it might be a description
                    if before_text and len(before_text) < 200:
                        api_entry["description"] = before_text
                    # If there's text after the endpoint, it might be parameters or description
                    elif after_text:
                        # Try to find parameters
                        params_match = param_pattern.search(after_text)
                        if params_match:
                            param_text = params_match.group(1)
                            api_entry["parameters"] = [p.strip() for p in param_text.split(",")]

                        # Use remaining text as description
                        api_entry["description"] = after_text[:200]

                    api_info.append(api_entry)

        return api_info