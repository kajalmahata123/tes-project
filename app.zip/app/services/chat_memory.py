import time
from typing import Dict, List, Any, Optional
import uuid

class ChatMemoryService:
    """In-memory storage for chat sessions"""

    def __init__(self, max_sessions: int = 1000, ttl_seconds: int = 3600 * 24):
        """
        Initialize chat memory service

        Args:
            max_sessions: Maximum number of sessions to store
            ttl_seconds: Time to live for sessions in seconds (default: 24 hours)
        """
        self.sessions: Dict[str, Dict[str, Any]] = {}
        self.max_sessions = max_sessions
        self.ttl_seconds = ttl_seconds

    def get_session(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Get session by ID"""
        # Clean expired sessions periodically
        self._clean_expired_sessions()

        # Return session if it exists
        session = self.sessions.get(session_id)
        if session:
            # Update last access time
            session["last_accessed"] = time.time()
            return session

        return None

    def create_session(self, session_data: Optional[Dict[str, Any]] = None) -> str:
        """Create a new session"""
        # Clean expired sessions periodically
        self._clean_expired_sessions()

        # Check if max sessions reached, remove oldest session if needed
        if len(self.sessions) >= self.max_sessions:
            oldest_session_id = min(
                self.sessions.keys(),
                key=lambda session_id: self.sessions[session_id]["last_accessed"]
            )
            del self.sessions[oldest_session_id]

        # Create new session
        session_id = str(uuid.uuid4())
        self.sessions[session_id] = {
            "session_id": session_id,
            "created_at": time.time(),
            "last_accessed": time.time(),
            "messages": [],
            "context": {},
            **(session_data or {})
        }

        return session_id

    def update_session(self, session_id: str, data: Dict[str, Any]) -> bool:
        """Update session data"""
        if session_id not in self.sessions:
            return False

        # Update session data
        self.sessions[session_id].update(data)
        self.sessions[session_id]["last_accessed"] = time.time()

        return True

    def add_message(self, session_id: str, role: str, content: str) -> bool:
        """Add message to session"""
        session = self.get_session(session_id)
        if not session:
            return False

        # Add message
        session["messages"].append({
            "role": role,
            "content": content,
            "timestamp": time.time()
        })

        return True

    def get_messages(self, session_id: str) -> List[Dict[str, Any]]:
        """Get all messages for a session"""
        session = self.get_session(session_id)
        if not session:
            return []

        return session.get("messages", [])

    def delete_session(self, session_id: str) -> bool:
        """Delete a session"""
        if session_id in self.sessions:
            del self.sessions[session_id]
            return True

        return False

    def _clean_expired_sessions(self):
        """Clean expired sessions"""
        current_time = time.time()
        expired_sessions = [
            session_id for session_id, session in self.sessions.items()
            if current_time - session["last_accessed"] > self.ttl_seconds
        ]

        for session_id in expired_sessions:
            del self.sessions[session_id]