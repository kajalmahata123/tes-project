import os
import uuid
from typing import List, Dict, Any, Optional
import logging

import chromadb
from chromadb.config import Settings
from chromadb.utils import embedding_functions
from chromadb.utils.embedding_functions import DefaultEmbeddingFunction

from app.services.embedding_service import EmbeddingService

logger = logging.getLogger(__name__)


class ChromaService:
    """Service for interacting with ChromaDB vector store"""

    def __init__(
            self,
            embedding_service: EmbeddingService,
            persist_directory: str,
            collection_name: str = "api_documents"
    ):
        self.embedding_service = embedding_service
        self.persist_directory = persist_directory
        self.collection_name = collection_name

        # Ensure persist directory exists
        os.makedirs(persist_directory, exist_ok=True)

        # Initialize ChromaDB client
        self.client = chromadb.PersistentClient(
            path=persist_directory,
            settings=Settings(
                anonymized_telemetry=False
            )
        )

        # Get or create collection
        self.collection = self._get_or_create_collection()

        logger.info(f"ChromaDB initialized with collection '{collection_name}'")

    def _get_or_create_collection(self):
        """Get existing collection or create a new one"""
        try:
            return self.client.get_collection(
                name=self.collection_name,
                embedding_function=self._get_embedding_function()
            )
        except chromadb.errors.InvalidCollectionException:
            logger.info(f"Creating new collection: {self.collection_name}")
            return self.client.create_collection(
                name=self.collection_name,
                embedding_function=self._get_embedding_function()
            )


    def add_documents(
            self,
            documents: List[str],
            metadatas: Optional[List[Dict[str, Any]]] = None,
            ids: Optional[List[str]] = None
    ) -> List[str]:
        """
        Add documents to the ChromaDB collection

        Args:
            documents: List of document texts
            metadatas: Optional list of metadata dictionaries for each document
            ids: Optional list of IDs for each document

        Returns:
            List of document IDs
        """
        if ids is None:
            ids = [str(uuid.uuid4()) for _ in range(len(documents))]

        if metadatas is None:
            metadatas = [{} for _ in range(len(documents))]

        self.collection.add(
            documents=documents,
            metadatas=metadatas,
            ids=ids
        )

        logger.info(f"Added {len(documents)} documents to ChromaDB")
        return ids

    def query(
            self,
            query_text: str,
            n_results: int = 5,
            where: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Query the vector database

        Args:
            query_text: Query string
            n_results: Number of results to return
            where: Optional filter criteria

        Returns:
            Query results
        """
        results = self.collection.query(
            query_texts=[query_text],
            n_results=n_results,
            where=where
        )

        return results

    def get_document_by_id(self, doc_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve a document by its ID"""
        try:
            result = self.collection.get(ids=[doc_id])
            if result["documents"]:
                return {
                    "id": result["ids"][0],
                    "document": result["documents"][0],
                    "metadata": result["metadatas"][0] if result["metadatas"] else {}
                }
            return None
        except Exception as e:
            logger.error(f"Error retrieving document {doc_id}: {str(e)}")
            return None

    def delete_document(self, doc_id: str) -> bool:
        """Delete a document by its ID"""
        try:
            self.collection.delete(ids=[doc_id])
            logger.info(f"Deleted document {doc_id}")
            return True
        except Exception as e:
            logger.error(f"Error deleting document {doc_id}: {str(e)}")
            return False

    def _get_embedding_function(self):
        """Create appropriate embedding function based on embedding service type"""
        # Use a safer type check that doesn't rely on isinstance
        if hasattr(self.embedding_service, 'model') and type(
                self.embedding_service.model).__name__ == 'DefaultEmbeddingFunction':
            return self.embedding_service.model
        else:
            # Create a function that wraps your embedding service methods
            from chromadb.api.types import Documents, EmbeddingFunction, Embeddings

            class CustomEmbeddingFunction(EmbeddingFunction):
                def __init__(self, embed_service):
                    self.embed_service = embed_service

                def __call__(self, texts: Documents) -> Embeddings:
                    return self.embed_service.embed_documents(texts)

            return CustomEmbeddingFunction(self.embedding_service)