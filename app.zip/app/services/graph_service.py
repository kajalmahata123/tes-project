"""
Graph Service for generating visualization data structures.
This service handles the creation of graph structures for agents and tools.
"""

from typing import Dict, List, Optional, Any
import logging
import hashlib
from datetime import datetime
import asyncio

from app.core.session_manager import SessionManager
from app.services.metrics_service import MetricsService
from app.schemas.graph_schemas import AgentGraphResponse, ToolGraphResponse, AgentDetailResponse, ToolDetailResponse
from app.api.websocket import get_graph_update_manager

logger = logging.getLogger(__name__)


class GraphService:
    """Service for generating graph data structures for visualization."""
    
    def __init__(self):
        self.metrics_service = MetricsService()
        
        # Get singleton instances for accessing agents and tools
        from app.core.agent_registry import AgentRegistry
        # Create AgentRegistry directly instead of calling get_instance()
        self.agent_registry = AgentRegistry()
        
        # Get singleton instances for accessing session data
        from app.dependencies import get_agent_registry
        # This will be used to get registered agents for graph visualization
        self.get_agent_registry = get_agent_registry
        
        # Session manager for accessing metrics
        self.session_manager = SessionManager.get_instance()
    
    async def generate_agent_graph(self, app_id: Optional[str] = None) -> AgentGraphResponse:
        """
        Generate a complete agent graph visualization structure.
        
        Args:
            app_id: Optional application ID to filter agents
        """
        try:
            # Get all registered agents using the dependency function
            registry = await self.get_agent_registry()
            agent_types = registry.get_registered_agents()
            
            # Create agent nodes
            nodes = []
            for agent_type in agent_types:
                agent_class = registry.get_agent_class(agent_type)
                if agent_class:
                    # Generate a stable position based on agent type
                    position = self._calculate_agent_position(agent_type, len(agent_types))
                    
                    # Get agent metrics if available
                    metrics = {}
                    try:
                        if app_id:
                            metrics = await self.metrics_service.get_agent_metrics(f"{app_id}_{agent_type}")
                    except Exception as e:
                        logger.warning(f"Failed to get metrics for agent {agent_type}: {e}")
                    
                    nodes.append({
                        "id": agent_type,
                        "type": self._map_agent_type_to_node_type(agent_type),
                        "position": position,
                        "data": {
                            "label": agent_class.__name__,
                            "type": agent_type,
                            "description": agent_class.__doc__ or f"Agent of type {agent_class.__name__}",
                            "status": "active",  # Default to active
                            "metrics": metrics.get(f"{app_id}_{agent_type}", {}) if app_id else {}
                        }
                    })
            
            # Add system component nodes (LLM, Knowledge Base, etc.)
            system_nodes = self._get_system_component_nodes()
            nodes.extend(system_nodes)
            
            # Generate edges between nodes
            edges = self._generate_agent_graph_edges(nodes)
            
            # Ensure we return a valid response even if empty
            return AgentGraphResponse(
                nodes=nodes or [], 
                edges=edges or []
            )
            
        except Exception as e:
            logger.error(f"Failed to generate agent graph: {str(e)}", exc_info=True)
            # Return empty but valid response on error
            return AgentGraphResponse(nodes=[], edges=[])
    
    async def generate_tool_graph(self) -> ToolGraphResponse:
        """
        Generate a complete tool ecosystem graph with relationships.
        """
        try:
            # Get all available tools from registered agents
            registry = await self.get_agent_registry()
            tools = []
            
            # Get all registered agents
            agent_types = registry.get_registered_agents()
            for agent_type in agent_types:
                agent_class = registry.get_agent_class(agent_type)
                if agent_class and hasattr(agent_class, 'tools'):
                    # Create a temporary instance to get tools
                    # This is safe because we're not initializing the agent
                    agent = agent_class(None)  # Pass None as config
                    if agent.tools:
                        tools.extend(agent.tools)
            
            # Remove duplicates and map to consistent structure
            unique_tools = {}
            for tool in tools:
                tool_id = tool.name
                if tool_id not in unique_tools:
                    # Get tool metrics if available
                    metrics = {}
                    try:
                        metrics = await self.metrics_service.get_tool_metrics(tool_id)
                    except Exception as e:
                        logger.warning(f"Failed to get metrics for tool {tool_id}: {e}")
                    
                    unique_tools[tool_id] = {
                        "id": tool_id,
                        "type": "tool",
                        "data": {
                            "label": tool.name,
                            "description": tool.description,
                            "metrics": metrics.get(tool_id, {})
                        }
                    }
            
            # Create edges between tools and agents
            edges = []
            for agent_type in agent_types:
                agent_class = registry.get_agent_class(agent_type)
                if agent_class and hasattr(agent_class, 'tools'):
                    agent = agent_class(None)
                    if agent.tools:
                        for tool in agent.tools:
                            edges.append({
                                "id": f"{agent_type}-{tool.name}",
                                "source": agent_type,
                                "target": tool.name,
                                "type": "uses"
                            })
            
            return ToolGraphResponse(
                nodes=list(unique_tools.values()),
                edges=edges
            )
            
        except Exception as e:
            logger.error(f"Failed to generate tool graph: {str(e)}", exc_info=True)
            # Return empty but valid response on error
            return ToolGraphResponse(nodes=[], edges=[])
    
    async def get_agent_details(self, agent_id: str) -> Optional[AgentDetailResponse]:
        """
        Get detailed information about a specific agent.
        
        Args:
            agent_id: ID of the agent to retrieve
            
        Returns:
            Detailed agent information or None if not found
        """
        try:
            # Find the agent in registry
            registry = await self.get_agent_registry()
            agent = next((a for a in registry.list_agents() if a.id == agent_id), None)
            if not agent:
                logger.warning(f"Agent {agent_id} not found")
                return None
            
            # Get metrics for this agent
            metrics_dict = await self.metrics_service.get_agent_metrics(agent_id=agent_id)
            metrics = metrics_dict.get(agent_id, {})
            
            # Get tools associated with this agent
            tools = [tool.id if hasattr(tool, 'id') else tool.name 
                     for tool in (agent.tools or [])]
            
            # Create agent detail response
            return {
                "id": agent.id,
                "name": agent.name,
                "type": agent.type,
                "description": agent.description,
                "capabilities": agent.capabilities if hasattr(agent, 'capabilities') else [],
                "metrics": {
                    "query_count": metrics.get('query_count', 0),
                    "success_rate": f"{metrics.get('success_rate', 0):.1f}%",
                    "avg_response_time": f"{metrics.get('avg_response_time', 0):.2f}s",
                    "status": metrics.get('status', 'inactive')
                },
                "tools": tools,
                "created_at": datetime.utcnow().isoformat(),  # Placeholder 
                "updated_at": datetime.utcnow().isoformat()   # Placeholder
            }
            
        except Exception as e:
            logger.error(f"Error getting agent details: {e}", exc_info=True)
            return None
    
    async def get_tool_details(self, tool_id: str) -> Optional[ToolDetailResponse]:
        """
        Get detailed information about a specific tool.
        
        Args:
            tool_id: ID of the tool to retrieve
            
        Returns:
            Detailed tool information or None if not found
        """
        try:
            # Find the tool across all agents
            tool = None
            compatible_agents = []
            
            registry = await self.get_agent_registry()
            for agent in registry.list_agents():
                for t in (agent.tools or []):
                    t_id = t.id if hasattr(t, 'id') else f"tool-{t.name.lower().replace(' ', '-')}"
                    if t_id == tool_id:
                        tool = t
                        compatible_agents.append(agent.id)
            
            if not tool:
                logger.warning(f"Tool {tool_id} not found")
                return None
            
            # Get metrics for this tool
            metrics_dict = await self.metrics_service.get_tool_metrics(tool_id=tool_id)
            metrics = metrics_dict.get(tool_id, {})
            
            # Get parameters if available
            parameters = {}
            if hasattr(tool, 'parameters'):
                parameters = tool.parameters
            elif hasattr(tool, 'args'):
                parameters = tool.args
            
            # Get usage examples if available
            usage_examples = []
            if hasattr(tool, 'examples'):
                usage_examples = tool.examples
            
            # Create tool detail response
            return {
                "id": tool_id,
                "name": tool.name if hasattr(tool, 'name') else tool_id,
                "category": tool.category if hasattr(tool, 'category') else "Unknown",
                "description": tool.description if hasattr(tool, 'description') else "",
                "usage_examples": usage_examples,
                "parameters": parameters,
                "stats": {
                    "usage_count": metrics.get('usage_count', 0),
                    "success_rate": f"{metrics.get('success_rate', 0):.1f}%",
                    "avg_processing_time": f"{metrics.get('avg_processing_time', 0):.2f}s"
                },
                "compatible_agents": compatible_agents
            }
            
        except Exception as e:
            logger.error(f"Error getting tool details: {e}", exc_info=True)
            return None
    
    # Helper methods for node positioning and relationships
    def _map_agent_type_to_node_type(self, agent_type: str) -> str:
        """Map internal agent types to React node types."""
        type_mapping = {
            "visa_api_agent": "visaApiAgent",
            "code_generator": "codeGenerator",
            "workflow_creator": "workflowAgent"
        }
        return type_mapping.get(agent_type, "defaultAgent")
    
    def _calculate_agent_position(self, agent_type: str, total_agents: int) -> Dict[str, int]:
        """Calculate visual positions for each agent node."""
        # Fixed positions for known agents
        base_positions = {
            "visa_api_agent": {"x": 250, "y": 100},
            "code_generator": {"x": 100, "y": 250},
            "workflow_creator": {"x": 400, "y": 250}
        }
        
        if agent_type in base_positions:
            return base_positions[agent_type]
        
        # Fallback to calculated position
        # Use hash of agent_type to get a consistent but pseudo-random position
        hash_value = int(hashlib.md5(agent_type.encode()).hexdigest(), 16) 
        return {
            "x": 200 + (hash_value % 300),
            "y": 150 + ((hash_value // 10) % 200)
        }
    
    def _get_system_component_nodes(self) -> List[Dict[str, Any]]:
        """Generate nodes for system components like LLM and Knowledge Base."""
        return [
            {
                "id": "llm-claude",
                "type": "llm",
                "position": {"x": 250, "y": 400},
                "data": {
                    "label": "Claude 3.5 Sonnet",
                    "description": "Large language model powering all agents",
                    "metrics": {
                        "tokenCount": "8.75M",
                        "avgResponseTime": "1.8s"
                    },
                    "status": "active"
                }
            },
            {
                "id": "knowledge-base",
                "type": "knowledgeBase",
                "position": {"x": 400, "y": 400},
                "data": {
                    "label": "API Knowledge Base",
                    "description": "Vector store of API documentation",
                    "metrics": {
                        "documentCount": 258,
                        "lastUpdated": "2023-03-15T14:30:00Z"
                    },
                    "status": "active"
                }
            }
        ]
    
    def _generate_agent_graph_edges(self, nodes: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Generate edges connecting agent graph nodes."""
        # Basic connections between components
        edges = []
        agent_nodes = [n for n in nodes if n["type"] in ["visaApiAgent", "codeGenerator", "workflowAgent"]]
        system_nodes = [n for n in nodes if n["type"] in ["llm", "knowledgeBase"]]
        
        # Connect all agents to LLM
        llm_node = next((n for n in system_nodes if n["type"] == "llm"), None)
        kb_node = next((n for n in system_nodes if n["type"] == "knowledgeBase"), None)
        
        if llm_node:
            for agent in agent_nodes:
                edges.append({
                    "id": f"e{agent['id']}-{llm_node['id']}",
                    "source": agent["id"],
                    "target": llm_node["id"]
                })
        
        # Connect LLM to Knowledge Base
        if llm_node and kb_node:
            edges.append({
                "id": f"e{llm_node['id']}-{kb_node['id']}",
                "source": llm_node["id"],
                "target": kb_node["id"]
            })
        
        # Connect Knowledge Base back to specific agents
        visa_api_agent = next((n for n in agent_nodes if n["type"] == "visaApiAgent"), None)
        if kb_node and visa_api_agent:
            edges.append({
                "id": f"e{kb_node['id']}-{visa_api_agent['id']}",
                "source": kb_node["id"],
                "target": visa_api_agent["id"]
            })
        
        # Connect workflow agent to other agents (if it exists)
        workflow_agent = next((n for n in agent_nodes if n["type"] == "workflowAgent"), None)
        if workflow_agent:
            for agent in agent_nodes:
                if agent["id"] != workflow_agent["id"]:
                    edges.append({
                        "id": f"e{workflow_agent['id']}-{agent['id']}",
                        "source": workflow_agent["id"],
                        "target": agent["id"],
                        "animated": True
                    })
        
        return edges
    
    def _generate_tool_graph_links(self, tools: List[Any]) -> List[Dict[str, Any]]:
        """Generate links between related tools."""
        links = []
        
        # Group tools by category
        tools_by_category = {}
        for tool in tools:
            category = "Unknown"
            if hasattr(tool, 'category'):
                category = tool.category
            elif hasattr(tool, 'metadata') and isinstance(tool.metadata, dict) and 'category' in tool.metadata:
                category = tool.metadata['category']
                
            if category not in tools_by_category:
                tools_by_category[category] = []
            
            tools_by_category[category].append(tool)
        
        # Connect tools within same category
        for category, category_tools in tools_by_category.items():
            for i, tool1 in enumerate(category_tools):
                tool1_id = tool1.id if hasattr(tool1, 'id') else f"tool-{tool1.name.lower().replace(' ', '-')}"
                
                for j, tool2 in enumerate(category_tools[i+1:], i+1):
                    tool2_id = tool2.id if hasattr(tool2, 'id') else f"tool-{tool2.name.lower().replace(' ', '-')}"
                    
                    # Stronger connection within category
                    links.append({
                        "source": tool1_id,
                        "target": tool2_id,
                        "value": 5  # Strength of relationship
                    })
        
        # Add some cross-category connections based on common usage patterns
        common_tool_pairs = [
            # This would ideally come from actual usage data or metadata
            ("vector-search", "code-generator", 3),
            ("context-ranking", "diagram-creator", 6),
            ("markdown-parser", "code-generator", 4)
        ]
        
        for source_id, target_id, strength in common_tool_pairs:
            # Check if both tools exist before adding the link
            source_exists = any(
                (hasattr(t, 'id') and t.id == source_id) or 
                (hasattr(t, 'name') and f"tool-{t.name.lower().replace(' ', '-')}" == source_id) 
                for t in tools
            )
            
            target_exists = any(
                (hasattr(t, 'id') and t.id == target_id) or 
                (hasattr(t, 'name') and f"tool-{t.name.lower().replace(' ', '-')}" == target_id) 
                for t in tools
            )
            
            if source_exists and target_exists:
                links.append({
                    "source": source_id,
                    "target": target_id,
                    "value": strength
                })
        
        return links 