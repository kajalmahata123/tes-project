from abc import ABC, abstractmethod
from typing import List, Any, Dict, Optional
import numpy as np

from langchain_openai import OpenAIEmbeddings
import chromadb


class EmbeddingService(ABC):
    """Abstract base class for embedding services"""

    @abstractmethod
    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """Embed multiple documents"""
        pass

    @abstractmethod
    def embed_query(self, text: str) -> List[float]:
        """Embed a single query string"""
        pass


class ChromaBasicEmbedding(EmbeddingService):
    """
    Wrapper for ChromaDB's basic embedding model
    """

    def __init__(self):
        self.model = chromadb.utils.embedding_functions.DefaultEmbeddingFunction()

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """Embed a list of documents"""
        return self.model(texts)

    def embed_query(self, text: str) -> List[float]:
        """Embed a single query string"""
        return self.model([text])[0]


class OpenAIEmbeddingService(EmbeddingService):
    """
    Wrapper for OpenAI embeddings to provide consistent interface
    """

    def __init__(self, api_key: str, model_name: str = "text-embedding-3-small"):
        self.embeddings = OpenAIEmbeddings(
            api_key=api_key,
            model=model_name
        )

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """Embed a list of documents"""
        return self.embeddings.embed_documents(texts)

    def embed_query(self, text: str) -> List[float]:
        """Embed a single query string"""
        return self.embeddings.embed_query(text)