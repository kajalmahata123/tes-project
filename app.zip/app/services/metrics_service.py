"""
Metrics Service for collecting agent and tool usage data.
This service handles recording and retrieving metrics for visualization.
"""

import logging
import time
import asyncio
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
from sqlalchemy import text

logger = logging.getLogger(__name__)


class MetricsService:
    """
    Service for collecting and retrieving metrics for agents and tools.
    These metrics power the visualizations in the graph components.
    """
    
    def __init__(self):
        from app.db.manager import DatabaseManager
        self.db = DatabaseManager()
    
    async def record_agent_usage(self, agent_id: str, success: bool, response_time: float) -> None:
        """
        Record a usage instance of an agent.
        
        Args:
            agent_id: ID of the agent
            success: Whether the query was successful
            response_time: Time taken to process the query in seconds
        """
        try:
            query = text("""
            INSERT INTO agent_metrics (agent_id, success, response_time, timestamp)
            VALUES (:agent_id, :success, :response_time, :timestamp)
            """)
            
            async with self.db.async_session_factory() as session:
                await session.execute(
                    query, 
                    {
                        "agent_id": agent_id,
                        "success": 1 if success else 0,
                        "response_time": response_time,
                        "timestamp": datetime.utcnow().isoformat()
                    }
                )
                await session.commit()
                
            logger.debug(f"Recorded usage for agent {agent_id}: success={success}, time={response_time:.3f}s")
            
            # Broadcast the metric update via WebSocket
            try:
                # Get updated metrics for this agent
                agent_metrics = await self.get_agent_metrics(agent_id)
                
                from app.api.websocket import get_graph_update_manager
                update_manager = get_graph_update_manager()
                # Use create_task to avoid blocking
                asyncio.create_task(update_manager.broadcast_metric_update(
                    "agent_metric", 
                    {
                        "agent_id": agent_id,
                        "metrics": agent_metrics.get(agent_id, {})
                    }
                ))
            except Exception as e:
                logger.error(f"Error broadcasting agent metric update: {e}")
                
        except Exception as e:
            logger.error(f"Error recording agent usage: {e}", exc_info=True)
    
    async def record_tool_usage(self, 
                                tool_id: str, 
                                agent_id: str, 
                                success: bool, 
                                processing_time: float) -> None:
        """
        Record a usage instance of a tool by an agent.
        
        Args:
            tool_id: ID of the tool
            agent_id: ID of the agent using the tool
            success: Whether the tool usage was successful
            processing_time: Time taken to process the tool in seconds
        """
        try:
            query = text("""
            INSERT INTO tool_metrics (tool_id, agent_id, success, processing_time, timestamp)
            VALUES (:tool_id, :agent_id, :success, :processing_time, :timestamp)
            """)
            
            async with self.db.async_session_factory() as session:
                await session.execute(
                    query,
                    {
                        "tool_id": tool_id,
                        "agent_id": agent_id,
                        "success": 1 if success else 0,
                        "processing_time": processing_time,
                        "timestamp": datetime.utcnow().isoformat()
                    }
                )
                await session.commit()
                
            logger.debug(f"Recorded usage for tool {tool_id} by agent {agent_id}: success={success}, time={processing_time:.3f}s")
            
            # Broadcast the metric update via WebSocket
            try:
                # Get updated metrics for this tool
                tool_metrics = await self.get_tool_metrics(tool_id)
                
                from app.api.websocket import get_graph_update_manager
                update_manager = get_graph_update_manager()
                # Use create_task to avoid blocking
                asyncio.create_task(update_manager.broadcast_metric_update(
                    "tool_metric",
                    {
                        "tool_id": tool_id,
                        "agent_id": agent_id,
                        "metrics": tool_metrics.get(tool_id, {})
                    }
                ))
                
                # Also trigger a graph update since tool relationships may have changed
                from app.services.graph_service import GraphService
                graph_service = GraphService()
                asyncio.create_task(graph_service.get_tool_graph())
                
            except Exception as e:
                logger.error(f"Error broadcasting tool metric update: {e}")
                
        except Exception as e:
            logger.error(f"Error recording tool usage: {e}", exc_info=True)
    
    async def get_agent_metrics(self, 
                                agent_id: Optional[str] = None, 
                                time_period: int = 7) -> Dict[str, Dict[str, Any]]:
        """
        Get metrics for agents over a specified time period.
        
        Args:
            agent_id: Optional ID to filter for a specific agent
            time_period: Number of days to look back
            
        Returns:
            Dictionary of agent metrics by agent ID
        """
        try:
            # Calculate date range
            end_date = datetime.utcnow()
            start_date = end_date - timedelta(days=time_period)
            
            # Build query
            query = text("""
            SELECT 
                agent_id, 
                COUNT(*) as query_count,
                SUM(CASE WHEN success = 1 THEN 1 ELSE 0 END) as success_count,
                AVG(response_time) as avg_response_time
            FROM agent_metrics
            WHERE timestamp >= :start_date
            """)
            
            params = {"start_date": start_date.isoformat()}
            
            if agent_id:
                query = text(query.text + " AND agent_id = :agent_id")
                params["agent_id"] = agent_id
            
            query = text(query.text + " GROUP BY agent_id")
            
            # Execute query
            async with self.db.async_session_factory() as session:
                result = await session.execute(query, params)
                rows = result.fetchall()
            
            # Process results
            result = {}
            for row in rows:
                agent_id = row[0]
                query_count = row[1]
                success_count = row[2]
                success_rate = (success_count / query_count) * 100 if query_count > 0 else 0
                
                result[agent_id] = {
                    'query_count': query_count,
                    'success_count': success_count,
                    'success_rate': success_rate,
                    'avg_response_time': row[3],
                    'status': 'active' if query_count > 0 else 'inactive'
                }
            
            return result
            
        except Exception as e:
            logger.error(f"Error getting agent metrics: {e}", exc_info=True)
            return {}
    
    async def get_tool_metrics(self, 
                               tool_id: Optional[str] = None, 
                               time_period: int = 7) -> Dict[str, Dict[str, Any]]:
        """
        Get metrics for tools over a specified time period.
        
        Args:
            tool_id: Optional ID to filter for a specific tool
            time_period: Number of days to look back
            
        Returns:
            Dictionary of tool metrics by tool ID
        """
        try:
            # Calculate date range
            end_date = datetime.utcnow()
            start_date = end_date - timedelta(days=time_period)
            
            # Build query
            query = text("""
            SELECT 
                tool_id, 
                COUNT(*) as usage_count,
                SUM(CASE WHEN success = 1 THEN 1 ELSE 0 END) as success_count,
                AVG(processing_time) as avg_processing_time
            FROM tool_metrics
            WHERE timestamp >= :start_date
            """)
            
            params = {"start_date": start_date.isoformat()}
            
            if tool_id:
                query = text(query.text + " AND tool_id = :tool_id")
                params["tool_id"] = tool_id
            
            query = text(query.text + " GROUP BY tool_id")
            
            # Execute query
            async with self.db.async_session_factory() as session:
                result = await session.execute(query, params)
                rows = result.fetchall()
            
            # Process results
            result = {}
            for row in rows:
                tool_id = row[0]
                usage_count = row[1]
                success_count = row[2]
                success_rate = (success_count / usage_count) * 100 if usage_count > 0 else 0
                
                result[tool_id] = {
                    'usage_count': usage_count,
                    'success_count': success_count,
                    'success_rate': success_rate,
                    'avg_processing_time': row[3]
                }
            
            return result
            
        except Exception as e:
            logger.error(f"Error getting tool metrics: {e}", exc_info=True)
            return {}
    
    async def get_agent_tool_interactions(self, 
                                         agent_id: Optional[str] = None,
                                         tool_id: Optional[str] = None,
                                         limit: int = 20) -> List[Dict[str, Any]]:
        """
        Get recent interactions between agents and tools.
        
        Args:
            agent_id: Optional agent ID to filter by
            tool_id: Optional tool ID to filter by
            limit: Maximum number of interactions to return
            
        Returns:
            List of agent-tool interactions
        """
        try:
            query = text("""
            SELECT 
                tool_id,
                agent_id,
                success,
                processing_time,
                timestamp
            FROM tool_metrics
            WHERE 1=1
            """)
            
            params = {}
            
            if agent_id:
                query = text(query.text + " AND agent_id = :agent_id")
                params["agent_id"] = agent_id
            
            if tool_id:
                query = text(query.text + " AND tool_id = :tool_id")
                params["tool_id"] = tool_id
            
            query = text(query.text + " ORDER BY timestamp DESC LIMIT :limit")
            params["limit"] = limit
            
            # Execute query
            async with self.db.async_session_factory() as session:
                result = await session.execute(query, params)
                rows = result.fetchall()
            
            # Process results
            interactions = []
            for row in rows:
                interactions.append({
                    'tool_id': row[0],
                    'agent_id': row[1],
                    'success': bool(row[2]),
                    'processing_time': row[3],
                    'timestamp': row[4]
                })
            
            return interactions
            
        except Exception as e:
            logger.error(f"Error getting agent-tool interactions: {e}", exc_info=True)
            return [] 