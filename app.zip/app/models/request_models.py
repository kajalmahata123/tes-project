from enum import Enum
from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field

class MessageRole(str, Enum):
    """Enum for message roles"""
    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"

class Message(BaseModel):
    """Chat message model"""
    role: MessageRole
    content: str

class ChatRequest(BaseModel):
    """Request model for chat endpoint"""
    messages: List[Message]
    session_id: Optional[str] = None
    context: Optional[Dict[str, Any]] = Field(default_factory=dict)

class WorkflowGenerationRequest(BaseModel):
    """Request model for workflow generation endpoint"""
    description: str = Field(..., description="Description of the workflow to generate")
    api_ids: Optional[List[str]] = Field(default=None, description="IDs of API endpoints to include in workflow")
    context: Optional[Dict[str, Any]] = Field(default_factory=dict)

class CodeGenerationRequest(BaseModel):
    """Request model for code generation endpoint"""
    workflow_id: Optional[str] = Field(default=None, description="ID of the workflow to generate code for")
    api_ids: Optional[List[str]] = Field(default=None, description="IDs of API endpoints to include in code")
    language: str = Field(..., description="Programming language for generated code")
    description: Optional[str] = Field(default=None, description="Description of functionality for code generation")
    context: Optional[Dict[str, Any]] = Field(default_factory=dict)

class DocumentUploadRequest(BaseModel):
    """Request model for document upload endpoint"""
    document_type: str = Field(..., description="Type of document (pdf, openapi)")
    document_name: str = Field(..., description="Name of the document")
    document_description: Optional[str] = Field(default=None, description="Description of the document")
    add_to_vector_db: bool = Field(default=True, description="Whether to add document to vector database")