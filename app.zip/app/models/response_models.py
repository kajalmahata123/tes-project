from typing import List, Dict, Any, Optional
from datetime import datetime
from pydantic import BaseModel, Field

class ChatResponse(BaseModel):
    """Response model for chat endpoint"""
    response: str
    session_id: str
    created_at: datetime = Field(default_factory=datetime.now)
    sources: Optional[List[Dict[str, Any]]] = None

class WorkflowResponse(BaseModel):
    """Response model for workflow generation endpoint"""
    workflow_id: str
    title: str
    description: str
    steps: List[Dict[str, Any]]
    created_at: datetime = Field(default_factory=datetime.now)
    visualization: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None

class CodeResponse(BaseModel):
    """Response model for code generation endpoint"""
    code_id: str
    language: str
    code: str
    created_at: datetime = Field(default_factory=datetime.now)
    workflow_id: Optional[str] = None
    description: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None

class DocumentUploadResponse(BaseModel):
    """Response model for document upload endpoint"""
    document_id: str
    document_name: str
    document_type: str
    upload_success: bool
    vector_db_added: bool
    created_at: datetime = Field(default_factory=datetime.now)
    chunks_count: Optional[int] = None
    metadata: Optional[Dict[str, Any]] = None

class ErrorResponse(BaseModel):
    """Error response model"""
    error: str
    detail: Optional[str] = None
    timestamp: datetime = Field(default_factory=datetime.now)