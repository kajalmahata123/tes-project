"""
Schema definitions for graph visualization API responses.
These schemas define the structure of the data returned by the graph endpoints.
"""

from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field


# Agent Graph Schemas
class AgentNodeData(BaseModel):
    """Data contained within an agent node."""
    label: str
    description: Optional[str] = None
    metrics: Dict[str, Any] = Field(default_factory=dict)
    status: str = "inactive"


class AgentNode(BaseModel):
    """A node in the agent graph."""
    id: str
    type: str
    position: Dict[str, int]
    data: AgentNodeData


class AgentEdge(BaseModel):
    """An edge connecting two nodes in the agent graph."""
    id: str
    source: str
    target: str
    animated: Optional[bool] = None
    style: Optional[Dict[str, Any]] = None


class AgentGraphResponse(BaseModel):
    """Response model for the agent graph endpoint."""
    nodes: List[AgentNode]
    edges: List[AgentEdge]


# Tool Graph Schemas
class ToolStats(BaseModel):
    """Statistics for a tool node."""
    usageCount: int = 0
    successRate: str = "0%"
    avgProcessingTime: str = "0s"


class ToolNode(BaseModel):
    """A node in the tool graph."""
    id: str
    name: str
    category: str
    description: Optional[str] = None
    value: int = 10  # Size of node in visualization
    stats: Optional[ToolStats] = None


class ToolLink(BaseModel):
    """A link between two tool nodes."""
    source: str
    target: str
    value: int = 1  # Strength of connection


class ToolGraphResponse(BaseModel):
    """Response model for the tool graph endpoint."""
    nodes: List[ToolNode]
    links: List[ToolLink]


# Detail Schemas
class AgentDetailResponse(BaseModel):
    """Detailed information about an agent."""
    id: str
    name: str
    type: str
    description: Optional[str] = None
    capabilities: List[str] = Field(default_factory=list)
    metrics: Dict[str, Any] = Field(default_factory=dict)
    tools: List[str] = Field(default_factory=list)
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


class ToolDetailResponse(BaseModel):
    """Detailed information about a tool."""
    id: str
    name: str
    category: str
    description: Optional[str] = None
    usage_examples: List[str] = Field(default_factory=list)
    parameters: Dict[str, Any] = Field(default_factory=dict)
    stats: Dict[str, Any] = Field(default_factory=dict)
    compatible_agents: List[str] = Field(default_factory=list) 