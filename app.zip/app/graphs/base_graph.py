from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, List
from langchain.schema.language_model import BaseLanguageModel
from langchain.tools import BaseTool
from langgraph.graph import StateGraph

import logging

logger = logging.getLogger(__name__)


class BaseAgentGraph(ABC):
    """
    Abstract base class for agent graph implementations.
    Defines common interface for different pattern implementations.
    """

    def __init__(
            self,
            llm: BaseLanguageModel,
            tools: List[BaseTool] = None,
            system_prompt: Optional[str] = None,
            max_iterations: int = 5
    ):
        """
        Initialize the agent graph.

        Args:
            llm: Language model to use for agent
            tools: List of tools available to the agent
            system_prompt: System prompt for the agent
            max_iterations: Maximum number of iterations for reasoning cycles
        """
        self.llm = llm
        self.tools = tools or []
        self.system_prompt = system_prompt
        self.max_iterations = max_iterations
        self.graph = None
        logger.info(f"Initialized {self.__class__.__name__}")

    @abstractmethod
    async def build(self) -> StateGraph:
        """
        Build the agent graph.

        Returns:
            Compiled StateGraph
        """
        pass

    @abstractmethod
    async def run(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Run the agent graph with input data.

        Args:
            input_data: Input data for the agent

        Returns:
            Output from the agent
        """
        pass

    def get_tool_by_name(self, name: str) -> Optional[BaseTool]:
        """
        Get a tool by name.

        Args:
            name: Tool name

        Returns:
            Tool if found, None otherwise
        """
        for tool in self.tools:
            if tool.name.lower() == name.lower():
                return tool
        return None