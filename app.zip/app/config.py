import os
from dotenv import load_dotenv
from pydantic_settings import BaseSettings

# Load environment variables from .env file
load_dotenv()


class Settings(BaseSettings):
    # App configuration
    APP_NAME: str = "Agent-Based Chatbot"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = os.getenv("DEBUG", "False").lower() == "true"

    # API Keys
    ANTHROPIC_API_KEY: str = os.getenv("ANTHROPIC_API_KEY", "")
    OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "")

    # Vector DB configuration
    VECTOR_DB_DIR: str = os.getenv("VECTOR_DB_DIR", "./data/vector_db")
    EMBEDDING_TYPE: str = os.getenv("EMBEDDING_TYPE", "chroma_basic")  # Options: "chroma_basic", "openai"
    # In app/config.py
    DOCUMENT_DIR: str = os.getenv("DOCUMENT_DIR", "./data/documents")
    # Model configuration
    ANTHROPIC_MODEL: str = os.getenv("ANTHROPIC_MODEL", "claude-3-opus-20240229")

    # Chat memory configuration
    MAX_CHAT_SESSIONS: int = int(os.getenv("MAX_CHAT_SESSIONS", "1000"))
    CHAT_SESSION_TTL: int = int(os.getenv("CHAT_SESSION_TTL", "86400"))  # 24 hours in seconds

    # Server settings
    HOST: str = os.getenv("HOST", "0.0.0.0")
    PORT: int = int(os.getenv("PORT", "8000"))

    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()