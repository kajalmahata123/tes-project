import logging
from typing import List, Dict, Any, Optional
from langchain_anthropic import ChatAnthropic
from langchain.schema import BaseMessage, HumanMessage, AIMessage
from langchain.memory import ConversationBufferMemory
from app.agents.base_agent import BaseAgent
from app.config import get_settings
from app.llm.llm_service import create_llm_instance
from app.schemas.chat_schemas import ChatMessage
from app.schemas.agent_schemas import AgentConfig
from app.graphs.react_graph import create_react_graph
from app.tools.documentation_tool import DocumentationTool
import time

logger = logging.getLogger(__name__)


class VisaApiAgent(BaseAgent):
    """
    Agent specialized for handling Visa API documentation queries.
    Implements the ReAct pattern for reasoning and tool usage.
    """

    def __init__(self, config: AgentConfig):
        """
        Initialize Visa API agent.

        Args:
            config: Agent configuration
        """
        super().__init__(config)
        self.llm = None
        self.memory = None
        self.doc_tool = None

    async def initialize(self) -> None:
        """Initialize agent resources."""
        # Initialize LLM
        self.llm = self.initialize_llm(temperature=0.2)

        # Initialize memory
        self.memory = ConversationBufferMemory(
            memory_key="chat_history",
            return_messages=True,
            input_key="input",
            output_key="output"
        )

        # Initialize tools
        self.doc_tool = DocumentationTool(
            knowledge_base=self.config.knowledge_base,
            top_k=5
        )

        # Add tools to config
        if not self.tools:
            self.tools = [self.doc_tool]

        # Create the agent graph
        self.agent_graph = await create_react_graph(
            llm=self.llm,
            tools=[self.doc_tool],
            system_prompt=self._get_system_prompt()
        )

        logger.info(f"Initialized {self.__class__.__name__} agent")

    async def process_message(self, message: str, chat_history: List[ChatMessage]) -> str:
        """
        Process a message using the agent graph.

        Args:
            message: User message to process
            chat_history: Chat history for context

        Returns:
            Agent response text
        """
        # Start timing
        start_time = time.time()
        success = True
        
        try:
            # Update memory based on chat history
            self._update_memory_from_history(chat_history)

            # Create the system prompt with context
            system_prompt = self._get_system_prompt()

            # Process the message
            logger.info(f"Processing message with {self.__class__.__name__} agent")
            response = await self.agent_graph.ainvoke({
                "input": message,
                "chat_history": self.memory.buffer,
                "system_prompt": system_prompt,
                "new_request": True,
                "accumulated_knowledge": {},
                "tool_cache": {},
                "llm_cache": {}
            })

            # Clean up response (remove any tool-related formatting)
            if isinstance(response, dict) and "output" in response:
                response = response["output"]
            response = response.strip() if isinstance(response, str) else str(response)
            
            return response
        except Exception as e:
            success = False
            logger.error(f"Error processing message: {e}", exc_info=True)
            # Return a graceful error message instead of raising
            return "I'm sorry, I encountered an error processing your request. Please try again."
        finally:
            # Record metrics
            await self._record_agent_metrics(start_time, success)

    def get_memory_messages(self) -> List[BaseMessage]:
        """
        Get the current messages in the agent's memory.

        Returns:
            List of messages in memory
        """
        return self.memory.buffer if self.memory else []

    def clear_memory(self) -> None:
        """Clear the agent's conversation memory."""
        if self.memory:
            self.memory.clear()

    def _update_memory_from_history(self, chat_history: List[ChatMessage]) -> None:
        """
        Update memory with messages from chat history.

        Args:
            chat_history: List of chat messages
        """
        if not chat_history:
            return

        # Clear existing memory
        self.clear_memory()

        # Add messages from chat history
        for message in chat_history:
            if message.role == "user":
                self.memory.chat_memory.add_message(HumanMessage(content=message.content))
            elif message.role == "assistant":
                self.memory.chat_memory.add_message(AIMessage(content=message.content))

    def _get_system_prompt(self) -> str:
        """
        Create system prompt with context about Visa APIs.

        Returns:
            System prompt string
        """
        return """
        You are a helpful Visa API assistant. Your role is to help developers understand and use Visa's APIs effectively.
        
        IMPORTANT GUIDELINES:
        1. Answer questions about Visa APIs, focusing on accuracy and technical details
        2. Provide code examples when relevant, including proper authentication patterns
        3. When you don't know something, use your tools to search for information
        4. Always cite your sources when providing documentation-based answers
        5. Be concise but comprehensive - don't omit important details
        6. Format your responses using markdown for readability
        
        Remember that you can use the documentation tool to look up information about Visa APIs.
        """

    @property
    def capabilities(self) -> List[str]:
        """
        List of agent capabilities.

        Returns:
            List of capability strings
        """
        return [
            "Visa API documentation lookup",
            "API usage guidance",
            "Code examples for Visa API integration",
            "API authentication guidance",
            "Troubleshooting API issues"
        ]