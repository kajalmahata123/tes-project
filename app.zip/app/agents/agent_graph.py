import json
import logging
from typing import Dict, Any, List, Optional, TypedDict, Annotated, Literal, Union
from enum import Enum
from langchain_anthropic import ChatAnthropic
from langgraph.graph import StateGraph, END
from pydantic import BaseModel, Field
from app.services.chroma_service import ChromaService
from app.agents.document_processor import DocumentProcessorAgent
from app.agents.workflow_generator import WorkflowGeneratorAgent
from app.agents.code_generator import CodeGeneratorAgent
from app.agents.qa_system import QASystemAgent
from app.config import settings
import datetime
# Fix the import for graph visualization
#from langgraph.graph.graph import VisOptions

try:
    from IPython.display import HTML
except ImportError:
    pass  # Handle case when not in IPython environment

logger = logging.getLogger(__name__)


# Define state types
class AgentType(str, Enum):
    DOCUMENT_PROCESSOR = "document_processor"
    WORKFLOW_GENERATOR = "workflow_generator"
    CODE_GENERATOR = "code_generator"
    QA_SYSTEM = "qa_system"


class QueryType(str, Enum):
    PROCESS_DOCUMENT = "process_document"
    GENERATE_WORKFLOW = "generate_workflow"
    GENERATE_CODE = "generate_code"
    ANSWER_QUESTION = "answer_question"


class ConversationStage(str, Enum):
    """Track stages of conversation for more natural flows"""
    INITIAL = "initial"
    CLARIFYING = "clarifying"
    EXPLAINING = "explaining"
    FOLLOW_UP = "follow_up"
    REFINING = "refining"


class ChatState(BaseModel):
    """State for chat graph"""
    query_type: QueryType
    input: Dict[str, Any]
    working_memory: Dict[str, Any] = Field(default_factory=dict)
    documents: List[Dict[str, Any]] = Field(default_factory=list)
    workflow: Optional[Dict[str, Any]] = None
    code: Optional[Dict[str, Any]] = None
    answer: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    next: Optional[Union[AgentType, Literal["end"]]] = None
    conversation_stage: ConversationStage = Field(default=ConversationStage.INITIAL)
    intent_metadata: Dict[str, Any] = Field(default_factory=dict)


class AgentGraph:
    """LangGraph coordination of agents"""

    def __init__(
            self,
            llm: ChatAnthropic,
            chroma_service: ChromaService
    ):
        self.llm = llm
        self.chroma_service = chroma_service

        # Initialize agents
        self.document_processor = DocumentProcessorAgent(
            llm=llm,
            chroma_service=chroma_service,
            document_dir=settings.DOCUMENT_DIR
        )

        self.workflow_generator = WorkflowGeneratorAgent(
            llm=llm,
            chroma_service=chroma_service
        )

        self.code_generator = CodeGeneratorAgent(
            llm=llm,
            chroma_service=chroma_service
        )

        self.qa_system = QASystemAgent(
            llm=llm,
            chroma_service=chroma_service
        )

        # Initialize graph
        self.graph = self._build_graph()

    def _build_graph(self) -> StateGraph:
        """Build the agent graph"""
        # Create graph
        builder = StateGraph(ChatState)

        # Add router node and other nodes
        builder.add_node("router", self._route_query)
        builder.add_node(AgentType.DOCUMENT_PROCESSOR, self._process_document)
        builder.add_node(AgentType.WORKFLOW_GENERATOR, self._generate_workflow)
        builder.add_node(AgentType.CODE_GENERATOR, self._generate_code)
        builder.add_node(AgentType.QA_SYSTEM, self._answer_question)
        builder.add_node("format_response", self._format_response)

        # Router edges to all agents
        builder.add_conditional_edges(
            "router",
            self._route_initial_query,
            {
                AgentType.DOCUMENT_PROCESSOR: AgentType.DOCUMENT_PROCESSOR,
                AgentType.WORKFLOW_GENERATOR: AgentType.WORKFLOW_GENERATOR,
                AgentType.CODE_GENERATOR: AgentType.CODE_GENERATOR,
                AgentType.QA_SYSTEM: AgentType.QA_SYSTEM,
                "end": END
            }
        )

        # Add error handling conditional routing
        builder.add_conditional_edges(
            AgentType.DOCUMENT_PROCESSOR,
            self._handle_errors,
            {
                "retry": AgentType.DOCUMENT_PROCESSOR,
                "format_response": "format_response"
            }
        )

        # Workflow generator can route to code generator or format response
        builder.add_conditional_edges(
            AgentType.WORKFLOW_GENERATOR,
            self._route_after_workflow_generator,
            {
                AgentType.CODE_GENERATOR: AgentType.CODE_GENERATOR,
                "format_response": "format_response"
            }
        )

        # Code generator can route to qa system for explanation or format response
        builder.add_conditional_edges(
            AgentType.CODE_GENERATOR,
            self._route_after_code_generator,
            {
                AgentType.QA_SYSTEM: AgentType.QA_SYSTEM,
                "format_response": "format_response"
            }
        )

        # QA system can route to other agents or format response
        builder.add_conditional_edges(
            AgentType.QA_SYSTEM,
            self._route_after_qa,
            {
                AgentType.WORKFLOW_GENERATOR: AgentType.WORKFLOW_GENERATOR,
                AgentType.CODE_GENERATOR: AgentType.CODE_GENERATOR,
                "format_response": "format_response"
            }
        )

        # Format response always goes to END
        builder.add_edge("format_response", END)

        # Set entry point to the router
        builder.set_entry_point("router")

        # Compile the graph
        graph = builder.compile()

        # Create and save visualization
        '''try:
            # Set visualization options
            vis_options = VisOptions(
                cluster=True,  # Group agent nodes
                save_to_file="agent_graph.html"  # Save to file
            )
            # Visualize and save
            graph.visualize(vis_options)
            logger.info("Graph visualization saved to agent_graph.html")
        except Exception as e:
            logger.error(f"Failed to create visualization: {str(e)}")'''

        return graph

    def _route_query(self, state: ChatState) -> ChatState:
        """Router node that prepares state and detects conversation stage"""
        logger.info(f"Routing query: {state.query_type}")

        # Extract conversation stage indicators from user input
        message = ""
        if "question" in state.input:
            message = state.input["question"]
        elif "description" in state.input:
            message = state.input["description"]

        # Detect conversation stage
        message_lower = message.lower()

        # Check for follow-up questions
        if any(term in message_lower for term in ["can you explain", "explain", "what does this", "how does this"]):
            state.conversation_stage = ConversationStage.EXPLAINING
            state.intent_metadata["explanation_requested"] = True

        # Check for refinement requests
        elif any(term in message_lower for term in ["refine", "improve", "make it better", "optimize", "update"]):
            state.conversation_stage = ConversationStage.REFINING
            state.intent_metadata["refinement_requested"] = True

        # Check for clarification questions
        elif any(term in message_lower for term in
                 ["what do you mean", "clarify", "don't understand", "confused", "what is"]):
            state.conversation_stage = ConversationStage.CLARIFYING
            state.intent_metadata["clarification_requested"] = True

        # Check for follow-up questions
        elif any(term in message_lower for term in ["also", "additionally", "another", "next"]):
            state.conversation_stage = ConversationStage.FOLLOW_UP
            state.intent_metadata["followup_detected"] = True

        # Save chat history in working memory
        if "chat_history" in state.input:
            state.working_memory["chat_history"] = state.input["chat_history"]

        # Extract session info if available
        if "session_id" in state.input:
            state.working_memory["session_id"] = state.input["session_id"]

        return state

    def _route_initial_query(self, state: ChatState) -> str:
        """Route initial query to appropriate agent"""
        query_type = state.query_type
        logger.info(f"Initial routing for query type: {query_type}")

        # Handle follow-up or clarification based on conversation stage
        if state.conversation_stage in [ConversationStage.EXPLAINING, ConversationStage.CLARIFYING]:
            # If explaining code, route to QA
            if state.intent_metadata.get("explanation_requested") and state.input.get("context", {}).get("recent_code"):
                state.working_memory["code_to_explain"] = state.input.get("context", {}).get("recent_code")
                return AgentType.QA_SYSTEM

        # Handle refining requests
        if state.conversation_stage == ConversationStage.REFINING:
            # If refining code
            if state.input.get("context", {}).get("recent_code"):
                return AgentType.CODE_GENERATOR
            # If refining workflow
            elif state.input.get("context", {}).get("recent_workflow"):
                return AgentType.WORKFLOW_GENERATOR

        # Standard routing by query type
        if query_type == QueryType.PROCESS_DOCUMENT:
            return AgentType.DOCUMENT_PROCESSOR
        elif query_type == QueryType.GENERATE_WORKFLOW:
            return AgentType.WORKFLOW_GENERATOR
        elif query_type == QueryType.GENERATE_CODE:
            return AgentType.CODE_GENERATOR
        elif query_type == QueryType.ANSWER_QUESTION:
            return AgentType.QA_SYSTEM
        else:
            logger.warning(f"Unknown query type: {query_type}")
            state.error = f"Unknown query type: {query_type}"
            return "end"

    def _handle_errors(self, state: ChatState) -> str:
        """Handle errors and determine if we should retry or end"""
        if state.error:
            if state.input.get("retry_on_error", False):
                logger.info(f"Retrying after error: {state.error}")
                # Clear the error before retry
                state.error = None
                return "retry"
            else:
                logger.warning(f"Error encountered: {state.error}")
                state.working_memory["error_message"] = state.error
                return "format_response"
        return "format_response"

    def _route_after_workflow_generator(self, state: ChatState) -> str:
        """Route after workflow generator"""
        # Check for explicit next step in state
        if state.next:
            logger.info(f"Following explicit next step: {state.next}")
            # Check if next is a valid AgentType
            if isinstance(state.next, AgentType):
                return state.next
            elif state.next == "end":
                return "format_response"
            else:
                # Convert string to AgentType if possible
                try:
                    return AgentType(state.next)
                except ValueError:
                    logger.warning(f"Invalid next value: {state.next}")
                    return "format_response"

        # Check if code generation should follow
        if state.input.get("generate_code", False) or state.intent_metadata.get("generate_code", False):
            logger.info("Routing to code generator after workflow")

            # Prepare input for code generator
            if not "code_description" in state.working_memory and state.workflow:
                state.working_memory[
                    "code_description"] = f"Implement the workflow: {state.workflow.get('title', 'Generated Workflow')}"

            return AgentType.CODE_GENERATOR

        # Default to format response
        return "format_response"

    def _route_after_code_generator(self, state: ChatState) -> str:
        """Route after code generator"""
        # Store the generated code for potential explanations
        if state.code:
            state.working_memory["recent_code"] = state.code

        # Mark that we're coming from code generator to prevent loops
        state.working_memory["from_code_generator"] = True

        # Track transitions
        agent_transition_count = state.working_memory.get("agent_transition_count", {})
        from_code_to_qa = agent_transition_count.get("code_to_qa", 0)

        # Limit automatic transitions to QA
        if from_code_to_qa >= 1:
            logger.info(f"Reached code_to_qa transition limit ({from_code_to_qa}), stopping automatic transitions")
            return "format_response"

        # Check if explanation is explicitly requested by user
        explicit_explanation_requested = False
        if state.input.get("explain_code", False):
            explicit_explanation_requested = True
        elif state.intent_metadata.get("explanation_requested", False):
            # Check if it was from an explicit user request
            if state.input.get("question", "").lower() and any(term in state.input.get("question", "").lower()
                                                               for term in ["explain", "how does", "what does",
                                                                            "help me understand"]):
                explicit_explanation_requested = True

        if explicit_explanation_requested:
            logger.info("Routing to QA for code explanation based on explicit request")
            # Update context for QA
            state.working_memory["code_explanation_request"] = True
            state.working_memory["code_to_explain"] = state.code
            state.working_memory["in_explanation_flow"] = True

            # Prepare a question for the QA system
            if "question" not in state.input:
                state.input["question"] = f"Explain the following code: {state.code.get('code', '')[:100]}..."

            # Update transition counter
            agent_transition_count["code_to_qa"] = from_code_to_qa + 1
            state.working_memory["agent_transition_count"] = agent_transition_count

            return AgentType.QA_SYSTEM

        # Check for explicit next step
        if state.next:
            return AgentType.QA_SYSTEM if state.next == AgentType.QA_SYSTEM else "format_response"

        return "format_response"

    def _route_after_qa(self, state: ChatState) -> str:
        """Route after QA system"""
        # Store the QA response for reference
        if state.answer:
            state.working_memory["recent_qa"] = state.answer

        # Prevent circular loops between agents
        agent_transition_count = state.working_memory.get("agent_transition_count", {})

        # Track transitions from QA
        from_qa_to_code = agent_transition_count.get("qa_to_code", 0)
        from_qa_to_workflow = agent_transition_count.get("qa_to_workflow", 0)

        # Check if we're already in an explanation cycle
        if state.working_memory.get("code_explanation_request") or state.working_memory.get("in_explanation_flow"):
            logger.info("Already in explanation flow, stopping automatic transitions")
            return "format_response"

        # Check if we just came from code generator
        if state.working_memory.get("from_code_generator"):
            logger.info("Coming from code generator, avoiding circular loop")
            # Reset the flag but don't route back to code
            state.working_memory["from_code_generator"] = False
            return "format_response"

        # Check if we've already transitioned too many times (limit to 1 automatic transition)
        if from_qa_to_code >= 1 or from_qa_to_workflow >= 1:
            logger.info(
                f"Reached transition limit (code: {from_qa_to_code}, workflow: {from_qa_to_workflow}), stopping automatic transitions")
            return "format_response"

        # Only process explicit user requests, not implied ones from agent responses
        explicit_user_request = state.input.get("question", "").lower()

        # Check if user explicitly asked about implementation
        if state.answer and any(term in explicit_user_request
                                for term in ["implement this", "create workflow", "make a workflow"]):
            logger.info("QA detected explicit implementation request, routing to workflow generator")
            state.working_memory["from_qa"] = True

            # Update transition counter
            agent_transition_count["qa_to_workflow"] = from_qa_to_workflow + 1
            state.working_memory["agent_transition_count"] = agent_transition_count

            return AgentType.WORKFLOW_GENERATOR

        # Check if user explicitly asked about code generation
        if state.answer and any(term in explicit_user_request
                                for term in ["code for this", "program for this", "script for this",
                                             "implement this", "write code for this"]):
            logger.info("QA detected explicit code request, routing to code generator")
            state.working_memory["from_qa"] = True

            # Update transition counter
            agent_transition_count["qa_to_code"] = from_qa_to_code + 1
            state.working_memory["agent_transition_count"] = agent_transition_count

            return AgentType.CODE_GENERATOR

        # Check for explicit next step
        if state.next:
            try:
                return AgentType(state.next)
            except ValueError:
                if state.next == "end":
                    return "format_response"
                logger.warning(f"Invalid next value: {state.next}")

        return "format_response"

    def _format_response(self, state: ChatState) -> ChatState:
        """Format response based on conversation stage and agent outputs"""
        # If there's an error, format an error response
        if state.error:
            error_message = state.error
            state.answer = {
                "response": f"I encountered an issue: {error_message}\n\nCould you please try rephrasing your request?",
                "sources": []
            }
            return state

        # Format based on conversation stage and content
        stage = state.conversation_stage

        # Handle case when BOTH workflow AND code are present
        if state.workflow and state.code:
            workflow = state.workflow
            code = state.code

            # Start with greeting
            response_text = "I've created a workflow and implemented it in code as requested:\n\n"

            # Add workflow title and description
            response_text += f"# {workflow.get('title', 'API Workflow')}\n\n"
            response_text += f"{workflow.get('description', '')}\n\n"

            # Add steps
            for step in workflow.get("steps", []):
                response_text += f"## Step {step.get('step_number', '')}: {step.get('api_method', '')} {step.get('api_path', '')}\n"
                response_text += f"{step.get('description', '')}\n"

                if step.get('parameters'):
                    response_text += "Parameters:\n"
                    for param in step.get('parameters', []):
                        response_text += f"- {param}\n"

                response_text += f"Next Steps: {step.get('next_steps', '')}\n\n"

            # Add visualization if available
            if workflow.get("visualization"):
                response_text += "\n## Workflow Diagram\n```mermaid\n"
                response_text += workflow.get("visualization", "")
                response_text += "\n```\n"

            # Add code section with clear separation
            response_text += "\n## Implementation Code\n\n"

            # Add code description if available
            if code.get("description"):
                response_text += f"{code.get('description')}\n\n"

            # Add code block
            response_text += f"```{code.get('language', '')}\n"
            response_text += code.get("code", "")
            response_text += "\n```\n"

            # Add follow-up suggestions
            response_text += "\n**What would you like to do next?**\n"
            response_text += "- I can explain how this code implements the workflow\n"
            response_text += "- I can modify this code to add more features\n"
            response_text += "- I can refine the workflow and update the code accordingly\n"

            state.answer = {
                "response": response_text,
                "sources": []
            }

            # Return early since we've handled this special case
            return state

        # Format workflow response (no code)
        elif state.workflow:
            workflow = state.workflow

            # Start with greeting based on conversation stage
            response_text = ""
            if stage == ConversationStage.INITIAL:
                response_text = "I've created a workflow based on your requirements:\n\n"
            elif stage == ConversationStage.REFINING:
                response_text = "I've refined the workflow as requested:\n\n"
            elif stage == ConversationStage.FOLLOW_UP:
                response_text = "Here's the additional workflow you requested:\n\n"

            # Add workflow title and description
            response_text += f"# {workflow.get('title', 'API Workflow')}\n\n"
            response_text += f"{workflow.get('description', '')}\n\n"

            # Add steps
            for step in workflow.get("steps", []):
                response_text += f"## Step {step.get('step_number', '')}: {step.get('api_method', '')} {step.get('api_path', '')}\n"
                response_text += f"{step.get('description', '')}\n"

                if step.get('parameters'):
                    response_text += "Parameters:\n"
                    for param in step.get('parameters', []):
                        response_text += f"- {param}\n"

                response_text += f"Next Steps: {step.get('next_steps', '')}\n\n"

            # Add visualization if available
            if workflow.get("visualization"):
                response_text += "\n## Workflow Diagram\n```mermaid\n"
                response_text += workflow.get("visualization", "")
                response_text += "\n```\n"

            # Add follow-up suggestions
            response_text += "\n**What would you like to do next?**\n"
            response_text += "- I can generate code to implement this workflow\n"
            response_text += "- I can explain any part of this workflow in more detail\n"
            response_text += "- I can refine this workflow based on additional requirements\n"

            state.answer = {
                "response": response_text,
                "sources": []
            }

        # Format code response (no workflow)
        elif state.code:
            code = state.code

            # Start with greeting based on conversation stage
            response_text = ""
            if stage == ConversationStage.INITIAL:
                response_text = f"I've written the {code.get('language', 'code')} as requested:\n\n"
            elif stage == ConversationStage.REFINING:
                response_text = f"I've refined the {code.get('language', 'code')} as requested:\n\n"
            elif stage == ConversationStage.FOLLOW_UP:
                response_text = f"Here's the additional {code.get('language', 'code')} implementation:\n\n"

            # Add description if available
            if code.get("description"):
                response_text += f"{code.get('description')}\n\n"

            # Add code block
            response_text += f"```{code.get('language', '')}\n"
            response_text += code.get("code", "")
            response_text += "\n```\n"

            # Add follow-up suggestions
            response_text += "\n**What would you like to do next?**\n"
            response_text += "- I can explain how this code works\n"
            response_text += "- I can modify this code to add new features\n"
            response_text += "- I can optimize or refactor this code\n"

            state.answer = {
                "response": response_text,
                "sources": []
            }

        # Format QA response if it's not already formatted
        elif state.answer and isinstance(state.answer, dict) and "response" in state.answer:
            answer = state.answer
            response_text = answer.get("response", "")

            # Add conversational elements based on stage
            if stage == ConversationStage.EXPLAINING:
                if not response_text.startswith("Let me explain"):
                    response_text = f"Let me explain:\n\n{response_text}"
            elif stage == ConversationStage.CLARIFYING:
                if not response_text.startswith("To clarify"):
                    response_text = f"To clarify:\n\n{response_text}"

            # If we're explaining code, format it nicely
            if state.working_memory.get("code_explanation_request"):
                # Add explanation introduction if not present
                if not any(phrase in response_text[:100] for phrase in
                           ["Here's an explanation", "Let me explain", "This code", "The code"]):
                    response_text = f"Here's an explanation of the code:\n\n{response_text}"

            state.answer = {
                "response": response_text,
                "sources": answer.get("sources", [])
            }

        # Default response if nothing else is available
        else:
            state.answer = {
                "response": "I've processed your request, but I don't have a specific response to provide. Could you please clarify what you'd like me to do?",
                "sources": []
            }

        return state

    async def _process_document(self, state: ChatState) -> ChatState:
        """Process document node"""
        try:
            input_data = state.input
            file_path = input_data.get("file_path")
            document_type = input_data.get("document_type")
            add_to_vector_db = input_data.get("add_to_vector_db", True)

            if not file_path:
                state.error = "File path not provided"
                return state

            if document_type == "pdf":
                result = await self.document_processor.process_pdf(
                    file_path=file_path,
                    add_to_vector_db=add_to_vector_db
                )
            elif document_type == "openapi":
                result = await self.document_processor.process_openapi(
                    file_path=file_path,
                    add_to_vector_db=add_to_vector_db
                )
            else:
                state.error = f"Unsupported document type: {document_type}"
                return state

            # Update state
            state.documents.append(result)
            logger.info(f"Document processed: {file_path}")

            # Add to working memory
            state.working_memory["processed_documents"] = state.working_memory.get("processed_documents", []) + [result]

            # Create a conversational response about the document
            document_info = {
                "response": f"I've processed the {document_type} document '{file_path}'. "
                            f"The document contains {result.get('chunk_count', 'several')} chunks of information "
                            f"that I can now reference when answering your questions.",
                "sources": []
            }
            state.answer = document_info

            return state

        except Exception as e:
            logger.error(f"Error in document processor: {str(e)}")
            state.error = f"Document processing error: {str(e)}"
            return state

    async def _generate_workflow(self, state: ChatState) -> ChatState:
        """Generate workflow node with improved error handling for JSON parsing"""
        try:
            # Check if this was called from QA
            from_qa = state.working_memory.get("from_qa", False)

            input_data = state.input
            # If from QA, use the question as description
            description = input_data.get("description")
            if from_qa and not description:
                description = input_data.get("question", "")

            api_ids = input_data.get("api_ids")
            context = input_data.get("context", {})

            # Add answer from QA to context if available
            if from_qa and state.answer:
                context["qa_answer"] = state.answer.get("response", "")

            # Check for refinement
            is_refinement = state.conversation_stage == ConversationStage.REFINING
            previous_workflow = None

            if is_refinement and "recent_workflow" in state.input.get("context", {}):
                previous_workflow = state.input.get("context", {}).get("recent_workflow")
                # Add to context for the workflow generator
                context["previous_workflow"] = previous_workflow

                # Enhance description with refinement specifics
                if description:
                    description = f"Refine the previous workflow with these changes: {description}"

            if not description:
                state.error = "Workflow description not provided"
                return state

            # Call the workflow generator with additional logging
            logger.info(f"Calling workflow generator with description: {description[:100]}...")

            try:
                result = await self.workflow_generator.generate_workflow(
                    description=description,
                    api_ids=api_ids,
                    context=context
                )

                # Validate the result to ensure it's not empty or invalid JSON
                if not result:
                    raise ValueError("Workflow generator returned empty result")

                # Ensure the result has the expected structure
                if not isinstance(result, dict):
                    raise ValueError(f"Expected dict result, got {type(result)}")

                required_keys = ["workflow_id", "title", "description"]
                missing_keys = [key for key in required_keys if key not in result]
                if missing_keys:
                    raise ValueError(f"Workflow result missing required keys: {missing_keys}")

            except json.JSONDecodeError as json_err:
                logger.error(f"JSON decoding error in workflow generator: {str(json_err)}")
                # Create a fallback workflow structure
                result = {
                    "workflow_id": f"fallback-{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}",
                    "title": "Workflow (JSON Error Recovery)",
                    "description": f"A workflow based on: {description[:100]}...",
                    "steps": [],
                    "error_details": f"Original error: {str(json_err)}"
                }
                state.error = f"Warning: JSON processing error occurred. Created fallback workflow structure."
            except Exception as inner_err:
                logger.error(f"Other error in workflow generator: {str(inner_err)}")
                raise  # Re-raise for the outer exception handler

            # Update state
            state.workflow = result
            logger.info(f"Workflow generated: {result.get('workflow_id')}")

            # Store for future reference
            state.working_memory["recent_workflow"] = result

            # Check for next step in input or explicit generation flag
            if "next" in input_data:
                state.next = input_data["next"]
            elif input_data.get("generate_code", False) or state.intent_metadata.get("generate_code", False):
                # Auto-transition to code generation if requested
                state.next = AgentType.CODE_GENERATOR

                # Prepare input for code generation
                if "code_language" in input_data:
                    state.working_memory["code_language"] = input_data["code_language"]

            return state

        except Exception as e:
            logger.error(f"Error in workflow generator: {str(e)}")

            # Create a more descriptive error message
            error_message = f"Workflow generation error: {str(e)}"

            # If it's a JSON error, provide more helpful info
            if "Expecting value" in str(e):
                error_message = "The workflow generator produced invalid JSON. This usually happens when the input description is too vague or the system lacks necessary context. Please try providing more details about the workflow you need."

            state.error = error_message
            return state

    async def _generate_code(self, state: ChatState) -> ChatState:
        """Generate code node"""
        try:
            # Check if this was called from QA
            from_qa = state.working_memory.get("from_qa", False)

            input_data = state.input
            language = input_data.get("language") or state.working_memory.get(
                "code_language") or "python"  # Default to python
            workflow_id = input_data.get("workflow_id")
            api_ids = input_data.get("api_ids")

            # If from QA, use the question as description
            description = input_data.get("description")
            if from_qa and not description:
                description = input_data.get("question", "")

            # Check for workflow-derived code description
            if not description and "code_description" in state.working_memory:
                description = state.working_memory["code_description"]

            context = input_data.get("context") or {}

            # Add answer from QA to context if available
            if from_qa and state.answer:
                context["qa_answer"] = state.answer.get("response", "")

            # Check for refinement
            is_refinement = state.conversation_stage == ConversationStage.REFINING
            previous_code = None

            if is_refinement and "recent_code" in state.input.get("context", {}):
                previous_code = state.input.get("context", {}).get("recent_code")
                # Add to context for the code generator
                context["previous_code"] = previous_code

                # Enhance description with refinement specifics
                if description:
                    description = f"Refine the previous code with these changes: {description}"

            # Check if this is a follow-up about previously discussed API
            last_api_info = state.working_memory.get("last_api_info")
            if description and ("it" in description.lower() or "this api" in description.lower()) and last_api_info:
                logger.info(f"Using stored API info for code generation: {last_api_info}")

                # Enhance the description with previous API details
                if "method" in last_api_info and "path" in last_api_info:
                    enhanced_description = f"Code for {last_api_info['method']} {last_api_info['path']} API. {description}"
                else:
                    enhanced_description = f"Code for the API discussed in the previous question. {description}"

                # Update description
                description = enhanced_description

                # Add the previous API response to context for more information
                context["previous_api_response"] = last_api_info.get("response_text", "")
                context["previous_api_question"] = last_api_info.get("question", "")

            # Use workflow from state if available
            workflow = None
            if state.workflow:
                workflow = state.workflow
                workflow_id = workflow.get("workflow_id")

            result = await self.code_generator.generate_code(
                language=language,
                workflow_id=workflow_id,
                api_ids=api_ids,
                description=description or (workflow.get("description") if workflow else None),
                context=context
            )

            # Update state
            state.code = result
            logger.info(f"Code generated in {language}")

            # Store for future reference
            state.working_memory["recent_code"] = result

            # Check for next step in input
            if "next" in input_data:
                state.next = input_data["next"]
            elif input_data.get("explain_code", False) or state.intent_metadata.get("explanation_requested", False):
                # Auto-transition to QA for explanation if requested
                state.next = AgentType.QA_SYSTEM

            return state

        except Exception as e:
            logger.error(f"Error in code generator: {str(e)}")
            state.error = f"Code generation error: {str(e)}"
            return state

    async def _answer_question(self, state: ChatState) -> ChatState:
        """Answer question node"""
        try:
            input_data = state.input
            question = input_data.get("question")
            chat_history = input_data.get("chat_history")
            context = input_data.get("context", {})

            # If we're explaining code, add it to the context
            if state.working_memory.get("code_explanation_request") or state.intent_metadata.get(
                    "explanation_requested"):
                code_to_explain = state.working_memory.get("code_to_explain") or context.get("recent_code")
                if code_to_explain and "code" in code_to_explain:
                    context["code_to_explain"] = code_to_explain["code"]
                    if not question:
                        question = f"Please explain this code: {code_to_explain['code'][:100]}..."

            # If we're clarifying, use specific prompting
            if state.conversation_stage == ConversationStage.CLARIFYING:
                if not context.get("clarification_context"):
                    # Try to extract what needs clarification
                    terms_to_check = ["what is", "what are", "what does", "how do", "explain"]
                    for term in terms_to_check:
                        if term in question.lower():
                            context["clarification_context"] = f"The user is asking for clarification about: {question}"
                            break

            if not question:
                state.error = "Question not provided"
                return state

            result = await self.qa_system.answer_question(
                question=question,
                chat_history=chat_history,
                context=context
            )

            # Update state
            state.answer = result
            logger.info(f"Question answered: {question[:50]}...")

            # Store API details in working memory if the question is about an API
            if any(term in question.lower() for term in ["api", "endpoint", "route", "method"]):
                # Extract API information from response
                response_text = result.get("response", "")

                # Try to extract API method and path using regex
                import re
                method_match = re.search(r'(GET|POST|PUT|DELETE|PATCH)\s+([/\w{}]+)', response_text)

                api_info = {
                    "question": question,
                    "response_text": response_text,
                    "timestamp": datetime.datetime.now().isoformat(),
                    "sources": result.get("sources", [])
                }

                if method_match:
                    api_info["method"] = method_match.group(1)
                    api_info["path"] = method_match.group(2)

                # Store in working memory
                state.working_memory["last_api_info"] = api_info

            # Check for next step in input
            if "next" in input_data:
                state.next = input_data["next"]
            # Check for implementation request in question
            elif question and any(term in question.lower() for term in
                                  ["implement", "create code", "generate code", "write code"]):
                state.next = AgentType.CODE_GENERATOR
            # Check for workflow request in question
            elif question and any(term in question.lower() for term in
                                  ["workflow", "process flow", "steps to"]):
                state.next = AgentType.WORKFLOW_GENERATOR

            return state

        except Exception as e:
            logger.error(f"Error in QA system: {str(e)}")
            state.error = f"Question answering error: {str(e)}"
            return state

    async def invoke(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Invoke the agent graph

        Args:
            input_data: Input data for the graph

        Returns:
            Result of graph execution
        """
        # Initialize state
        query_type_str = input_data.get("query_type")
        if not query_type_str:
            raise ValueError("query_type not provided")

        try:
            query_type = QueryType(query_type_str)
        except ValueError:
            raise ValueError(f"Invalid query_type: {query_type_str}")

        # Create initial state
        state = ChatState(
            query_type=query_type,
            input=input_data,
            conversation_stage=ConversationStage.INITIAL,
            intent_metadata={}
        )

        # Check for conversation stage indicators in input
        if input_data.get("context", {}).get("conversation_stage"):
            try:
                state.conversation_stage = ConversationStage(input_data["context"]["conversation_stage"])
            except ValueError:
                # Invalid stage, use default
                pass

        # Parse intent metadata if available
        if input_data.get("context", {}).get("intent_metadata"):
            state.intent_metadata = input_data["context"]["intent_metadata"]

        # Execute graph
        result = await self.graph.ainvoke(state)

        # Prepare result for return
        if hasattr(result, 'dict'):
            # Save conversation state for next interaction
            result_dict = result.dict()

            # Add conversation metadata to be saved in session
            if "context_updates" not in result_dict:
                result_dict["context_updates"] = {}

            # Save conversation stage
            result_dict["context_updates"]["conversation_stage"] = result.conversation_stage

            # Save recent content references
            if result.workflow:
                result_dict["context_updates"]["recent_workflow"] = result.workflow
            if result.code:
                result_dict["context_updates"]["recent_code"] = result.code

            return result_dict
        elif hasattr(result, 'model_dump'):
            # For Pydantic v2
            result_dict = result.model_dump()

            # Add conversation metadata
            if "context_updates" not in result_dict:
                result_dict["context_updates"] = {}

            result_dict["context_updates"]["conversation_stage"] = result.conversation_stage

            if result.workflow:
                result_dict["context_updates"]["recent_workflow"] = result.workflow
            if result.code:
                result_dict["context_updates"]["recent_code"] = result.code

            return result_dict
        else:
            return dict(result)