from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional
from langchain.schema import BaseMessage
import logging
import time
from app.schemas.chat_schemas import ChatMessage
from app.schemas.agent_schemas import AgentConfig
from app.llm.llm_service import create_llm_instance
from app.services.metrics_service import MetricsService
logger = logging.getLogger(__name__)


class BaseAgent(ABC):
    """
    Abstract base class for all agents in the system.
    Provides common functionality and required interface methods.
    """

    def __init__(self, config: AgentConfig):
        """
        Initialize the base agent with configuration.

        Args:
            config: Agent configuration parameters
        """
        self.config = config
        self.name = config.name
        self.tools = config.tools
        self.agent_graph = None
        self.llm = None
        self.metrics_service = MetricsService()
        logger.info(f"Initialized {self.__class__.__name__} with name '{self.name}'")

    def initialize_llm(self, temperature: Optional[float] = None, max_tokens: Optional[int] = None, model: Optional[str] = None):
        """
        Initialize the LLM instance with custom parameters.
        
        Args:
            temperature: Temperature for text generation (lower for more deterministic outputs)
            max_tokens: Maximum tokens to generate in responses
            model: Model name to use
            
        Returns:
            Initialized LLM instance
        """
        return create_llm_instance(
            temperature=temperature,
            max_tokens=max_tokens,
            model=model
        )

    @abstractmethod
    async def initialize(self) -> None:
        """
        Initialize agent resources like LLMs, memory, etc.
        Should be called before the agent is used.
        """
        pass

    @abstractmethod
    async def process_message(self, message: str, chat_history: List[ChatMessage]) -> str:
        """
        Process a user message and generate a response.

        Args:
            message: User message text
            chat_history: List of previous messages in the conversation

        Returns:
            Agent response text
        """
        pass

    async def _record_agent_metrics(self, start_time: float, success: bool) -> None:
        """
        Record metrics for agent usage.
        
        Args:
            start_time: Start time of processing (timestamp)
            success: Whether processing was successful
        """
        processing_time = time.time() - start_time
        try:
            await self.metrics_service.record_agent_usage(
                agent_id=self.config.id if hasattr(self.config, 'id') else self.name,
                success=success,
                response_time=processing_time
            )
        except Exception as e:
            logger.error(f"Failed to record agent metrics: {e}", exc_info=True)

    async def use_tool(self, tool_id: str, params: Dict[str, Any]) -> Any:
        """
        Use a tool and record metrics.
        
        Args:
            tool_id: ID of the tool to use
            params: Parameters to pass to the tool
            
        Returns:
            Tool execution result
        """
        start_time = time.time()
        success = True
        
        try:
            # Find tool
            tool = None
            for t in self.tools:
                if (hasattr(t, 'id') and t.id == tool_id) or (hasattr(t, 'name') and t.name == tool_id):
                    tool = t
                    break
            
            if not tool:
                raise ValueError(f"Tool {tool_id} not found")
            
            # Execute tool
            if hasattr(tool, 'run'):
                result = await tool.run(**params)
            elif hasattr(tool, 'execute'):
                result = await tool.execute(**params)
            else:
                # Fallback to direct calling
                result = await tool(**params)
                
            return result
            
        except Exception as e:
            success = False
            logger.error(f"Error using tool {tool_id}: {e}", exc_info=True)
            raise
        finally:
            # Record metrics regardless of success/failure
            processing_time = time.time() - start_time
            try:
                await self.metrics_service.record_tool_usage(
                    tool_id=tool_id,
                    agent_id=self.config.id if hasattr(self.config, 'id') else self.name,
                    success=success,
                    processing_time=processing_time
                )
            except Exception as e:
                logger.error(f"Failed to record tool metrics: {e}", exc_info=True)

    @abstractmethod
    def get_memory_messages(self) -> List[BaseMessage]:
        """
        Get the current messages in the agent's memory.

        Returns:
            List of messages in memory
        """
        pass

    @abstractmethod
    def clear_memory(self) -> None:
        """Clear the agent's conversation memory."""
        pass

    @property
    def capabilities(self) -> List[str]:
        """
        List of agent capabilities.

        Returns:
            List of capability strings
        """
        return []

    def get_metadata(self) -> Dict[str, Any]:
        """
        Get agent metadata for client usage.

        Returns:
            Dictionary of agent metadata
        """
        return {
            "name": self.name,
            "type": self.__class__.__name__,
            "capabilities": self.capabilities,
            "tools": [tool.name for tool in self.tools] if self.tools else []
        }

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(name='{self.name}')"