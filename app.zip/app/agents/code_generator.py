import uuid
import logging
from typing import Dict, Any, List, Optional

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_anthropic import ChatAnthropic

from app.services.chroma_service import ChromaService

logger = logging.getLogger(__name__)


class CodeGeneratorAgent:
    """Agent for generating client code for APIs"""

    def __init__(
            self,
            llm: ChatAnthropic,
            chroma_service: ChromaService
    ):
        self.llm = llm
        self.chroma_service = chroma_service

        # Supported programming languages
        self.supported_languages = [
            "python", "javascript", "typescript", "java",
            "csharp", "go", "rust", "ruby", "php"
        ]

    async def generate_code(
            self,
            language: str,
            workflow_id: Optional[str] = None,
            api_ids: Optional[List[str]] = None,
            description: Optional[str] = None,
            context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Generate client code for APIs

        Args:
            language: Programming language for generated code
            workflow_id: Optional workflow ID to generate code for
            api_ids: Optional list of API IDs to include
            description: Optional description of functionality
            context: Optional additional context

        Returns:
            Generated code
        """
        logger.info(f"Generating {language} code for workflow: {workflow_id}")

        # Validate language
        language = language.lower()
        if language not in self.supported_languages:
            raise ValueError(
                f"Unsupported language: {language}. Supported languages: {', '.join(self.supported_languages)}")

        # Get workflow details if provided
        workflow = None
        if workflow_id:
            # In a real implementation, retrieve workflow from database
            # For now, just include placeholder logic
            workflow = {"workflow_id": workflow_id, "steps": []}

        # Retrieve API details
        api_details = []

        if api_ids:
            # Retrieve API details by IDs
            # In a real implementation, retrieve from database
            pass
        elif description:
            # Retrieve relevant API documentation from vector DB
            relevant_docs = self._retrieve_relevant_docs(description)
            api_details = self._extract_api_details(relevant_docs)

        # Generate code using Claude
        code_result = await self._generate_code_with_claude(
            language=language,
            api_details=api_details,
            workflow=workflow,
            description=description,
            context=context
        )

        return code_result

    def _retrieve_relevant_docs(self, query: str) -> List[Dict[str, Any]]:
        """Retrieve relevant API documentation from vector DB"""
        # Query vector DB for relevant documents
        results = self.chroma_service.query(
            query_text=query,
            n_results=10,
            where={"type": {"$in": ["api_endpoint", "pdf_api", "openapi"]}}
        )

        docs = []

        # Format results
        for i in range(len(results["documents"][0])):
            docs.append({
                "document": results["documents"][0][i],
                "metadata": results["metadatas"][0][i] if results["metadatas"] else {},
                "id": results["ids"][0][i] if results["ids"] else None,
            })

        return docs

    def _extract_api_details(self, relevant_docs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Extract API details from relevant documents"""
        api_details = []

        for doc in relevant_docs:
            if doc["metadata"].get("type") in ["api_endpoint", "pdf_api", "openapi"]:
                api_detail = {
                    "path": doc["metadata"].get("api_path") or doc["metadata"].get("path", ""),
                    "method": doc["metadata"].get("api_method") or doc["metadata"].get("method", ""),
                    "description": "",
                    "parameters": [],
                    "document_id": doc["metadata"].get("document_id", ""),
                    "document_name": doc["metadata"].get("document_name", "")
                }

                # Extract description and parameters from document text
                document_text = doc["document"]

                # Simple parsing based on common patterns
                if "Description:" in document_text:
                    desc_start = document_text.find("Description:") + len("Description:")
                    desc_end = document_text.find("\n", desc_start)
                    if desc_end == -1:
                        desc_end = len(document_text)
                    api_detail["description"] = document_text[desc_start:desc_end].strip()

                if "Parameters:" in document_text:
                    params_start = document_text.find("Parameters:") + len("Parameters:")
                    params_end = document_text.find("\n\n", params_start)
                    if params_end == -1:
                        params_end = len(document_text)

                    params_text = document_text[params_start:params_end].strip()
                    params = []
                    for param_line in params_text.split("\n"):
                        param = param_line.strip()
                        if param.startswith("-") or param.startswith("*"):
                            param = param[1:].strip()
                        if param:
                            params.append(param)

                    api_detail["parameters"] = params

                api_details.append(api_detail)

        return api_details

    async def _generate_code_with_claude(
            self,
            language: str,
            api_details: List[Dict[str, Any]],
            workflow: Optional[Dict[str, Any]] = None,
            description: Optional[str] = None,
            context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Generate code using Claude"""
        # Prepare API descriptions
        api_descriptions = []

        for api in api_details:
            api_str = (
                f"Path: {api['path']}\n"
                f"Method: {api['method']}\n"
                f"Description: {api['description']}\n"
                f"Parameters: {', '.join(api['parameters'])}\n"
            )
            api_descriptions.append(api_str)

        # Join API descriptions with separators
        apis_text = "\n---\n".join(api_descriptions)

        # Prepare workflow description if available
        workflow_text = ""
        if workflow:
            workflow_text = "The code should implement this workflow:\n\n"

            for step in workflow.get("steps", []):
                step_number = step.get("step_number", 0)
                api_method = step.get("api_method", "")
                api_path = step.get("api_path", "")
                step_desc = step.get("description", "")

                workflow_text += f"Step {step_number}: {api_method} {api_path} - {step_desc}\n"

        # Prepare context text
        context_text = ""
        if context:
            context_text = "Additional context:\n"
            for key, value in context.items():
                context_text += f"{key}: {value}\n"

        # Prepare description text
        description_text = f"Purpose: {description}\n" if description else ""

        # Prepare prompt for Claude
        prompt = f"""
        Generate {language} client code that interacts with the following APIs:

        {apis_text}

        {description_text}
        {workflow_text}
        {context_text}

        The code should:
        1. Be well-structured and follow best practices for {language}
        2. Include error handling
        3. Include appropriate comments
        4. Use modern language features
        5. Be production-ready

        Please provide the complete implementation. Do not omit any code.
        """

        try:
            # Query Claude
            messages = [
                SystemMessage(content=f"You are an expert {language} developer who writes clean, efficient code."),
                HumanMessage(content=prompt)
            ]

            response = await self.llm.ainvoke(messages)
            response_text = response.content

            # Extract code from response
            import re

            # Try to extract code block
            code_match = re.search(f"```{language}\n(.*?)```", response_text, re.DOTALL)
            if code_match:
                code = code_match.group(1)
            else:
                # Try with just triple backticks
                code_match = re.search(r"```\n(.*?)```", response_text, re.DOTALL)
                if code_match:
                    code = code_match.group(1)
                else:
                    # Use the full response if no code blocks found
                    code = response_text

            # Create code result
            code_result = {
                "code_id": str(uuid.uuid4()),
                "language": language,
                "code": code,
                "workflow_id": workflow.get("workflow_id") if workflow else None,
                "description": description,
                "metadata": {
                    "api_count": len(api_details),
                    "original_query": description
                }
            }

            return code_result

        except Exception as e:
            logger.error(f"Error generating code: {str(e)}")
            raise