import os
import uuid
import logging
from typing import Dict, Any, List, Optional, Tuple

from langchain.schema import Document
from langchain_core.messages import HumanMessage, SystemMessage
from langchain_anthropic import ChatAnthropic

from app.services.pdf_parser import PDFParser
from app.services.openapi_parser import OpenAPIParser
from app.services.chroma_service import ChromaService

logger = logging.getLogger(__name__)

class DocumentProcessorAgent:
    """Agent for processing documents and extracting structured information"""

    def __init__(
        self,
        llm: ChatAnthropic,
        chroma_service: ChromaService,
        document_dir: str
    ):
        self.llm = llm
        self.chroma_service = chroma_service
        self.document_dir = document_dir
        self.pdf_parser = PDFParser()
        self.openapi_parser = OpenAPIParser()

        # Ensure document directory exists
        os.makedirs(document_dir, exist_ok=True)

    async def process_pdf(
        self,
        file_path: str,
        add_to_vector_db: bool = True
    ) -> Dict[str, Any]:
        """
        Process a PDF document

        Args:
            file_path: Path to PDF file
            add_to_vector_db: Whether to add to vector database

        Returns:
            Dictionary with processing results
        """
        logger.info(f"Processing PDF document: {file_path}")

        try:
            # Parse PDF
            pdf_data = self.pdf_parser.parse_pdf(file_path)

            # Extract API information from chunks
            api_info = self.pdf_parser.extract_api_information(pdf_data["chunks"])

            # Enhance API information with Claude
            enhanced_api_info = await self._enhance_api_info(api_info, pdf_data["chunks"])

            result = {
                "document_id": str(uuid.uuid4()),
                "document_type": "pdf",
                "document_name": pdf_data["metadata"]["title"],
                "metadata": pdf_data["metadata"],
                "toc": pdf_data["toc"],
                "chunks_count": len(pdf_data["chunks"]),
                "api_info": enhanced_api_info,
                "vector_db_added": False
            }

            # Add to vector database if requested
            if add_to_vector_db:
                vector_docs = []

                # Add chunks to vector documents
                for chunk in pdf_data["chunks"]:
                    vector_docs.append({
                        "text": chunk["text"],
                        "metadata": {
                            "document_id": result["document_id"],
                            "document_name": pdf_data["metadata"]["title"],
                            "chunk_index": chunk["chunk_index"],
                            "document_type": "pdf",
                            "page": self._extract_page_from_chunk(chunk["text"])
                        }
                    })

                # Add API info to vector documents
                for api in enhanced_api_info:
                    api_text = (
                        f"API: {api['method']} {api['path']}\n"
                        f"Description: {api['description']}\n"
                        f"Parameters: {', '.join(api['parameters'])}\n"
                    )

                    vector_docs.append({
                        "text": api_text,
                        "metadata": {
                            "document_id": result["document_id"],
                            "document_name": pdf_data["metadata"]["title"],
                            "document_type": "pdf_api",
                            "api_method": api["method"],
                            "api_path": api["path"]
                        }
                    })

                # Add to vector DB
                texts = [doc["text"] for doc in vector_docs]
                metadatas = [doc["metadata"] for doc in vector_docs]

                self.chroma_service.add_documents(
                    documents=texts,
                    metadatas=metadatas
                )

                result["vector_db_added"] = True

            return result

        except Exception as e:
            logger.error(f"Error processing PDF document: {str(e)}")
            raise

    async def process_openapi(
        self,
        file_path: str,
        add_to_vector_db: bool = True
    ) -> Dict[str, Any]:
        """
        Process an OpenAPI specification file

        Args:
            file_path: Path to OpenAPI file
            add_to_vector_db: Whether to add to vector database

        Returns:
            Dictionary with processing results
        """
        logger.info(f"Processing OpenAPI document: {file_path}")

        try:
            # Parse OpenAPI spec
            spec = self.openapi_parser.parse_spec(file_path)

            # Extract endpoints
            endpoints = self.openapi_parser.extract_endpoints(spec)

            result = {
                "document_id": str(uuid.uuid4()),
                "document_type": "openapi",
                "document_name": spec["info"].get("title", os.path.basename(file_path)),
                "metadata": {
                    "title": spec["info"].get("title", ""),
                    "version": spec["info"].get("version", ""),
                    "description": spec["info"].get("description", ""),
                    "file_name": os.path.basename(file_path),
                    "file_path": file_path
                },
                "endpoints_count": len(endpoints),
                "endpoints": endpoints,
                "vector_db_added": False
            }

            # Add to vector database if requested
            if add_to_vector_db:
                # Prepare for vector DB
                vector_docs = self.openapi_parser.prepare_for_vector_db(spec)

                # Add document ID to metadata
                for doc in vector_docs:
                    doc["metadata"]["document_id"] = result["document_id"]
                    doc["metadata"]["document_name"] = result["document_name"]

                # Add to vector DB
                texts = [doc["text"] for doc in vector_docs]
                metadatas = [doc["metadata"] for doc in vector_docs]

                self.chroma_service.add_documents(
                    documents=texts,
                    metadatas=metadatas
                )

                result["vector_db_added"] = True

            return result

        except Exception as e:
            logger.error(f"Error processing OpenAPI document: {str(e)}")
            raise

    async def _enhance_api_info(
        self,
        api_info: List[Dict[str, Any]],
        chunks: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Enhance API information with Claude"""
        if not api_info:
            return []

        # Get chunks by index to provide context for each API
        chunks_by_index = {chunk["chunk_index"]: chunk["text"] for chunk in chunks}

        enhanced_api_info = []

        for api in api_info:
            # Get chunk text for context
            chunk_text = chunks_by_index.get(api["chunk_index"], "")

            # Prepare prompt for Claude
            prompt = f"""
            I have extracted an API endpoint from a document. Please help enhance the information by filling in missing details. The format is:
            
            Method: {api['method']}
            Path: {api['path']}
            Current description: {api['description']}
            Current parameters: {api['parameters']}
            
            Here is the context from the document where this API was mentioned:
            
            {chunk_text}
            
            Please provide:
            1. A more complete and clear description of what this API does
            2. A comprehensive list of parameters with their data types and whether they are required
            3. Any noted responses or status codes
            4. Any additional details that might be relevant
            
            Format your response as a JSON object with these keys: description, parameters, responses, additional_details
            """

            try:
                # Query Claude
                messages = [
                    SystemMessage(content="You are a helpful assistant that extracts and enhances API information from documentation."),
                    HumanMessage(content=prompt)
                ]

                response = await self.llm.ainvoke(messages)
                response_text = response.content

                # Extract JSON from response (Claude might wrap it in ```json``` blocks)
                import json
                import re

                # Try to extract JSON block if present
                json_match = re.search(r'```json\n(.*?)\n```', response_text, re.DOTALL)
                if json_match:
                    json_str = json_match.group(1)
                else:
                    json_str = response_text

                # Clean up and parse JSON
                try:
                    enhanced_data = json.loads(json_str)
                except json.JSONDecodeError:
                    # If JSON parsing fails, use regex to extract fields
                    description_match = re.search(r'"description":\s*"([^"]*)"', json_str)
                    parameters_match = re.search(r'"parameters":\s*(\[[^\]]*\])', json_str)

                    enhanced_data = {
                        "description": description_match.group(1) if description_match else api["description"],
                        "parameters": json.loads(parameters_match.group(1)) if parameters_match else api["parameters"],
                        "responses": [],
                        "additional_details": ""
                    }

                # Update API info
                api_copy = api.copy()
                api_copy["description"] = enhanced_data.get("description", api["description"])
                api_copy["parameters"] = enhanced_data.get("parameters", api["parameters"])
                api_copy["responses"] = enhanced_data.get("responses", [])
                api_copy["additional_details"] = enhanced_data.get("additional_details", "")

                enhanced_api_info.append(api_copy)

            except Exception as e:
                logger.error(f"Error enhancing API info: {str(e)}")
                # Return original if enhancement fails
                enhanced_api_info.append(api)

        return enhanced_api_info

    def _extract_page_from_chunk(self, chunk_text: str) -> Optional[int]:
        """Extract page number from chunk text based on page markers"""
        import re

        page_match = re.search(r'--- Page (\d+) ---', chunk_text)
        if page_match:
            return int(page_match.group(1))

        return None
