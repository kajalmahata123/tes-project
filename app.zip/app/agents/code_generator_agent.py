import logging
from typing import List, Dict, Any, Optional
from langchain_anthropic import ChatAnthropic
from langchain.schema import BaseMessage, HumanMessage, AIMessage, SystemMessage
from langchain.memory import ConversationBufferMemory
from app.agents.base_agent import BaseAgent
from app.schemas.chat_schemas import ChatMessage
from app.schemas.agent_schemas import AgentConfig
from app.tools.documentation_tool import DocumentationTool
from app.graphs.react_graph import create_react_graph

logger = logging.getLogger(__name__)


class CodeGeneratorAgent(BaseAgent):
    """
    Agent specialized for generating client code for API endpoints.
    Generates code examples in multiple programming languages.
    """

    def __init__(self, config: AgentConfig):
        """
        Initialize Code Generator agent.

        Args:
            config: Agent configuration
        """
        super().__init__(config)
        self.llm = None
        self.memory = None
        self.doc_tool = None
        self.supported_languages = [
            "python", "javascript", "java", "csharp", "go",
            "ruby", "php", "typescript", "curl", "powershell"
        ]

    async def initialize(self) -> None:
        """Initialize agent resources."""
        # Initialize LLM
        self.llm = self.initialize_llm(
            temperature=0.1,  # Lower temperature for code generation
            max_tokens=8192  # Higher token limit for code generation
        )

        # Initialize memory
        self.memory = ConversationBufferMemory(
            memory_key="chat_history",
            return_messages=True,
            input_key="input",
            output_key="output"
        )

        # Initialize tools
        self.doc_tool = DocumentationTool(
            knowledge_base=self.config.knowledge_base,
            top_k=5
        )

        # Set up tools list
        self.tools = [self.doc_tool]

        # Create the agent graph using LangGraph
        self.agent_graph = await create_react_graph(
            llm=self.llm,
            tools=self.tools,
            system_prompt=self._get_system_prompt()
        )

        logger.info(f"Initialized {self.__class__.__name__} with {len(self.tools)} tools")

    async def process_message(self, message: str, chat_history: List[ChatMessage]) -> str:
        """
        Process user message and return agent response.

        Args:
            message: User message text
            chat_history: List of previous chat messages

        Returns:
            Agent response text with code examples
        """
        logger.info(f"Processing code generation request: {message[:50]}...")

        # Convert chat history to memory format if not already in memory
        if chat_history:
            self._update_memory_from_history(chat_history)

        # Get current memory messages to provide as context
        memory_messages = self.get_memory_messages()

        # Parse language preference from message
        language_pref = self._extract_language_preference(message)

        # Execute the ReAct agent graph
        try:
            # Add language preference to input if detected
            enhanced_input = message
            if language_pref and language_pref not in message:
                enhanced_input = f"{message} (Generate code in {language_pref})"

            result = await self.agent_graph.ainvoke({
                "input": enhanced_input,
                "chat_history": memory_messages
            })

            response = result.get("output", "I'm sorry, I couldn't generate the code.")

            # Update memory with this exchange
            self.memory.chat_memory.add_user_message(message)
            self.memory.chat_memory.add_ai_message(response)

            return response

        except Exception as e:
            logger.error(f"Error in code generation: {e}", exc_info=True)
            return "I encountered an error while generating the code. Please try again with a more specific request."

    def get_memory_messages(self) -> List[BaseMessage]:
        """
        Get messages from memory.

        Returns:
            List of messages from memory
        """
        if not self.memory:
            return []
        return self.memory.chat_memory.messages

    def clear_memory(self) -> None:
        """Clear conversation memory."""
        if self.memory:
            self.memory.clear()

    def _update_memory_from_history(self, chat_history: List[ChatMessage]) -> None:
        """
        Update memory with chat history.

        Args:
            chat_history: List of chat messages
        """
        # Clear existing memory
        self.clear_memory()

        # Add messages to memory
        for msg in chat_history:
            if msg.role == "user":
                self.memory.chat_memory.add_user_message(msg.content)
            elif msg.role == "assistant":
                self.memory.chat_memory.add_ai_message(msg.content)

    def _extract_language_preference(self, message: str) -> Optional[str]:
        """
        Extract programming language preference from message.

        Args:
            message: User message

        Returns:
            Language name if found, None otherwise
        """
        message = message.lower()

        # Check for explicit mentions of programming languages
        for lang in self.supported_languages:
            if lang in message:
                return lang

        return None

    def _get_system_prompt(self) -> str:
        """
        Get system prompt for the agent.

        Returns:
            System prompt string
        """
        return """You are a specialized AI assistant focused on generating high-quality API client code. 
Your purpose is to help developers implement client code for API integrations.

When generating code:
1. First, search the API documentation to understand the endpoint details.
2. Generate complete, production-ready code examples.
3. Include proper error handling, authentication, and best practices.
4. Add comprehensive comments explaining the code.
5. Structure the code for readability and maintainability.
6. Include sample usage where appropriate.

You can generate code in multiple languages including Python, JavaScript, TypeScript, Java, C#, Go, Ruby, PHP, curl, and PowerShell.

Important guidelines:
- Always include proper authentication in the examples.
- Always add error handling.
- Include clear comments explaining each section of code.
- Follow language-specific best practices and conventions.
- Generate complete, functional code that can be directly copied and used.
- Make sure to include any required imports or dependencies.
- For HTTP requests, use the most appropriate libraries for each language.

Remember that you cannot make actual API calls - you are only generating example code.
"""

    @property
    def capabilities(self) -> List[str]:
        """
        List agent capabilities.

        Returns:
            List of capability strings
        """
        return [
            "Generate client code for API endpoints",
            f"Support for {', '.join(self.supported_languages)} code examples",
            "Include authentication, error handling, and best practices",
            "Provide commented code for educational purposes",
            "Generate complete, runnable examples"
        ]