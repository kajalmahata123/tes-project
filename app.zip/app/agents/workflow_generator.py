import uuid
import logging
from typing import Dict, Any, List, Optional

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_anthropic import ChatAnthropic

from app.services.chroma_service import ChromaService

logger = logging.getLogger(__name__)


class WorkflowGeneratorAgent:
    """Agent for generating API workflows based on user queries"""

    def __init__(
            self,
            llm: ChatAnthropic,
            chroma_service: ChromaService
    ):
        self.llm = llm
        self.chroma_service = chroma_service

    async def generate_workflow(
            self,
            description: str,
            api_ids: Optional[List[str]] = None,
            context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Generate an API workflow based on description

        Args:
            description: Description of the workflow to generate
            api_ids: Optional list of specific API IDs to include
            context: Optional additional context

        Returns:
            Generated workflow
        """
        logger.info(f"Generating workflow for: {description}")

        # Retrieve relevant API documentation from vector DB
        relevant_docs = self._retrieve_relevant_docs(description)

        # Filter by API IDs if provided
        if api_ids:
            filtered_docs = []
            for doc in relevant_docs:
                if doc.get("metadata", {}).get("api_id") in api_ids:
                    filtered_docs.append(doc)

            # If there are filtered docs, use them; otherwise use original docs
            if filtered_docs:
                relevant_docs = filtered_docs

        # Extract API details
        api_details = self._extract_api_details(relevant_docs)

        # Generate workflow using Claude
        workflow = await self._generate_workflow_with_claude(description, api_details, context)

        return workflow

    def _retrieve_relevant_docs(self, query: str) -> List[Dict[str, Any]]:
        """Retrieve relevant API documentation from vector DB"""
        # Query vector DB for relevant documents
        results = self.chroma_service.query(
            query_text=query,
            n_results=10,
            where={"type": {"$in": ["api_endpoint", "pdf_api", "openapi"]}}
        )

        docs = []

        # Format results
        for i in range(len(results["documents"][0])):
            docs.append({
                "document": results["documents"][0][i],
                "metadata": results["metadatas"][0][i] if results["metadatas"] else {},
                "id": results["ids"][0][i] if results["ids"] else None,
            })

        return docs

    def _extract_api_details(self, relevant_docs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Extract API details from relevant documents"""
        api_details = []

        for doc in relevant_docs:
            if doc["metadata"].get("type") in ["api_endpoint", "pdf_api", "openapi"]:
                api_detail = {
                    "path": doc["metadata"].get("api_path") or doc["metadata"].get("path", ""),
                    "method": doc["metadata"].get("api_method") or doc["metadata"].get("method", ""),
                    "description": "",
                    "parameters": [],
                    "document_id": doc["metadata"].get("document_id", ""),
                    "document_name": doc["metadata"].get("document_name", "")
                }

                # Extract description and parameters from document text
                document_text = doc["document"]

                # Simple parsing based on common patterns
                if "Description:" in document_text:
                    desc_start = document_text.find("Description:") + len("Description:")
                    desc_end = document_text.find("\n", desc_start)
                    if desc_end == -1:
                        desc_end = len(document_text)
                    api_detail["description"] = document_text[desc_start:desc_end].strip()

                if "Parameters:" in document_text:
                    params_start = document_text.find("Parameters:") + len("Parameters:")
                    params_end = document_text.find("\n\n", params_start)
                    if params_end == -1:
                        params_end = len(document_text)

                    params_text = document_text[params_start:params_end].strip()
                    params = []
                    for param_line in params_text.split("\n"):
                        param = param_line.strip()
                        if param.startswith("-") or param.startswith("*"):
                            param = param[1:].strip()
                        if param:
                            params.append(param)

                    api_detail["parameters"] = params

                api_details.append(api_detail)

        return api_details

    async def _generate_workflow_with_claude(
            self,
            description: str,
            api_details: List[Dict[str, Any]],
            context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Generate workflow using Claude"""
        api_descriptions = []

        for api in api_details:
            api_str = (
                f"Path: {api['path']}\n"
                f"Method: {api['method']}\n"
                f"Description: {api['description']}\n"
                f"Parameters: {', '.join(api['parameters'])}\n"
            )
            api_descriptions.append(api_str)

        # Join API descriptions with separators
        apis_text = "\n---\n".join(api_descriptions)

        # Prepare context text
        context_text = ""
        if context:
            context_text = "Additional context:\n"
            for key, value in context.items():
                context_text += f"{key}: {value}\n"

        # Prepare prompt for Claude
        prompt = f"""
        I need to create an API workflow based on the following description:

        {description}

        Available APIs that might be relevant:

        {apis_text}

        {context_text}

        Please create a detailed workflow that accomplishes the described task using the available APIs. 

        The workflow should include:
        1. A clear title for the workflow
        2. A brief description of what the workflow accomplishes
        3. A numbered sequence of steps, where each step includes:
           - The API to call (method and path)
           - Required parameters
           - What to do with the response
           - How it connects to the next step

        Return your response as a JSON object with these keys with out any additional text:
        - title: The workflow title
        - description: Brief description of the workflow
        - steps: Array of workflow steps, each with these properties:
          - step_number: The step number (starting from 1)
          - api_method: The HTTP method
          - api_path: The API path
          - parameters: Array of required parameters
          - description: What this step does
          - next_steps: What to do with the response

        Only include APIs in the workflow that are necessary for the described task.
        """

        try:
            # Query Claude
            messages = [
                SystemMessage(content="You are a helpful assistant that generates API workflows."),
                HumanMessage(content=prompt)
            ]

            response = await self.llm.ainvoke(messages)
            response_text = response.content

            # Extract JSON from response
            import json
            import re

            # Try to extract JSON block if present
            json_match = re.search(r'```json\n(.*?)\n```', response_text, re.DOTALL)
            if json_match:
                json_str = json_match.group(1)
            else:
                json_str = response_text
            json_str = re.sub(r'[\x00-\x1F\x7F]', ' ', json_str)
            # Parse workflow JSON
            workflow_data = json.loads(json_str)

            # Generate a visualization (Mermaid diagram)
            visualization = await self._generate_visualization(workflow_data)

            # Create final workflow result
            workflow_result = {
                "workflow_id": str(uuid.uuid4()),
                "title": workflow_data.get("title", "API Workflow"),
                "description": workflow_data.get("description", ""),
                "steps": workflow_data.get("steps", []),
                "visualization": visualization,
                "metadata": {
                    "api_count": len(workflow_data.get("steps", [])),
                    "original_query": description
                }
            }

            return workflow_result

        except Exception as e:
            logger.error(f"Error generating workflow: {str(e)}")
            raise

    async def _generate_visualization(self, workflow_data: Dict[str, Any]) -> str:
        """Generate Mermaid diagram for workflow visualization"""
        title = workflow_data.get("title", "API Workflow")
        steps = workflow_data.get("steps", [])

        mermaid_diagram = "graph TD\n"
        mermaid_diagram += f"    title[{title}]\n"

        # Add nodes for each step
        for step in steps:
            step_number = step.get("step_number", 0)
            api_method = step.get("api_method", "")
            api_path = step.get("api_path", "")

            node_id = f"step{step_number}"
            node_label = f"Step {step_number}: {api_method} {api_path}"

            mermaid_diagram += f"    {node_id}[\"{node_label}\"]\n"

        # Add title connection to first step
        if steps:
            mermaid_diagram += "    title --> step1\n"

        # Add connections between steps
        for i in range(len(steps) - 1):
            current_step = i + 1
            next_step = current_step + 1

            mermaid_diagram += f"    step{current_step} --> step{next_step}\n"

        return mermaid_diagram