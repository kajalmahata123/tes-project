import logging
from typing import Dict, Any, List, Optional

from langchain_core.messages import HumanMessage, SystemMessage, AIMessage
from langchain_anthropic import ChatAnthropic

from app.services.chroma_service import ChromaService

logger = logging.getLogger(__name__)


class QASystemAgent:
    """Agent for answering questions based on API documentation"""

    def __init__(
            self,
            llm: ChatAnthropic,
            chroma_service: ChromaService
    ):
        self.llm = llm
        self.chroma_service = chroma_service

    async def answer_question(
            self,
            question: str,
            chat_history: Optional[List[Dict[str, str]]] = None,
            context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Answer a question based on API documentation

        Args:
            question: User's question
            chat_history: Optional chat history
            context: Optional additional context

        Returns:
            Answer with sources
        """
        logger.info(f"Answering question: {question}")

        # Retrieve relevant documents from vector DB
        relevant_docs = self._retrieve_relevant_docs(question)

        # Generate answer using Claude
        answer = await self._generate_answer_with_claude(
            question=question,
            relevant_docs=relevant_docs,
            chat_history=chat_history,
            context=context
        )

        return answer

    def _retrieve_relevant_docs(self, query: str) -> List[Dict[str, Any]]:
        """Retrieve relevant documents from vector DB"""
        # Query vector DB for relevant documents
        results = self.chroma_service.query(
            query_text=query,
            n_results=5
        )

        docs = []

        # Format results
        for i in range(len(results["documents"][0])):
            docs.append({
                "document": results["documents"][0][i],
                "metadata": results["metadatas"][0][i] if results["metadatas"] else {},
                "id": results["ids"][0][i] if results["ids"] else None,
            })

        return docs

    async def _generate_answer_with_claude(
            self,
            question: str,
            relevant_docs: List[Dict[str, Any]],
            chat_history: Optional[List[Dict[str, str]]] = None,
            context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Generate answer using Claude"""
        # Prepare relevant documents text
        docs_text = ""
        sources = []

        for i, doc in enumerate(relevant_docs):
            docs_text += f"\nDocument {i + 1}:\n{doc['document']}\n"

            # Add to sources
            sources.append({
                "id": doc["id"],
                "metadata": doc["metadata"]
            })

        # Prepare chat history if available
        history_text = ""
        if chat_history and len(chat_history) > 0:
            history_text = "Previous conversation:\n\n"
            for message in chat_history:
                role = message.get("role", "")
                content = message.get("content", "")
                history_text += f"{role.upper()}: {content}\n\n"

        # Prepare context text
        context_text = ""
        if context:
            context_text = "Additional context:\n"
            for key, value in context.items():
                context_text += f"{key}: {value}\n"

        # Prepare prompt for Claude
        prompt = f"""
        Answer the following question based on the provided documents. If you cannot answer based on the documents, say so.

        Question: {question}

        {history_text}
        {context_text}

        Relevant documents:
        {docs_text}

        Answer the question thoroughly using information from the provided documents. If information from multiple documents is relevant, combine it appropriately.

        Include only information present in the documents. If the documents don't contain enough information to answer the question, clearly state what is missing.
        """

        try:
            # Prepare messages for chat history
            messages = [
                SystemMessage(content="You are a helpful assistant that answers questions about API documentation.")
            ]

            # Add chat history if available
            if chat_history:
                for message in chat_history:
                    role = message.get("role", "")
                    content = message.get("content", "")

                    if role == "user":
                        messages.append(HumanMessage(content=content))
                    elif role == "assistant":
                        messages.append(AIMessage(content=content))

            # Add current question
            messages.append(HumanMessage(content=prompt))

            # Query Claude
            response = await self.llm.ainvoke(messages)
            answer_text = response.content

            # Create answer result
            answer_result = {
                "response": answer_text,
                "sources": sources,
                "metadata": {
                    "document_count": len(relevant_docs),
                    "original_question": question
                }
            }

            return answer_result

        except Exception as e:
            logger.error(f"Error generating answer: {str(e)}")
            raise