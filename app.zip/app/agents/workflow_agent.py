import logging
from typing import List, Dict, Any, Optional
from langchain_anthropic import ChatAnthropic
from langchain.schema import BaseMessage, HumanMessage, AIMessage, SystemMessage
from langchain.memory import ConversationBufferMemory
from app.agents.base_agent import BaseAgent
from app.schemas.chat_schemas import ChatMessage
from app.schemas.agent_schemas import AgentConfig
from app.tools.documentation_tool import DocumentationTool
from app.graphs.react_graph import create_react_graph

logger = logging.getLogger(__name__)


class WorkflowAgent(BaseAgent):
    """
    Agent specialized for creating implementation workflows.
    Breaks down complex API integration tasks into step-by-step guides.
    """

    def __init__(self, config: AgentConfig):
        """
        Initialize Workflow agent.

        Args:
            config: Agent configuration
        """
        super().__init__(config)
        self.llm = None
        self.memory = None
        self.doc_tool = None

    async def initialize(self) -> None:
        """Initialize agent resources."""
        # Initialize LLM
        self.llm = self.initialize_llm(temperature=0.2)

        # Initialize memory
        self.memory = ConversationBufferMemory(
            memory_key="chat_history",
            return_messages=True,
            input_key="input",
            output_key="output"
        )

        # Initialize tools
        self.doc_tool = DocumentationTool(
            knowledge_base=self.config.knowledge_base,
            top_k=5
        )

        # Set up tools list
        self.tools = [self.doc_tool]

        # Create the agent graph using LangGraph
        self.agent_graph = await create_react_graph(
            llm=self.llm,
            tools=self.tools,
            system_prompt=self._get_system_prompt()
        )

        logger.info(f"Initialized {self.__class__.__name__} with {len(self.tools)} tools")

    async def process_message(self, message: str, chat_history: List[ChatMessage]) -> str:
        """
        Process user message and return agent response.

        Args:
            message: User message text
            chat_history: List of previous chat messages

        Returns:
            Agent response with workflow steps and Mermaid diagram
        """
        logger.info(f"Processing workflow request: {message[:50]}...")

        # Convert chat history to memory format if not already in memory
        if chat_history:
            self._update_memory_from_history(chat_history)

        # Get current memory messages to provide as context
        memory_messages = self.get_memory_messages()

        # Execute the ReAct agent graph
        try:
            result = await self.agent_graph.ainvoke({
                "input": message,
                "chat_history": memory_messages
            })

            response = result.get("output", "I'm sorry, I couldn't create the workflow.")

            # Generate Mermaid diagram for the workflow if not already included
            if "```mermaid" not in response:
                mermaid_diagram = await self._generate_colorful_mermaid_diagram(message, response)
                if mermaid_diagram:
                    response += f"\n\n### Workflow Visualization\n\n{mermaid_diagram}"

            # Update memory with this exchange
            self.memory.chat_memory.add_user_message(message)
            self.memory.chat_memory.add_ai_message(response)

            return response

        except Exception as e:
            logger.error(f"Error in workflow creation: {e}", exc_info=True)
            return "I encountered an error while creating the workflow. Please try again with a more specific request."

    async def _generate_colorful_mermaid_diagram(self, query: str, workflow_text: str) -> str:
        """
        Generate a colorful, visually attractive Mermaid diagram based on the workflow text.

        Args:
            query: Original user query
            workflow_text: Generated workflow text

        Returns:
            Mermaid diagram code with styling
        """
        try:
            # Create a prompt for generating the styled Mermaid diagram
            prompt = f"""Create a visually appealing, colorful Mermaid flowchart that visualizes the following workflow:

Query: {query}

Workflow:
{workflow_text}

Requirements:
1. Use graph TD (top-down) syntax for the flowchart
2. Apply vibrant, attractive colors using classDef and class
3. Use meaningful icons or emojis where appropriate
4. Add styling for boxes, edges, and text
5. Include clear labels for each step
6. Group related steps using subgraph if appropriate
7. Add visual hierarchy with different node shapes and colors
8. Make the flow direction clear with styled arrows
9. Ensure the diagram is complete and represents all major steps

Here's an example styling pattern to follow, but feel free to create your own color scheme:
```
classDef start fill:#4CAF50,stroke:#388E3C,stroke-width:2px,color:white;
classDef process fill:#42A5F5,stroke:#1976D2,stroke-width:2px,color:white;
classDef decision fill:#FFCA28,stroke:#FFA000,stroke-width:2px,color:black;
classDef end fill:#EF5350,stroke:#D32F2F,stroke-width:2px,color:white;
```

Generate the complete Mermaid code only, without markdown code fences.
"""

            # Generate the Mermaid diagram with special styling
            messages = [
                SystemMessage(content="""You are a data visualization expert specializing in Mermaid diagrams. 
Create visually stunning, colorful flowcharts that are both informative and aesthetically pleasing.
Focus on using vibrant colors, clear visual hierarchy, and intuitive flow.
Always include styling with classDef and class statements.
Use appropriate icons or emojis to enhance understanding.
Your diagrams should be production-ready and visually impressive."""),
                HumanMessage(content=prompt)
            ]

            response = await self.llm.ainvoke(messages)
            mermaid_code = response.content.strip()

            # Clean up the response if needed
            if "```mermaid" in mermaid_code:
                mermaid_code = mermaid_code.split("```mermaid")[1].split("```")[0].strip()
            elif "```" in mermaid_code:
                mermaid_code = mermaid_code.split("```")[1].split("```")[0].strip()

            # Ensure diagram has styling if not present
            if "classDef" not in mermaid_code:
                mermaid_code += """

classDef start fill:#4CAF50,stroke:#388E3C,stroke-width:2px,color:white;
classDef process fill:#42A5F5,stroke:#1976D2,stroke-width:2px,color:white;
classDef decision fill:#FFCA28,stroke:#FFA000,stroke-width:2px,color:black;
classDef end fill:#EF5350,stroke:#D32F2F,stroke-width:2px,color:white;

class A start;
class J end;
class B,C,D,E,F,G,H process;
class I decision;
"""

            return f"```mermaid\n{mermaid_code}\n```"

        except Exception as e:
            logger.error(f"Error generating Mermaid diagram: {e}", exc_info=True)
            # Fallback to basic diagram if something goes wrong
            fallback_diagram = """```mermaid
graph TD
    A[Start] --> B[Step 1]
    B --> C[Step 2]
    C --> D[Step 3]
    D --> E[End]

    classDef start fill:#4CAF50,stroke:#388E3C,stroke-width:2px,color:white;
    classDef process fill:#42A5F5,stroke:#1976D2,stroke-width:2px,color:white;
    classDef end fill:#EF5350,stroke:#D32F2F,stroke-width:2px,color:white;

    class A start;
    class B,C,D process;
    class E end;
```"""
            return fallback_diagram

    def get_memory_messages(self) -> List[BaseMessage]:
        """
        Get messages from memory.

        Returns:
            List of messages from memory
        """
        if not self.memory:
            return []
        return self.memory.chat_memory.messages

    def clear_memory(self) -> None:
        """Clear conversation memory."""
        if self.memory:
            self.memory.clear()

    def _update_memory_from_history(self, chat_history: List[ChatMessage]) -> None:
        """
        Update memory with chat history.

        Args:
            chat_history: List of chat messages
        """
        # Clear existing memory
        self.clear_memory()

        # Add messages to memory
        for msg in chat_history:
            if msg.role == "user":
                self.memory.chat_memory.add_user_message(msg.content)
            elif msg.role == "assistant":
                self.memory.chat_memory.add_ai_message(msg.content)

    def _get_system_prompt(self) -> str:
        """
        Get system prompt for the agent.

        Returns:
            System prompt string
        """
        return """You are a specialized AI assistant focused on creating implementation workflows for API integrations.
Your purpose is to help developers understand how to implement complex API-related tasks step by step.

When creating workflows:
1. First, search the API documentation to understand the necessary endpoints and concepts.
2. Break down the implementation into clear, logical steps.
3. For each step, provide detailed explanations and where appropriate, code snippets.
4. Organize steps in a sequential order that makes implementation straightforward.
5. Include best practices, common pitfalls, and tips.
6. Consider error handling, testing, and edge cases.
7. Always include a Mermaid diagram to visualize the workflow.

Important guidelines:
- Start with a high-level overview of the workflow.
- Number the steps for clarity.
- Include prerequisites or setup requirements at the beginning.
- For each step, explain WHY it's necessary, not just WHAT to do.
- Include code snippets where appropriate, but focus on explanation and process.
- End with validation or testing steps to ensure the implementation works.
- Consider authentication, error handling, and performance.
- Include a visually appealing, colorful Mermaid diagram that visualizes the workflow process.

Remember that your goal is to create complete, practical implementation guides that a developer can follow from start to finish.
"""

    @property
    def capabilities(self) -> List[str]:
        """
        List agent capabilities.

        Returns:
            List of capability strings
        """
        return [
            "Create step-by-step implementation workflows",
            "Break down complex API integrations into manageable tasks",
            "Provide detailed explanations for each workflow step",
            "Include code examples within workflow steps",
            "Generate visually appealing, colorful Mermaid diagrams for workflow visualization",
            "Cover authentication, error handling, and testing considerations"
        ]