from contextlib import asynccontextmanager
from fastapi import FastAPI, Depends, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.docs import get_redoc_html, get_swagger_ui_html
from fastapi.openapi.utils import get_openapi
import logging
import time
from app.config import get_settings
from app.api.routes import chat, health, upload, api_keys, bootstrap, graphs, websocket
from app.core.session_manager import SessionManager
from app.dependencies import verify_api_key, get_agent_factory
from app.llm.llm_service import get_llm_service
from app.utils.logging import get_logger
from fastapi.responses import JSONResponse

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = get_logger("fastapi")

# Get environment configuration
settings = get_settings()

# Define lifespan context manager
@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Starting up API service...")
    get_llm_service()
    # Initialize database first
    from app.db.manager import DatabaseManager
    from app.db.migration import add_app_id_column, create_metrics_tables

    db_url = settings.DB_URL
    db_manager = DatabaseManager(db_url)
    await db_manager.initialize()
    logger.info("Database initialized")
    
    # Run database migrations
    add_app_id_column()
    create_metrics_tables()
    logger.info("Database migrations completed")

    # Initialize session manager
    session_manager = SessionManager.get_instance()

    # Create agent factory instance at startup
    agent_factory = await get_agent_factory()
    logger.info(f"Loaded agent types: {', '.join(agent_factory.available_agents())}")

    try:
        yield
    finally:
        logger.info("Shutting down API service...")

# Create the FastAPI app
app = FastAPI(lifespan=lifespan)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origins for API access
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Middleware for request timing
@app.middleware("http")
async def add_process_time_header(request: Request, call_next):
    start_time = time.time()
    response = await call_next(request)
    process_time = time.time() - start_time
    response.headers["X-Process-Time"] = str(process_time)
    return response

# API routes
app.include_router(chat.router, prefix=f"{settings.API_PREFIX}/chat")
app.include_router(health.router, prefix=f"{settings.API_PREFIX}/status")
app.include_router(upload.router, prefix=f"{settings.API_PREFIX}/document")
app.include_router(api_keys.router, prefix=f"{settings.API_PREFIX}/admin")
app.include_router(bootstrap.router, prefix=f"{settings.API_PREFIX}/bootstrap")

# Add graph visualization routes
app.include_router(
    graphs.router, 
    prefix=f"{settings.API_PREFIX}/graphs",
    tags=["graphs"]
)

# Add WebSocket routes for real-time updates
app.include_router(
    websocket.router,
    prefix=f"{settings.API_PREFIX}/ws",
    tags=["websocket"]
)

# Custom OpenAPI schema
def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    openapi_schema = get_openapi(
        title="Content-Craft Visa API Agent",
        version="1.0.0",
        description="API for Content-Craft Visa API Agent",
        routes=app.routes,
    )
    app.openapi_schema = openapi_schema
    return app.openapi_schema

app.openapi = custom_openapi

# Serve API documentation
@app.get("/docs", include_in_schema=False)
async def custom_swagger_ui_html():
    return get_swagger_ui_html(
        openapi_url=f"{settings.API_PREFIX}/openapi.json",
        title="API Documentation",
    )

@app.get("/redoc", include_in_schema=False)
async def custom_redoc_html():
    return get_redoc_html(
        openapi_url=f"{settings.API_PREFIX}/openapi.json",
        title="API Documentation",
    )

# OpenAPI endpoint
@app.get(f"{settings.API_PREFIX}/openapi.json", include_in_schema=False)
async def get_openapi_schema():
    return JSONResponse(content=custom_openapi())

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.DEBUG,
        log_level="info",
    )