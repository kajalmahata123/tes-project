import logging
from typing import List, Dict, Any, Optional
import numpy as np
from langchain_openai import OpenAIEmbeddings
from app.config import get_settings

logger = logging.getLogger(__name__)


class EmbeddingManager:
    """
    Utility class for managing embeddings operations.
    Provides methods for creating, comparing, and analyzing embeddings.
    """

    def __init__(self, model_name: Optional[str] = None, api_key: Optional[str] = None):
        """
        Initialize embedding manager.

        Args:
            model_name: OpenAI embedding model name
            api_key: OpenAI API key
        """
        settings = get_settings()
        self.model_name = model_name or settings.EMBEDDING_MODEL
        self.api_key = api_key or settings.OPENAI_API_KEY
        self.embeddings = OpenAIEmbeddings(
            model=self.model_name,
            openai_api_key=self.api_key
        )
        logger.info(f"Initialized EmbeddingManager with model {self.model_name}")

    async def get_embeddings(self, texts: List[str]) -> List[List[float]]:
        """
        Get embeddings for a list of texts.

        Args:
            texts: List of texts to embed

        Returns:
            List of embedding vectors
        """
        if not texts:
            return []

        try:
            embeddings = await self.embeddings.aembed_documents(texts)
            logger.debug(f"Generated {len(embeddings)} embeddings")
            return embeddings
        except Exception as e:
            logger.error(f"Error generating embeddings: {e}", exc_info=True)
            raise

    async def get_single_embedding(self, text: str) -> List[float]:
        """
        Get embedding for a single text.

        Args:
            text: Text to embed

        Returns:
            Embedding vector
        """
        try:
            embedding = await self.embeddings.aembed_query(text)
            return embedding
        except Exception as e:
            logger.error(f"Error generating single embedding: {e}", exc_info=True)
            raise

    def calculate_similarity(self, embedding1: List[float], embedding2: List[float]) -> float:
        """
        Calculate cosine similarity between two embeddings.

        Args:
            embedding1: First embedding vector
            embedding2: Second embedding vector

        Returns:
            Cosine similarity score (0-1)
        """
        # Convert to numpy arrays for calculation
        vec1 = np.array(embedding1)
        vec2 = np.array(embedding2)

        # Calculate cosine similarity
        dot_product = np.dot(vec1, vec2)
        norm1 = np.linalg.norm(vec1)
        norm2 = np.linalg.norm(vec2)

        if norm1 == 0 or norm2 == 0:
            return 0.0  # Handle zero vectors

        similarity = dot_product / (norm1 * norm2)
        return float(similarity)

    async def find_most_similar(
            self,
            query: str,
            candidates: List[str],
            top_k: int = 1
    ) -> List[Dict[str, Any]]:
        """
        Find the most similar texts to a query.

        Args:
            query: Query text
            candidates: List of candidate texts
            top_k: Number of top results to return

        Returns:
            List of dictionaries with text and similarity score
        """
        if not candidates:
            return []

        # Get embeddings
        query_embedding = await self.get_single_embedding(query)
        candidate_embeddings = await self.get_embeddings(candidates)

        # Calculate similarities
        similarities = [
            self.calculate_similarity(query_embedding, cand_emb)
            for cand_emb in candidate_embeddings
        ]

        # Create result objects
        results = [
            {"text": text, "similarity": sim}
            for text, sim in zip(candidates, similarities)
        ]

        # Sort by similarity and return top_k
        results.sort(key=lambda x: x["similarity"], reverse=True)
        return results[:top_k]