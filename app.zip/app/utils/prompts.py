from typing import Dict, Any, List, Optional
import logging
import re

logger = logging.getLogger(__name__)


class PromptTemplate:
    """
    Utility class for managing prompt templates.
    Provides methods for template rendering with variable substitution.
    """

    def __init__(self, template: str, input_variables: List[str] = None):
        """
        Initialize prompt template.

        Args:
            template: Template string with {variable} placeholders
            input_variables: List of variable names in the template
        """
        self.template = template

        # Extract input variables if not provided
        if input_variables is None:
            self.input_variables = self._extract_variables(template)
        else:
            self.input_variables = input_variables

    def _extract_variables(self, template: str) -> List[str]:
        """
        Extract variable names from template string.

        Args:
            template: Template string

        Returns:
            List of variable names
        """
        # Find all {variable} patterns in the template
        pattern = r'\{([a-zA-Z0-9_]+)\}'
        matches = re.finditer(pattern, template)
        return [match.group(1) for match in matches]

    def format(self, **kwargs) -> str:
        """
        Format the template with provided variables.

        Args:
            **kwargs: Variables for template substitution

        Returns:
            Formatted prompt string

        Raises:
            KeyError: If a required variable is missing
        """
        # Check for missing variables
        missing = [var for var in self.input_variables if var not in kwargs]
        if missing:
            raise KeyError(f"Missing variables: {', '.join(missing)}")

        # Format the template
        return self.template.format(**kwargs)

    def partial(self, **kwargs) -> 'PromptTemplate':
        """
        Create a partial template with some variables pre-filled.

        Args:
            **kwargs: Variables to pre-fill

        Returns:
            New PromptTemplate with remaining variables
        """
        # Replace provided variables in the template
        new_template = self.template
        for key, value in kwargs.items():
            if key in self.input_variables:
                new_template = new_template.replace(f"{{{key}}}", str(value))

        # Calculate remaining variables
        remaining_vars = [var for var in self.input_variables if var not in kwargs]

        # Create new template
        return PromptTemplate(new_template, remaining_vars)


# Common prompt templates for the application
VISA_API_AGENT_PROMPT = PromptTemplate("""You are a helpful AI assistant specializing in the Visa API. 
Your purpose is to help developers understand and implement Visa API integrations.

When answering questions:
1. First, determine if you need to search the API documentation.
2. Use the documentation search tool to find relevant information.
3. Analyze the search results to formulate a complete and accurate answer.
4. Provide code examples when appropriate.
5. Be specific and reference relevant API endpoints, parameters, and schemas.
6. If you're unsure about something, acknowledge it and provide the best information you have.

Remember that you cannot make actual API calls - you can only provide guidance, documentation, and example code.

{additional_instructions}

User question: {question}
""")

CODE_GENERATOR_PROMPT = PromptTemplate("""You are a specialized AI assistant focused on generating high-quality API client code. 
Your purpose is to help developers implement client code for API integrations.

Generate code in {language} for the following API:

{api_details}

Follow these guidelines:
1. Generate complete, production-ready code
2. Include proper error handling and authentication
3. Add comprehensive comments explaining the code
4. Structure the code for readability and maintainability
5. Include sample usage where appropriate

{additional_instructions}
""")

WORKFLOW_CREATOR_PROMPT = PromptTemplate("""You are a specialized AI assistant focused on creating implementation workflows for API integrations.
Your purpose is to help developers understand how to implement complex API-related tasks step by step.

Create a workflow for implementing the following:

{task_description}

API details:
{api_details}

The workflow should:
1. Break down the implementation into clear, logical steps
2. Provide detailed explanations for each step
3. Include code snippets where appropriate
4. Cover error handling, testing, and edge cases

{additional_instructions}
""")