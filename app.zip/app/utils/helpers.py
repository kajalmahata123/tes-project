import os
import json
import uuid
import logging
from typing import Dict, Any, List, Optional, Union
from datetime import datetime, date

logger = logging.getLogger(__name__)


class CustomJSONEncoder(json.JSONEncoder):
    """Custom JSON encoder that handles datetime objects"""

    def default(self, obj):
        if isinstance(obj, (datetime, date)):
            return obj.isoformat()
        return super().default(obj)


def serialize_to_json(obj: Any) -> str:
    """Serialize object to JSON string with custom encoder"""
    return json.dumps(obj, cls=CustomJSONEncoder)


def deserialize_from_json(json_str: str) -> Any:
    """Deserialize object from JSON string"""
    return json.loads(json_str)


def generate_id() -> str:
    """Generate a unique ID"""
    return str(uuid.uuid4())


def safe_file_operations(func):
    """Decorator for safe file operations"""

    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            logger.error(f"Error in file operation: {str(e)}")
            raise

    return wrapper


@safe_file_operations
def save_json_to_file(data: Dict[str, Any], file_path: str) -> str:
    """Save data to JSON file"""
    # Ensure directory exists
    os.makedirs(os.path.dirname(file_path), exist_ok=True)

    with open(file_path, 'w') as f:
        json.dump(data, f, cls=CustomJSONEncoder, indent=2)

    return file_path


@safe_file_operations
def load_json_from_file(file_path: str) -> Dict[str, Any]:
    """Load data from JSON file"""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")

    with open(file_path, 'r') as f:
        return json.load(f)


def truncate_text(text: str, max_length: int = 100) -> str:
    """Truncate text to specified length with ellipsis"""
    if len(text) <= max_length:
        return text
    return text[:max_length - 3] + "..."


def flatten_dict(
        d: Dict[str, Any],
        parent_key: str = '',
        separator: str = '_'
) -> Dict[str, Any]:
    """Flatten nested dictionaries for easier storage/retrieval"""
    items = []
    for k, v in d.items():
        new_key = parent_key + separator + k if parent_key else k
        if isinstance(v, dict):
            items.extend(flatten_dict(v, new_key, separator).items())
        else:
            items.append((new_key, v))
    return dict(items)