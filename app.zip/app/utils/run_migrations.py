#!/usr/bin/env python
"""
Utility script to run database migrations.
"""

import logging
import os
import sys

# Add parent directory to path to allow for imports
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("migrations")

def main():
    """Run all database migrations."""
    try:
        logger.info("Starting database migrations...")
        
        # Import migration functions
        from app.db.migration import add_app_id_column, create_metrics_tables
        
        # Run migrations
        add_app_id_column()
        create_metrics_tables()
        
        logger.info("Database migrations completed successfully.")
    except Exception as e:
        logger.error(f"Error during migrations: {str(e)}", exc_info=True)
        sys.exit(1)

if __name__ == "__main__":
    main() 