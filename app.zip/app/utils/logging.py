# app/utils/enhanced_logger.py
import os
import logging
import sys
import traceback
import linecache
import time
from logging.handlers import RotatingFileHandler
from typing import Dict, Any, Optional

# Base log directory
BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
LOG_DIR = os.path.join(BASE_DIR, "logs")

# Ensure log directory exists
if not os.path.exists(LOG_DIR):
    os.makedirs(LOG_DIR)

# Default format for log messages
DEFAULT_FORMAT = '%(asctime)s - %(name)s - %(levelname)s - [%(filename)s:%(lineno)d] - %(message)s'
DEFAULT_FORMATTER = logging.Formatter(DEFAULT_FORMAT)

# Maximum log file size (10MB)
MAX_LOG_SIZE = 10 * 1024 * 1024
# Number of backup log files
BACKUP_COUNT = 5


class Logger(logging.Logger):
    """Logger that automatically adds detailed error information to log records"""

    def error(self, msg, *args, **kwargs):
        """Enhanced error logging with detailed exception information if an exception is being handled"""
        if sys.exc_info()[0] is not None:  # There's an active exception
            error_details = self._get_exception_details()
            detailed_msg = (
                f"{msg}\n"
                f"File: {error_details['filename']}, Line: {error_details['line_number']}\n"
                f"Function: {error_details['function']}\n"
                f"Error: {error_details['error_type']}: {error_details['error_message']}\n"
                f"Code: {error_details['line']}\n"
                f"Traceback:\n{error_details['traceback']}"
            )
            super().error(detailed_msg, *args, **kwargs)
        else:
            super().error(msg, *args, **kwargs)

    def critical(self, msg, *args, **kwargs):
        """Enhanced critical logging with detailed exception information if an exception is being handled"""
        if sys.exc_info()[0] is not None:  # There's an active exception
            error_details = self._get_exception_details()
            detailed_msg = (
                f"{msg}\n"
                f"File: {error_details['filename']}, Line: {error_details['line_number']}\n"
                f"Function: {error_details['function']}\n"
                f"Error: {error_details['error_type']}: {error_details['error_message']}\n"
                f"Code: {error_details['line']}\n"
                f"Traceback:\n{error_details['traceback']}"
            )
            super().critical(detailed_msg, *args, **kwargs)
        else:
            super().critical(msg, *args, **kwargs)

    def _get_exception_details(self) -> Dict[str, Any]:
        """Get detailed exception information"""
        exc_type, exc_obj, tb = sys.exc_info()

        # Start with the frame where the exception occurred
        current_tb = tb
        while current_tb.tb_next:
            current_tb = current_tb.tb_next

        frame = current_tb.tb_frame
        lineno = current_tb.tb_lineno
        filename = frame.f_code.co_filename
        function_name = frame.f_code.co_name

        # Get the code line that caused the exception
        linecache.checkcache(filename)
        line = linecache.getline(filename, lineno, frame.f_globals)

        # Get the full traceback
        traceback_details = traceback.format_exc()

        return {
            'timestamp': time.time(),
            'date_time': time.strftime('%Y-%m-%d %H:%M:%S'),
            'filename': filename,
            'function': function_name,
            'line_number': lineno,
            'line': line.strip() if line else None,
            'error_type': exc_type.__name__ if exc_type else None,
            'error_message': str(exc_obj),
            'traceback': traceback_details
        }


# Register the enhanced logger class
logging.setLoggerClass(Logger)


# In enhanced_logger.py, modify the get_logger function:

def get_logger(module_name: str, console_logging: bool = True) -> logging.Logger:
    """
    Get a configured logger for a specific module with separate files for INFO and ERROR

    Args:
        module_name: Name of the module
        console_logging: Whether to enable console logging

    Returns:
        Configured logger instance
    """
    # Create module directory
    module_log_dir = os.path.join(LOG_DIR, module_name)
    if not os.path.exists(module_log_dir):
        os.makedirs(module_log_dir)

    # Create module logger (will be an EnhancedLogger instance)
    logger = logging.getLogger(module_name)

    # Only set up handlers if they haven't been set up yet
    if not logger.handlers:
        logger.setLevel(logging.DEBUG)

        # Create INFO log handler
        info_log_path = os.path.join(module_log_dir, "info.log")
        info_handler = RotatingFileHandler(
            info_log_path,
            maxBytes=MAX_LOG_SIZE,
            backupCount=BACKUP_COUNT
        )
        info_handler.setLevel(logging.INFO)
        info_handler.setFormatter(DEFAULT_FORMATTER)
        logger.addHandler(info_handler)

        # Create ERROR log handler
        error_log_path = os.path.join(module_log_dir, "error.log")
        error_handler = RotatingFileHandler(
            error_log_path,
            maxBytes=MAX_LOG_SIZE,
            backupCount=BACKUP_COUNT
        )
        error_handler.setLevel(logging.ERROR)
        error_handler.setFormatter(DEFAULT_FORMATTER)
        logger.addHandler(error_handler)

        # Create DEBUG log handler
        debug_log_path = os.path.join(module_log_dir, "debug.log")
        debug_handler = RotatingFileHandler(
            debug_log_path,
            maxBytes=MAX_LOG_SIZE,
            backupCount=BACKUP_COUNT
        )
        debug_handler.setLevel(logging.DEBUG)
        debug_handler.setFormatter(DEFAULT_FORMATTER)
        logger.addHandler(debug_handler)

        # Create console handler for development
        if console_logging:
            console_handler = logging.StreamHandler()
            console_handler.setLevel(logging.INFO)
            console_handler.setFormatter(DEFAULT_FORMATTER)
            logger.addHandler(console_handler)

    return logger