import os
from typing import Annotated
from fastapi import Depends, HTTPException, status
from langchain_anthropic import ChatAnthropic
from langchain_openai import OpenAIEmbeddings

from app.config import settings
from app.services.chroma_service import ChromaService
from app.services.embedding_service import EmbeddingService, ChromaBasicEmbedding
from app.services.chat_memory import ChatMemoryService

# Singleton pattern for service instances
_chroma_service = None
_embedding_service = None
_llm_service = None
_chat_memory_service = None


def get_embedding_service() -> EmbeddingService:
    """Return singleton instance of embedding service"""
    global _embedding_service
    if _embedding_service is None:
        if settings.EMBEDDING_TYPE == "openai":
            if not settings.OPENAI_API_KEY:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail="OpenAI API key not configured",
                )
            _embedding_service = OpenAIEmbeddings(api_key=settings.OPENAI_API_KEY)
        else:
            # Default to Chroma Basic Embedding
            _embedding_service = ChromaBasicEmbedding()

    return _embedding_service


def get_chroma_service() -> ChromaService:
    """Return singleton instance of ChromaDB service"""
    global _chroma_service
    if _chroma_service is None:
        embedding_service = get_embedding_service()
        _chroma_service = ChromaService(
            embedding_service=embedding_service,
            persist_directory=settings.VECTOR_DB_DIR,
        )

    return _chroma_service


def get_llm_service() -> ChatAnthropic:
    """Return singleton instance of Anthropic Claude LLM service"""
    global _llm_service
    if _llm_service is None:
        if not settings.ANTHROPIC_API_KEY:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Anthropic API key not configured",
            )

        _llm_service = ChatAnthropic(
            model=settings.ANTHROPIC_MODEL,
            anthropic_api_key=settings.ANTHROPIC_API_KEY,
            temperature=0.1,
            max_tokens=4000,
        )

    return _llm_service


def get_chat_memory_service() -> ChatMemoryService:
    """Return singleton instance of chat memory service"""
    global _chat_memory_service
    if _chat_memory_service is None:
        _chat_memory_service = ChatMemoryService(
            max_sessions=settings.MAX_CHAT_SESSIONS,
            ttl_seconds=settings.CHAT_SESSION_TTL
        )

    return _chat_memory_service


# Annotated dependencies for FastAPI
ChromaDB = Annotated[ChromaService, Depends(get_chroma_service)]
LLM = Annotated[ChatAnthropic, Depends(get_llm_service)]
EmbeddingModel = Annotated[EmbeddingService, Depends(get_embedding_service)]
ChatMemory = Annotated[ChatMemoryService, Depends(get_chat_memory_service)]