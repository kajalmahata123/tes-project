import os
import time
from fastapi import Header, HTTPException, Depends, Request, WebSocket
from typing import Optional, Dict
from app.config import get_settings
from app.core.agent_factory import AgentFactory
from app.core.agent_registry import AgentRegistry
from app.core.knowledge_base import KnowledgeBase
from app.db.manager import DatabaseManager
import logging
from fastapi import WebSocketDisconnect

logger = logging.getLogger(__name__)

# Singleton instances
_agent_factory = None
_knowledge_base = None
_agent_registry = None
_db_manager = None

# Rate limiting storage (in-memory for simplicity)
# In production, use Redis or another distributed cache
rate_limit_store = {}


async def get_db_manager() -> DatabaseManager:
    """
    Get or create DatabaseManager instance.

    Returns:
        DatabaseManager instance
    """
    global _db_manager

    if _db_manager is None:
        logger.info("Initializing database manager")
        _db_manager = DatabaseManager(get_settings().DB_URL)
        await _db_manager.initialize()

    return _db_manager


async def verify_api_key(
        api_key: Optional[str] = Header(None, alias="X-API-Key"),
        app_id: Optional[str] = Header(None, alias="X-App-ID")
):
    """
    Verify that both X-API-Key and X-App-ID headers are present.
    The X-App-ID must be 'Visa_api_Bot'.

    Args:
        api_key: API key from X-API-Key header
        app_id: Application ID from X-App-ID header

    Raises:
        HTTPException: If either header is missing or if app_id is not 'Visa_api_Bot'
    """
    if not api_key:
        raise HTTPException(
            status_code=401,
            detail="Missing X-API-Key header",
            headers={"WWW-Authenticate": "API-Key"},
        )

    if not app_id:
        raise HTTPException(
            status_code=400,
            detail="Missing X-App-ID header"
        )
    
    # Hard coded check for Visa_api_Bot
    if app_id != "Visa_api_Bot":
        raise HTTPException(
            status_code=403,
            detail="Invalid X-App-ID. Must be 'Visa_api_Bot'"
        )

    return {"api_key": api_key, "app_id": app_id}


async def verify_api_key_and_app_id(
        request: Request,
        x_api_key: Optional[str] = Header(None, alias="X-API-Key"),
        x_app_id: Optional[str] = Header(None, alias="X-App-ID"),
        db_manager: DatabaseManager = Depends(get_db_manager)
):
    """
    Verify API key and APP_ID, and apply rate limiting.
    The X-App-ID must be 'Visa_api_Bot'.

    Args:
        request: FastAPI request object
        x_api_key: API key from header
        x_app_id: Application ID from header
        db_manager: Database manager instance

    Returns:
        Dict with app_id and app_info

    Raises:
        HTTPException: If API key is invalid or if app_id is not 'Visa_api_Bot'
    """
    # Support legacy API key for backward compatibility
    if not x_api_key and not x_app_id:
        settings = get_settings()
        api_key = request.headers.get(settings.API_KEY_NAME)
        if settings.API_KEY != "your-api-key" and api_key == settings.API_KEY:
            # Use default app_id for legacy authentication
            return {"app_id": "Visa_api_Bot", "app_info": {"app_name": "Legacy App", "rate_limit": 100}}

    if not x_api_key:
        raise HTTPException(
            status_code=401,
            detail="Missing API key",
            headers={"WWW-Authenticate": "API-Key"},
        )

    if not x_app_id:
        raise HTTPException(
            status_code=400,
            detail="Missing X-App-ID header"
        )

    # Hard coded check for Visa_api_Bot
    if x_app_id != "Visa_api_Bot":
        raise HTTPException(
            status_code=403,
            detail="Invalid X-App-ID. Must be 'Visa_api_Bot'"
        )

    # Validate API key
    app_info = await db_manager.validate_api_key(x_api_key)
    if not app_info:
        raise HTTPException(
            status_code=401,
            detail="Invalid API key",
            headers={"WWW-Authenticate": "API-Key"},
        )

    # Apply rate limiting
    rate_limit = app_info.get("rate_limit", 100)  # Default to 100 requests per minute

    # Get client IP for more granular rate limiting
    client_ip = request.client.host
    rate_limit_key = f"{x_app_id}:{client_ip}"

    current_time = int(time.time())
    minute_window = current_time // 60

    # Check the rate limit window
    if rate_limit_key in rate_limit_store:
        window, count = rate_limit_store[rate_limit_key]

        if window == minute_window:
            # Same time window
            if count >= rate_limit:
                raise HTTPException(
                    status_code=429,
                    detail="Rate limit exceeded"
                )
            # Increment the count
            rate_limit_store[rate_limit_key] = (window, count + 1)
        else:
            # New time window
            rate_limit_store[rate_limit_key] = (minute_window, 1)
    else:
        # First request for this key
        rate_limit_store[rate_limit_key] = (minute_window, 1)

    # Clean up old rate limit entries (every 10 minutes)
    if current_time % 600 < 10:  # Do cleanup roughly every 10 minutes
        for key in list(rate_limit_store.keys()):
            window, _ = rate_limit_store[key]
            if window < minute_window - 10:  # Remove entries older than 10 minutes
                del rate_limit_store[key]

    # Return the app information with hard-coded app_id
    return {"app_id": "Visa_api_Bot", "app_info": app_info}


async def get_app_id(auth: Dict = Depends(verify_api_key_and_app_id)) -> str:
    """
    Extract APP_ID from the authentication result.

    Args:
        auth: Authentication result from verify_api_key_and_app_id

    Returns:
        APP_ID string
    """
    return auth["app_id"]


async def get_knowledge_base() -> KnowledgeBase:
    """
    Get or create KnowledgeBase instance.

    Returns:
        KnowledgeBase instance
    """
    global _knowledge_base

    if _knowledge_base is None:
        logger.info("Initializing knowledge base")
        _knowledge_base = KnowledgeBase()
        try:
            await _knowledge_base.initialize()
            logger.info("Knowledge base successfully initialized")
        except Exception as e:
            logger.error(f"Error initializing knowledge base: {e}", exc_info=True)
            # Create directory structure if needed
            os.makedirs(get_settings().CHROMA_PERSIST_DIRECTORY, exist_ok=True)
            os.makedirs(get_settings().DOCS_PATH, exist_ok=True)
            
            # Instead of trying again and failing, just mark the KB as initialized
            # but not fully functional - this will allow the application to start
            logger.warning("Running with limited knowledge base functionality due to API error")
            _knowledge_base._initialized = True

    return _knowledge_base


async def get_agent_registry() -> AgentRegistry:
    """
    Get or create AgentRegistry instance.

    Returns:
        AgentRegistry instance
    """
    global _agent_registry

    if _agent_registry is None:
        logger.info("Initializing agent registry")
        _agent_registry = AgentRegistry()

        # Register agents
        from app.agents.visa_api_agent import VisaApiAgent
        from app.agents.code_generator_agent import CodeGeneratorAgent
        from app.agents.workflow_agent import WorkflowAgent

        _agent_registry.register_agent("visa_api_agent", VisaApiAgent)
        _agent_registry.register_agent("code_generator", CodeGeneratorAgent)
        _agent_registry.register_agent("workflow_creator", WorkflowAgent)

    return _agent_registry


async def get_agent_factory() -> AgentFactory:
    """
    Get or create AgentFactory instance.

    Returns:
        AgentFactory instance
    """
    global _agent_factory

    if _agent_factory is None:
        logger.info("Initializing agent factory")

        # Get dependencies
        kb = await get_knowledge_base()
        registry = await get_agent_registry()

        # Create factory
        _agent_factory = AgentFactory(registry, kb)

    return _agent_factory


async def verify_api_key_ws(
    websocket: WebSocket,
    api_key: str,
    app_id: str
) -> dict:
    """
    Verify API key and app_id for WebSocket connections.
    The app_id must be 'Visa_api_Bot'.

    Args:
        websocket: WebSocket connection
        api_key: API key from query parameters
        app_id: Application ID from query parameters

    Returns:
        Dict with api_key and app_id

    Raises:
        WebSocketDisconnect: If authentication fails
    """
    if not api_key:
        await websocket.close(code=4001, reason="Missing API key")
        raise WebSocketDisconnect(code=4001)

    if not app_id:
        await websocket.close(code=4002, reason="Missing app_id")
        raise WebSocketDisconnect(code=4002)

    # Hard coded check for Visa_api_Bot
    if app_id != "Visa_api_Bot":
        await websocket.close(code=4003, reason="Invalid app_id")
        raise WebSocketDisconnect(code=4003)

    return {"api_key": api_key, "app_id": app_id}