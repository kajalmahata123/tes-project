import json
import logging
from typing import Dict, Any
import os
import yaml
from app.core.knowledge_base import KnowledgeBase
from langchain.schema import Document

logger = logging.getLogger(__name__)


class OpenAPILoader:
    """
    Tool for loading and processing OpenAPI specification files.
    Extracts endpoints, schemas, parameters, and request/response bodies.
    """

    def __init__(self, knowledge_base: KnowledgeBase):
        """
        Initialize the OpenAPI loader.

        Args:
            knowledge_base: Knowledge base to store processed API docs
        """
        self.knowledge_base = knowledge_base
        logger.info("Initialized OpenAPI loader")

    async def load_spec(self, file_path: str) -> Dict[str, Any]:
        """
        Load and parse an OpenAPI specification file.

        Args:
            file_path: Path to the OpenAPI spec file (.json or .yaml)

        Returns:
            Parsed API specification

        Raises:
            ValueError: If file is not a valid OpenAPI spec
        """
        logger.info(f"Loading OpenAPI spec from {file_path}")

        try:
            # Check file extension
            ext = os.path.splitext(file_path)[1].lower()

            # Load file based on extension
            with open(file_path, 'r') as f:
                if ext == '.json':
                    spec = json.load(f)
                elif ext in ['.yaml', '.yml']:
                    spec = yaml.safe_load(f)
                else:
                    raise ValueError(f"Unsupported file format: {ext}")

            # Validate basic OpenAPI structure
            if 'openapi' not in spec and 'swagger' not in spec:
                raise ValueError("File does not appear to be a valid OpenAPI specification")

            logger.info(f"Successfully loaded {file_path}")
            return spec

        except (json.JSONDecodeError, yaml.YAMLError) as e:
            logger.error(f"Error parsing file {file_path}: {e}")
            raise ValueError(f"Invalid file format: {e}")
        except Exception as e:
            logger.error(f"Error loading file {file_path}: {e}", exc_info=True)
            raise

    async def process_spec(self, spec: Dict[str, Any], file_name: str) -> None:
        """
        Process an OpenAPI spec and store in knowledge base.
        Extracts paths, operations, schemas, etc. and creates searchable chunks.

        Args:
            spec: Parsed OpenAPI specification
            file_name: Original file name for reference
        """
        logger.info(f"Processing OpenAPI spec from {file_name}")

        try:
            # Ensure knowledge base is initialized
            if not hasattr(self.knowledge_base, 'vectorstore') or self.knowledge_base.vectorstore is None:
                logger.info("Knowledge base vectorstore not initialized, initializing now")
                await self.knowledge_base.initialize()
                if not hasattr(self.knowledge_base, 'vectorstore') or self.knowledge_base.vectorstore is None:
                    logger.error("Failed to initialize knowledge base vectorstore")
                    # Create a fallback method to store documents without vectorstore
                    self._fallback_documents = []
                    logger.info("Using fallback document storage")

            # Extract API info
            api_info = spec.get('info', {})
            api_title = api_info.get('title', 'Unknown API')
            api_version = api_info.get('version', 'Unknown')
            api_description = api_info.get('description', '')

            logger.info(f"Processing API: {api_title} (v{api_version})")

            # Add API overview to knowledge base
            await self._add_document(
                content=f"# {api_title}\n\nVersion: {api_version}\n\n{api_description}",
                metadata={
                    "source": file_name,
                    "type": "api_overview",
                    "api_title": api_title,
                    "api_version": api_version
                }
            )

            # Process paths and operations
            paths = spec.get('paths', {})
            for path, path_item in paths.items():
                await self._process_path(path, path_item, file_name, api_title, api_version)

            # Process components/schemas
            components = spec.get('components', {})
            schemas = components.get('schemas', {})
            for schema_name, schema in schemas.items():
                await self._process_schema(schema_name, schema, file_name, api_title, api_version)

            logger.info(f"Completed processing API: {api_title}")

            # If we used fallback storage, log the count
            if hasattr(self, '_fallback_documents'):
                logger.info(f"Stored {len(self._fallback_documents)} documents in fallback storage")

        except Exception as e:
            logger.error(f"Error processing OpenAPI spec: {e}", exc_info=True)
            raise

    async def _add_document(self, content: str, metadata: Dict[str, Any]) -> None:
        """
        Add a document to the knowledge base with fallback handling.

        Args:
            content: Document content
            metadata: Document metadata
        """
        try:
            # Try to add to the knowledge base
            await self.knowledge_base.add_document(content, metadata)
        except Exception as e:
            logger.error(f"Error adding document to knowledge base: {e}", exc_info=True)

            # Use fallback storage if available
            if hasattr(self, '_fallback_documents'):
                doc = Document(page_content=content, metadata=metadata)
                self._fallback_documents.append(doc)
                logger.debug(f"Added document to fallback storage: {metadata.get('type')}")

    async def _process_path(
            self,
            path: str,
            path_item: Dict[str, Any],
            file_name: str,
            api_title: str,
            api_version: str
    ) -> None:
        """
        Process a path item and store relevant information.

        Args:
            path: URL path
            path_item: Path item object
            file_name: Original file name
            api_title: API title
            api_version: API version
        """
        # Process each operation (GET, POST, etc.)
        operations = ['get', 'post', 'put', 'delete', 'patch', 'options', 'head']

        for method in operations:
            operation = path_item.get(method)
            if not operation:
                continue

            operation_id = operation.get('operationId', f"{method.upper()} {path}")
            summary = operation.get('summary', '')
            description = operation.get('description', '')

            # Format operation details
            content = f"# {operation_id}\n\n"
            content += f"**Path:** {path}\n"
            content += f"**Method:** {method.upper()}\n\n"

            if summary:
                content += f"**Summary:** {summary}\n\n"
            if description:
                content += f"**Description:** {description}\n\n"

            # Parameters
            parameters = operation.get('parameters', [])
            if parameters:
                content += "## Parameters\n\n"
                for param in parameters:
                    param_name = param.get('name', 'Unknown')
                    param_in = param.get('in', 'Unknown')
                    param_required = param.get('required', False)
                    param_desc = param.get('description', '')

                    content += f"- **{param_name}** ({param_in}"
                    if param_required:
                        content += ", required"
                    content += f"): {param_desc}\n"

            # Request body
            request_body = operation.get('requestBody', {})
            if request_body:
                content += "\n## Request Body\n\n"
                content += f"{request_body.get('description', '')}\n\n"

                content_types = request_body.get('content', {})
                for content_type, media_type in content_types.items():
                    content += f"**Content Type:** {content_type}\n\n"

                    schema = media_type.get('schema', {})
                    schema_ref = schema.get('$ref', '')

                    if schema_ref:
                        # Extract schema name from reference
                        schema_name = schema_ref.split('/')[-1]
                        content += f"**Schema:** {schema_name}\n\n"
                    else:
                        # Include inline schema details
                        content += "**Schema:**\n```json\n"
                        content += json.dumps(schema, indent=2)
                        content += "\n```\n\n"

            # Responses
            responses = operation.get('responses', {})
            if responses:
                content += "\n## Responses\n\n"
                for status_code, response in responses.items():
                    content += f"### Status: {status_code}\n\n"
                    content += f"{response.get('description', '')}\n\n"

                    content_types = response.get('content', {})
                    for content_type, media_type in content_types.items():
                        content += f"**Content Type:** {content_type}\n\n"

                        schema = media_type.get('schema', {})
                        schema_ref = schema.get('$ref', '')

                        if schema_ref:
                            # Extract schema name from reference
                            schema_name = schema_ref.split('/')[-1]
                            content += f"**Schema:** {schema_name}\n\n"
                        else:
                            # Include inline schema details
                            content += "**Schema:**\n```json\n"
                            content += json.dumps(schema, indent=2)
                            content += "\n```\n\n"

            # Add to knowledge base
            await self._add_document(
                content=content,
                metadata={
                    "source": file_name,
                    "type": "api_operation",
                    "api_title": api_title,
                    "api_version": api_version,
                    "path": path,
                    "method": method,
                    "operation_id": operation_id
                }
            )

    async def _process_schema(
            self,
            schema_name: str,
            schema: Dict[str, Any],
            file_name: str,
            api_title: str,
            api_version: str
    ) -> None:
        """
        Process a schema definition and store in knowledge base.

        Args:
            schema_name: Name of the schema
            schema: Schema object
            file_name: Original file name
            api_title: API title
            api_version: API version
        """
        # Format schema details
        content = f"# Schema: {schema_name}\n\n"

        schema_type = schema.get('type', '')
        schema_desc = schema.get('description', '')

        if schema_desc:
            content += f"{schema_desc}\n\n"

        if schema_type:
            content += f"**Type:** {schema_type}\n\n"

        # Properties
        properties = schema.get('properties', {})
        if properties:
            content += "## Properties\n\n"
            for prop_name, prop in properties.items():
                prop_type = prop.get('type', 'object')
                prop_desc = prop.get('description', '')
                prop_format = prop.get('format', '')
                prop_required = schema.get('required', [])

                content += f"- **{prop_name}**"
                content += f" ({prop_type}"
                if prop_format:
                    content += f", format: {prop_format}"
                if prop_name in prop_required:
                    content += ", required"
                content += f"): {prop_desc}\n"

        # Add to knowledge base
        await self._add_document(
            content=content,
            metadata={
                "source": file_name,
                "type": "api_schema",
                "api_title": api_title,
                "api_version": api_version,
                "schema_name": schema_name
            }
        )