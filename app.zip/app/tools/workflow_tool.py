import logging
from typing import  Any, List, Optional
from langchain.schema import HumanMessage, SystemMessage
from langchain.schema.language_model import BaseLanguageModel
from app.tools.base_tool import BaseTool
from app.core.knowledge_base import KnowledgeBase

logger = logging.getLogger(__name__)


class WorkflowGenerationTool(BaseTool):
    """
    Tool for creating implementation workflows based on API documentation.
    Generates step-by-step guides for implementing API integrations.
    """

    name = "workflow_generator"
    description = "Create step-by-step workflows for implementing API integrations and common tasks."

    def __init__(
            self,
            llm: BaseLanguageModel,
            knowledge_base: KnowledgeBase,
            code_gen_tool=None
    ):
        """
        Initialize the workflow generation tool.

        Args:
            llm: Language model to use for workflow generation
            knowledge_base: Knowledge base containing API documentation
            code_gen_tool: Optional code generation tool for code examples
        """
        super().__init__()
        self.llm = llm
        self.knowledge_base = knowledge_base
        self.code_gen_tool = code_gen_tool
        logger.info(f"Initialized {self.__class__.__name__}")

    async def _arun(
            self,
            query: str,
            task_type: Optional[str] = None,
            operations: Optional[List[str]] = None,
            include_code: bool = True,
            language: Optional[str] = None,
            include_diagram: bool = True,  # New parameter for mermaid diagrams
            **kwargs
    ) -> str:
        """
        Generate a workflow for an API implementation task.

        Args:
            query: Description of the workflow to generate
            task_type: Type of task (e.g., "authentication", "data processing")
            operations: List of API operations to include
            include_code: Whether to include code examples
            language: Programming language for code examples
            include_diagram: Whether to include a mermaid diagram

        Returns:
            Generated workflow as a markdown-formatted string
        """
        logger.info(f"Generating workflow for query: {query[:100]}...")

        # Search for relevant API documentation
        search_query = query
        if task_type:
            search_query += f" task:{task_type}"
        if operations and len(operations) > 0:
            operation_str = " ".join(operations)
            search_query += f" operations:{operation_str}"

        # Apply filter if operations are specified
        filter_criteria = {}
        if operations and len(operations) > 0:
            filter_criteria["operation_id"] = {"$in": operations}

        # Get relevant docs
        docs = await self.knowledge_base.search(
            query=search_query,
            top_k=5,
            filter_criteria=filter_criteria if filter_criteria else None
        )

        # Combine doc content
        doc_content = "\n\n".join([doc.page_content for doc in docs])

        # Check if multiple APIs are involved by analyzing doc metadata or content
        # This is a simple heuristic - you might need a more sophisticated approach based on your data
        api_names = set()
        for doc in docs:
            # Extract API names from metadata if available
            if hasattr(doc, "metadata") and "api_name" in doc.metadata:
                api_names.add(doc.metadata["api_name"])
            # Alternatively, you can try to extract API names from content
            elif "API" in doc.page_content:
                # This is a simple regex-like approach; you might need NLP for production
                import re
                matches = re.findall(r'(\w+)\s+API', doc.page_content)
                api_names.update(matches)

        has_multiple_apis = len(api_names) > 1
        
        # Generate initial workflow
        messages = [
            SystemMessage(content=self._get_workflow_prompt(include_code, language, include_diagram, has_multiple_apis, api_names)),
            HumanMessage(content=f"""
Create a step-by-step workflow for the following API implementation task:

{query}

Here is the relevant API documentation:

{doc_content}

The workflow should include all necessary steps to complete the task, from setup to testing.
{'Please include a Mermaid diagram showing the interactions between different APIs.' if has_multiple_apis and include_diagram else ''}
""")
        ]

        # Get LLM response
        response = await self.llm.ainvoke(messages)
        workflow_content = response.content

        # If the workflow doesn't include a Mermaid diagram but should, generate one
        if has_multiple_apis and include_diagram and "```mermaid" not in workflow_content:
            mermaid_diagram = await self._generate_mermaid_diagram(query, api_names, docs)
            # Insert the diagram after the introduction
            sections = workflow_content.split("## ")
            if len(sections) > 1:
                workflow_content = sections[0] + "\n\n" + mermaid_diagram + "\n\n## " + "## ".join(sections[1:])
            else:
                workflow_content = workflow_content + "\n\n" + mermaid_diagram

        # If code examples are requested and code_gen_tool is available, enhance with code
        if include_code and self.code_gen_tool and language:
            workflow_content = await self._enhance_with_code(workflow_content, language, operations)

        return workflow_content

    async def _generate_mermaid_diagram(
            self, 
            query: str, 
            api_names: set, 
            docs: List[Any]
    ) -> str:
        """
        Generate a Mermaid diagram for workflows involving multiple APIs.

        Args:
            query: The original query for context
            api_names: Set of API names involved
            docs: The relevant documentation

        Returns:
            Mermaid diagram as a markdown string
        """
        logger.info(f"Generating Mermaid diagram for workflow with APIs: {', '.join(api_names)}")

        # Create a prompt for diagram generation
        api_list = ", ".join(api_names)
        doc_summaries = "\n".join([f"- {doc.page_content[:200]}..." for doc in docs[:3]])
        
        messages = [
            SystemMessage(content="""You are an expert at creating clear and informative Mermaid diagrams.
Your task is to create a workflow diagram showing the interactions between multiple APIs.

Guidelines for the diagram:
1. Use the flowchart or sequence diagram format, whichever is more appropriate.
2. Include a clear starting point (usually the client or user application).
3. Show each API as a separate node.
4. Illustrate the flow of data or control between APIs.
5. Include key endpoints or operations where relevant.
6. Use descriptive labels for flows (e.g., "POST /auth", "Returns token").
7. Keep the diagram clean and readable - not too complex.
8. Use appropriate formatting (colors, shapes) to distinguish between different types of elements.

Return ONLY the Mermaid diagram code wrapped in a Markdown code block with 'mermaid' syntax highlighting.
"""),
            HumanMessage(content=f"""
Create a Mermaid diagram for a workflow involving these APIs: {api_list}

The workflow is related to: {query}

Here are summaries of the relevant API documentation:
{doc_summaries}

The diagram should show how these APIs interact with each other and with the client application.
""")
        ]

        # Get LLM response
        response = await self.llm.ainvoke(messages)
        diagram_content = response.content
        
        # Ensure the diagram is properly formatted with mermaid code block
        if "```mermaid" not in diagram_content:
            diagram_content = "```mermaid\n" + diagram_content.strip() + "\n```"
        
        # Add a heading
        return "## Workflow Diagram\n\nThe following diagram illustrates the interactions between the different APIs in this workflow:\n\n" + diagram_content

    async def _enhance_with_code(
            self,
            workflow: str,
            language: str,
            operations: Optional[List[str]] = None
    ) -> str:
        """
        Enhance workflow with code examples.

        Args:
            workflow: Initial workflow content
            language: Programming language
            operations: List of API operations

        Returns:
            Enhanced workflow with code examples
        """
        # This is a basic implementation that requests code for detected code placeholders
        # A more robust implementation would parse the workflow structure and insert code strategically

        # Check if there are code placeholder sections
        if "[CODE EXAMPLE]" not in workflow and "```" not in workflow:
            # No explicit code placeholders, just return the original
            return workflow

        try:
            # Extract sections that need code examples
            sections = []
            current_section = ""
            in_code_section = False

            for line in workflow.split("\n"):
                if "[CODE EXAMPLE]" in line or (line.strip().startswith("```") and not in_code_section):
                    # Found a code placeholder
                    if current_section:
                        sections.append(("text", current_section))
                        current_section = ""

                    # Extract code description from previous lines
                    code_desc = line.replace("[CODE EXAMPLE]", "").strip()
                    if not code_desc and sections:
                        # Use the last few lines as context
                        context = sections[-1][1].split("\n")[-3:]
                        code_desc = " ".join(context)

                    # Generate code for this section
                    if self.code_gen_tool:
                        code = await self.code_gen_tool._arun(
                            query=code_desc,
                            language=language,
                            operations=operations
                        )
                        sections.append(("code", code))
                    else:
                        sections.append(("code", f"```{language}\n# Code would go here\n```"))

                    in_code_section = True
                elif line.strip().startswith("```") and in_code_section:
                    in_code_section = False
                else:
                    current_section += line + "\n"

            # Add the last section if any
            if current_section:
                sections.append(("text", current_section))

            # Combine all sections
            enhanced_workflow = ""
            for section_type, content in sections:
                enhanced_workflow += content

            return enhanced_workflow

        except Exception as e:
            logger.error(f"Error enhancing workflow with code: {e}", exc_info=True)
            # Fall back to original workflow
            return workflow

    def _get_workflow_prompt(
            self, 
            include_code: bool, 
            language: Optional[str] = None,
            include_diagram: bool = False,
            has_multiple_apis: bool = False,
            api_names: Optional[set] = None
    ) -> str:
        """
        Get system prompt for workflow generation.

        Args:
            include_code: Whether to include code examples
            language: Programming language for code examples
            include_diagram: Whether to include a mermaid diagram
            has_multiple_apis: Whether multiple APIs are involved
            api_names: Set of API names involved

        Returns:
            System prompt for workflow generation
        """
        code_instructions = ""
        if include_code and language:
            code_instructions = f"""
- Include placeholders for code examples using the format [CODE EXAMPLE] or markdown code blocks.
- For each step that requires code, indicate what the code should demonstrate.
- Use {language} for all code examples.
"""
        elif include_code:
            code_instructions = """
- Include placeholders for code examples using the format [CODE EXAMPLE] or markdown code blocks.
- For each step that requires code, indicate what the code should demonstrate.
"""
        
        diagram_instructions = ""
        if include_diagram and has_multiple_apis:
            api_list = ", ".join(api_names) if api_names else "the identified APIs"
            diagram_instructions = f"""
- Create a Mermaid diagram showing the interactions between {api_list}.
- Place the diagram after the introduction/overview section.
- Use the flowchart or sequence diagram format, whichever is more appropriate.
- Include a clear starting point (usually the client application).
- Show each API as a separate node with key operations.
- Use the following format for the diagram:

```mermaid
flowchart LR
    Client[Client Application] --> API1[API Name 1]
    API1 --> API2[API Name 2]
    API2 --> Client
    %% Add more nodes and connections as needed
```
"""

        return f"""You are an expert API integration specialist.
Your task is to create detailed, step-by-step workflows for implementing API integrations.

Guidelines for the workflow you create:
1. Break down the implementation into clear, logical steps.
2. Start with a high-level overview of what the workflow will accomplish.
3. Number each step for clarity.
4. For each step, explain WHAT to do, WHY it's necessary, and HOW to do it.
5. Include prerequisites or setup requirements at the beginning.
6. Cover authentication, error handling, and testing.
7. End with validation steps to ensure the implementation works correctly.
{code_instructions}
{diagram_instructions}
8. Format the workflow in clear, readable Markdown.
9. Include tips, warnings, and best practices where relevant.

Create a comprehensive workflow that a developer can follow from start to finish.
"""