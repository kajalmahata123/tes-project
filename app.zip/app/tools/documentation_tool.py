from typing import Dict, Any, List, Optional
from langchain.tools import BaseTool
from pydantic import Field
from app.core.knowledge_base import KnowledgeBase
import logging
logger = logging.getLogger(__name__)


class DocumentationTool(BaseTool):
    """
    Tool for retrieving information from the Visa API documentation.
    """

    name: str = "documentation_search"
    description: str = "Search the Visa API documentation for information about endpoints, parameters, schemas, and concepts."
    knowledge_base: KnowledgeBase = Field(description="Knowledge base for searching API documentation")
    top_k: int = Field(default=5, description="Number of search results to return")
    query_cache: Dict[str, str] = Field(default_factory=dict, description="Cache for search results")

    def __init__(self, knowledge_base: KnowledgeBase, top_k: int = 5):
        """
        Initialize the documentation tool.

        Args:
            knowledge_base: Knowledge base containing API documentation
            top_k: Number of results to return
        """
        super().__init__(knowledge_base=knowledge_base, top_k=top_k)
        self.query_cache = {}  # Initialize cache
        logger.info(f"Initialized {self.__class__.__name__} with top_k={top_k}")

    async def _arun(self, query: str, filter_criteria: Optional[Dict[str, Any]] = None) -> str:
        """
        Search the documentation and return relevant information.

        Args:
            query: Search query
            filter_criteria: Optional filter criteria for metadata

        Returns:
            String containing relevant documentation
        """
        # Create cache key from query and filter criteria
        cache_key = f"{query.lower().strip()}:{str(filter_criteria)}"

        # Check cache first
        if cache_key in self.query_cache:
            logger.info(f"Cache hit for query: {query[:50]}...")
            return self.query_cache[cache_key]

        logger.info(f"Searching documentation for: {query[:50]}...")

        # Normalize filter_criteria if provided
        if filter_criteria and not isinstance(filter_criteria, dict):
            logger.warning(f"Invalid filter_criteria type: {type(filter_criteria)}")
            filter_criteria = None

        # Search knowledge base
        results = await self.knowledge_base.search(
            query=query,
            top_k=self.top_k,
            filter_criteria=filter_criteria
        )

        if not results:
            return "No relevant documentation found."

        # Format results
        formatted_results = []
        for i, doc in enumerate(results, 1):
            # Extract helpful metadata
            metadata = doc.metadata
            source = metadata.get("path", "Unknown source")

            # Format document content
            content = doc.page_content.strip()

            # Add formatted result
            formatted_results.append(
                f"[Document {i}] Source: {source}\n"
                f"{'-' * 40}\n"
                f"{content}\n"
            )

        # Combine results
        result = "\n\n".join(formatted_results)

        # Store in cache
        self.query_cache[cache_key] = result

        return result

    def _run(self, query: str, filter_criteria: Optional[Dict[str, Any]] = None) -> str:
        """
        Synchronous version - not implemented.

        Raises:
            NotImplementedError: This tool only works asynchronously
        """
        raise NotImplementedError("This tool only supports async execution.")