from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, List, Callable, Awaitable
from langchain.tools import BaseTool as LangChainBaseTool
import logging

logger = logging.getLogger(__name__)


class BaseTool(LangChainBaseTool, ABC):
    """
    Abstract base class for all tools in the system.
    Extends LangChain's BaseTool with additional functionality.
    """

    def __init__(self, **kwargs):
        """Initialize the base tool."""
        super().__init__(**kwargs)
        logger.info(f"Initialized {self.__class__.__name__}")

    @abstractmethod
    async def _arun(self, query: str, **kwargs) -> str:
        """
        Asynchronously run the tool with the provided input.
        Must be implemented by subclasses.

        Args:
            query: The input query or parameters for the tool
            **kwargs: Additional parameters

        Returns:
            Tool output as a string
        """
        pass

    def _run(self, query: str, **kwargs) -> str:
        """
        Run the tool synchronously.
        By default, raises NotImplementedError to encourage async usage.

        Args:
            query: The input query or parameters for the tool
            **kwargs: Additional parameters

        Returns:
            Tool output as a string

        Raises:
            NotImplementedError: This tool only supports async execution
        """
        raise NotImplementedError(f"{self.__class__.__name__} only supports async execution")

    async def with_fallbacks(
            self,
            query: str,
            fallbacks: List[Callable[[str, Dict[str, Any]], Awaitable[str]]],
            **kwargs
    ) -> str:
        """
        Execute the tool with fallback options if it fails.

        Args:
            query: The input query
            fallbacks: List of fallback functions to try in order
            **kwargs: Additional parameters

        Returns:
            Tool output from main execution or a fallback
        """
        try:
            # Try main execution
            return await self._arun(query, **kwargs)
        except Exception as e:
            # Log the error
            logger.error(f"Error in {self.__class__.__name__}: {e}", exc_info=True)

            # Try fallbacks in order
            for i, fallback in enumerate(fallbacks):
                try:
                    logger.info(f"Trying fallback {i + 1}/{len(fallbacks)}")
                    return await fallback(query, kwargs)
                except Exception as fallback_error:
                    logger.error(f"Error in fallback {i + 1}: {fallback_error}")

            # If all fallbacks fail, raise the original error
            raise

    def validate_input(self, query: str, **kwargs) -> None:
        """
        Validate the input before execution.
        Override this in subclasses for input validation.

        Args:
            query: The input query
            **kwargs: Additional parameters

        Raises:
            ValueError: If input validation fails
        """
        pass