import logging
from typing import Dict, Any, List, Optional

from langchain.schema import HumanMessage, SystemMessage
from langchain.schema.language_model import BaseLanguageModel

from app.tools.base_tool import BaseTool
from app.core.knowledge_base import KnowledgeBase

logger = logging.getLogger(__name__)


class CodeGenerationTool(BaseTool):
    """
    Tool for generating code examples based on API documentation.
    Can generate code in multiple programming languages.
    """

    name = "code_generator"
    description = "Generate code examples for API operations in various programming languages."

    def __init__(
            self,
            llm: BaseLanguageModel,
            knowledge_base: KnowledgeBase,
            supported_languages: Optional[List[str]] = None
    ):
        """
        Initialize the code generation tool.

        Args:
            llm: Language model to use for code generation
            knowledge_base: Knowledge base containing API documentation
            supported_languages: List of supported programming languages
        """
        super().__init__()
        self.llm = llm
        self.knowledge_base = knowledge_base
        self.supported_languages = supported_languages or [
            "python", "javascript", "java", "csharp", "go",
            "ruby", "php", "typescript", "curl", "powershell"
        ]
        logger.info(f"Initialized {self.__class__.__name__} with {len(self.supported_languages)} supported languages")

    async def _arun(
            self,
            query: str,
            language: Optional[str] = None,
            operation_id: Optional[str] = None,
            path: Optional[str] = None,
            method: Optional[str] = None,
            include_auth: bool = True,
            include_error_handling: bool = True,
            **kwargs
    ) -> str:
        """
        Generate code for an API operation.

        Args:
            query: Description of the code to generate
            language: Programming language to use
            operation_id: API operation ID
            path: API path
            method: HTTP method
            include_auth: Whether to include authentication
            include_error_handling: Whether to include error handling

        Returns:
            Generated code as a string with Markdown formatting
        """
        logger.info(f"Generating code for query: {query[:100]}...")

        # Determine target language
        target_language = self._determine_language(query, language)
        logger.info(f"Target language: {target_language}")

        # Search for API documentation
        search_query = query
        if operation_id:
            search_query += f" operation_id:{operation_id}"
        if path:
            search_query += f" path:{path}"
        if method:
            search_query += f" method:{method}"

        # Apply filter if operation_id, path, or method is specified
        filter_criteria = {}
        if operation_id:
            filter_criteria["operation_id"] = operation_id
        if path:
            filter_criteria["path"] = path
        if method:
            filter_criteria["method"] = method

        # Get relevant docs
        docs = await self.knowledge_base.search(
            query=search_query,
            top_k=3,
            filter_criteria=filter_criteria if filter_criteria else None
        )

        # Combine doc content
        doc_content = "\n\n".join([doc.page_content for doc in docs])

        # Generate code
        messages = [
            SystemMessage(content=self._get_code_gen_prompt(target_language, include_auth, include_error_handling)),
            HumanMessage(content=f"""
Generate code in {target_language} for the following API request:

{query}

Here is the API documentation:

{doc_content}

Generate complete, well-commented code that follows best practices for {target_language}.
""")
        ]

        # Get LLM response
        response = await self.llm.ainvoke(messages)
        code_content = response.content

        # Format response with language-specific markdown code block
        formatted_code = self._format_code_response(code_content, target_language)

        return formatted_code

    def _determine_language(self, query: str, specified_language: Optional[str] = None) -> str:
        """
        Determine the target programming language.

        Args:
            query: User query
            specified_language: Explicitly specified language

        Returns:
            Target language name
        """
        # Use specified language if provided and supported
        if specified_language:
            for lang in self.supported_languages:
                if specified_language.lower() == lang.lower():
                    return lang

        # Try to infer from query
        query_lower = query.lower()
        for lang in self.supported_languages:
            if lang.lower() in query_lower:
                return lang

        # Default to Python if no language is specified or inferred
        return "python"

    def _format_code_response(self, code_content: str, language: str) -> str:
        """
        Format the code response with proper markdown.

        Args:
            code_content: Generated code content
            language: Programming language

        Returns:
            Formatted code with markdown
        """
        # Clean up the response to extract just the code block if needed
        if "```" in code_content:
            # Try to extract the code block
            parts = code_content.split("```")

            if len(parts) >= 3:
                # Extract the code from the first code block
                code_block = parts[1]

                # Remove language identifier if present
                if "\n" in code_block:
                    code_block = code_block.split("\n", 1)[1]

                code_content = code_block.strip()

        # Format with language-specific markdown block
        return f"```{language}\n{code_content}\n```"

    def _get_code_gen_prompt(self, language: str, include_auth: bool, include_error_handling: bool) -> str:
        """
        Get system prompt for code generation.

        Args:
            language: Target programming language
            include_auth: Whether to include authentication
            include_error_handling: Whether to include error handling

        Returns:
            System prompt for code generation
        """
        return f"""You are an expert {language} developer specializing in API integrations.
Your task is to generate high-quality, production-ready {language} code based on API documentation.

Guidelines for the code you generate:
1. Follow {language} best practices and idiomatic patterns.
2. Use appropriate libraries and packages commonly used in {language} for API requests.
3. Include detailed comments explaining key parts of the code.
4. Structure the code for readability and maintainability.
5. Include all necessary imports.
{"6. Include robust error handling and retry logic." if include_error_handling else ""}
{"7. Implement proper authentication." if include_auth else ""}
8. The code should be complete and runnable with minimal modifications.

Do not include explanations outside of code comments - only output the code itself.
"""