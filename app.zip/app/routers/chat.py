import logging
import re
from typing import Optional, Dict, Any, List, Tuple

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import JSONResponse

from app.dependencies import LLM, ChromaDB, ChatMemory
from app.models.request_models import ChatRequest
from app.models.response_models import ChatResponse, ErrorResponse
from app.agents.agent_graph import AgentGraph, QueryType, ConversationStage
from app.services.chat_memory import ChatMemoryService

router = APIRouter(
    prefix="/chat",
    tags=["chat"],
    responses={
        status.HTTP_404_NOT_FOUND: {"model": ErrorResponse},
        status.HTTP_500_INTERNAL_SERVER_ERROR: {"model": ErrorResponse}
    }
)

logger = logging.getLogger(__name__)

# Cache for agent graph instance
_agent_graph = None


def get_agent_graph(
        llm: LLM,
        chroma_service: ChromaDB
) -> AgentGraph:
    """Get or create agent graph instance"""
    global _agent_graph
    if _agent_graph is None:
        _agent_graph = AgentGraph(
            llm=llm,
            chroma_service=chroma_service
        )
    return _agent_graph


@router.post(
    "",
    response_model=ChatResponse,
    status_code=status.HTTP_200_OK,
    summary="Chat with the agent system",
    description="Send chat messages and get a response from the agent system"
)
async def chat(
        request: ChatRequest,
        llm: LLM,
        chroma_service: ChromaDB,
        chat_memory: ChatMemory,
        agent_graph: AgentGraph = Depends(get_agent_graph)
) -> ChatResponse:
    """
    Chat endpoint to interact with the agent system, supporting:
    - QA about APIs
    - Workflow generation
    - Code generation
    """
    try:
        # Extract the user's last message
        if not request.messages:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="No messages provided"
            )

        # Get last user message
        user_messages = [msg for msg in request.messages if msg.role == "user"]
        if not user_messages:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="No user messages found"
            )

        last_user_message = user_messages[-1].content

        # Handle session management
        session_id = request.session_id
        if session_id:
            # Check if session exists, create if not
            session = chat_memory.get_session(session_id)
            if not session:
                session_id = chat_memory.create_session({
                    "context": request.context
                })
        else:
            # Create new session
            session_id = chat_memory.create_session({
                "context": request.context
            })

        # Get existing chat history from memory
        memory_messages = chat_memory.get_messages(session_id)

        # Get existing session context from the session
        session = chat_memory.get_session(session_id) or {}
        session_context = session.get("context", {})

        # Add current user message to memory
        chat_memory.add_message(session_id, "user", last_user_message)

        # Prepare chat history for agent
        chat_history = []
        for msg in memory_messages:
            chat_history.append({
                "role": msg["role"],
                "content": msg["content"]
            })

        # Enhanced intent detection that returns query type, conversation stage, and context updates
        query_type, conversation_stage, context_updates = detect_intent_and_stage(
            last_user_message,
            chat_history,
            session_context
        )

        # Create context by merging request context, session context, and detected context updates
        context = request.context or {}
        context.update(session_context)
        context.update(context_updates)

        # Add conversation stage to context
        context["conversation_stage"] = conversation_stage

        # Prepare input for agent graph based on query type
        if query_type == QueryType.GENERATE_WORKFLOW:
            input_data = {
                "query_type": QueryType.GENERATE_WORKFLOW.value,
                "description": extract_workflow_description(last_user_message),
                "generate_code": context.get("generate_code", False),  # Important for workflow->code transition
                "code_language": context.get("code_language", "python"),
                "context": context,
                "chat_history": chat_history,
                "session_id": session_id
            }
        elif query_type == QueryType.GENERATE_CODE:
            input_data = {
                "query_type": QueryType.GENERATE_CODE.value,
                "language": context.get("code_language", extract_programming_language(last_user_message)),
                "description": extract_code_description(last_user_message),
                "context": context,
                "chat_history": chat_history,
                "session_id": session_id
            }
        else:  # Default to QA
            input_data = {
                "query_type": QueryType.ANSWER_QUESTION.value,
                "question": last_user_message,
                "chat_history": chat_history,
                "context": context,
                "session_id": session_id
            }

        # Invoke agent graph
        result = await agent_graph.invoke(input_data)

        # Check for errors
        if result.get("error"):
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=result["error"]
            )

        # Get response from agent graph
        answer = result.get("answer", {})
        response_text = answer.get("response", "I couldn't generate a response.")

        # Build response
        response = ChatResponse(
            response=response_text,
            session_id=session_id,
            sources=answer.get("sources", [])
        )

        # Store assistant response in memory
        chat_memory.add_message(session_id, "assistant", response_text)

        # Update session context with any new context updates from the agent
        if result.get("context_updates"):
            updated_context = session_context.copy()
            updated_context.update(result["context_updates"])
            # Get the current session again in case it changed
            current_session = chat_memory.get_session(session_id) or {}
            # Update the context in the session
            current_session["context"] = updated_context
            # Update the session
            chat_memory.update_session(session_id, current_session)

        return response

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in chat endpoint: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"An error occurred while processing your request: {str(e)}"
        )


def detect_intent_and_stage(message: str, chat_history: List[Dict[str, Any]],
                            session_context: Dict[str, Any]) -> Tuple[QueryType, str, Dict[str, Any]]:
    """
    Enhanced intent detection that identifies query type, conversation stage, and context updates

    Args:
        message: The user message
        chat_history: Previous messages in the conversation
        session_context: Current session context

    Returns:
        Tuple of (query_type, conversation_stage, context_updates)
    """
    context_updates = {}

    # Detect conversation stage
    conversation_stage = detect_conversation_stage(message, chat_history, session_context)

    # If we're in refining or explaining stage, context matters more
    if conversation_stage in [ConversationStage.REFINING.value, ConversationStage.EXPLAINING.value]:
        # Check what we're refining or explaining
        if session_context.get("recent_code"):
            context_updates["refinement_target"] = "code"
            # For refining code
            if conversation_stage == ConversationStage.REFINING.value:
                return QueryType.GENERATE_CODE, conversation_stage, context_updates
            # For explaining code
            elif conversation_stage == ConversationStage.EXPLAINING.value:
                context_updates["explanation_requested"] = True
                context_updates["code_to_explain"] = session_context.get("recent_code")
                return QueryType.ANSWER_QUESTION, conversation_stage, context_updates

        elif session_context.get("recent_workflow"):
            context_updates["refinement_target"] = "workflow"
            # For refining workflow
            if conversation_stage == ConversationStage.REFINING.value:
                return QueryType.GENERATE_WORKFLOW, conversation_stage, context_updates
            # For explaining workflow
            elif conversation_stage == ConversationStage.EXPLAINING.value:
                context_updates["explanation_requested"] = True
                context_updates["workflow_to_explain"] = session_context.get("recent_workflow")
                return QueryType.ANSWER_QUESTION, conversation_stage, context_updates

    # Check for combined workflow and code generation
    combined_patterns = [
        r"(create|generate|build|design)(?:\s+a)?\s+workflow.+(?:generate|write|implement|code|create).+code",
        r"(generate|write|implement|code|create).+code.+(?:create|generate|build|design)(?:\s+a)?\s+workflow",
        r"workflow.+code",
        r"code.+workflow"
    ]

    for pattern in combined_patterns:
        if re.search(pattern, message, re.IGNORECASE):
            # Set context for both workflow and subsequent code generation
            context_updates["generate_code"] = True

            # Detect language
            language = extract_programming_language(message)
            if language:
                context_updates["code_language"] = language

            logger.info(f"Detected combined workflow and code intent. Context updates: {context_updates}")
            return QueryType.GENERATE_WORKFLOW, conversation_stage, context_updates

    # Check for workflow generation request
    workflow_patterns = [
        r"create (?:a )?workflow",
        r"generate (?:a )?workflow",
        r"workflow for",
        r"design (?:a )?workflow",
        r"build (?:a )?workflow"
    ]

    for pattern in workflow_patterns:
        if re.search(pattern, message, re.IGNORECASE):
            return QueryType.GENERATE_WORKFLOW, conversation_stage, context_updates

    # Check for code generation request
    code_patterns = [
        r"generate (?:some )?code",
        r"write (?:some )?code",
        r"create (?:a )?(?:python|javascript|java|typescript|go|rust|ruby|php|c#|csharp)",
        r"implement (?:in|using) (?:python|javascript|java|typescript|go|rust|ruby|php|c#|csharp)",
        r"code (?:in|using) (?:python|javascript|java|typescript|go|rust|ruby|php|c#|csharp)"
    ]

    for pattern in code_patterns:
        if re.search(pattern, message, re.IGNORECASE):
            language = extract_programming_language(message)
            if language:
                context_updates["code_language"] = language
            return QueryType.GENERATE_CODE, conversation_stage, context_updates

    # Default to QA
    return QueryType.ANSWER_QUESTION, conversation_stage, context_updates


def detect_conversation_stage(message: str, chat_history: List[Dict[str, Any]],
                              session_context: Dict[str, Any]) -> str:
    """
    Detect the current stage of the conversation

    Args:
        message: Current user message
        chat_history: Previous conversation history
        session_context: Current session context

    Returns:
        The conversation stage
    """
    message_lower = message.lower()

    # Check for clarification requests
    if any(term in message_lower for term in ["what do you mean", "clarify", "don't understand",
                                              "confused", "what is", "what are"]):
        return ConversationStage.CLARIFYING.value

    # Check for explanation requests
    if any(term in message_lower for term in ["explain", "how does", "tell me about",
                                              "why does", "what does this"]):
        return ConversationStage.EXPLAINING.value

    # Check for refinement requests
    if any(term in message_lower for term in ["refine", "improve", "update", "change",
                                              "modify", "fix", "optimize"]):
        return ConversationStage.REFINING.value

    # Check for follow-up requests
    if (len(chat_history) >= 2 and
            any(term in message_lower for term in ["also", "additionally", "another", "more",
                                                   "next", "continue", "furthermore"])):
        return ConversationStage.FOLLOW_UP.value

    # Default to initial
    return ConversationStage.INITIAL.value


def extract_workflow_description(message: str) -> str:
    """Extract workflow description from message"""
    # Remove workflow-related commands
    workflow_patterns = [
        r"create (?:a )?workflow for ",
        r"generate (?:a )?workflow for ",
        r"create (?:a )?workflow that ",
        r"generate (?:a )?workflow that ",
        r"design (?:a )?workflow (?:for|that) ",
        r"build (?:a )?workflow (?:for|that) "
    ]

    description = message
    for pattern in workflow_patterns:
        description = re.sub(pattern, "", description, flags=re.IGNORECASE)

    # If there's mention of code after workflow, remove that part
    code_mentions = [
        r" and (?:generate|write|create|implement) (?:some )?code.*$",
        r" then (?:generate|write|create|implement) (?:some )?code.*$",
        r" with (?:some )?code.*$"
    ]

    for pattern in code_mentions:
        description = re.sub(pattern, "", description, flags=re.IGNORECASE)

    return description


def extract_programming_language(message: str) -> str:
    """Extract programming language from message"""
    language_patterns = {
        "python": r"python",
        "javascript": r"javascript|js",
        "typescript": r"typescript|ts",
        "java": r"java\b",
        "csharp": r"c#|csharp|c-sharp",
        "go": r"golang|go\b",
        "rust": r"rust",
        "ruby": r"ruby",
        "php": r"php"
    }

    for language, pattern in language_patterns.items():
        if re.search(pattern, message, re.IGNORECASE):
            return language

    # Default to python if no language specified
    return "python"


def extract_code_description(message: str) -> str:
    """Extract code description from message"""
    # Remove code generation commands
    code_patterns = [
        r"generate (?:some )?code (?:for|that) ",
        r"write (?:some )?code (?:for|that) ",
        r"implement (?:in|using) (?:python|javascript|java|typescript|go|rust|ruby|php|c#|csharp) ",
        r"code (?:in|using) (?:python|javascript|java|typescript|go|rust|ruby|php|c#|csharp) (?:for|that) "
    ]

    description = message
    for pattern in code_patterns:
        description = re.sub(pattern, "", description, flags=re.IGNORECASE)

    # If there's mention of workflow before code, capture just the code part
    workflow_mentions = [
        r"^.*?workflow.*?and (?=generate|write|implement|code)",
        r"^.*?workflow.*?then (?=generate|write|implement|code)"
    ]

    for pattern in workflow_mentions:
        match = re.search(pattern, description, re.IGNORECASE)
        if match:
            description = description[match.end():]

    return description


@router.delete(
    "/{session_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete chat session",
    description="Delete a chat session by ID"
)
async def delete_chat_session(
        session_id: str,
        chat_memory: ChatMemory
):
    """Delete chat session endpoint"""
    if not chat_memory.delete_session(session_id):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {session_id} not found"
        )

    return None