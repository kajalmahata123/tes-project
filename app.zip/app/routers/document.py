import os
import logging
import shutil
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File, Form

from app.dependencies import LLM, ChromaDB, get_chroma_service
from app.models.response_models import DocumentUploadResponse, ErrorResponse
from app.config import settings

from app.utils.helpers import generate_id
from app.agents.agent_graph import AgentGraph, QueryType

router = APIRouter(
    prefix="/documents",
    tags=["documents"],
    responses={
        status.HTTP_404_NOT_FOUND: {"model": ErrorResponse},
        status.HTTP_500_INTERNAL_SERVER_ERROR: {"model": ErrorResponse}
    }
)

logger = logging.getLogger(__name__)

# Agent graph cache
_agent_graph = None


def get_agent_graph(
        llm: LLM,
        chroma_service: ChromaDB
) -> AgentGraph:
    """Get or create agent graph instance"""
    global _agent_graph
    if _agent_graph is None:
        _agent_graph = AgentGraph(
            llm=llm,
            chroma_service=chroma_service
        )
    return _agent_graph


@router.post(
    "/upload",
    response_model=DocumentUploadResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Upload document",
    description="Upload PDF or OpenAPI specification document"
)
async def upload_document(
    file: UploadFile = File(...),
    document_type: str = Form(...),
    document_description: Optional[str] = Form(None),
    add_to_vector_db: bool = Form(True),
    chroma_service = Depends(get_chroma_service),
    agent_graph = Depends(get_agent_graph)
) -> DocumentUploadResponse:
    """
    Upload document endpoint
    """
    try:
        # Validate document type
        if document_type not in ["pdf", "openapi"]:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid document type. Supported types: pdf, openapi"
            )

        # Validate file extension
        file_ext = os.path.splitext(file.filename)[1].lower()
        if document_type == "pdf" and file_ext != ".pdf":
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid file extension for PDF document"
            )

        if document_type == "openapi" and file_ext not in [".json", ".yaml", ".yml"]:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid file extension for OpenAPI specification. Supported extensions: .json, .yaml, .yml"
            )

        # Create document directory if it doesn't exist
        os.makedirs(settings.DOCUMENT_DIR, exist_ok=True)

        # Generate unique filename
        document_id = generate_id()
        filename = f"{document_id}_{os.path.basename(file.filename)}"
        file_path = os.path.join(settings.DOCUMENT_DIR, filename)

        # Save uploaded file
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)

        # Process document using agent graph
        input_data = {
            "query_type": QueryType.PROCESS_DOCUMENT,
            "file_path": file_path,
            "document_type": document_type,
            "document_description": document_description,
            "add_to_vector_db": add_to_vector_db
        }

        result = await agent_graph.invoke(input_data)

        # Check for errors
        if result.get("error"):
            # Clean up file if processing failed
            try:
                os.remove(file_path)
            except Exception:
                pass

            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=result["error"]
            )

        # Get processed document from result
        document = result.get("documents", [{}])[0]

        # Prepare response
        response = DocumentUploadResponse(
            document_id=document.get("document_id", document_id),
            document_name=document.get("document_name", filename),
            document_type=document.get("document_type", document_type),
            upload_success=True,
            vector_db_added=document.get("vector_db_added", False),
            chunks_count=document.get("chunks_count"),
            metadata=document.get("metadata", {})
        )

        return response

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error uploading document: {str(e)}")
        # Clean up file if upload failed
        if 'file_path' in locals() and os.path.exists(file_path):
            try:
                os.remove(file_path)
            except Exception:
                pass

        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"An error occurred while processing your document: {str(e)}"
        )


@router.get(
    "/{document_id}",
    status_code=status.HTTP_200_OK,
    summary="Get document metadata",
    description="Get document metadata by ID"
)
async def get_document(
        document_id: str,
        chroma_service=Depends(get_chroma_service),
):
    """Get document metadata endpoint"""
    try:
        # Query vector DB for document metadata
        results = chroma_service.query(
            query_text="",
            n_results=1,
            where={"document_id": document_id}
        )

        if not results["ids"][0]:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Document {document_id} not found"
            )

        metadata = results["metadatas"][0][0] if results["metadatas"] else {}

        return {
            "document_id": document_id,
            "metadata": metadata
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error retrieving document: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"An error occurred while retrieving the document: {str(e)}"
        )


@router.delete(
    "/{document_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete document",
    description="Delete document by ID"
)
async def delete_document(
        document_id: str,
        chroma_service = Depends(get_chroma_service),
):
    """Delete document endpoint"""
    try:
        # Query vector DB for document data
        results = chroma_service.query(
            query_text="",
            n_results=1,
            where={"document_id": document_id}
        )

        if not results["ids"][0]:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Document {document_id} not found"
            )

        # Delete document records from vector DB
        doc_ids = results["ids"][0]
        for doc_id in doc_ids:
            chroma_service.delete_document(doc_id)

        # Try to find and delete the physical file
        file_pattern = f"{document_id}_*"
        for filename in os.listdir(settings.DOCUMENT_DIR):
            if filename.startswith(file_pattern):
                file_path = os.path.join(settings.DOCUMENT_DIR, filename)
                os.remove(file_path)
                break

        return None

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting document: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"An error occurred while deleting the document: {str(e)}"
        )